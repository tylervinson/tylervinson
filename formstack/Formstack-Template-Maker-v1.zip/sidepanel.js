let generatedTemplate = '';
let generatedJSON = '';

// Message display functions
function showMessage(elementId, message, type) {
  const messageEl = document.getElementById(elementId);
  messageEl.textContent = message;
  messageEl.className = `message ${type} visible`;
  
  if (type === 'success') {
    setTimeout(() => {
      messageEl.classList.remove('visible');
    }, 3000);
  }
}

function hideMessage(elementId) {
  const messageEl = document.getElementById(elementId);
  messageEl.classList.remove('visible');
}

function setButtonLoading(buttonId, isLoading, originalText) {
  const button = document.getElementById(buttonId);
  if (isLoading) {
    button.disabled = true;
    button.innerHTML = '<span class="loading-spinner"></span>' + originalText;
  } else {
    button.disabled = false;
    button.innerHTML = originalText;
  }
}

// Auto-detect snippets from the current page
async function autoDetectSnippets() {
  const scanButton = document.getElementById('scanButton');
  const originalText = 'Scan Current Page';
  
  try {
    setButtonLoading('scanButton', true, 'Scanning...');
    hideMessage('scanMessage');
    
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    chrome.tabs.sendMessage(tab.id, { action: 'findSnippets' }, (response) => {
      setButtonLoading('scanButton', false, originalText);
      
      if (chrome.runtime.lastError) {
        showMessage('scanMessage', '❌ Unable to scan page. Make sure you\'re on a valid webpage and refresh the extension.', 'error');
        return;
      }
      
      const snippetsContainer = document.getElementById('detectedSnippets');
      
      if (response.snippets && response.snippets.length > 0) {
        snippetsContainer.innerHTML = '';
        
        response.snippets.forEach((snippet, index) => {
          const snippetDiv = document.createElement('div');
          snippetDiv.className = 'snippet-item';
          snippetDiv.innerHTML = `
            <div class="snippet-info">
              <strong>Snippet ${index + 1}</strong>
              <span class="snippet-stats">${snippet.cellCount} fields, ${snippet.sectionCount} sections</span>
            </div>
            <div class="snippet-preview">${snippet.preview}</div>
          `;
          
          snippetDiv.onclick = () => loadSnippet(index);
          snippetsContainer.appendChild(snippetDiv);
        });
        
        snippetsContainer.classList.add('visible');
        showMessage('scanMessage', `✓ Found ${response.snippets.length} snippet(s)! Click one to generate templates.`, 'success');
      } else {
        snippetsContainer.innerHTML = '<div class="no-snippets">No form snippets detected on this page</div>';
        snippetsContainer.classList.add('visible');
        showMessage('scanMessage', 'ℹ️ No form snippets detected. Try pasting HTML manually below.', 'info');
      }
    });
  } catch (error) {
    setButtonLoading('scanButton', false, originalText);
    showMessage('scanMessage', '❌ Error scanning page: ' + error.message, 'error');
  }
}

// Load a specific snippet and generate template
async function loadSnippet(index) {
  try {
    showMessage('generateMessage', 'Loading snippet...', 'info');
    
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    chrome.tabs.sendMessage(tab.id, { action: 'getSnippet', index: index }, (response) => {
      if (response.snippet) {
        document.getElementById('htmlInput').value = response.snippet.html;
        generateTemplate();
        
        // Scroll to results
        setTimeout(() => {
          document.getElementById('stats').scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        showMessage('generateMessage', '❌ Failed to load snippet', 'error');
      }
    });
  } catch (error) {
    showMessage('generateMessage', '❌ Error loading snippet: ' + error.message, 'error');
  }
}

function generateTemplate() {
  const htmlInput = document.getElementById('htmlInput').value.trim();
  
  if (!htmlInput) {
    showMessage('generateMessage', '❌ Please paste HTML content first', 'error');
    return;
  }
  
  try {
    setButtonLoading('generateButton', true, 'Generating...');
    hideMessage('generateMessage');
    
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlInput, 'text/html');
    
    const fields = [];
    const sections = [];
    
    console.log('=== DEBUG START ===');
    console.log('Total HTML length:', htmlInput.length);
    
    // Find sections (h1 tags inside slate-webFormSection)
    const sectionElements = doc.querySelectorAll('.slate-webFormSection h1');
    sectionElements.forEach(header => {
      const text = header.textContent.trim();
      if (text && text !== 'Form Submission') {
        sections.push(text);
        console.log('Found section:', text);
      }
    });
    
    console.log(`Total sections found: ${sections.length}`);
    
    // Find all form cells
    const cells = doc.querySelectorAll('.slate-webFormCell');
    console.log(`Total cells found: ${cells.length}`);
    
    let currentSection = null;
    
    // Process each cell
    cells.forEach((cell, idx) => {
      console.log(`\n--- Processing cell ${idx + 1} ---`);
      
      // Check if there's a section before this cell
      const cellHTML = cell.outerHTML;
      let tempSection = null;
      sections.forEach(sectionName => {
        const beforeCell = htmlInput.substring(0, htmlInput.indexOf(cellHTML));
        if (beforeCell.includes(sectionName)) {
          tempSection = sectionName;
        }
      });
      if (tempSection) {
        currentSection = tempSection;
      }
      
      // Get all paragraphs in this cell
      const paragraphs = cell.querySelectorAll('p');
      
      let hasIfStatement = false;
      let label = null;
      let variable = null;
      
      paragraphs.forEach((p, pIdx) => {
        const text = p.textContent.trim();
        console.log(`  Para ${pIdx}: "${text}"`);
        
        // Check for {if statement
        if (text.includes('{if $')) {
          hasIfStatement = true;
          console.log('    -> Contains {if statement');
        }
        
        // Check for {/if closing
        if (text === '{/if}') {
          console.log('    -> Closing {/if}');
        }
        
        // Look for label (has <strong> tag and no $ or curly braces)
        const strong = p.querySelector('strong');
        if (strong && !text.includes('$') && !text.includes('{')) {
          label = strong.textContent.trim();
          console.log(`    -> Found label: "${label}"`);
        }
        
        // Look for variable - could be in multiple formats:
        // Format 1: {$Variable_Name} 
        if (text.includes('{$') && !text.includes('{if') && !text.includes('{/if}')) {
          const match = text.match(/\{\$([A-Za-z_][A-Za-z0-9_]*)/);
          if (match) {
            variable = match[1];
            console.log(`    -> Found variable (with {$): ${variable}`);
          }
        }
        // Format 2: Just bare variable name like "Variable_Name" (no $, no {})
        else if (!text.includes('{') && !text.includes('}') && !text.includes('$') && !strong) {
          // Check if this looks like a variable name (starts with letter/underscore, only contains alphanumeric + underscores)
          const variablePattern = /^([A-Za-z_][A-Za-z0-9_]*)$/;
          const match = text.match(variablePattern);
          if (match) {
            variable = match[1];
            console.log(`    -> Found variable (bare name): ${variable}`);
          }
        }
      });
      
      // If we found both label and variable, add the field
      if (label && variable) {
        console.log(`✓ Adding field: "${label}" -> ${variable} (section: ${currentSection || 'none'})`);
        fields.push({
          label: label,
          variable: variable,
          section: currentSection
        });
      } else {
        console.log(`✗ Skipping cell - label: ${label ? 'yes' : 'no'}, variable: ${variable ? 'yes' : 'no'}`);
      }
    });
    
    console.log('\n=== DEBUG END ===');
    console.log('Total fields extracted:', fields.length);
    
    if (fields.length === 0) {
      setButtonLoading('generateButton', false, 'Generate Template');
      showMessage('generateMessage', '❌ No label/variable pairs found. Check console for details.', 'error');
      return;
    }
    
    // Generate the template and JSON
    generatedTemplate = generateHTMLTemplate(fields, sections);
    generatedJSON = generateTestJSON(fields);
    
    // Update UI
    document.getElementById('fieldCount').textContent = fields.length;
    document.getElementById('sectionCount').textContent = sections.length;
    document.getElementById('stats').classList.add('visible');
    document.getElementById('templateOutput').textContent = generatedTemplate;
    document.getElementById('outputSection').classList.add('visible');
    document.getElementById('jsonOutput').textContent = generatedJSON;
    document.getElementById('jsonOutputSection').classList.add('visible');
    
    setButtonLoading('generateButton', false, 'Generate Template');
    showMessage('generateMessage', `✓ Successfully generated templates with ${fields.length} fields!`, 'success');
    
  } catch (error) {
    setButtonLoading('generateButton', false, 'Generate Template');
    showMessage('generateMessage', '❌ Error: ' + error.message, 'error');
    console.error('Exception:', error);
  }
}

function generateTestJSON(fields) {
  const testData = {};
  
  fields.forEach(field => {
    const variable = field.variable;
    const label = field.label;
    
    // Generate appropriate test data based on field label
    testData[variable] = generateTestValue(label, variable);
  });
  
  return JSON.stringify(testData, null, 2);
}

function generateTestValue(label, variable) {
  const lowerLabel = label.toLowerCase();
  const lowerVar = variable.toLowerCase();
  
  // NPI numbers
  if (lowerLabel.includes('npi') || lowerVar.includes('npi')) {
    return '1234567890';
  }
  
  // Tax ID
  if (lowerLabel.includes('tax id') || lowerVar.includes('tax')) {
    return '12-3456789';
  }
  
  // Phone numbers
  if (lowerLabel.includes('phone') || lowerVar.includes('phone')) {
    return '(602) 555-0100';
  }
  
  // Fax numbers
  if (lowerLabel.includes('fax') || lowerVar.includes('fax')) {
    return '(602) 555-0101';
  }
  
  // Email addresses
  if (lowerLabel.includes('email') || lowerVar.includes('email')) {
    return 'contact@example.com';
  }
  
  // Addresses
  if (lowerLabel.includes('address') || lowerVar.includes('address')) {
    return '123 Main Street, Suite 100, Phoenix, AZ 85001';
  }
  
  // Specialty
  if (lowerLabel.includes('specialty') || lowerVar.includes('specialty')) {
    return 'Internal Medicine';
  }
  
  // Provider/Group Name
  if (lowerLabel.includes('provider name') || lowerLabel.includes('group name') || 
      lowerVar.includes('provider') || lowerVar.includes('group')) {
    return 'ABC Medical Group';
  }
  
  // Dates
  if (lowerLabel.includes('date') || lowerVar.includes('date')) {
    return '01/15/2024';
  }
  
  // Yes/No fields
  if (lowerLabel.includes('are you') || lowerLabel.includes('do you')) {
    return 'Yes';
  }
  
  // Office hours
  if (lowerLabel.includes('office hours') || lowerLabel.includes('hours')) {
    return 'Monday-Friday: 8:00 AM - 5:00 PM';
  }
  
  // Time fields
  if (lowerLabel.includes('start time') || lowerVar.includes('start')) {
    return '8:00 AM';
  }
  if (lowerLabel.includes('end time') || lowerVar.includes('end')) {
    return '5:00 PM';
  }
  
  // Website URL
  if (lowerLabel.includes('website') || lowerLabel.includes('url') || lowerVar.includes('url')) {
    return 'www.example.com';
  }
  
  // Signature or File Upload - generate a small test image
  if (lowerLabel.includes('signature') || lowerLabel.includes('file upload') || 
      lowerVar.includes('signature') || lowerVar.includes('file')) {
    // Return a small 1x1 transparent PNG as base64 (this is a valid test image)
    // In real use, Formstack would replace this with the actual uploaded image
    return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  }
  
  // Title/Degree
  if (lowerLabel.includes('title') || lowerLabel.includes('degree')) {
    return 'MD';
  }
  
  // Privilege
  if (lowerLabel.includes('privilege') || lowerVar.includes('privilege')) {
    return 'Active';
  }
  
  // Default: use the label as a template
  return `Test value for ${label}`;
}

function generateHTMLTemplate(fields, sections) {
  let html = `<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: Arial, sans-serif;
  font-size: 10pt;
  margin: 0;
  padding: 20px;
}
table {
  width: 7.5in;
  border-collapse: collapse;
  margin-bottom: 20px;
}
.section-header {
  background-color: #f2f1f1;
  font-weight: bold;
  padding: 8px;
  text-align: left;
}
.field-row td {
  padding: 6px 8px;
  border-bottom: 1px solid #e0e0e0;
  vertical-align: top;
}
.field-number {
  width: 10%;
  font-weight: bold;
}
.field-label {
  width: 45%;
  font-weight: bold;
}
.field-value {
  width: 45%;
}
.document-uploaded {
  font-style: italic;
  color: #666;
}
</style>
</head>
<body>
<table>
`;

  let rowNumber = 1;
  let currentSection = null;
  
  fields.forEach(field => {
    // Add section header if section changes
    if (field.section && field.section !== currentSection) {
      currentSection = field.section;
      html += `  <tr>
    <td colspan="3" class="section-header">${field.section}</td>
  </tr>
`;
    }
    
    // Detect if this is a signature or file upload field
    const isSignatureOrFile = 
      field.label.toLowerCase().includes('signature') ||
      field.label.toLowerCase().includes('file upload') ||
      field.variable.toLowerCase().includes('signature') ||
      field.variable.toLowerCase().includes('file');
    
    // Use insert_image modifier for signature/file fields, with reasonable dimensions
    const fieldValue = isSignatureOrFile 
      ? `{$${field.variable}|insert_image:400:100}`
      : `{$${field.variable}}`;
    
    // Add field row
    html += `  {if $${field.variable} != ''}
  <tr class="field-row">
    <td class="field-number">${rowNumber}</td>
    <td class="field-label">${field.label}</td>
    <td class="field-value">${fieldValue}</td>
  </tr>
  {/if}
`;
    rowNumber++;
  });
  
  html += `</table>
</body>
</html>`;
  
  return html;
}

function copyTemplate() {
  navigator.clipboard.writeText(generatedTemplate).then(() => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✓ Copied!';
    btn.style.background = '#4CAF50';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  }).catch(err => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✗ Failed';
    btn.style.background = '#f44336';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  });
}

function copyJSON() {
  navigator.clipboard.writeText(generatedJSON).then(() => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✓ Copied!';
    btn.style.background = '#4CAF50';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  }).catch(err => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✗ Failed';
    btn.style.background = '#f44336';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  });
}

function generateJsonFromTemplate() {
  const templateInput = document.getElementById('templateInput').value.trim();
  
  if (!templateInput) {
    showMessage('jsonGenerateMessage', '❌ Please paste a template first', 'error');
    return;
  }
  
  try {
    setButtonLoading('generateJsonButton', true, 'Generating...');
    hideMessage('jsonGenerateMessage');
    
    // Extract all {$Variable} patterns from the template
    const variableRegex = /\{\$([A-Za-z_][A-Za-z0-9_]*)/g;
    const matches = [...templateInput.matchAll(variableRegex)];
    
    console.log('=== JSON FROM TEMPLATE ===');
    console.log('Variables found:', matches.length);
    
    if (matches.length === 0) {
      setButtonLoading('generateJsonButton', false, 'Generate Test JSON');
      showMessage('jsonGenerateMessage', '❌ No variables found in template. Make sure it contains {$Variable} tags.', 'error');
      return;
    }
    
    // Deduplicate variables
    const uniqueVariables = [...new Set(matches.map(m => m[1]))];
    console.log('Unique variables:', uniqueVariables.length);
    
    // Generate test data for each variable
    const testData = {};
    uniqueVariables.forEach(variable => {
      // Try to infer the field type from the variable name
      testData[variable] = generateTestValue(variable, variable);
    });
    
    generatedJSON = JSON.stringify(testData, null, 2);
    
    // Update UI
    document.getElementById('fieldCount').textContent = uniqueVariables.length;
    document.getElementById('sectionCount').textContent = '-';
    document.getElementById('stats').classList.add('visible');
    document.getElementById('jsonOutput').textContent = generatedJSON;
    document.getElementById('jsonOutputSection').classList.add('visible');
    
    // Hide the template output section since we're only generating JSON
    document.getElementById('outputSection').classList.remove('visible');
    
    setButtonLoading('generateJsonButton', false, 'Generate Test JSON');
    showMessage('jsonGenerateMessage', `✓ Successfully generated test data for ${uniqueVariables.length} variables!`, 'success');
    
  } catch (error) {
    setButtonLoading('generateJsonButton', false, 'Generate Test JSON');
    showMessage('jsonGenerateMessage', '❌ Error: ' + error.message, 'error');
    console.error('Exception:', error);
  }
}

function clearAll() {
  document.getElementById('htmlInput').value = '';
  document.getElementById('templateOutput').textContent = '';
  document.getElementById('jsonOutput').textContent = '';
  document.getElementById('stats').classList.remove('visible');
  document.getElementById('outputSection').classList.remove('visible');
  document.getElementById('jsonOutputSection').classList.remove('visible');
  document.getElementById('detectedSnippets').classList.remove('visible');
  document.getElementById('detectedSnippets').innerHTML = '';
  hideMessage('scanMessage');
  hideMessage('generateMessage');
  generatedTemplate = '';
  generatedJSON = '';
}

// Initialize event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('scanButton').addEventListener('click', autoDetectSnippets);
  document.getElementById('generateButton').addEventListener('click', generateTemplate);
  document.getElementById('generateJsonButton').addEventListener('click', generateJsonFromTemplate);
  
  document.querySelectorAll('.btn-secondary').forEach(btn => {
    if (btn.textContent === 'Clear') {
      btn.addEventListener('click', clearAll);
    }
  });
  
  // Clear button for template input
  document.getElementById('clearTemplateButton').addEventListener('click', function() {
    document.getElementById('templateInput').value = '';
    hideMessage('jsonGenerateMessage');
  });
  
  // Add event listeners for copy buttons
  const copyButtons = document.querySelectorAll('.btn-success');
  copyButtons.forEach(btn => {
    if (btn.textContent.includes('Copy Template')) {
      btn.addEventListener('click', copyTemplate);
    } else if (btn.textContent.includes('Copy JSON')) {
      btn.addEventListener('click', copyJSON);
    }
  });
});
