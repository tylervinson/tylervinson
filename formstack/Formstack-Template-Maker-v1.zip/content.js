// Content script that runs on web pages to find and extract HTML snippets

// Function to find the container with the most slate-webFormCell children
function findFormSnippets() {
  const snippets = [];
  
  // Strategy 1: Find any element that contains multiple slate-webFormCell children
  const allElements = document.querySelectorAll('*');
  const candidateContainers = [];
  
  for (const element of allElements) {
    const cells = element.querySelectorAll('.slate-webFormCell');
    
    // Only consider direct or near-direct parents of cells
    if (cells.length > 0) {
      // Check if this element directly contains cells (not nested deep)
      let directCells = 0;
      for (const cell of cells) {
        // Count cells that are close descendants (within 3 levels)
        let parent = cell.parentElement;
        let depth = 0;
        while (parent && depth < 5) {
          if (parent === element) {
            directCells++;
            break;
          }
          parent = parent.parentElement;
          depth++;
        }
      }
      
      if (directCells > 0) {
        candidateContainers.push({
          element: element,
          cellCount: directCells,
          depth: element.querySelectorAll('*').length // Use depth as tiebreaker
        });
      }
    }
  }
  
  // Sort by cell count (descending) and depth (ascending) to find the best container
  candidateContainers.sort((a, b) => {
    if (b.cellCount !== a.cellCount) {
      return b.cellCount - a.cellCount; // More cells is better
    }
    return a.depth - b.depth; // Shallower is better
  });
  
  // Take the best container
  if (candidateContainers.length > 0) {
    const bestContainer = candidateContainers[0].element;
    const cells = bestContainer.querySelectorAll('.slate-webFormCell');
    const sections = bestContainer.querySelectorAll('.slate-webFormSection');
    
    snippets.push({
      index: 0,
      html: bestContainer.outerHTML,
      cellCount: cells.length,
      sectionCount: sections.length,
      preview: bestContainer.textContent.substring(0, 100).trim(),
      source: 'flexible-search'
    });
  }
  
  return snippets;
}

// Listen for messages from the sidebar
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'findSnippets') {
    const snippets = findFormSnippets();
    sendResponse({ snippets: snippets });
  } else if (request.action === 'getSnippet') {
    const snippets = findFormSnippets();
    const snippet = snippets[request.index];
    sendResponse({ snippet: snippet });
  }
  return true;
});
