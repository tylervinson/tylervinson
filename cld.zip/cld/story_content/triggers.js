function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Y5smiGCsna":
        Script1();
        break;
      case "6GOrEshmuNT":
        Script2();
        break;
      case "6LYAtpK66RO":
        Script3();
        break;
      case "6jg7vQOoKqT":
        Script4();
        break;
      case "6VPCT4FCJqv":
        Script5();
        break;
      case "5gaPXXF0J8d":
        Script6();
        break;
      case "6SR753rqxoc":
        Script7();
        break;
      case "6jbIvNLWMnE":
        Script8();
        break;
      case "6hHGAVUtGrH":
        Script9();
        break;
      case "6jQaR2xEVeg":
        Script10();
        break;
      case "6pajn2RrMDV":
        Script11();
        break;
      case "65zkGJEgXIp":
        Script12();
        break;
      case "6l1mn0y4ZAS":
        Script13();
        break;
      case "6CMdqBlw14Q":
        Script14();
        break;
      case "690Sw2iA7kU":
        Script15();
        break;
      case "6XWndGP8FFX":
        Script16();
        break;
      case "6TzgE3gZud4":
        Script17();
        break;
      case "6LWLOzxxB6o":
        Script18();
        break;
      case "6So0pYOnroQ":
        Script19();
        break;
      case "6Rok3qlyn3w":
        Script20();
        break;
      case "5yUa6l3FW9o":
        Script21();
        break;
      case "6hWRNu6j1aY":
        Script22();
        break;
      case "5l7IM2ZCopg":
        Script23();
        break;
      case "5VYir0b3tKq":
        Script24();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  const target = object('61lZsZEMa4H');
const duration = 750;
const easing = 'ease-out';
const id = '5xK5qUXaKV8';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('6gs5YO14rkK');
const duration = 750;
const easing = 'ease-out';
const id = '6WnI3YpNK12';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('6MquxLkcV7v');
const duration = 750;
const easing = 'ease-out';
const id = '6ct9LnzP66O';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('6XgYL4NR6Qr');
const duration = 750;
const easing = 'ease-out';
const id = '5Wyv4vDBRbM';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6YPsDYsNUlo');
const duration = 750;
const easing = 'ease-out';
const id = '6p8JPBUTNKi';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('6069ZupBkcV');
const duration = 750;
const easing = 'ease-out';
const id = '5u1mPtYxosV';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('5eJfA5MwmaJ');
const duration = 750;
const easing = 'ease-out';
const id = '60vkC3dqQQn';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6IynkYxiEAp');
const duration = 750;
const easing = 'ease-out';
const id = '5xSB4SZ9UY3';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6ZqPTL9m4cW');
const duration = 750;
const easing = 'ease-out';
const id = '69kKdvr3yLZ';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('6H8M6txBMjz');
const duration = 750;
const easing = 'ease-out';
const id = '6hxJJvWDWAy';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5vpAGH15rnr');
const duration = 750;
const easing = 'ease-out';
const id = '5oLSlZUdLOF';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('6H2o3bvR99H');
const duration = 750;
const easing = 'ease-out';
const id = '5nBrT78bz2c';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('5r1cO12cDTd');
const duration = 750;
const easing = 'ease-out';
const id = '6p2Mfy5DKqL';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('5t7pEE4V7wK');
const duration = 750;
const easing = 'ease-out';
const id = '6rQJ22RAB43';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  const target = object('63KAeJEsXbb');
const duration = 750;
const easing = 'ease-out';
const id = '5iUr6P7Ldo7';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  const target = object('5kPlkhag8Vg');
const duration = 750;
const easing = 'ease-out';
const id = '62bMihZF9UU';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  const target = object('5a3ZmGHe3dB');
const duration = 750;
const easing = 'ease-out';
const id = '62jLhZlkUNf';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script18 = function()
{
  const target = object('5VFFoflVHfB');
const duration = 750;
const easing = 'ease-out';
const id = '6n55vn8oh8g';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script19 = function()
{
  const target = object('5mLOZyejjUl');
const duration = 750;
const easing = 'ease-out';
const id = '5lUoQATq6yX';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script20 = function()
{
  const target = object('5udtqb0q0yM');
const duration = 750;
const easing = 'ease-out';
const id = '6gIVDmGIQeU';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script21 = function()
{
  const target = object('6IoMi0GryXp');
const duration = 750;
const easing = 'ease-out';
const id = '5lo12huuXze';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('6ocj8WQLr4q');
const duration = 750;
const easing = 'ease-out';
const id = '6K49y1mVlYF';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  const target = object('630wfEqbl9e');
const duration = 750;
const easing = 'ease-out';
const id = '67l7NF33p51';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script24 = function()
{
  const target = object('6EYXEHfctV3');
const duration = 750;
const easing = 'ease-out';
const id = '69SCR5P6h3l';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

};
