/* Runs inside the dashboard iframe. Generated from dashboard.js — do not edit by hand.
   Reads its payload from the parent (same extension origin), so no inline script is needed. */
(function () {
  try { window.__DASH_DATA__ = parent.__DASH_PAYLOAD__; }
  catch (e) { console.error('[dashview] no payload from parent', e); }

function dashboardCss(){
  return [
    ':root{--bg:#1a1a1a;--card:#242424;--card-alt:#1e1e1e;--border:#2e2e2e;--text:#f0f0f0;--muted:#888;--muted2:#666;--accent:#FFBE5F;--crit:#d98a84;--warn:#d8a24a;--ok:#7dbf82}',
    '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;font-weight:300;line-height:1.6}',
    '.wrap{max-width:1440px;margin:0 auto;padding:2.5rem 1.5rem}',
    '.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:.13em;font-size:.7rem;font-weight:500;margin:0}',
    'h1{font-weight:300;font-size:2rem;margin:.2rem 0}.sub{color:var(--muted);font-size:.88rem;margin:.3rem 0 0}',
    '.tabs{display:flex;gap:.4rem;margin:2rem 0 1.5rem;border-bottom:1px solid var(--border)}',
    '.tab{background:none;border:none;color:var(--muted);padding:.7rem 1.1rem;cursor:pointer;font-size:.95rem;border-bottom:2px solid transparent;font-family:inherit}',
    '.tab.active{color:var(--accent);border-bottom-color:var(--accent)}',
    '.card{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:1.5rem;margin-bottom:1.5rem}',
    '.label{color:var(--accent);text-transform:uppercase;letter-spacing:.1em;font-size:.7rem;font-weight:500;margin:0 0 1rem}',
    '.grid{display:grid;gap:1rem}.stats{grid-template-columns:repeat(auto-fit,minmax(110px,1fr))}',
    '.stat{background:var(--card-alt);border:1px solid var(--border);border-radius:8px;padding:.9rem 1rem;cursor:pointer;transition:border-color .2s}',
    '.stat:hover{border-color:var(--accent)}.stat .n{font-size:1.9rem;font-weight:300;line-height:1}.stat .l{color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;margin-top:.3rem}',
    '.crit{color:var(--crit)}.warn{color:var(--warn)}.ok{color:var(--ok)}.accent{color:var(--accent)}.muted{color:var(--muted)}',
    'table{width:100%;border-collapse:collapse;font-size:.86rem}th,td{text-align:left;padding:.5rem .6rem;border-bottom:1px solid var(--border)}',
    'th{color:var(--muted);font-weight:500;text-transform:uppercase;font-size:.68rem;letter-spacing:.06em}td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}',
    '.filters{display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:1.2rem;align-items:center}',
    'select,input{background:var(--card-alt);border:1px solid #333;color:var(--text);border-radius:6px;padding:.5rem .7rem;font-size:.85rem;font-family:inherit}',
    '.finding{border:1px solid var(--border);border-left:3px solid var(--muted2);border-radius:6px;margin:.5rem 0;background:var(--card-alt)}',
    '.finding.s-critical{border-left-color:var(--crit)}.finding.s-warning{border-left-color:var(--warn)}.finding.s-info{border-left-color:var(--muted2)}',
    '.finding .body{padding:.6rem .85rem}.cat{font-size:.68rem;text-transform:uppercase;letter-spacing:.06em;color:var(--accent)}',
    '.det{margin:.25rem 0 0;font-size:.9rem}.sugg{color:var(--ok);font-size:.82rem;margin-top:.35rem}.path-mini{color:var(--muted2);font-size:.72rem;margin-top:.35rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    '.finding details{margin:.1rem .85rem .7rem}.finding summary{cursor:pointer;color:var(--accent);font-size:.72rem;list-style:none}.finding summary::-webkit-details-marker{display:none}',
    'pre.src{font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.72rem;white-space:pre-wrap;word-break:break-word;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:.6rem;margin:.4rem 0 0}',
    '.trend{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;text-align:center}.delta{font-size:1.9rem;font-weight:300}',
    '.empty{color:var(--muted);font-size:.88rem}',
    '.ftable-wrap{overflow-x:auto;margin-top:.2rem}',
    'table.ft{width:100%;border-collapse:collapse;font-size:.83rem}',
    'table.ft th{text-align:left;color:var(--muted2);font-weight:500;text-transform:uppercase;font-size:.62rem;letter-spacing:.06em;padding:.35rem .55rem;border-bottom:1px solid var(--border);white-space:nowrap}',
    'table.ft td{padding:.5rem .55rem;border-bottom:1px solid var(--border);vertical-align:top}table.ft tbody tr.frow:last-of-type td{border-bottom:none}',
    'tr.frow{cursor:pointer;transition:background .12s}tr.frow:hover{background:#2a2a2a}tr.frow.open{background:#2a2a2a}',
    'table.ft th.sortable{cursor:pointer;user-select:none;white-space:nowrap}table.ft th.sortable:hover{color:var(--text)}',
    'table.ft th.sortable .sort-ind{margin-left:.3rem;font-size:.75em;opacity:.3}table.ft th.sortable .sort-ind::after{content:"\\2195"}',
    'table.ft th.sortable[data-dir] .sort-ind{opacity:1;color:var(--accent)}',
    'table.ft th.sortable[data-dir="asc"] .sort-ind::after{content:"\\2191"}table.ft th.sortable[data-dir="desc"] .sort-ind::after{content:"\\2193"}',
    '.sevb{display:inline-flex;align-items:center;gap:.4rem;font-size:.64rem;text-transform:uppercase;letter-spacing:.04em;font-weight:500;white-space:nowrap}.sevb .dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto}',
    '.sevb.c{color:var(--crit)}.sevb.c .dot{background:var(--crit)}.sevb.w{color:var(--warn)}.sevb.w .dot{background:var(--warn)}.sevb.i{color:var(--muted)}.sevb.i .dot{background:var(--muted2)}',
    '.ft .fc-pg{color:var(--text)}.ft .fc-path{display:block;color:var(--muted2);font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.68rem;margin-top:.1rem}',
    '.ft .fc-lang,.ft .fc-cat{color:var(--muted);white-space:nowrap}.ft .fc-issue{color:var(--text);display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:62ch}.drill-body .fc-issue{max-width:30ch}',
    '.ft .fc-exp{width:1.4rem;text-align:right;color:var(--muted2)}.fchev{display:inline-block;font-size:1rem;transition:transform .2s}tr.frow.open .fchev{transform:rotate(90deg)}',
    'tr.fdetail{display:none}tr.fdetail.show{display:table-row}tr.fdetail>td{padding:.1rem .55rem .7rem;background:#1b1b1b;border-bottom:1px solid var(--border)}',
    '.fd-inner{padding:.6rem .8rem;border-left:2px solid var(--accent);background:var(--card-alt);border-radius:0 6px 6px 0}',
    '.fd-sugg{color:var(--ok);font-size:.82rem;margin:0 0 .4rem}.fd-meta{color:var(--muted);font-size:.73rem;margin:0 0 .4rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    'details.drill{border-bottom:1px solid var(--border)}details.drill>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:.7rem;padding:.55rem 0;font-size:.88rem}details.drill>summary::-webkit-details-marker{display:none}',
    '.finding details.evidence{margin:.1rem .85rem .7rem}.finding details.evidence>summary{cursor:pointer;color:var(--accent);font-size:.72rem;list-style:none}.finding details.evidence>summary::-webkit-details-marker{display:none}',
    'ul.evlist{list-style:none;margin:.4rem 0 0;padding:0;border:1px solid var(--border);border-radius:6px;background:var(--bg);max-height:320px;overflow:auto}',
    'ul.evlist li{font-size:.78rem;padding:.35rem .6rem;border-bottom:1px solid var(--border);word-break:break-word;font-family:"SF Mono",Monaco,Consolas,monospace}ul.evlist li:last-child{border-bottom:none}',
    'ul.evlist li.evhead{font-family:Inter,sans-serif;color:var(--accent);text-transform:uppercase;letter-spacing:.05em;font-size:.66rem;background:var(--card-alt)}',
    'details.drill>summary:hover .drill-label{color:var(--accent)}.drill-label{min-width:170px}.drill-label .chev{color:var(--muted2);margin-right:.5rem;font-size:1rem;display:inline-block;width:1rem;transition:transform .2s}details.drill[open]>summary .chev{transform:rotate(90deg)}',
    '.bartrack{flex:1;height:9px;background:#33322f;border-radius:5px;overflow:hidden;max-width:none}.barfill{display:block;height:100%;background:linear-gradient(90deg,#ffce85,#f0a63a);border-radius:5px;min-width:3px}.drill-count{min-width:34px;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);font-weight:400}',
    '.drill-body{padding:.3rem 0 .9rem}',
    'details.pagecard{border:1px solid var(--border);border-radius:8px;margin-bottom:.7rem;background:var(--card-alt)}details.pagecard>summary{list-style:none;cursor:pointer;padding:.8rem 1rem;display:flex;align-items:center;gap:.8rem;flex-wrap:wrap}details.pagecard>summary::-webkit-details-marker{display:none}',
    '.pc-name{font-weight:400;font-size:1rem;flex:1;min-width:160px}.pc-name .chev{color:var(--muted2);margin-right:.5rem;font-size:1rem;display:inline-block;transition:transform .2s}details.pagecard[open]>summary .pc-name .chev{transform:rotate(90deg)}',
    '.pc-path{color:var(--muted2);font-size:.72rem;font-family:"SF Mono",Monaco,Consolas,monospace;flex-basis:100%;margin-left:1.1rem}',
    '.pill{font-size:.7rem;padding:.12rem .5rem;border-radius:20px;border:1px solid var(--border)}.pill.c{color:var(--crit);border-color:var(--crit)}.pill.w{color:var(--warn);border-color:var(--warn)}.pill.i{color:var(--muted);border-color:var(--muted2)}.pill.date{color:var(--muted)}',
    '.pc-body{padding:0 1rem .8rem}',
    '.picker{border:1px solid var(--border);border-radius:8px;background:var(--card-alt);margin-bottom:1rem}',
    '.picker-head{cursor:pointer;padding:.85rem 1rem;display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;user-select:none}',
    '.picker-head .chev{color:var(--accent);font-size:1rem;display:inline-block;transition:transform .2s}.picker.open .picker-head .chev{transform:rotate(90deg)}',
    '.picker-head .pk-name{font-weight:400;font-size:1rem}.picker-head .pk-hint{color:var(--muted);font-size:.78rem;white-space:nowrap}',
    '.picker-list{display:none;border-top:1px solid var(--border);max-height:340px;overflow:auto}.picker.open .picker-list{display:block}',
    '.picker-opt{display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;padding:.6rem 1rem;cursor:pointer;border-bottom:1px solid var(--border);transition:background .12s}.picker-opt:last-child{border-bottom:none}.picker-opt:hover{background:#2a2a2a}.picker-opt.sel{background:#2a2a2a}',
    '.picker-opt .po-name{flex:1;min-width:150px}.picker-opt .pc-path{flex-basis:100%;margin-left:0}',
    'details.stale{border:1px solid var(--border);border-radius:8px;margin-bottom:.5rem;background:var(--card-alt)}details.stale.is-stale{border-left:3px solid var(--crit)}details.stale>summary{list-style:none;cursor:pointer;padding:.65rem 1rem;display:grid;grid-template-columns:1fr auto auto auto;gap:1rem;align-items:center;font-size:.85rem}details.stale>summary::-webkit-details-marker{display:none}',
    '.st-path{font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.78rem;overflow:hidden;text-overflow:ellipsis}.st-age{color:var(--muted);font-variant-numeric:tabular-nums;min-width:48px;text-align:right}.st-date{color:var(--muted);min-width:84px;text-align:right}',
    '.st-body{padding:.2rem 1rem .8rem;font-size:.82rem;color:var(--muted);display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:.5rem 1.5rem}.st-body .k{color:var(--muted2);text-transform:uppercase;font-size:.66rem;letter-spacing:.05em}.st-body .v{color:var(--text)}',
    '.headrow{display:grid;grid-template-columns:1fr auto auto auto;gap:1rem;padding:0 1rem .4rem;font-size:.66rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted2)}',
    '.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;margin-bottom:1.25rem}',
    '.kpi{appearance:none;text-align:left;background:var(--card);border:1px solid var(--border);border-left:3px solid var(--muted2);border-radius:10px;padding:1.1rem 1.2rem;cursor:pointer;font-family:inherit;display:flex;flex-direction:column;gap:.4rem;transition:border-color .2s,transform .2s,background .2s}',
    '.kpi:hover{transform:translateY(-2px);background:#2a2a2a}.kpi .kpi-n{font-size:2.3rem;font-weight:300;line-height:1;color:var(--text)}.kpi .kpi-l{color:var(--muted);font-size:.7rem;text-transform:uppercase;letter-spacing:.08em}',
    '.kpi.crit{border-left-color:var(--crit)}.kpi.crit:hover{border-color:var(--crit)}.kpi.crit .kpi-n{color:var(--crit)}',
    '.kpi.warn{border-left-color:var(--warn)}.kpi.warn:hover{border-color:var(--warn)}.kpi.warn .kpi-n{color:var(--warn)}',
    '.kpi.accent{border-left-color:var(--accent)}.kpi.accent:hover{border-color:var(--accent)}',
    '.dash-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;margin-bottom:1.25rem;align-items:start}.dash-grid .card{margin:0}',
    '.dash-split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;margin-bottom:1.25rem;align-items:start}.dash-split>.dash-col{display:flex;flex-direction:column;gap:1.25rem;min-width:0}.dash-split .card{margin:0}',
    '.dash-grid-eq{align-items:stretch}.dash-grid-eq>.card{display:flex;flex-direction:column}',
    '.s404-list{display:flex;flex-direction:column;gap:.5rem;max-height:320px;overflow:auto}',
    '.s404-row{display:flex;align-items:center;gap:.5rem;font-size:.82rem;border-bottom:1px solid var(--border);padding-bottom:.45rem}',
    '.s404-url{color:var(--text);text-decoration:none;word-break:break-all;flex:1 1 auto;min-width:0}.s404-url:hover{color:var(--accent);text-decoration:underline}',
    '.s404-seen{color:var(--muted2);font-size:.72rem;flex:0 0 auto;white-space:nowrap}',
    '.s404-new{flex:0 0 auto;background:var(--crit);color:#1a1a1a;font-weight:600;font-size:.62rem;letter-spacing:.04em;padding:.1rem .35rem;border-radius:4px}',
    '.card-404.has-dead{border-left:3px solid var(--crit)}',
    '.s404-group + .s404-group{margin-top:1.1rem;padding-top:1rem;border-top:1px solid var(--border)}',
    '.s404-grouphead{font-size:.75rem;font-weight:600;color:var(--text);margin:0 0 .5rem;letter-spacing:.01em}',
    '.card-404 .label{display:flex;align-items:center;gap:.5rem}',
    '.stale-summary{cursor:pointer;margin:0;list-style:none;user-select:none;display:flex;align-items:center;gap:.5rem}',
    '.stale-summary::-webkit-details-marker{display:none}',
    '.stale-summary .chev{margin-left:auto;color:var(--muted);font-size:1rem;transition:transform .2s ease}',
    '.stale-collapse[open] > .stale-summary{margin-bottom:1rem}',
    '.stale-collapse[open] .stale-summary .chev{transform:rotate(90deg)}',
    '.acc-summary{cursor:pointer;margin:0;list-style:none;user-select:none;display:flex;align-items:center;gap:.5rem}',
    '.acc-summary::-webkit-details-marker{display:none}',
    '.acc-summary .chev{margin-left:auto;color:var(--muted);font-size:1rem;transition:transform .2s ease}',
    '.acc-collapse[open] > .acc-summary{margin-bottom:1rem}',
    '.acc-collapse[open] .acc-summary .chev{transform:rotate(90deg)}',
    '.count-pill{display:inline-block;background:var(--crit);color:#1a1a1a;font-weight:700;font-size:.7rem;line-height:1;padding:.22rem .5rem;border-radius:10px}',
    '.card-404 .s404-list{max-height:300px}',
    '@media(min-width:760px){.card-404 .s404-list{display:grid;grid-template-columns:1fr 1fr;gap:.15rem 1.8rem}}',
    '.label{display:flex;align-items:center;gap:.5rem}.label::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--accent);display:inline-block;flex:0 0 auto}',
    '.sevmix{display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap}.donut{width:148px;height:148px;flex:0 0 auto}.donut-n{fill:var(--text);font-size:30px;font-weight:300}.donut-l{fill:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}',
    '.legend{display:flex;flex-direction:column;gap:.65rem;flex:1;min-width:130px}.legend-row{display:flex;align-items:center;gap:.6rem;font-size:.88rem}.swatch{width:11px;height:11px;border-radius:3px;flex:0 0 auto}.legend-row .ln{margin-left:auto;font-variant-numeric:tabular-nums;color:var(--text)}.legend-row .lt{color:var(--muted)}',
    '.covrow{display:flex;align-items:baseline;gap:.6rem;margin-bottom:.7rem}.covrow .big{font-size:1.8rem;font-weight:300;color:var(--accent);line-height:1}.barrow{display:flex;gap:.6rem;margin:.3rem 0;font-size:.85rem}',
    '@media(max-width:820px){.kpis{grid-template-columns:repeat(2,1fr)}.dash-grid{grid-template-columns:1fr}.dash-split{grid-template-columns:1fr}}',
    '.queue-stale{border-left:3px solid var(--warn);margin-bottom:1.25rem}.queue-stale .label{color:var(--warn)}.queue-stale .label::before{background:var(--warn)}',
    '.queue-ok{margin-bottom:1.25rem}',
    'tr.frow.resolved td{opacity:.45}tr.frow.resolved .fc-issue{text-decoration:line-through}.ftag{display:inline-block;font-size:.85rem;margin-right:.35rem;vertical-align:middle}.ftag.done{color:var(--ok)}.ftag.ignored{color:var(--muted2)}',
    '.tri-row{display:flex;gap:.5rem;align-items:center;margin-top:.7rem;flex-wrap:wrap}.tri-meta{color:var(--muted);font-size:.76rem;margin-right:.3rem}',
    '.tri-btn{appearance:none;border:1px solid var(--border);background:var(--card);color:var(--muted);font-family:inherit;font-size:.74rem;padding:.32rem .7rem;border-radius:6px;cursor:pointer;transition:color .15s,border-color .15s}.tri-btn:hover{color:var(--text);border-color:var(--muted2)}.tri-btn.done:hover{color:var(--ok);border-color:var(--ok)}.tri-btn.ignore:hover{color:var(--warn);border-color:var(--warn)}',
    '.f-toggle{display:inline-flex;align-items:center;gap:.35rem;color:var(--muted);font-size:.8rem;cursor:pointer;white-space:nowrap}.f-toggle input{accent-color:var(--accent)}',
    '.tprog{height:8px;background:#33322f;border-radius:5px;overflow:hidden;margin-top:.2rem}.tprog-bar{display:block;height:100%;background:linear-gradient(90deg,var(--ok),#5fae6a)}',
    '.dash-headrow{display:flex;align-items:baseline;justify-content:space-between;gap:1rem;flex-wrap:wrap}',
    '.pdf-link{display:inline-flex;align-items:center;gap:.4rem;color:var(--muted);font-size:.82rem;cursor:pointer;text-decoration:none;white-space:nowrap;transition:color .15s}.pdf-link:hover{color:var(--accent)}.pdf-link svg{flex:0 0 auto}',
    '.pub-actions{display:flex;gap:.6rem}',
    '.pub-btn{appearance:none;flex:1 1 0;min-width:0;border:1px solid var(--border);background:var(--card-alt);color:var(--text);font-family:inherit;font-size:.86rem;padding:.65rem 1rem;border-radius:8px;cursor:pointer;transition:border-color .15s,color .15s,background .15s,filter .15s}.pub-btn:hover{border-color:var(--muted2)}',
    '.pub-btn.pub-primary{background:var(--accent);color:#1a1a1a;border-color:var(--accent);font-weight:500}.pub-btn.pub-primary:hover{filter:brightness(1.05)}',
    '.pub-btn.pub-secondary{background:transparent;border-color:var(--accent);color:var(--accent);font-weight:500}.pub-btn.pub-secondary:hover{background:rgba(255,190,95,.08);border-color:var(--accent)}',
    '.pub-btn:disabled{opacity:.4;cursor:not-allowed;background:transparent;border-color:var(--border);color:var(--muted)}.pub-btn:disabled:hover{background:transparent;border-color:var(--border)}',
    '.pub-status{font-size:.78rem;color:var(--muted);margin-top:.7rem;min-height:1em}.pub-status.ok{color:var(--ok)}.pub-status.err{color:var(--crit)}',
    '.rank-label{display:flex;align-items:center;gap:.5rem;min-width:210px}',
    '.rank-name{display:flex;flex-direction:column;gap:1px;min-width:0}',
    '.rank-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;font-size:.88rem;color:var(--text)}',
    '.rank-path{display:block;color:var(--muted2);font-size:.68rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    '.lchart-legend{display:flex;flex-wrap:wrap;gap:14px;margin-top:.9rem;font-size:12px;color:var(--muted)}',
    '.lchart-legend .item{display:flex;align-items:center;gap:5px}',
    '.lchart-legend .item .n{color:var(--muted2)}'
  ].join('');
}

function dashboardApp(){
  var D = window.__DASH_DATA__;
  var esc = function(s){ return (s==null?'':String(s)).replace(/[&<>"]/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[m]; }); };
  var sevRank = { critical:0, warning:1, info:2 };
  var chev = '<span class="chev">\u25B6</span>';
  var app = document.getElementById('app');

  var TRIAGE = D.triage || {};
  function statusOf(f){ var t = TRIAGE[f.key]; return (t && t.status) ? t.status : 'open'; }
  function isOpen(f){ return statusOf(f) === 'open'; }
  function activeFindings(){ return (D.findings||[]).filter(isOpen); }
  function countByApp(arr, prop){ var o={}; arr.forEach(function(x){ var k=x[prop]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; }
  window.__triage = function(ek, status){
    var key = decodeURIComponent(ek);
    if(status === 'open'){ delete TRIAGE[key]; } else { TRIAGE[key] = { status:status, at:new Date().toISOString() }; }
    try { parent.postMessage({ __mlaudit:'triage', key:key, status:status }, '*'); } catch(e){}
    renderAuthors(); renderLeaders(); postHeight();
  };
  function triageActions(f){
    var k = encodeURIComponent(f.key||'');
    var st = statusOf(f);
    var btn = function(label, status, cls){ return '<button class="tri-btn '+(cls||'')+'" data-click="__triage(\''+k+'\',\''+status+'\')">'+label+'</button>'; };
    if(st === 'open') return '<div class="tri-row">'+btn('\u2713 Mark done','done','done')+btn('\u2298 Ignore','ignored','ignore')+'</div>';
    var when = (TRIAGE[f.key] && TRIAGE[f.key].at) ? esc(new Date(TRIAGE[f.key].at).toLocaleDateString()) : '';
    return '<div class="tri-row"><span class="tri-meta">'+(st==='done'?'Completed':'Ignored')+(when?' \u00B7 '+when:'')+'</span>'+btn('Reopen','open','')+'</div>';
  }

  function evidenceBlock(f){
    var out = '';
    if(f.items && f.items.length){
      var label = (f.evidenceLabel || 'items');
      var rows = f.items.map(function(it){
        var s = String(it);
        if(/^—.*—$/.test(s)) return '<li class="evhead">' + esc(s.replace(/—/g,'').trim()) + '</li>';
        return '<li>' + esc(s) + '</li>';
      }).join('');
      out += '<details class="evidence"><summary>\u25B8 ' + esc(label) + ' (' + f.items.length + ')</summary><ul class="evlist">' + rows + '</ul></details>';
    }
    if(f.snippet){
      out += '<details class="evidence"><summary>\u25B8 show source</summary><pre class="src">' + f.snippet + '</pre></details>';
    }
    return out;
  }
  function findingCard(f){
    return '<div class="finding s-' + f.severity + '"><div class="body">'
      + '<span class="cat">' + esc(f.lang) + ' \u00B7 ' + esc(f.category) + ' \u00B7 ' + f.severity + '</span>'
      + '<div class="det">' + esc(f.detail) + '</div>'
      + (f.suggestion ? '<div class="sugg">\u2192 ' + esc(f.suggestion) + '</div>' : '')
      + '<div class="path-mini">/' + esc(f.path) + '</div>'
      + '</div>'
      + evidenceBlock(f)
      + '</div>';
  }
  /* ---- compact, scannable findings table (replaces stacked cards) ---- */
  function sevAbbr(s){ return s==='critical'?'c':s==='warning'?'w':'i'; }
  function sevBadge(s){ return '<span class="sevb '+sevAbbr(s)+'"><span class="dot"></span>'+esc(s)+'</span>'; }
  var FCELL = {
    sev:  function(f){ return sevBadge(f.severity); },
    page: function(f){ return '<span class="fc-pg">'+esc(f.page)+'</span><span class="fc-path">/'+esc(f.path)+'</span>'; },
    lang: function(f){ return '<span class="fc-lang">'+esc(f.lang)+'</span>'; },
    cat:  function(f){ return '<span class="fc-cat">'+esc(f.category)+'</span>'; },
    issue:function(f){ return '<span class="fc-issue">'+esc(f.detail)+'</span>'; }
  };
  var FHEAD = { sev:'Severity', page:'Page', lang:'Language', cat:'Category', issue:'Issue' };
  function findingsTable(rows, cols){
    if(!rows || !rows.length) return '<p class="empty">No findings.</p>';
    var span = cols.length + 1;
    var thead = '<thead><tr>' + cols.map(function(k){ return '<th class="sortable" data-k="'+k+'">'+FHEAD[k]+'<span class="sort-ind"></span></th>'; }).join('') + '<th></th></tr></thead>';
    var body = rows.map(function(f){
      var st = statusOf(f);
      var rowCls = st === 'done' ? ' resolved done' : st === 'ignored' ? ' resolved ignored' : '';
      var tag = st === 'done' ? '<span class="ftag done" title="Completed">\u2713</span>'
              : st === 'ignored' ? '<span class="ftag ignored" title="Ignored">\u2298</span>' : '';
      var tds = cols.map(function(k){ return '<td>'+FCELL[k](f)+'</td>'; }).join('')
        + '<td class="fc-exp">'+tag+'<span class="fchev">\u25B8</span></td>';
      var sortAttrs = ' data-sev="'+(sevRank[f.severity]!=null?sevRank[f.severity]:9)+'"'
        + ' data-page="'+esc(((f.page||'')+' '+(f.path||'')).toLowerCase())+'"'
        + ' data-lang="'+esc((f.lang||'').toLowerCase())+'"'
        + ' data-cat="'+esc((f.category||'').toLowerCase())+'"'
        + ' data-issue="'+esc((f.detail||'').toLowerCase())+'"';
      var detail = '<div class="fd-inner">'
        + (f.suggestion ? '<div class="fd-sugg">\u2192 '+esc(f.suggestion)+'</div>' : '')
        + '<div class="fd-meta">'+esc(f.lang)+' \u00B7 '+esc(f.category)+' \u00B7 /'+esc(f.path)+'</div>'
        + evidenceBlock(f) + triageActions(f) + '</div>';
      return '<tr class="frow'+rowCls+'"'+sortAttrs+'>'+tds+'</tr><tr class="fdetail"><td colspan="'+span+'">'+detail+'</td></tr>';
    }).join('');
    return '<div class="ftable-wrap"><table class="ft">'+thead+'<tbody>'+body+'</tbody></table></div>';
  }

  app.innerHTML =
    '<p class="eyebrow">Localization QA dashboard</p>'
    + '<h1>' + esc(D.meta.host) + '</h1>'
    + '<div class="dash-headrow">'
      + '<p class="sub">Generated ' + esc(D.meta.generated) + ' \u00B7 ' + esc(D.meta.langs.join(', ')) + ' \u00B7 translation check: ' + esc(D.meta.translationCheck) + '</p>'
      + '<a class="pdf-link" id="pdfLink" data-click="__pdf()" title="Save as PDF">'
        + '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>'
        + '<span>Save as report PDF</span></a>'
    + '</div>'
    + '<div class="tabs"><button class="tab active" id="tab-authors">Authors</button><button class="tab" id="tab-leaders">Admin</button></div>'
    + '<div id="view-authors"></div><div id="view-leaders" style="display:none"></div>';

  var curView = 'authors';
  window.__pdf = function(){ try { parent.postMessage({ __mlaudit:'pdf', view: curView }, '*'); } catch(e){} };
  window.__exportcsv = function(){ try { parent.postMessage({ __mlaudit:'exportcsv' }, '*'); } catch(e){} };

  function show(t){
    curView = t;
    document.getElementById('view-authors').style.display = t==='authors'?'block':'none';
    document.getElementById('view-leaders').style.display = t==='leaders'?'block':'none';
    document.getElementById('tab-authors').className = 'tab' + (t==='authors'?' active':'');
    document.getElementById('tab-leaders').className = 'tab' + (t==='leaders'?' active':'');
  }
  document.getElementById('tab-authors').onclick = function(){ show('authors'); };
  document.getElementById('tab-leaders').onclick = function(){ show('leaders'); };

  // when embedded in the audit page (iframe), let the parent drive the tab and hide our own tab bar
  function postHeight(){ try { parent.postMessage({ dashHeight: document.body.scrollHeight }, '*'); } catch(e){} }
  window.__publishRun = function(){
    var s=document.getElementById('publishStatus'); if(s){ s.textContent='Publishing…'; s.className='pub-status'; }
    try { parent.postMessage({ __mlaudit:'publish' }, '*'); } catch(e){}
  };
  window.__genAudit = function(){ try { parent.postMessage({ __mlaudit:'runAudit' }, '*'); } catch(e){} };
  window.__scan404 = function(){
    var s=document.getElementById('s404-status'); if(s){ s.textContent='Scanning sitemap…'; }
    var btn=document.getElementById('s404-btn'); if(btn){ btn.disabled=true; }
    try { parent.postMessage({ __mlaudit:'scan404' }, '*'); } catch(e){}
  };
  window.addEventListener('message', function(e){
    var m = e.data;
    if(m === 'hidetabs'){ var tb = document.querySelector('.tabs'); if(tb) tb.style.display = 'none'; }
    else if(m === 'tab:authors'){ show('authors'); postHeight(); }
    else if(m === 'tab:leaders'){ show('leaders'); postHeight(); }
    else if(m && m.__mlaudit_ack === 'publish'){
      var s=document.getElementById('publishStatus');
      if(s){ s.textContent = m.ok ? ('Published \u2713 ' + new Date(m.at).toLocaleTimeString()) : 'Publish failed — check the connection.'; s.className = 'pub-status' + (m.ok?' ok':' err'); }
    }
    else if(m && m.__mlaudit_scan){
      var st=document.getElementById('s404-status'); var p=m.__mlaudit_scan;
      if(st){
        if(p.phase==='start') st.textContent='Scanning sitemap…';
        else if(p.phase==='progress') st.textContent='Checking '+p.done+' of '+p.total+'…';
        else if(p.phase==='done'){ st.textContent = p.rec && p.rec.error==='no-sitemap' ? 'No saved sitemap — run “Discover pages from sitemap” first.' : ''; }
      }
    }
  });
  if(window.ResizeObserver){ new ResizeObserver(postHeight).observe(document.body); }
  setTimeout(postHeight, 200);

  /* expand/collapse a findings-table row to show its detail */
  document.addEventListener('click', function(e){
    var row = e.target.closest ? e.target.closest('tr.frow') : null;
    if(!row) return;
    var det = row.nextElementSibling;
    if(det && det.className.indexOf('fdetail') !== -1){
      var willOpen = !det.classList.contains('show');
      det.classList.toggle('show', willOpen);
      row.classList.toggle('open', willOpen);
      postHeight();
    }
  });

  // Click a column header to sort that findings table (keeps each row's detail with it).
  document.addEventListener('click', function(e){
    var th = e.target.closest ? e.target.closest('th.sortable') : null;
    if(!th) return;
    var table = th.closest('table.ft'); if(!table) return;
    var tbody = table.querySelector('tbody'); if(!tbody) return;
    var k = th.getAttribute('data-k');
    var dir = (table.getAttribute('data-sk') === k && table.getAttribute('data-sd') === 'asc') ? 'desc' : 'asc';
    table.setAttribute('data-sk', k); table.setAttribute('data-sd', dir);
    var kids = Array.prototype.slice.call(tbody.children), pairs = [];
    for(var i=0;i<kids.length;i+=2){ pairs.push([kids[i], kids[i+1]]); }
    var numeric = (k === 'sev');
    pairs.sort(function(a,b){
      var va = a[0].getAttribute('data-'+k) || '', vb = b[0].getAttribute('data-'+k) || '', c;
      if(numeric){ c = (parseFloat(va)||0) - (parseFloat(vb)||0); }
      else { c = va < vb ? -1 : va > vb ? 1 : 0; }
      return dir === 'asc' ? c : -c;
    });
    pairs.forEach(function(p){ tbody.appendChild(p[0]); if(p[1]) tbody.appendChild(p[1]); });
    table.querySelectorAll('th.sortable').forEach(function(h){ h.removeAttribute('data-dir'); });
    th.setAttribute('data-dir', dir);
    postHeight();
  });

  /* content-date lookup (best-effort match of audited page -> Sitecore date) */
  var cdByKey = {};
  function normKey(p){ return (p||'').toLowerCase().replace(/^\/+|\/+$/g,'').replace(/\s+/g,'-'); }
  (D.contentDates||[]).forEach(function(r){ cdByKey[normKey(r.path)] = r; });
  function pageDate(path){ return cdByKey[normKey((path||'').replace(/^(es|zh)\//,''))] || null; }
  function ageDays(iso, now){ var d=new Date(iso); return isNaN(d)?null:Math.floor((now - d.getTime())/86400000); }
  function fmtAge(days){ if(days==null) return ''; if(days<60) return days+'d'; var mo=Math.floor(days/30.44); if(mo<24) return mo+'mo'; return (days/365).toFixed(1)+'y'; }

  /* ===== Authors: pages with all their findings, click to expand ===== */
  var langOpts = Array.from(new Set(D.findings.map(function(f){return f.lang;}))).sort();
  var catOpts = Array.from(new Set(D.findings.map(function(f){return f.category;}))).sort();
  var av = document.getElementById('view-authors');
  av.innerHTML =
    '<div class="card"><div class="filters">'
    + '<select id="f-lang"><option value="">All languages</option>' + langOpts.map(function(l){return '<option>'+esc(l)+'</option>';}).join('') + '</select>'
    + '<select id="f-sev"><option value="">All severities</option><option>critical</option><option>warning</option><option>info</option></select>'
    + '<select id="f-cat"><option value="">All categories</option>' + catOpts.map(function(c){return '<option>'+esc(c)+'</option>';}).join('') + '</select>'
    + '<input id="f-q" placeholder="Search text or page\u2026" style="flex:1;min-width:160px">'
    + '<label class="f-toggle"><input type="checkbox" id="f-resolved"> show resolved</label>'
    + '<span class="muted" id="f-count" style="font-size:.8rem"></span>'
    + '</div><div id="author-list"></div></div>';

  var authorSel = null;
  function pageMeta(key, items, now){
    var head=key.split('||'), name=head[0], path=head[1];
    var cc=items.filter(function(f){return f.severity==='critical';}).length;
    var wc=items.filter(function(f){return f.severity==='warning';}).length;
    var ic=items.filter(function(f){return f.severity==='info';}).length;
    var cd=pageDate(path), datePill='';
    if(cd && cd.updated){ var a=ageDays(cd.updated, now); datePill='<span class="pill date">updated '+esc(cd.updated.slice(0,10))+(a!=null?' \u00B7 '+fmtAge(a):'')+(cd.updatedBy?' \u00B7 '+esc(cd.updatedBy):'')+'</span>'; }
    var pills=(cc?'<span class="pill c">'+cc+' critical</span>':'')+(wc?'<span class="pill w">'+wc+' warning</span>':'')+(ic?'<span class="pill i">'+ic+' info</span>':'')+datePill;
    return { name:name, path:path, pills:pills };
  }
  function renderAuthors(){
    var l=document.getElementById('f-lang').value, s=document.getElementById('f-sev').value,
        c=document.getElementById('f-cat').value, q=document.getElementById('f-q').value.toLowerCase();
    var showRes = document.getElementById('f-resolved').checked;
    var matched = D.findings.filter(function(f){
      return (!l||f.lang===l) && (!s||f.severity===s) && (!c||f.category===c)
        && (!q || (f.detail+' '+f.page+' '+f.path).toLowerCase().indexOf(q)!==-1);
    });
    var rows = matched.filter(function(f){ return showRes || isOpen(f); });
    var resolvedHidden = matched.length - rows.length;
    document.getElementById('f-count').textContent = rows.length + ' ' + (showRes?'finding(s)':'open') + ' across ' + (new Set(rows.map(function(f){return f.path;}))).size + ' page(s)' + (!showRes && resolvedHidden ? ' \u00B7 ' + resolvedHidden + ' resolved hidden' : '');
    var groups={}; rows.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
    var keys=Object.keys(groups).sort(function(a,b){ return groups[b].length-groups[a].length; });
    var host=document.getElementById('author-list');
    if(!keys.length){ host.innerHTML='<p class="empty">No findings match these filters.</p>'; authorSel=null; return; }
    if(keys.indexOf(authorSel)===-1) authorSel=keys[0];
    var now=D.now||Date.now();
    var selItems=groups[authorSel].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity])||a.lang.localeCompare(b.lang); });
    var selMeta=pageMeta(authorSel, groups[authorSel], now);
    var opts=keys.map(function(k){
      var m=pageMeta(k, groups[k], now);
      return '<div class="picker-opt'+(k===authorSel?' sel':'')+'" data-key="'+encodeURIComponent(k)+'">'
        + '<span class="po-name">'+esc(m.name)+'</span>'+m.pills
        + '<span class="pc-path">/'+esc(m.path)+'</span></div>';
    }).join('');
    host.innerHTML =
      '<div class="picker" id="pk">'
        + '<div class="picker-head" id="pk-head">'+chev
          + '<span class="pk-name">'+esc(selMeta.name)+'</span>'+selMeta.pills
          + '<span class="pc-path">/'+esc(selMeta.path)+'</span>'
          + '<span class="spacer" style="flex:1"></span>'
          + '<span class="pk-hint">'+keys.length+' page(s) \u00B7 click to change</span>'
        + '</div>'
        + '<div class="picker-list" id="pk-list">'+opts+'</div>'
      + '</div>'
      + '<div class="picker-detail">'+findingsTable(selItems, ['sev','lang','cat','issue'])+'</div>';
    document.getElementById('pk-head').onclick=function(){ document.getElementById('pk').classList.toggle('open'); };
    document.getElementById('pk-list').onclick=function(e){
      var opt=e.target.closest ? e.target.closest('.picker-opt') : null; if(!opt) return;
      authorSel=decodeURIComponent(opt.getAttribute('data-key'));
      renderAuthors();
    };
  }
  ['f-lang','f-sev','f-cat','f-resolved'].forEach(function(id){ document.getElementById(id).onchange=renderAuthors; });
  document.getElementById('f-q').oninput=renderAuthors;
  renderAuthors();

  /* ===== Leaders ===== */
  function kpi(n, label, cls, sev){
    return '<button class="kpi ' + (cls||'') + '" data-click="__drillSev(\'' + (sev||'') + '\')">'
      + '<span class="kpi-n">' + n + '</span><span class="kpi-l">' + label + '</span></button>';
  }
  function donut(parts, total){
    var r=58, c=2*Math.PI*r, cx=74, cy=74, off=0;
    var segs = parts.filter(function(p){return p.n>0;}).map(function(p){
      var len = total ? c*(p.n/total) : 0;
      var s = '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="'+p.color+'" stroke-width="15" '
        + 'stroke-dasharray="'+len+' '+(c-len)+'" stroke-dashoffset="'+(-off)+'" transform="rotate(-90 '+cx+' '+cy+')"/>';
      off += len; return s;
    }).join('');
    return '<svg viewBox="0 0 148 148" class="donut">'
      + '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="var(--border)" stroke-width="15"/>'
      + (total ? segs : '')
      + '<text x="74" y="72" text-anchor="middle" class="donut-n">'+total+'</text>'
      + '<text x="74" y="90" text-anchor="middle" class="donut-l">findings</text></svg>';
  }
  function legRow(color, label, n, tot){
    var pct = tot ? Math.round(n/tot*100) : 0;
    return '<div class="legend-row"><span class="swatch" style="background:'+color+'"></span>'
      + '<span class="lt">'+label+'</span><span class="ln">'+n+' \u00B7 '+pct+'%</span></div>';
  }
  function panel(title, inner){
    return '<section class="card"><p class="label">'+title+'</p>'+inner+'</section>';
  }
  window.__drillSev = function(sev){
    show('authors');
    document.getElementById('f-sev').value = sev || '';
    renderAuthors();
    document.getElementById('view-authors').scrollIntoView({behavior:'smooth', block:'start'});
  };
  function drill(dim, list){
    var cols = ['sev','page','issue'];
    var src = list || D.findings;
    var groups={}; src.forEach(function(f){ var k=f[dim]||'\u2014'; (groups[k]=groups[k]||[]).push(f); });
    var keys=Object.keys(groups).sort(function(a,b){ return groups[b].length-groups[a].length; });
    if(!keys.length) return '<p class="empty">No open findings.</p>';
    var max=groups[keys[0]].length;
    return keys.map(function(k){
      var list2=groups[k].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity]); });
      var pct=Math.round(list2.length/max*100);
      return '<details class="drill"><summary><span class="drill-label">'+chev+esc(k)+'</span>'
        +'<span class="bartrack"><span class="barfill" style="width:'+pct+'%"></span></span>'
        +'<span class="drill-count">'+list2.length+'</span></summary>'
        +'<div class="drill-body">'+findingsTable(list2, cols)+'</div></details>';
    }).join('');
  }
  function topProblemPages(list, n){
    var groups={}; list.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
    var scored=Object.keys(groups).map(function(k){
      var items=groups[k], w=0; items.forEach(function(f){ w += f.severity==='critical'?100:f.severity==='warning'?10:1; });
      var head=k.split('||');
      return { name:head[0], path:head[1], score:w, items:items.slice().sort(function(a,b){ return sevRank[a.severity]-sevRank[b.severity]; }) };
    });
    scored.sort(function(a,b){ return b.score-a.score; });
    var top=scored.slice(0, n||5);
    if(!top.length) return '<p class="empty">No open findings.</p>';
    var mx=top[0].score||1;
    return top.map(function(r){
      var pct=Math.round(r.score/mx*100);
      return '<details class="drill"><summary><span class="rank-label">'+chev+'<span class="rank-name"><span class="rank-title">'+esc(r.name)+'</span><span class="rank-path">/'+esc(r.path)+'</span></span></span>'
        +'<span class="bartrack"><span class="barfill" style="width:'+pct+'%"></span></span>'
        +'<span class="drill-count">'+r.score+'</span></summary>'
        +'<div class="drill-body">'+findingsTable(r.items, ['sev','lang','cat','issue'])+'</div></details>';
    }).join('');
  }
  function sevByLangLine(list){
    var byLang={};
    list.forEach(function(f){ var l=f.lang||'\u2014'; byLang[l]=byLang[l]||{critical:0,warning:0,info:0}; byLang[l][f.severity]=(byLang[l][f.severity]||0)+1; });
    var langs=Object.keys(byLang).sort(function(a,b){
      var ta=byLang[a].critical+byLang[a].warning+byLang[a].info, tb=byLang[b].critical+byLang[b].warning+byLang[b].info;
      return tb-ta;
    });
    if(!langs.length) return '<p class="empty">No open findings.</p>';
    var palette = ['var(--accent)','var(--ok)','#8aa9d9','#b48ae0','#e08ac0','#7fd0c9'];
    var cats = ['critical','warning','info'], catLabels = ['Critical','Warning','Info'];
    var maxV = 1;
    langs.forEach(function(l){ cats.forEach(function(c){ if(byLang[l][c] > maxV) maxV = byLang[l][c]; }); });
    var W=440, H=200, padL=30, padR=14, padT=14, padB=28;
    var plotW=W-padL-padR, plotH=H-padT-padB;
    function xFor(i){ return padL + plotW*i/(cats.length-1); }
    function yFor(v){ return padT + plotH - (plotH*v/maxV); }
    var yTicks=[0, Math.round(maxV/2), maxV];
    var gridSvg = yTicks.map(function(t){
      var y=yFor(t);
      return '<line x1="'+padL+'" y1="'+y+'" x2="'+(W-padR)+'" y2="'+y+'" stroke="var(--border)" stroke-width="1"/>'
        + '<text x="'+(padL-8)+'" y="'+(y+3)+'" text-anchor="end" font-size="10" fill="var(--muted2)">'+t+'</text>';
    }).join('');
    var xLabels = cats.map(function(c,i){
      return '<text x="'+xFor(i)+'" y="'+(H-8)+'" text-anchor="middle" font-size="10" fill="var(--muted)">'+catLabels[i]+'</text>';
    }).join('');
    var lines = langs.map(function(l, li){
      var color = palette[li % palette.length];
      var pts = cats.map(function(c,i){ return xFor(i)+','+yFor(byLang[l][c]); }).join(' ');
      var dots = cats.map(function(c,i){
        return '<circle cx="'+xFor(i)+'" cy="'+yFor(byLang[l][c])+'" r="3.5" fill="'+color+'"><title>'+esc(l)+' \u00B7 '+catLabels[i]+': '+byLang[l][c]+'</title></circle>';
      }).join('');
      return '<polyline points="'+pts+'" fill="none" stroke="'+color+'" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>'+dots;
    }).join('');
    var svg = '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto;display:block">'+gridSvg+xLabels+lines+'</svg>';
    var legend = '<div class="lchart-legend">'+langs.map(function(l, li){
      var color = palette[li % palette.length];
      var t = byLang[l].critical+byLang[l].warning+byLang[l].info;
      return '<span class="item"><span class="swatch" style="background:'+color+'"></span>'+esc(l)+' <span class="n">('+t+')</span></span>';
    }).join('')+'</div>';
    return svg + legend;
  }
  var staleMonths = '12';
  var findingsDim = 'category';

  var lv=document.getElementById('view-leaders');
  function renderLeaders(){
    var ACT = activeFindings();

    var bs = countByApp(ACT, 'severity');
    var sc=bs.critical||0, sw=bs.warning||0, si=bs.info||0, stot=sc+sw+si;
    var sevInner='<div class="sevmix">'
      + donut([{n:sc,color:'var(--crit)'},{n:sw,color:'var(--warn)'},{n:si,color:'var(--muted2)'}], stot)
      + '<div class="legend">'
        + legRow('var(--crit)','Critical',sc,stot)
        + legRow('var(--warn)','Warning',sw,stot)
        + legRow('var(--muted2)','Info',si,stot)
      + '</div></div>';

    var cov=D.coverage;
    var covMissing=cov.missing.length
      ? cov.missing.map(function(m){ return '<div class="barrow"><span style="min-width:150px">'+esc(m.lang)+'</span><span class="crit">'+m.count+' page(s) missing / errored</span></div>'; }).join('')
      : '<p class="ok" style="font-size:.85rem">Every audited page returned a version in all languages.</p>';
    var covInner='<div class="covrow"><span class="big">'+cov.audited+'</span><span class="muted">of '+cov.discovered+' discovered page(s) audited</span></div>'+covMissing;

    var sync = D.sync || {};
    var staleFindings = ACT.filter(function(f){ return f.category === 'source changed, translation stale'; });
    var queueHtml = '';
    if(sync.hasBaseline){
      var apprTxt = sync.approvedAt ? ' \u00B7 approved ' + esc(new Date(sync.approvedAt).toLocaleDateString()) : '';
      if(staleFindings.length){
        queueHtml = '<section class="card queue-stale"><p class="label">\u26A0 Stale because English changed \u00B7 retranslate these (' + staleFindings.length + ')' + apprTxt + '</p>'
          + findingsTable(staleFindings, ['sev','page','lang','issue']) + '</section>';
      } else {
        queueHtml = '<section class="card queue-ok"><p class="label">Source sync' + apprTxt + '</p>'
          + '<p class="ok" style="font-size:.88rem">No open stale translations — every approved translation still matches its English source.</p></section>';
      }
    }

    // triage progress
    var doneN=0, ignN=0;
    (D.findings||[]).forEach(function(f){ var st=statusOf(f); if(st==='done')doneN++; else if(st==='ignored')ignN++; });
    var totalN=(D.findings||[]).length, openN=ACT.length;
    var pctDone = totalN ? Math.round((doneN+ignN)/totalN*100) : 0;
    var triageInner = '<div class="covrow"><span class="big">'+openN+'</span><span class="muted">open of '+totalN+' finding(s)</span></div>'
      + '<div class="tprog"><span class="tprog-bar" style="width:'+pctDone+'%"></span></div>'
      + '<div class="barrow" style="margin-top:.6rem"><span class="ok">'+doneN+' completed</span><span class="muted">'+ignN+' ignored</span></div>';

    var modeLabel = (D.storeMode === 'remote') ? 'Shared store \u00B7 team-wide' : 'Local only \u00B7 this browser';
    var canPublish = !!D.hasLocalRun;
    var publishInner = '<p class="muted" style="font-size:.82rem;margin:0 0 .9rem">'+esc(modeLabel)+'</p>'
      + '<div class="pub-actions">'
        + '<button class="pub-btn pub-secondary"'+(canPublish?'':' disabled')+' data-click="__publishRun()">Publish run to team</button>'
        + (D.canRun ? '<button class="pub-btn pub-primary" data-click="__genAudit()">Generate new audit</button>' : '')
      + '</div>'
      + '<div id="publishStatus" class="pub-status">'+(canPublish?'':'Run a new audit to publish it to the team.')+'</div>';

    // Prefer the explicit missing-translations list; fall back to reconstructing from
    // findings so older runs still match the Findings box.
    var mtList = Array.isArray(D.missingTranslations) ? D.missingTranslations.slice()
      : (D.findings || []).filter(function(f){ return f.category === 'load error' && f.lang !== 'English (reference)'; })
          .map(function(f){ return { page:f.page, lang:f.lang, url:'', error:f.detail || 'failed to load' }; });

    var s404Inner = (function(){
      var out = '';

      // Group 1 — missing/broken foreign-language pages found by the last audit
      var mt = mtList.slice().sort(function(a,b){ return (a.page+a.lang).localeCompare(b.page+b.lang); });
      out += '<details class="acc-collapse s404-group" open><summary class="s404-grouphead acc-summary">Missing translations \u00B7 expected foreign-language pages that failed to load'
        + (mt.length? ' ('+mt.length+')':'') + '<span class="chev">\u25B8</span></summary>';
      if(!D.summary || !D.summary.pages){
        out += '<p class="muted" style="font-size:.82rem;margin:.1rem 0 .5rem">Run an audit to check whether each page\u2019s translated versions exist.</p>';
      } else if(!mt.length){
        out += '<p style="color:var(--ok);font-size:.85rem;margin:.1rem 0 .5rem">Every audited page returned a version in all languages.</p>';
      } else {
        var capN = 60, cap = mt.slice(0, capN);
        out += '<div class="s404-list">' + cap.map(function(m){
          var label = m.url ? m.url : (m.page + ' \u2014 ' + m.lang);
          var right = m.lang + ' \u00B7 ' + m.error;
          var inner = '<span class="s404-url">' + esc(label) + '</span>';
          if(m.url) inner = '<a class="s404-url" href="'+esc(m.url)+'" target="_blank" rel="noopener">'+esc(label)+'</a>';
          return '<div class="s404-row">' + inner + '<span class="s404-seen">'+esc(right)+'</span></div>';
        }).join('') + '</div>';
        if(mt.length > cap.length){
          out += '<p class="muted" style="font-size:.78rem;margin:.5rem 0 0">+' + (mt.length - cap.length)
            + ' more \u2014 see every one under <strong>Findings \u25B8 by language</strong>.</p>';
        }
      }
      out += '</details>';

      // Group 2 — sitemap monitor (internal pages the sitemap lists that 404)
      var s = D.sitemap404;
      out += '<details class="acc-collapse s404-group" open><summary class="s404-grouphead acc-summary">Sitemap monitor \u00B7 internal pages the sitemap lists that return 404<span class="chev">\u25B8</span></summary>';
      if(!s || !s.checked){
        out += '<p class="muted" style="margin:.1rem 0 .5rem;font-size:.82rem">Checks the saved sitemap for internal pages that return 404. The scheduled job also updates this list.</p>';
      } else {
        var deadUrls = Object.keys(s.urls || {});
        out += '<p class="muted" style="margin:.1rem 0 .5rem;font-size:.82rem">Last checked '+new Date(s.checked).toLocaleString()+' \u00B7 '+s.dead+' dead of '+s.total+' checked'+(s.newCount? ' \u00B7 '+s.newCount+' new':'')+'</p>';
        if(!deadUrls.length){
          out += '<p style="color:var(--ok);font-size:.85rem">No 404s — every page in the saved sitemap resolved.</p>';
        } else {
          out += '<div class="s404-list">' + deadUrls.sort(function(a,b){ return (s.urls[b].firstSeen||'').localeCompare(s.urls[a].firstSeen||''); }).map(function(u){
            var isNew = s.newUrls && s.newUrls.indexOf(u) !== -1;
            var seen = s.urls[u].firstSeen ? 'since '+new Date(s.urls[u].firstSeen).toLocaleDateString() : '';
            return '<div class="s404-row">'+(isNew?'<span class="s404-new">NEW</span>':'')
              + '<a class="s404-url" href="'+esc(u)+'" target="_blank" rel="noopener">'+esc(u)+'</a>'
              + '<span class="s404-seen">'+seen+'</span></div>';
          }).join('') + '</div>';
        }
      }
      if(D.canRun){
        out += '<div style="margin-top:.7rem;display:flex;align-items:center;gap:.6rem;flex-wrap:wrap">'
          + '<button id="s404-btn" class="pub-btn pub-secondary" style="flex:0 0 auto;width:auto;padding:.5rem .9rem" data-click="__scan404()">Check sitemap now</button>'
          + '<span id="s404-status" class="muted" style="font-size:.8rem"></span></div>';
      }
      out += '</details>';
      return out;
    })();

    var critK = ACT.filter(function(f){return f.severity==='critical' && f.category!=='broken link';}).length;
    var brokenK = ACT.filter(function(f){return f.category==='broken link';}).length;
    lv.innerHTML=
      '<div class="kpis">'
        + kpi(D.summary.pages,'Pages','accent','')
        + kpi(critK,'Critical','crit','critical')
        + kpi(sw,'Warnings','warn','warning')
        + kpi(brokenK,'Broken links',brokenK?'crit':'','')
        + kpi(openN,'Open findings','','')
        + '</div>'
      + '<div class="dash-grid dash-grid-eq">'
        + panel('Severity mix \u00B7 click a metric above to drill in', sevInner)
        + panel('Publish &amp; generate', publishInner)
        + '</div>'
      + queueHtml
      + panel('Top problem pages', topProblemPages(ACT, 5))
      + (function(){
          var dead = ((D.sitemap404 && D.sitemap404.urls) ? Object.keys(D.sitemap404.urls).length : 0)
                   + mtList.length;
          var pill = dead ? ' <span class="count-pill">'+dead+'</span>' : '';
          return '<section class="card card-404'+(dead?' has-dead':'')+'">'
            + '<p class="label">404 errors'+pill+'</p>'
            + s404Inner + '</section>';
        })()
      + '<div class="dash-grid dash-grid-eq">'
        + '<section class="card">'
          + '<details class="acc-collapse" open>'
            + '<summary class="label acc-summary">Findings<span class="chev">\u25B8</span></summary>'
            + '<div class="filters"><span class="muted">Group</span>'
            + '<select id="findings-dim">'
            + '<option value="category"'+(findingsDim==='category'?' selected':'')+'>by category</option>'
            + '<option value="lang"'+(findingsDim==='lang'?' selected':'')+'>by language</option>'
            + '<option value="dir"'+(findingsDim==='dir'?' selected':'')+'>by section / directory</option>'
            + '</select><span class="muted" style="font-size:.78rem">\u00B7 click a row to expand</span></div>'
            + '<div id="findings-drill">' + drill(findingsDim, ACT) + '</div>'
          + '</details>'
        + '</section>'
        + panel('Severity by language', sevByLangLine(ACT))
        + '</div>'
      + '<div class="dash-grid dash-grid-eq">'
        + panel('Triage progress', triageInner)
        + panel('Translation coverage', covInner)
        + '</div>'
      + '<section class="card">'
        + '<details class="stale-collapse" open>'
          + '<summary class="label stale-summary">Stale content<span class="chev">\u25B8</span></summary>'
          + '<div class="filters"><span class="muted">Flag pages not updated in over</span>'
          + '<select id="stale-threshold">'
          + ['3','6','12','18','24'].map(function(v){ return '<option value="'+v+'"'+(v===staleMonths?' selected':'')+'>'+v+' months</option>'; }).join('')
          + '</select></div>'
          + '<div id="stale-body"></div>'
        + '</details>'
      + '</section>';
    var sel=document.getElementById('stale-threshold');
    if(sel){ sel.onchange=function(){ staleMonths=sel.value; renderStale(); }; }
    var fdim=document.getElementById('findings-dim');
    if(fdim){ fdim.onchange=function(){ findingsDim=fdim.value; var fd=document.getElementById('findings-drill'); if(fd){ fd.innerHTML=drill(findingsDim, activeFindings()); } postHeight(); }; }
    renderStale();
  }

  function parseDate(s){
    if(!s) return null;
    var m=/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(s);
    if(m) return new Date(Date.UTC(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+m[6]));
    var t2=Date.parse(s); return isNaN(t2)?null:new Date(t2);
  }
  function renderStale(){
    var staleBody=document.getElementById('stale-body'); if(!staleBody) return; // panel disabled
    var months=+document.getElementById('stale-threshold').value;
    var now=D.now||Date.now();
    var cutoff=now-months*30.44*86400000;
    var useSc=D.contentDates && D.contentDates.length;
    var src=useSc
      ? D.contentDates.map(function(r){ return {path:r.path,by:r.updatedBy,created:r.created,createdBy:r.createdBy,date:parseDate(r.updated)}; })
      : (D.pages||[]).map(function(p){ return {path:p.path,by:'',date:parseDate(p.lastmod)}; });
    var dated=src.filter(function(r){return r.date;}).sort(function(a,b){return a.date-b.date;});
    var staleCount=dated.filter(function(r){return r.date.getTime()<cutoff;}).length;
    var html='<p class="sub">'+(useSc?'Real publish dates from Sitecore. ':'')
      +staleCount+' of '+dated.length+' page(s) not updated in over '+months+' month(s). Click a row for detail.</p>';
    if(!dated.length){
      document.getElementById('stale-body').innerHTML=html+'<p class="empty">No dates loaded. In the audit tool, click \u201cLoad content dates\u201d and pick your \u201cItems last updated\u201d export, then save the dashboard again.</p>';
      return;
    }
    var staleRows=dated.filter(function(r){return r.date.getTime()<cutoff;});
    if(!staleRows.length){
      document.getElementById('stale-body').innerHTML=html+'<p class="empty" style="color:var(--ok)">No pages are stale at this threshold.</p>';
      return;
    }
    html+='<div class="headrow"><span>Page</span><span>Updated</span><span>Age</span><span>Status</span></div>';
    html+=staleRows.map(function(r){
      var dAge=Math.floor((now-r.date.getTime())/86400000);
      var stale=r.date.getTime()<cutoff;
      var body='<div class="st-body">'
        + '<div><span class="k">Last updated</span><br><span class="v">'+esc(r.date.toISOString().slice(0,10))+'</span></div>'
        + (r.by?'<div><span class="k">Updated by</span><br><span class="v">'+esc(r.by)+'</span></div>':'')
        + (r.created?'<div><span class="k">Created</span><br><span class="v">'+esc((parseDate(r.created)||r.created).toISOString?parseDate(r.created).toISOString().slice(0,10):r.created)+'</span></div>':'')
        + (r.createdBy?'<div><span class="k">Created by</span><br><span class="v">'+esc(r.createdBy)+'</span></div>':'')
        + '<div><span class="k">Full path</span><br><span class="v">/'+esc(r.path)+'</span></div>'
        + '</div>';
      return '<details class="stale'+(stale?' is-stale':'')+'"><summary>'
        + '<span class="st-path">'+chev+' /'+esc(r.path)+'</span>'
        + '<span class="st-date">'+esc(r.date.toISOString().slice(0,10))+'</span>'
        + '<span class="st-age">'+fmtAge(dAge)+'</span>'
        + '<span>'+(stale?'<span class="crit">stale</span>':'<span class="ok">current</span>')+'</span>'
        + '</summary>'+body+'</details>';
    }).join('');
    document.getElementById('stale-body').innerHTML=html;
  }
  renderLeaders();
}

  var st = document.createElement('style');
  st.textContent = dashboardCss();
  document.head.appendChild(st);
  dashboardApp();
})();
