/* Delegated handler dispatcher (MV3-safe: no inline JS, no eval).
   Elements carry data-click / data-change / data-input / data-keydown = "fn('a', this)". */
(function () {
  function parseArgs(str, el, ev) {
    var out = [], buf = '', q = null, depth = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str[i];
      if (q) {
        if (c === '\\' && i + 1 < str.length) { buf += c + str[++i]; continue; }
        if (c === q) q = null;
        buf += c;
      } else if (c === '"' || c === "'") { q = c; buf += c; }
      else if (c === '(' || c === '[') { depth++; buf += c; }
      else if (c === ')' || c === ']') { depth--; buf += c; }
      else if (c === ',' && depth === 0) { out.push(buf); buf = ''; }
      else buf += c;
    }
    if (buf.trim() !== '') out.push(buf);
    return out.map(function (a) { return coerce(a.trim(), el, ev); });
  }

  function coerce(tok, el, ev) {
    if (tok === 'this') return el;
    if (tok === 'event') return ev;
    if (tok === 'this.value') return el.value;
    if (tok === 'this.checked') return el.checked;
    if (tok === 'this.files') return el.files;
    if (tok === 'true') return true;
    if (tok === 'false') return false;
    if (tok === 'null') return null;
    if (/^-?\d+(\.\d+)?$/.test(tok)) return parseFloat(tok);
    var m = tok.match(/^'([\s\S]*)'$/) || tok.match(/^"([\s\S]*)"$/);
    if (m) return m[1].replace(/\\'/g, "'").replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    return tok;
  }

  function run(spec, el, ev) {
    var m = String(spec).match(/^\s*([\w$.]+)\s*\(([\s\S]*)\)\s*;?\s*$/);
    if (!m) return;
    var path = m[1].split('.'), ctx = window, fn = window[path[0]];
    for (var i = 1; i < path.length && fn; i++) { ctx = fn; fn = fn[path[i]]; }
    if (typeof fn !== 'function') { console.warn('[actions] unknown action:', m[1]); return; }
    try { fn.apply(ctx, parseArgs(m[2], el, ev)); }
    catch (e) { console.error('[actions] ' + m[1] + ' failed:', e); }
  }

  ['click', 'change', 'input', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      var el = e.target && e.target.closest ? e.target.closest('[data-' + ev + ']') : null;
      if (!el) return;
      run(el.getAttribute('data-' + ev), el, e);
    }, false);
  });

  /* helpers standing in for the multi-statement inline handlers */
  window.__file = function (input, fnName) {
    var f = input.files && input.files[0];
    if (f && typeof window[fnName] === 'function') window[fnName](f);
    input.value = '';
  };
  window.__pick = function (id) { var el = document.getElementById(id); if (el) el.click(); };
  window.__enter = function (e) { if (e && e.key === 'Enter' && typeof submitLogin === 'function') submitLogin(); };
  window.__togglePage = function (el) { togglePage(el.getAttribute('data-path'), el.checked); };
  window.__toggleDir = function (el) { toggleDir(el.getAttribute('data-dir'), el.checked); };
})();
