/* Highlights the element a finding refers to, on the live page.
   Receives a locator spec from the side panel and outlines the best match. */
(function () {
  const ID = '__sa_hl_style';
  const CLS = '__sa-hl';
  const LBL = '__sa-hl-label';

  function ensureStyle() {
    if (document.getElementById(ID)) return;
    const st = document.createElement('style');
    st.id = ID;
    st.textContent = `
      .${CLS}{ outline:2px solid #FFBE5F !important; outline-offset:2px !important;
               background:rgba(255,190,95,.16) !important; scroll-margin:120px !important;
               transition:background .25s ease !important; }
      .${CLS}.__sa-primary{ outline-width:3px !important; background:rgba(255,190,95,.28) !important; }
      .${LBL}{ position:absolute; z-index:2147483647; background:#1a1a1a; color:#FFBE5F;
               font:500 11px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
               padding:3px 7px; border-radius:5px; border:1px solid #FFBE5F;
               pointer-events:none; white-space:nowrap; box-shadow:0 2px 8px rgba(0,0,0,.4); }
    `;
    (document.head || document.documentElement).appendChild(st);
  }

  function clear() {
    document.querySelectorAll('.' + CLS).forEach((el) => el.classList.remove(CLS, '__sa-primary'));
    document.querySelectorAll('.' + LBL).forEach((el) => el.remove());
  }

  function label(el, text) {
    const r = el.getBoundingClientRect();
    const d = document.createElement('div');
    d.className = LBL;
    d.textContent = text;
    d.style.top = (window.scrollY + r.top - 24) + 'px';
    d.style.left = (window.scrollX + r.left) + 'px';
    document.body.appendChild(d);
  }

  /* --- locators, best-effort per finding type --- */
  function byLink(urls) {
    const out = [];
    const wanted = (urls || []).map((u) => {
      try { return new URL(u, location.href).pathname.replace(/\/+$/, ''); }
      catch (e) { return String(u); }
    });
    document.querySelectorAll('a[href]').forEach((a) => {
      let p;
      try { p = new URL(a.getAttribute('href'), location.href).pathname.replace(/\/+$/, ''); }
      catch (e) { p = a.getAttribute('href'); }
      if (wanted.some((w) => w && p && (p === w || p.endsWith(w)))) out.push(a);
    });
    return out;
  }
  function byHeadings() {
    return [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')]
      .filter((h) => h.offsetParent !== null && h.textContent.trim());
  }
  function byLinks() {
    const scope = document.querySelector('main') || document.body;
    return [...scope.querySelectorAll('a[href]')].filter((a) => a.offsetParent !== null);
  }
  function byTexts(list) {
    const out = [];
    (list || []).forEach((raw) => {
      // heading outlines arrive as "H2: Some text" — drop the level prefix
      const s = String(raw).replace(/^H[1-6]:\s*/i, '').trim();
      byText(s).forEach((el) => { if (!out.includes(el)) out.push(el); });
    });
    return out;
  }
  function byEmptyLinks() {
    return [...document.querySelectorAll('a')].filter((a) => {
      const h = a.getAttribute('href');
      return (h === null || h === '' || h === '#') && a.offsetParent !== null;
    });
  }
  function byFooter() {
    const f = document.querySelector('footer, [role="contentinfo"], [class*="footer" i]');
    return f ? [f] : [];
  }
  function byText(needle) {
    if (!needle) return [];
    const n = String(needle).trim().slice(0, 60).toLowerCase();
    if (n.length < 3) return [];
    // short tokens (todo, lorem) must match as whole words, or they hit ordinary copy
    const strict = n.length <= 8;
    const rx = strict ? new RegExp('(^|[^\\p{L}\\p{N}])' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '($|[^\\p{L}\\p{N}])', 'iu') : null;
    const out = [];
    const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walk.nextNode())) {
      const val = node.nodeValue ? node.nodeValue.toLowerCase() : '';
      const hit = strict ? (rx && rx.test(val)) : val.includes(n);
      if (hit) {
        let el = node.parentElement;
        // climb out of inline wrappers so the highlight is visible, but stop before huge blocks
        while (el && el.offsetParent === null && el.parentElement) el = el.parentElement;
        if (el && el.offsetParent !== null && !out.includes(el)
            && el.tagName !== 'BODY' && el.tagName !== 'HTML') out.push(el);
        if (out.length > 12) break;
      }
    }
    return out;
  }

  function resolve(spec) {
    const cat = ((spec.category || '') + ' ' + (spec.detail || '')).toLowerCase();

    if (spec.urls && spec.urls.length) {
      const hit = byLink(spec.urls);
      if (hit.length) return { els: hit, note: 'Broken link' };
    }
    if (cat.includes('empty or placeholder link')) {
      const hit = byEmptyLinks();
      if (hit.length) return { els: hit, note: 'Empty link' };
    }
    if (cat.includes('footer')) {
      const hit = byFooter();
      if (hit.length) return { els: hit, note: 'Footer' };
    }
    // the exact strings the audit found — most precise signal we have
    if (spec.items && spec.items.length) {
      const hit = byTexts(spec.items);
      if (hit.length) return { els: hit, note: spec.items.length === 1 ? 'Found here' : 'Found in ' + hit.length + ' place(s)' };
    }
    if (cat.includes('h1')) {
      const hit = [...document.querySelectorAll('h1')].filter((h) => h.offsetParent !== null);
      if (hit.length) return { els: hit, note: 'H1 headings' };
    }
    if (cat.includes('image')) {
      const hit = [...document.querySelectorAll('img')].filter((i) => i.offsetParent !== null);
      if (hit.length) return { els: hit, note: 'Images on this page' };
    }
    if (cat.includes('heading')) return { els: byHeadings(), note: 'Headings on this page' };
    if (cat.includes('link')) return { els: byLinks(), note: 'Links on this page' };
    if (spec.text) {
      const hit = byText(spec.text);
      if (hit.length) return { els: hit, note: 'Matching text' };
    }
    return { els: [], note: '' };
  }

  chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (!msg || msg.type !== 'sa-highlight') return;
    ensureStyle();
    clear();
    if (msg.clearOnly) { respond({ ok: true, count: 0 }); return true; }

    const { els, note } = resolve(msg.spec || {});
    els.slice(0, 40).forEach((el) => el.classList.add(CLS));
    if (els.length) {
      els[0].classList.add('__sa-primary');
      els[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => { try { label(els[0], note || 'Issue'); } catch (e) {} }, 350);
    }
    respond({ ok: true, count: els.length });
    return true;
  });
})();
