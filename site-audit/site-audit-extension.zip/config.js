/* Shared config for the extension. The access key authenticates every call to the
   state Worker — set it once here instead of asking each user to type it. */
window.AUDIT_CONFIG = {
  // ⚠️ SET THIS to the same value as the Worker's AUDIT_KEY secret.
  ACCESS_KEY: 'translate',
  STATE_URL: 'https://audit-state.bcbs-of-az.workers.dev/',
  SITE_URL: 'https://www.azblue.com',
  // Used by the AEP tab's pre-launch checks. Must also appear in host_permissions.
  STAGING_URL: 'https://staging.azblue.com',
};
