var EXT_MODE = (typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id));

/* CONFIG — edit once. Passphrase is typed in the UI at runtime, not stored here.
   Languages are the `langs` list below. */
const WORKER_URL = 'https://schema-cors-proxy.bcbs-of-az.workers.dev/';
const SITE_URL   = 'https://www.azblue.com';
// Staging origin for the AEP tab's pre-launch audits. In the extension, reaching it
// requires "https://staging.azblue.com/*" in the manifest's host_permissions.
const STAGING_URL = (window.AUDIT_CONFIG && window.AUDIT_CONFIG.STAGING_URL) || 'https://staging.azblue.com';
const CM_URL = (window.AUDIT_CONFIG && window.AUDIT_CONFIG.CM_URL) || 'https://cm.prod.azblue.com';
const WORKER_KEY = (window.AUDIT_CONFIG && window.AUDIT_CONFIG.ACCESS_KEY) || '';
const AI_MODEL   = 'claude-sonnet-4-6'; // model used for translation analysis (via your worker)
// Sitecore content root for the "Items last updated" export — used to turn item
// paths into clean relative paths in the stale-content view.
const SITECORE_ROOT = '/sitecore/content/bcbs az/azblue/home';
// Shared store: STATE_URL points at the KV Worker (audit-state-worker.js) so triage +
// runs are consistent for all users. Empty = local-only. Auth reuses the passphrase.
const STATE_URL = 'https://audit-state.bcbs-of-az.workers.dev/';
/* ===================================================================== */

/* ----------------------------- languages ----------------------------- */
// English is the reference (dir ''). Each translation is a path prefix.
// gcode = the Google Translate target code (e.g. 'es', 'zh-TW', 'fr', 'de').
const SOURCE_GCODE = 'en'; // source language Google translates FROM
let langs = [
  { id: 'ref', label: 'English', dir: '', ref: true, gcode: 'en' },
  { id: 'l1', label: 'Spanish', dir: 'es', ref: false, gcode: 'es' },
  { id: 'l2', label: 'Chinese Traditional', dir: 'zh', ref: false, gcode: 'zh-TW' }
];

/* ----------------------------- state ----------------------------- */
let pages = [
  { id: p(), name: 'Home', path: '', excluded: false }
];
let discovered = [];   // full sitemap list, kept in memory (not all rendered)
let dirInclude = {};   // directory -> included?
let pageExclude = {};  // path -> individually excluded?
function p(){ return 'p' + Math.random().toString(36).slice(2,8); }

/* ----------------------------- rendering inputs ----------------------------- */
function renderPages(){
  const tbl = document.getElementById('pagesTable');
  tbl.innerHTML = '';
  const head = document.createElement('tr');
  head.innerHTML = '<th style="min-width:140px;">Page name</th><th style="min-width:160px;">Path</th><th>Resolves to</th><th style="text-align:center;" title="Skip this page in the next audit run">Skip</th><th></th>';
  tbl.appendChild(head);
  pages.forEach(pg => {
    const tr = document.createElement('tr');
    if(pg.excluded) tr.style.opacity = '.45';
    const preview = langs.map(l => escapeHtml(buildUrl(SITE_URL, l.dir, pg.path))).join('<br>')
      + (pg.excluded ? '<br><span style="color:var(--critical);">Excluded from audit</span>' : '');
    tr.innerHTML =
      `<td class="name-cell"><input type="text" value="${escapeAttr(pg.name)}" data-input="updatePageName('${pg.id}', this.value)" placeholder="Page name"></td>` +
      `<td><input type="text" value="${escapeAttr(pg.path)}" placeholder="(home)" data-input="updatePagePath('${pg.id}', this.value)"></td>` +
      `<td style="font-size:.72rem;color:var(--muted);line-height:1.5;word-break:break-all;">${preview}</td>` +
      `<td style="text-align:center;"><input type="checkbox" ${pg.excluded?'checked':''} title="Skip this page in the next audit run" data-change="togglePageExcluded('${pg.id}', this.checked)"></td>` +
      `<td><button class="tiny ghost" data-click="removePage('${pg.id}')">✕</button></td>`;
    tbl.appendChild(tr);
  });
}
function updatePageName(id,v){ const pg = pages.find(x=>x.id===id); if(pg){ pg.name=v; updateRunHint(); saveManualPagesSoon(); } }
function updatePagePath(id,v){ const pg = pages.find(x=>x.id===id); if(pg){ pg.path=v.trim(); renderPages(); updateRunHint(); saveManualPagesSoon(); markDashStale(); refreshDashIfVisible(); } }
function addPage(){ pages.push({ id:p(), name:'Page ' + (pages.length+1), path:'', excluded:false }); renderPages(); updateRunHint(); saveManualPagesSoon(); }
function removePage(id){ pages = pages.filter(x=>x.id!==id); renderPages(); updateRunHint(); saveManualPagesSoon(); markDashStale(); refreshDashIfVisible(); }
function togglePageExcluded(id, checked){ const pg = pages.find(x=>x.id===id); if(pg){ pg.excluded = checked; renderPages(); updateRunHint(); saveManualPagesSoon(); markDashStale(); refreshDashIfVisible(); } }
let _manualPagesSaveTimer = null;
function saveManualPagesSoon(){
  clearTimeout(_manualPagesSaveTimer);
  _manualPagesSaveTimer = setTimeout(function(){
    statePut('manualPages', pages.map(function(pg){ return { name:pg.name, path:pg.path, excluded:!!pg.excluded }; })).catch(function(){});
  }, 600);
}
/* The discovered page list lived only in memory, so every extension reload emptied
   it and any scoped run had nothing to work from. Discovery already persists the
   sitemap URLs to shared state, so rebuild the list from those on startup. */
async function loadDiscovered(){
  if(discovered && discovered.length) return;
  try {
    const sm = await stateGet('sitemap');
    if(!sm || !Array.isArray(sm.urls) || !sm.urls.length) return;
    const paths = new Set();
    sm.urls.forEach(function(u){
      if(SKIP_EXT.test(u)) return;
      const pth = urlToPath(u);
      if(pth !== null) paths.add(pth);
    });
    if(!paths.size) return;
    discovered = Array.from(paths).sort().map(function(pth){ return { path: pth, lastmod: '' }; });
    const panel = document.getElementById('discoveredPanel');
    if(panel){ panel.style.display = 'block'; renderDiscovered(); }
    updateRunHint();
  } catch(e){}
}
async function loadManualPages(){
  try {
    const mp = await stateGet('manualPages');
    if(Array.isArray(mp)){
      pages = mp.map(function(pg){ return { id:p(), name:pg.name||'', path:pg.path||'', excluded:!!pg.excluded }; });
      renderPages();
      updateRunHint();
    }
  } catch(e){}
}

function buildUrl(site, dir, path){
  let base = (site||'').replace(/\/+$/,'');
  dir = (dir||'').replace(/^\/+|\/+$/g,'');
  path = (path||'').replace(/^\/+|\/+$/g,'');
  let out = base;
  if(dir) out += '/' + dir;
  if(path) out += '/' + path;
  return out;
}

// ---- English-only section exclusions (skip translation checks + 404 monitor) ----
function getExcludeDirs(){
  var raw = (document.getElementById('excludeDirs') && document.getElementById('excludeDirs').value) || '';
  return raw.split(/[\n,]+/).map(function(s){ return s.trim().replace(/^\/+|\/+$/g,'').toLowerCase(); }).filter(Boolean);
}
function pathIsExcluded(path, dirs){
  var p = String(path == null ? '' : path).trim().replace(/^\/+|\/+$/g,'').toLowerCase();
  if(!p) return false;
  return (dirs||[]).some(function(d){ return d && (p === d || p.indexOf(d + '/') === 0); });
}

/* ----------------------------- sitemap discovery ----------------------------- */
const SKIP_EXT = /\.(pdf|jpe?g|png|gif|webp|svg|ico|css|js|json|xml|zip|gz|mp4|mp3|woff2?|ttf|eot)$/i;

function urlToPath(u){
  try {
    const url = new URL(u);
    let path = url.pathname.replace(/^\/+|\/+$/g,'');
    const dirs = langs.map(l=>l.dir).filter(Boolean); // e.g. ['es','zh']
    const parts = path ? path.split('/') : [];
    if(parts.length && dirs.includes(parts[0])) parts.shift(); // drop language prefix
    return parts.join('/');
  } catch(e){ return null; }
}
function prettyName(path){
  if(!path) return 'Home';
  const seg = path.split('/').pop();
  return seg.replace(/[-_]+/g,' ').replace(/\b\w/g, c=>c.toUpperCase());
}

async function discoverPages(){
  const status = document.getElementById('discoverStatus');
  const setS = (t) => { status.textContent = t; status.style.color = 'var(--muted)'; };
  const setErr = (t) => { status.textContent = t; status.style.color = 'var(--critical)'; };

  if(!WORKER_URL || WORKER_URL.includes('your-worker')){ setErr('Set WORKER_URL in the config block first.'); return; }
  document.getElementById('discoverDiag').innerHTML = '';
  setS('Looking for a sitemap…');

  const root = SITE_URL.replace(/\/+$/,'');
  const siteHost = (()=>{ try { return new URL(SITE_URL).hostname; } catch(e){ return ''; } })();
  const diag = []; // { url, status, note }
  const looksHtml = (t) => /^\s*<(!doctype html|html)\b/i.test(t||'');

  // 1) robots.txt → Sitemap: directives
  let sitemaps = [];
  try {
    const r = await fetchPage(root + '/robots.txt');
    if(r.ok && r.text && !looksHtml(r.text)){
      r.text.split(/\r?\n/).forEach(line => {
        const m = line.match(/^\s*sitemap:\s*(\S+)/i);
        if(m) sitemaps.push(m[1].trim());
      });
      diag.push({ url: root+'/robots.txt', status: r.status, note: sitemaps.length ? `${sitemaps.length} sitemap line(s) found` : 'loaded, but no Sitemap: line' });
    } else {
      diag.push({ url: root+'/robots.txt', status: r.status, note: r.error ? r.error : (looksHtml(r.text) ? 'returned HTML, not robots.txt' : 'not available') });
    }
  } catch(e){ diag.push({ url: root+'/robots.txt', status: 0, note: e.message }); }

  // 2) fallbacks
  const guessed = !sitemaps.length;
  if(guessed){ sitemaps = [root + '/sitemap.xml', root + '/sitemap_index.xml', root + '/sitemap-index.xml']; }

  const MAX_SITEMAPS = 60, MAX_URLS = 3000;
  const seenSm = new Set();
  const foundUrls = new Set();
  const lastmodMap = {};
  let queue = [...sitemaps];

  while(queue.length && seenSm.size < MAX_SITEMAPS && foundUrls.size < MAX_URLS){
    const sm = queue.shift();
    if(!sm || seenSm.has(sm)) continue;
    seenSm.add(sm);
    setS(`Reading sitemap ${seenSm.size}… (${foundUrls.size} pages found)`);
    let r;
    try { r = await fetchPage(sm); } catch(e){ diag.push({ url: sm, status: 0, note: e.message }); continue; }
    if(!r.ok || !r.text){ diag.push({ url: sm, status: r.status, note: r.error ? r.error : 'no content' }); continue; }
    const doc = new DOMParser().parseFromString(r.text, 'text/xml');
    if(doc.querySelector('parsererror')){
      diag.push({ url: sm, status: r.status, note: looksHtml(r.text) ? 'got an HTML page, not XML (WAF or error page?)' : 'not valid XML' });
      continue;
    }
    const rootTag = doc.documentElement ? doc.documentElement.tagName.toLowerCase() : '';
    const locs = [...doc.querySelectorAll('loc')].map(l => clean(l.textContent)).filter(Boolean);
    if(rootTag.indexOf('sitemapindex') !== -1){
      locs.forEach(u => { if(!seenSm.has(u)) queue.push(u); }); // child sitemaps
      diag.push({ url: sm, status: r.status, note: `sitemap index → ${locs.length} child sitemap(s)` });
    } else {
      [...doc.querySelectorAll('url')].forEach(node => {
        const loc = clean(node.querySelector('loc')?.textContent || '');
        if(!loc) return;
        foundUrls.add(loc);
        const lm = clean(node.querySelector('lastmod')?.textContent || '');
        if(lm) lastmodMap[loc] = lm;
      });
      // fallback if structure was flat
      locs.forEach(u => foundUrls.add(u));
      diag.push({ url: sm, status: r.status, note: `${locs.length} page URL(s)` });
    }
  }

  if(!foundUrls.size){
    renderDiscoverDiag(diag, guessed, siteHost);
    setErr('No pages found in a sitemap — see the breakdown below, or add pages manually.');
    return;
  }

  // normalize → unique paths on our host, minus assets
  const paths = new Set();
  const pathLastmod = {};
  const keptUrls = [];
  const truncated = foundUrls.size >= MAX_URLS;
  foundUrls.forEach(u => {
    try {
      const url = new URL(u);
      if(siteHost && url.hostname !== siteHost) return;
      if(SKIP_EXT.test(url.pathname)) return;
      const path = urlToPath(u);
      if(path !== null){
        paths.add(path);
        keptUrls.push(u);
        const lm = lastmodMap[u];
        if(lm && (!pathLastmod[path] || lm > pathLastmod[path])) pathLastmod[path] = lm;
      }
    } catch(e){}
  });

  const list = [...paths].sort((a,b)=> a.localeCompare(b));
  if(!list.length){ setErr('Sitemap had entries but none matched your site host.'); return; }

  // keep full list in memory; surface directory facets, not raw rows
  discovered = list.map(path => ({ path, lastmod: pathLastmod[path] || '' }));

  // persist the sitemap URL list for the 404 monitor — written ONLY on manual discovery,
  // so the dashboard box and the Cron worker both scan a fixed list until you discover again.
  try {
    var smUrls = Array.from(new Set(keptUrls));
    statePut('sitemap', { urls: smUrls, count: smUrls.length, updated: new Date().toISOString() })
      .catch(function(){});
  } catch(e){}
  const dirCounts = {};
  discovered.forEach(d => { const dir = dirOf(d.path); dirCounts[dir] = (dirCounts[dir]||0)+1; });
  dirInclude = {};
  Object.keys(dirCounts).forEach(dir => dirInclude[dir] = true);
  pageExclude = {};
  document.getElementById('discoveredPanel').style.display = 'block';
  document.getElementById('discoverDiag').innerHTML = '';
  renderDiscovered();
  updateRunHint();

  let msg = `Found ${discovered.length} page(s) across ${Object.keys(dirCounts).length} director${Object.keys(dirCounts).length===1?'y':'ies'}.`;
  if(truncated) msg += ' Very large sitemap — list may be partial.';
  setS(msg);
}

function renderDiscoverDiag(diag, guessed, siteHost){
  const box = document.getElementById('discoverDiag');
  if(!diag.length){ box.innerHTML = ''; return; }

  // work out the most likely cause for a targeted hint
  const statuses = diag.map(d => d.status);
  const all403 = diag.length && diag.every(d => d.status === 403);
  const anyHtml = diag.some(d => /HTML/i.test(d.note));
  const offHost = diag.find(d => { try { return new URL(d.url).hostname !== siteHost; } catch(e){ return false; } });
  let hint = '';
  if(all403){
    hint = 'Every request came back 403 — the worker is rejecting them. Check that ACCESS_KEY in config.js matches the worker\'s AUDIT_KEY exactly.';
  } else if(offHost && (offHost.status === 403 || offHost.status === 0)){
    let host = ''; try { host = new URL(offHost.url).hostname; } catch(e){}
    hint = `Your sitemap lives on ${host}, which the worker\'s allowlist blocks. Add "${host}" to ALLOWED_HOSTS in the worker and redeploy.`;
  } else if(anyHtml){
    hint = 'A request returned an HTML page instead of XML — often a WAF challenge or a "not found" page dressed up as 200. Open the URL below via Test connection to see what the server actually sends.';
  } else if(guessed && statuses.every(s => s === 404 || s === 0)){
    hint = 'No sitemap at robots.txt or the common filenames. If you know the real sitemap URL, tell me and I can point discovery straight at it.';
  } else {
    hint = 'Discovery reached the server but found no page URLs. The breakdown below shows each attempt.';
  }

  const rows = diag.map(d => {
    const bad = !(d.status >= 200 && d.status < 300);
    return `<li><span class="code ${bad?'bad':''}">${d.status || '—'}</span><span style="word-break:break-all;">${escapeHtml(d.url)}</span><span style="margin-left:auto;color:var(--muted-2);">${escapeHtml(d.note)}</span></li>`;
  }).join('');

  box.innerHTML = `<div style="margin-top:.8rem; border:1px solid var(--border); border-radius:8px; padding:1rem;">
    <div class="err-note" style="margin-bottom:.8rem;">${escapeHtml(hint)}</div>
    <div class="section-label" style="margin-top:0;">What discovery tried</div>
    <ul class="tech">${rows}</ul>
  </div>`;
}

/* ---- directory facets over the discovered list ---- */
function dirOf(path){
  if(path === '') return '(home)';
  const segs = path.split('/');
  return segs.length === 1 ? '(top level)' : segs[0];
}
function dirIncluded(dir){
  // Absent means included. dirInclude is an opt-out map; a directory discovered
  // after the map was saved must not silently vanish from every scope.
  return Object.prototype.hasOwnProperty.call(dirInclude, dir) ? !!dirInclude[dir] : true;
}
function pageIncluded(path){ return dirIncluded(dirOf(path)) && !pageExclude[path]; }
function effectiveDiscovered(){ return discovered.filter(d => pageIncluded(d.path)); }

function toggleDir(dir, on){ dirInclude[dir] = on; renderDiscovered(); updateRunHint(); }
function setAllDirs(on){
  var all = {};
  discovered.forEach(function(d){ all[dirOf(d.path)] = true; });
  Object.keys(dirInclude).forEach(function(d){ all[d] = true; });
  Object.keys(all).forEach(function(d){ dirInclude[d] = on; });
  renderDiscovered(); updateRunHint();
}
function togglePage(path, on){ if(on) delete pageExclude[path]; else pageExclude[path] = true; renderDiscSummary(); renderDiscSearch(); updateRunHint(); }

function renderDiscovered(){
  const dirCounts = {};
  discovered.forEach(d => { const dir = dirOf(d.path); dirCounts[dir] = (dirCounts[dir]||0)+1; });
  const dirs = Object.keys(dirCounts).sort((a,b)=> dirCounts[b]-dirCounts[a] || a.localeCompare(b));
  document.getElementById('dirList').innerHTML = dirs.map(dir => {
    const on = dirIncluded(dir);
    return `<label class="dir-row ${on?'':'off'}">
      <input type="checkbox" ${on?'checked':''} data-dir="${escapeAttr(dir)}" data-change="__toggleDir(this)">
      <span>${escapeHtml(dir)}</span>
      <span class="count">${dirCounts[dir]}</span>
    </label>`;
  }).join('');
  renderDiscSummary();
  renderDiscSearch();
}
function renderDiscSummary(){
  const total = discovered.length;
  const sel = effectiveDiscovered().length;
  const excl = Object.keys(pageExclude).filter(k=>pageExclude[k] && dirIncluded(dirOf(k))).length;
  document.getElementById('discSummary').innerHTML =
    `<strong>${sel}</strong> of ${total} discovered pages selected for audit` +
    (excl ? ` (${excl} individually excluded)` : '') + '.';
}
function renderDiscSearch(){
  const box = document.getElementById('discSearchResults');
  const q = (document.getElementById('discSearch').value||'').trim().toLowerCase();
  if(!q){ box.innerHTML = ''; return; }
  const matches = discovered.filter(d => ('/'+d.path).toLowerCase().includes(q));
  if(!matches.length){ box.innerHTML = `<div class="disc-results"><div class="res"><span class="path">No matching pages found.</span></div></div>`; return; }
  const CAP = 60;
  const rows = matches.slice(0, CAP).map(d => {
    const dirOn = dirIncluded(dirOf(d.path));
    const inc = pageIncluded(d.path);
    const tag = inc ? 'included' : (dirOn ? 'excluded' : 'directory off');
    return `<div class="res">
      <input type="checkbox" ${inc?'checked':''} ${dirOn?'':'disabled'} data-path="${escapeAttr(d.path)}" data-change="__togglePage(this)">
      <span class="path">/${escapeHtml(d.path)}</span>
      <span class="tag ${inc?'in':'out'}">${tag}</span>
    </div>`;
  }).join('');
  const more = matches.length > CAP ? `<div class="res"><span class="path">…and ${matches.length-CAP} more — refine your search.</span></div>` : '';
  box.innerHTML = `<div class="disc-results">${rows}${more}</div>`;
}

/* combined audit set: selected discovered pages + manual rows, deduped by path */
function getAuditPages(){
  const map = new Map();
  effectiveDiscovered().forEach(d => map.set(normPath(d.path), { name: prettyName(d.path), path: d.path, lastmod: d.lastmod || '' }));
  pages.forEach(pg => {
    if(!pg) return;
    const k = normPath(pg.path);
    if(pg.excluded){ map.delete(k); return; }
    if(pg.name) map.set(k, { name: pg.name, path: pg.path, lastmod: (map.get(k)||{}).lastmod || '' });
  });
  return [...map.values()];
}
function updateRunHint(){
  const n = getAuditPages().length;
  const t = langs.filter(l=>!l.ref).length;
  document.getElementById('runHint').textContent = n ? `Will audit ${n} page${n===1?'':'s'} × ${t} language${t===1?'':'s'}.` : '';
}

function onTransToggle(){
  const on = document.getElementById('transToggle').checked;
  document.getElementById('engine').disabled = !on;
  document.getElementById('transToggleLabel').textContent = on ? 'On' : 'Off';
}

/* ----------------------------- save / load to JSON ----------------------------- */
function setSaveStatus(msg, err){ const el = document.getElementById('saveStatus'); if(!el) return; el.textContent = msg; el.style.color = err ? 'var(--critical)' : 'var(--muted)'; }
function setReportStatus(msg, err){ ['reportStatus','inputStatus'].forEach(function(id){ var el = document.getElementById(id); if(el){ el.textContent = msg; el.style.color = err ? 'var(--critical)' : 'var(--muted)'; } }); }

function exportState(){
  const data = {
    version: 1,
    savedAt: new Date().toISOString(),
    site: SITE_URL,
    languages: langs.map(l => ({ label:l.label, dir:l.dir, ref:!!l.ref })),
    discovered: discovered,
    dirInclude: dirInclude,
    pageExclude: pageExclude,
    manualPages: pages.map(pg => ({ name:pg.name, path:pg.path, excluded:!!pg.excluded })),
    noTranslate: (document.getElementById('noTranslate') && document.getElementById('noTranslate').value) || '',
    excludeDirs: (document.getElementById('excludeDirs') && document.getElementById('excludeDirs').value) || '',
    linkResults: [...linkResults.entries()]
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type:'application/json' });
  const host = (()=>{ try { return new URL(SITE_URL).hostname; } catch(e){ return 'site'; } })();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `audit-${host}-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(a.href);
  setSaveStatus(`Saved ${discovered.length} page(s) and ${linkResults.size} link result(s).`);
}

function importState(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if(!data || typeof data !== 'object') throw new Error('bad file');
      discovered = Array.isArray(data.discovered) ? data.discovered : [];
      dirInclude = data.dirInclude && typeof data.dirInclude === 'object' ? data.dirInclude : {};
      pageExclude = data.pageExclude && typeof data.pageExclude === 'object' ? data.pageExclude : {};
      if(Array.isArray(data.manualPages)) pages = data.manualPages.map(pg => ({ id:p(), name:pg.name||'', path:pg.path||'', excluded:!!pg.excluded }));
      if(typeof data.noTranslate === 'string' && document.getElementById('noTranslate')) document.getElementById('noTranslate').value = data.noTranslate;
      if(typeof data.excludeDirs === 'string' && document.getElementById('excludeDirs')) document.getElementById('excludeDirs').value = data.excludeDirs;
      linkResults = new Map(Array.isArray(data.linkResults) ? data.linkResults : []);
      if(discovered.length){ document.getElementById('discoveredPanel').style.display = 'block'; renderDiscovered(); }
      renderPages();
      updateRunHint();
      const when = data.savedAt ? new Date(data.savedAt).toLocaleString() : 'unknown date';
      let note = `Loaded ${discovered.length} page(s) and ${linkResults.size} saved link result(s) from ${when}.`;
      if(data.site && data.site !== SITE_URL) note += ` (Saved site was ${data.site} — current is ${SITE_URL}.)`;
      setSaveStatus(note);
    } catch(e){
      setSaveStatus('Could not read that file — is it a saved audit JSON?', true);
    }
  };
  reader.readAsText(file);
}

/* ----------------------------- export results as a report ----------------------------- */
function downloadBlob(content, mime, filename){
  const blob = new Blob([content], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(a.href);
}
function reportHost(){ try { return new URL(SITE_URL).hostname; } catch(e){ return 'site'; } }

/* Power BI export: flattens the current audit into one-row-per-record CSV tables.
   Same shape the Worker endpoint serves. */
function csvCell(v){
  if(v === null || v === undefined) return '';
  var str = String(v);
  if(/[",\r\n]/.test(str)) return '"' + str.replace(/"/g, '""') + '"';
  return str;
}
function toCSV(columns, rows){
  var head = columns.map(function(c){ return csvCell(c.header); }).join(',');
  var body = rows.map(function(r){
    return columns.map(function(c){ return csvCell(c.get(r)); }).join(',');
  });
  return '\ufeff' + [head].concat(body).join('\r\n');   // BOM so Excel/Power BI read UTF-8
}
function powerBITables(){
  var D = currentDashData() || {};
  var host = (D.meta && D.meta.host) || reportHost();
  var triage = triageState || {};

  var findings = (D.findings || []).map(function(f){
    var t = triage[f.key]; var status = (t && t.status) ? t.status : 'open';
    return { host:host, page:f.page, path:f.path, section:f.dir, area:f.section,
             language:f.lang, issue:f.category, severity:f.severity, status:status,
             detail:f.detail || '' };
  });

  var s404 = [];
  var sm = sitemap404;
  if(sm && sm.urls){
    var newSet = {}; (sm.newUrls || []).forEach(function(u){ newSet[u] = 1; });
    Object.keys(sm.urls).forEach(function(u){
      s404.push({ host:host, url:u, first_seen:(sm.urls[u].firstSeen || ''),
                  is_new:(newSet[u] ? 'yes' : 'no'), last_checked:(sm.checked || '') });
    });
  }

  var cov = ((D.coverage && D.coverage.missing) || []).map(function(m){
    var disc = (D.coverage && D.coverage.discovered) || 0;
    return { host:host, language:m.lang, discovered:disc, missing:m.count, live:Math.max(0, disc - m.count) };
  });

  var stale = (D.contentDates || []).map(function(r){
    return { host:host, path:r.path, last_updated:(r.updated || ''), updated_by:(r.updatedBy || ''),
             created:(r.created || ''), created_by:(r.createdBy || '') };
  });

  return { findings:findings, sitemap_404:s404, coverage:cov, stale:stale };
}
function pbiSpecs(){
  var t = powerBITables();
  return [
    { name:'findings', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'page',get:function(r){return r.page;}},
      {header:'path',get:function(r){return r.path;}}, {header:'section',get:function(r){return r.section;}},
      {header:'area',get:function(r){return r.area;}}, {header:'language',get:function(r){return r.language;}},
      {header:'issue',get:function(r){return r.issue;}}, {header:'severity',get:function(r){return r.severity;}},
      {header:'status',get:function(r){return r.status;}}, {header:'detail',get:function(r){return r.detail;}}
    ], rows:t.findings },
    { name:'sitemap_404', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'url',get:function(r){return r.url;}},
      {header:'first_seen',get:function(r){return r.first_seen;}}, {header:'is_new',get:function(r){return r.is_new;}},
      {header:'last_checked',get:function(r){return r.last_checked;}}
    ], rows:t.sitemap_404 },
    { name:'coverage', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'language',get:function(r){return r.language;}},
      {header:'discovered',get:function(r){return r.discovered;}}, {header:'missing',get:function(r){return r.missing;}},
      {header:'live',get:function(r){return r.live;}}
    ], rows:t.coverage },
    { name:'stale', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'path',get:function(r){return r.path;}},
      {header:'last_updated',get:function(r){return r.last_updated;}}, {header:'updated_by',get:function(r){return r.updated_by;}},
      {header:'created',get:function(r){return r.created;}}, {header:'created_by',get:function(r){return r.created_by;}}
    ], rows:t.stale }
  ];
}
function downloadPBITable(name, btn){
  var sp = pbiSpecs().filter(function(s){ return s.name === name; })[0];
  if(!sp) return;
  var stamp = new Date().toISOString().slice(0,10);
  downloadBlob(toCSV(sp.cols, sp.rows), 'text/csv;charset=utf-8', 'audit-' + sp.name + '-' + reportHost() + '-' + stamp + '.csv');
  flashBtnOk(btn, 'Downloaded');
}
function exportPowerBICsv(){
  var specs = pbiSpecs();
  var host = reportHost();
  var stamp = new Date().toISOString().slice(0,10);
  var i = 0;
  (function next(){
    if(i >= specs.length){ setReportStatus('Exported ' + specs.length + ' CSV tables for Power BI.'); return; }
    var sp = specs[i++];
    downloadBlob(toCSV(sp.cols, sp.rows), 'text/csv;charset=utf-8', 'audit-' + sp.name + '-' + host + '-' + stamp + '.csv');
    setTimeout(next, 350);   // stagger so browsers don't block the batch
  })();
}

/* Cross-user store for triage marks and the latest run: KV endpoint when STATE_URL
   is set, else this browser's localStorage. */
let triageState = {};      // { findingKey: { status:'done'|'ignored', at } }
let sharedDash  = null;    // a published dashboard-data object (for viewers who didn't run locally)
let sitemap404  = null;    // { urls:{url:{firstSeen}}, checked, total, dead, newCount } — saved 404 list
let storeMode   = (STATE_URL && STATE_URL.trim()) ? 'remote' : 'local';
let _lastTriageSaveAt = 0;
function stateNs(){ return 'mlaudit:' + reportHost(); }
function stateEndpoint(key){
  const base = (STATE_URL || '').trim();
  try { const u = new URL(base); u.searchParams.set('key', stateNs() + ':' + key); return u.href; }
  catch(e){ return base + (base.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(stateNs() + ':' + key); }
}
async function stateGet(key){
  if(storeMode === 'local'){
    try { const v = localStorage.getItem(stateNs() + ':' + key); return v ? JSON.parse(v) : null; } catch(e){ return null; }
  }
  const res = await fetch(stateEndpoint(key), fetchOpts());
  if(res.status === 404) return null;
  if(!res.ok) throw new Error('HTTP ' + res.status);
  const txt = await res.text();
  return txt ? JSON.parse(txt) : null;
}
async function statePut(key, value){
  if(storeMode === 'local'){
    try { localStorage.setItem(stateNs() + ':' + key, JSON.stringify(value)); return true; } catch(e){ return false; }
  }
  const res = await fetch(stateEndpoint(key), fetchOpts({ method:'PUT', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(value) }));
  if(!res.ok) throw new Error('HTTP ' + res.status);
  return true;
}
let _triageSaveTimer = null;
function saveTriageSoon(){
  clearTimeout(_triageSaveTimer);
  _triageSaveTimer = setTimeout(function(){
    _lastTriageSaveAt = Date.now();
    statePut('triage', triageState).then(function(){ setStoreStatus(); }).catch(function(err){ setStoreStatus('save failed'); });
  }, 600);
}
function setTriage(key, status){
  if(!key) return;
  if(status === 'open'){ delete triageState[key]; }
  else { triageState[key] = { status: status, at: new Date().toISOString() }; }
  saveTriageSoon();
  setStoreStatus();
}
async function loadSharedState(force){
  // skip a remote re-pull right after we just saved (avoid clobbering our own change)
  if(!force && storeMode === 'remote' && Date.now() - _lastTriageSaveAt < 2000) return;
  function sig(){ return JSON.stringify(triageState) + '|' + (sharedDash && sharedDash.meta ? sharedDash.meta.generated : '') + '|' + (sitemap404 ? sitemap404.checked : ''); }
  var before = sig();
  try { const t = await stateGet('triage'); if(t && typeof t === 'object') triageState = t; } catch(e){}
  try { const s = await stateGet('sitemap404'); if(s && s.urls) sitemap404 = s; } catch(e){}
  if(!(auditState && auditState.results && auditState.results.length)){
    try { const r = await stateGet('run'); if(r && r.data) sharedDash = r.data; } catch(e){}
  }
  setStoreStatus();
  renderNotifBell();
  if(sig() !== before){            // only rebuild the iframe when something actually changed
    markDashStale();
    refreshDashIfVisible();
  }
}
async function publishRun(){
  if(!(auditState && auditState.results && auditState.results.length)){ setReportStatus('Run an audit first.', true); return false; }
  const payload = { type:'mlaudit-run', at:new Date().toISOString(), host:reportHost(), data: buildDashboardData() };
  try {
    await statePut('run', payload);
    setReportStatus(storeMode === 'remote'
      ? 'Run published to the shared store — everyone now sees this audit.'
      : 'Run saved to this browser. Set STATE_URL (see audit-state-worker.js) to share it across users.');
    return true;
  } catch(e){ setReportStatus('Could not publish the run: ' + e.message, true); return false; }
}
// ---- sitemap 404 monitor (uses the saved sitemap list; does NOT re-fetch the sitemap) ----
async function check404(url){
  try {
    const res = await fetch(proxifyCheck(url), fetchOpts());
    const ct = res.headers.get('content-type') || '';
    if(ct.includes('application/json')){ const d = await res.json(); return { url, status: d.status || 0 }; }
    return { url, status: res.status };
  } catch(e){ return { url, status: 0 }; }
}
async function scanSitemap404s(onProgress){
  // load the saved sitemap URL list (written only on manual discovery)
  let urls = [];
  try { const sm = await stateGet('sitemap'); if(sm && Array.isArray(sm.urls)) urls = sm.urls; } catch(e){}
  if(!urls.length && discovered && discovered.length){
    var baseU = SITE_URL.replace(/\/+$/,'');
    urls = discovered.map(function(d){ return d.path ? (baseU + '/' + d.path.replace(/^\/+/,'')) : baseU; });
  }
  if(!urls.length) return { error:'no-sitemap' };
  // drop English-only sections (e.g. newsroom) so they aren't 404-checked
  var exclDirs = getExcludeDirs();
  try { statePut('excludeDirs', { dirs: exclDirs, updated: new Date().toISOString() }).catch(function(){}); } catch(e){}
  if(exclDirs.length){ urls = urls.filter(function(u){ return !pathIsExcluded(urlToPath(u), exclDirs); }); }
  if(!urls.length) return { error:'no-sitemap' };
  let done = 0;
  const results = await pool(urls, async function(u){ const r = await check404(u); done++; if(onProgress) onProgress(done, urls.length); return r; }, 6);
  const dead = results.filter(function(r){ return r.status === 404; }).map(function(r){ return r.url; });
  // merge with the saved list, preserving firstSeen for ones we already knew
  let prev = {};
  try { const k = await stateGet('sitemap404'); if(k && k.urls) prev = k.urls; } catch(e){}
  const now = new Date().toISOString();
  const merged = {}; const newOnes = [];
  dead.forEach(function(u){ if(prev[u]){ merged[u] = prev[u]; } else { merged[u] = { firstSeen: now }; newOnes.push(u); } });
  const rec = { urls: merged, checked: now, total: urls.length, dead: dead.length, newCount: newOnes.length, newUrls: newOnes };
  sitemap404 = rec;
  try { await statePut('sitemap404', rec); } catch(e){}
  markDashStale(); refreshDashIfVisible(); renderNotifBell();
  return rec;
}

function setStoreStatus(extra){
  const el = document.getElementById('storeStatus'); if(!el) return;
  const done = vals.filter(function(t){ return t && t.status === 'done'; }).length;
  const ign  = vals.filter(function(t){ return t && t.status === 'ignored'; }).length;
  const mode = storeMode === 'remote' ? 'Shared store · team-wide' : 'Local only · this browser';
  el.textContent = mode + ' · ' + done + ' done · ' + ign + ' ignored' + (extra ? (' · ' + extra) : '');
}
function filterSharedDash(src){
  // Published runs are pre-computed; still drop pages later marked "Skip" and
  // recompute derived fields from what's left.
  const EXCL = excludedManualPathSet();
  if(!EXCL.size) return Object.assign({}, src);
  const d = JSON.parse(JSON.stringify(src));
  const keep = f => !EXCL.has(normPath(f.path));
  d.findings = (d.findings || []).filter(keep);
  if(Array.isArray(d.pages)) d.pages = d.pages.filter(p => !EXCL.has(normPath(p.path)));
  if(Array.isArray(d.missingTranslations)) d.missingTranslations = d.missingTranslations.filter(m => !EXCL.has(normPath(m.path)));
  // recompute summary + rollups from the filtered findings
  let c=0,w=0,i=0,b=0;
  d.findings.forEach(f => { if(f.category === 'broken link'){ b++; return; } if(f.severity==='critical')c++; else if(f.severity==='warning')w++; else i++; });
  d.summary = { critical:c, warning:w, info:i, broken:b, pages:(d.pages? d.pages.length : d.summary.pages) };
  const cb = (arr, prop) => { const o={}; arr.forEach(x=>{ const k=x[prop]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; };
  d.rollups = { byLang:cb(d.findings,'lang'), byCategory:cb(d.findings,'category'), byDir:cb(d.findings,'dir'), bySeverity:cb(d.findings,'severity') };
  if(d.coverage) d.coverage.audited = d.pages ? d.pages.length : d.coverage.audited;
  return d;
}
function currentDashData(){
  let d = null;
  if(auditState && auditState.results && auditState.results.length){ d = buildDashboardData(); }
  else if(sharedDash){ d = filterSharedDash(sharedDash); }
  if(d){ d.triage = triageState; d.storeMode = storeMode; d.canRun = (userRole === 'admin'); d.hasLocalRun = !!(auditState && auditState.results && auditState.results.length); d.sitemap404 = sitemap404; }
  return d;
}

/* ---- unified findings model (one normalized row per issue, with a stable key) ---- */
function findingSubject(f){
  if(f.section === 'Links') return f.detail;          // the URL identifies the link
  if(f.category === 'placeholder text') return f.detail;
  return '';                                           // otherwise the issue is category-level
}
function keyFor(f){
  return [f.path||'', f.lang||'', f.section||'', f.category||'', findingSubject(f)].join('||').toLowerCase();
}
/* Content fingerprints: a normalized hash of a page's visible text, so we can tell
   "English changed since the translation was approved" from ordinary QA drift. */
function cyrb53(str, seed){
  seed = seed || 0;
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for(let i = 0, ch; i < str.length; i++){
    ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
function contentFingerprint(data){
  if(!data) return null;
  // Title + meta + ordered content segments. Numbers/dates are intentionally KEPT
  // (a changed % or year is a meaningful English change we want to catch).
  const parts = [data.title || '', data.metaDesc || ''].concat(data.segments || []);
  let s = parts.join('\u0001');
  try { s = s.normalize('NFC'); } catch(e){}
  s = s.replace(/\s+/g, ' ').trim();
  return cyrb53(s);
}
function currentFingerprints(){
  const en = {}, tr = {};
  (auditState.results || []).forEach(r => {
    const pk = r.page.path || '';
    if(r.enFp != null) en[pk] = r.enFp;
    (r.languages || []).forEach(b => { if(b.trFp != null) tr[pk + '||' + b.lang.label] = b.trFp; });
  });
  return { en, tr };
}
function normPath(p){
  var s = String(p == null ? '' : p).trim();
  if(s === '(home)') return '';
  return s.replace(/^\/+|\/+$/g, '');
}
function excludedManualPathSet(){
  const s = new Set();
  pages.forEach(pg => { if(pg && pg.excluded) s.add(normPath(pg.path)); });
  return s;
}
function flattenFindings(){
  const out = [];
  const EXCL = excludedManualPathSet();
  (auditState.results||[]).forEach(r => {
    const path = r.page.path || '';
    if(EXCL.has(normPath(path))) return; // skipped in Audit Settings — treat as removed from current data
    const page = r.page.name;
    const dir = (dirOf(path) || '(top level)');
    const base = (lang, section, cat, sev, detail, suggestion, snippet, items, evidenceLabel) =>
      out.push({ page, path, dir, lang, section, category: cat, severity: sev, detail: detail||'', suggestion: suggestion||'', snippet: snippet||'', items: items||null, evidenceLabel: evidenceLabel||'' });
    const fromIssue = (lang, section, is) => {
      let items = is.items || null, label = is.evidenceLabel || '';
      if(!items && (is.reference || is.translation)){
        items = [];
        if(is.reference) items.push('Expected (source): ' + is.reference);
        if(is.translation) items.push('On the page: ' + is.translation);
        label = 'Compared text';
      }
      base(lang, section, is.category||section.toLowerCase(), is.severity||'info', is.explanation||'', is.suggestion||'', is.snippet||'', items, label);
    };

    if(r.refError) base('English (reference)','Fetch','load error','critical', r.refError);
    if(r.refTech){
      r.refTech.code.forEach(c => base('English (reference)','Code','code', c.sev, c.text, '', c.snippet, c.items, c.evidenceLabel));
      r.refTech.links.forEach(l => base('English (reference)','Links','broken link','critical', l.url, '', l.snippet));
    }
    (r.languages||[]).forEach(b => {
      const lang = b.lang.label;
      if(b.error){ base(lang,'Fetch','load error','critical', b.error); return; }
      if(b.drift) (b.drift.issues||[]).forEach(is => fromIssue(lang,'Drift', is));
      if(b.ai) (b.ai.issues||[]).forEach(is => fromIssue(lang,'Translation (Claude)', is));
      (b.parity||[]).forEach(is => fromIssue(lang,'Sections & parity', is));
      (b.content||[]).forEach(is => fromIssue(lang,'Content & SEO', is));
      if(b.tech){
        b.tech.code.forEach(c => base(lang,'Code','code', c.sev, c.text, '', c.snippet, c.items, c.evidenceLabel));
        b.tech.links.forEach(l => base(lang,'Links','broken link','critical', l.url, '', l.snippet));
      }
      // Source sync: did English change after this translation was approved?
      if(baseline && baseline.fp && baseline.fp.en){
        const baseEn = baseline.fp.en[path];
        const curEn = r.enFp;
        if(baseEn != null && curEn != null && curEn !== baseEn){
          const baseTr = (baseline.fp.tr || {})[path + '||' + lang];
          const curTr = b.trFp;
          const approvedOn = baseline.approvedAt ? (' on ' + new Date(baseline.approvedAt).toLocaleDateString()) : '';
          if(baseTr != null && curTr != null && curTr === baseTr){
            base(lang,'Source sync','source changed, translation stale','warning',
              'English changed after this translation was approved' + approvedOn + ', but the ' + lang + ' page has not been updated since.',
              'Re-translate this page to match the updated English source.');
          } else if(baseTr != null && curTr != null && curTr !== baseTr){
            base(lang,'Source sync','source & translation both changed','info',
              'Both the English source and the ' + lang + ' translation changed since the approved baseline' + approvedOn + '. Confirm the translation reflects the new English.',
              'Review to confirm the translation is in sync with the new English.');
          }
        }
      }
    });
  });
  out.forEach(f => f.key = keyFor(f));
  return out;
}
function countBy(arr, prop){ const o = {}; arr.forEach(x => { const k = x[prop]||'—'; o[k] = (o[k]||0)+1; }); return o; }

/* ---- snapshot save + baseline load for trend tracking ---- */
let baseline = null;
function buildSnapshotObj(){
  const f = flattenFindings();
  return {
    type:'audit-snapshot', version:1, site: reportHost(),
    date: new Date().toISOString(),
    counts: { critical:auditState.crit, warning:auditState.warn, info:auditState.info, broken:auditState.broken, pages:auditState.pages },
    total: f.length,
    keys: f.map(x => x.key),
    byCategory: countBy(f, 'category'),
    byLang: countBy(f, 'lang'),
    fp: currentFingerprints()
  };
}
function exportSnapshot(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  downloadBlob(JSON.stringify(buildSnapshotObj()), 'application/json', `audit-snapshot-${reportHost()}-${new Date().toISOString().slice(0,10)}.json`);
  setReportStatus('Snapshot saved. Load it as the baseline before your next audit to track what changed.');
}
function approveBaseline(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  const obj = buildSnapshotObj();
  obj.approved = true;
  obj.approvedAt = obj.date;
  const fpEn = Object.keys(obj.fp.en || {}).length;
  downloadBlob(JSON.stringify(obj), 'application/json', `audit-baseline-${reportHost()}-${new Date().toISOString().slice(0,10)}.json`);
  setReportStatus(`Approved baseline saved (${fpEn} page fingerprint(s)). Load it before your next audit to flag pages where English changed after approval.`);
}
function loadBaseline(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const j = JSON.parse(e.target.result);
      if(j.type !== 'audit-snapshot') throw new Error('bad type');
      baseline = j;
      markDashStale();
      refreshDashIfVisible();
      const fpN = (j.fp && j.fp.en) ? Object.keys(j.fp.en).length : 0;
      const appr = j.approved ? `Approved baseline from ${new Date(j.approvedAt || j.date).toLocaleDateString()}` : `Baseline from ${new Date(j.date).toLocaleDateString()}`;
      setReportStatus(`${appr} loaded — ${j.keys.length} prior finding(s)` + (fpN ? `, ${fpN} page fingerprint(s) for source-change detection` : '') + '. The dashboards will show what changed since then.');
    } catch(err){ setReportStatus('That isn’t a valid audit snapshot file.', true); }
  };
  reader.readAsText(file);
}
function trendVsBaseline(currentKeys){
  if(!baseline) return { hasBaseline:false };
  const cur = new Set(currentKeys), base = new Set(baseline.keys);
  let resolved = 0, persisting = 0, added = 0;
  base.forEach(k => { if(cur.has(k)) persisting++; else resolved++; });
  cur.forEach(k => { if(!base.has(k)) added++; });
  return { hasBaseline:true, date: baseline.date, resolved, persisting, added,
           wasTotal: baseline.total, nowTotal: currentKeys.length,
           wasCounts: baseline.counts };
}

/* ---- Sitecore content dates (from the "Items last updated" export) ---- */
let contentDates = null; // array of { name, path, updated, updatedBy, created, createdBy, isComponent }
function parseScDate(s){
  if(!s) return '';
  const d = new Date(s);                 // handles "6/1/2026 10:43:28 PM"
  return isNaN(d.getTime()) ? '' : d.toISOString();
}
function scRelPath(fullPath){
  let p = (fullPath||'').toLowerCase().replace(/\\/g,'/');
  if(p.startsWith(SITECORE_ROOT)) p = p.slice(SITECORE_ROOT.length);
  return p.replace(/^\/+|\/+$/g,'');
}
function loadContentDates(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const rows = JSON.parse(e.target.result);
      if(!Array.isArray(rows) || !rows.length || !('Updated' in rows[0]) || !('Path' in rows[0])) throw new Error('shape');
      contentDates = rows.map(r => {
        const rel = scRelPath(r.Path);
        return {
          name: r.Name || '',
          path: rel || '(home)',
          updated: parseScDate(r.Updated),
          updatedBy: (r['Updated by']||'').replace(/^sitecore\\/i,''),
          created: parseScDate(r.Created),
          createdBy: (r['Created by']||'').replace(/^sitecore\\/i,''),
          isComponent: /(^|\/)(page datasources|datasources)(\/|$)/.test(rel)
        };
      });
      const pages = contentDates.filter(r => !r.isComponent).length;
      markDashStale();
      refreshDashIfVisible();
      setReportStatus(`Loaded ${contentDates.length} Sitecore item(s) — ${pages} page(s) with real publish dates. They’ll drive the stale-content view in the dashboard.`);
    } catch(err){
      setReportStatus('That isn’t a valid "Items last updated" JSON export.', true);
    }
  };
  reader.readAsText(file);
}

/* ---- two-view dashboard (Authors + Leaders) ---- */
function buildDashboardData(){
  const findings = flattenFindings();
  const EXCL = excludedManualPathSet();
  const activeResults = (auditState.results||[]).filter(r => !EXCL.has(normPath(r.page.path)));
  const missing = {};
  activeResults.forEach(r => (r.languages||[]).forEach(b => { if(b.error) missing[b.lang.label] = (missing[b.lang.label]||0)+1; }));
  // Foreign-language pages that 404'd during the audit (missing translations). Derived
  // here, not by the sitemap monitor, so the 404 box can show them.
  const missingTranslations = [];
  activeResults.forEach(r => (r.languages||[]).forEach(b => {
    if(b.error) missingTranslations.push({
      page: r.page.name, path: r.page.path || '', lang: b.lang.label,
      url: b.url || '', error: b.error
    });
  }));
  const pages = activeResults.map(r => ({
    path: r.page.path || '(home)', name: r.page.name, lastmod: r.page.lastmod || ''
  }));
  // Recount from the filtered findings (not the live-run counters) so "Skip" takes
  // effect immediately without re-running.
  let sCrit=0, sWarn=0, sInfo=0, sBroken=0;
  findings.forEach(f => {
    if(f.category === 'broken link'){ sBroken++; return; }
    if(f.severity === 'critical') sCrit++; else if(f.severity === 'warning') sWarn++; else sInfo++;
  });
  return {
    meta: {
      host: reportHost(),
      generated: new Date().toLocaleString(),
      langs: langs.filter(l=>!l.ref).map(l=>l.label),
      translationCheck: (document.getElementById('transToggle') && document.getElementById('transToggle').checked)
        ? ((document.getElementById('engine')||{}).value || 'on') : 'off'
    },
    now: Date.now(),
    summary: { critical:sCrit, warning:sWarn, info:sInfo, broken:sBroken, pages:activeResults.length },
    findings,
    rollups: {
      byLang: countBy(findings, 'lang'),
      byCategory: countBy(findings, 'category'),
      byDir: countBy(findings, 'dir'),
      bySeverity: countBy(findings, 'severity')
    },
    coverage: {
      discovered: (discovered && discovered.length) || 0,
      audited: activeResults.length,
      missing: Object.keys(missing).map(k => ({ lang:k, count:missing[k] }))
    },
    pages,
    missingTranslations,
    contentDates: (contentDates ? contentDates.filter(r => !r.isComponent) : null),
    sync: {
      hasBaseline: !!(baseline && baseline.fp && baseline.fp.en),
      approvedAt: (baseline && baseline.approvedAt) || null,
      stale: findings.filter(f => f.category === 'source changed, translation stale').length,
      bothChanged: findings.filter(f => f.category === 'source & translation both changed').length
    },
    trend: trendVsBaseline(findings.map(f => f.key))
  };
}
/* on-page view switching between detailed results and the embedded dashboard */
let dashFrameStale = true;
function markDashStale(){ dashFrameStale = true; }
function ensureDashFrame(targetTab){
  const frame = document.getElementById('dashFrame');
  if(dashFrameStale){
    frame.onload = function(){
      try {
        frame.contentWindow.postMessage('hidetabs', '*');
        frame.contentWindow.postMessage('tab:' + targetTab, '*');
      } catch(e){}
    };
    window.__DASH_PAYLOAD__ = currentDashData() || buildDashboardData();
    frame.srcdoc = buildDashboardHtml();
    dashFrameStale = false;
  } else {
    try { frame.contentWindow.postMessage('tab:' + targetTab, '*'); } catch(e){}
  }
}
let currentDashTab = 'authors';
function dashHasData(){ return !!((auditState && auditState.results && auditState.results.length) || sharedDash); }
let userRole = null, loginRole = 'admin';
function pickRole(r){
  loginRole = r;
  document.querySelectorAll('#roleToggle .role-opt').forEach(function(b){ b.classList.toggle('active', b.dataset.role === r); });
}
function showLoginError(msg){ var e=document.getElementById('loginError'); if(e){ e.textContent=msg; e.style.display = msg ? 'block' : 'none'; } }
async function validatePassphrase(){
  // Best-effort: a clear 403 means wrong passphrase. Anything else, let them through
  // (downstream requests still enforce the key on every call).
  if(STATE_URL && STATE_URL.trim()){
    try { await stateGet('triage'); return true; }
    catch(e){ return false; }
  }
  try {
    var r = await fetchPage(SITE_URL);
    if(r && (r.status === 403 || /\b403\b|forbidden|passphrase|unauthor/i.test(r.error || ''))) return false;
    return true;
  } catch(e){ return true; }
}
function submitLogin(){
  showLoginError('');
  enterApp(loginRole);
}
function buildTabsForRole(role){
  var nav = document.getElementById('pageTabs');
  if(role === 'admin'){
    nav.style.display = '';
    nav.innerHTML =
        '<button class="ptab" data-page="leaders" data-click="showPage(\'leaders\')">Admin</button>'
      + '<button class="ptab" data-page="authors" data-click="showPage(\'authors\')">Authors</button>'
      + '<button class="ptab" data-page="aep" data-click="showPage(\'aep\')">AEP Launch</button>'

      + '<button class="ptab" data-page="generate" data-click="showPage(\'generate\')">Audit Settings</button>'
      + '<button class="pbi-btn" data-click="showPage(\'pbi\')" title="Power BI import instructions" aria-label="Power BI import instructions">'
      +   '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h11l5 5v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"></path><path d="M14 4v6h6"></path><path d="M8 13h8M8 17h5"></path></svg>'
      +   '<span>Power BI Import Instructions</span></button>';
  } else {
    nav.style.display = 'none';
  }
}
function enterApp(role){
  try {
    if(WORKER_KEY && typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.set({ auditKey: WORKER_KEY });
  } catch(e){}
  userRole = role;
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('appShell').style.display = 'block';
  buildTabsForRole(role);
  try { sessionStorage.setItem('mlaudit-session', JSON.stringify({ role: role })); } catch(e){}
  loadSharedState(true);
  loadManualPages();
  loadDiscovered();
  showPage(role === 'admin' ? 'leaders' : 'authors');
}
function openSettingsModal(){
  var m=document.getElementById('settingsModal'); if(m) m.style.display='flex';
  var cr = document.getElementById('cfgRole'); if(cr) cr.textContent = userRole === 'admin' ? 'Admin' : 'Author';
  document.querySelectorAll('#settingsRoleToggle .role-opt').forEach(function(b){ b.classList.toggle('active', b.dataset.role === userRole); });
}
function closeSettingsModal(){ var m=document.getElementById('settingsModal'); if(m) m.style.display='none'; }
function openPowerBIModal(){ showPage('pbi'); }
/* Guided tour for whichever tab is showing. The dashboard renders in an iframe,
   so its tour has to run in there. */
var aepPromptDismissed = false;
/* The header button is the minimised form of the prompt: hidden while the prompt
   is up, shown once it is dismissed, and only ever on the AEP page. */
function setTourBtnVisible(on){
  var b = document.getElementById('tourBtn');
  if(b) b.style.display = on ? 'inline-flex' : 'none';
}
window.onTourDismissed = function(){
  aepPromptDismissed = true;
  setTourBtnVisible(currentPageId === 'aep');
};
window.onTourStarted = function(){ setTourBtnVisible(currentPageId === 'aep'); };
function maybeOpenAepPrompt(){
  if(currentPageId !== 'aep'){ setTourBtnVisible(false); return; }
  setTourBtnVisible(true);            // always available on this page
  if(aepPromptDismissed) return;
  setTimeout(function(){
    if(currentPageId !== 'aep' || aepPromptDismissed) return;
    if(window.SiteAuditTour) window.SiteAuditTour.start('aep', document);
  }, 260);
}
function startTabTour(){
  var p = currentPageId || 'leaders';
  // Tours are AEP-only for now. The dashboard, Audit Settings and Power BI step
  // sets still exist in tour.js — re-enable by restoring the branches below.
  // if(p === 'leaders' || p === 'authors'){
  //   var f = document.getElementById('dashFrame');
  //   try { f.contentWindow.postMessage('tour:dash', '*'); } catch(e){}
  //   return;
  // }
  // var key = (p === 'generate') ? 'generate' : (p === 'pbi' ? 'pbi' : p);
  if(p !== 'aep') return;
  if(window.SiteAuditTour) window.SiteAuditTour.start('aep', document);
}
/* Transient green check on a button, followed by a persistent green "done"
   indicator for the rest of the session. Purely visual — the button stays
   enabled and clickable throughout, and clicking again just re-flashes it. */
function flashBtnOk(btn, msg){
  if(!btn) return;
  if(btn._flashT) clearTimeout(btn._flashT);
  if(btn.getAttribute('data-flash-label') === null){
    btn.setAttribute('data-flash-label', btn.innerHTML);
  }
  btn.innerHTML = '<span class="fchk" aria-hidden="true">\u2713</span>' + escapeHtml(msg || 'Done');
  btn.classList.add('btn-flash-ok');
  btn.classList.add('btn-done'); // persists for the rest of the session
  btn._flashT = setTimeout(function(){
    var prev = btn.getAttribute('data-flash-label');
    if(prev !== null) btn.innerHTML = prev;
    btn.classList.remove('btn-flash-ok'); // checkmark/text-swap ends
    btn.removeAttribute('data-flash-label');
    btn._flashT = null;
    // .btn-done is intentionally left on — that's the persistent indicator
  }, 1800);
}
function copyPBIUrl(table, btn){
  var url = 'https://audit-state.bcbs-of-az.workers.dev/?export=' + table + '&format=csv&token=powerbitoken';
  function flash(){ flashBtnOk(btn, 'Copied'); }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(url).then(flash, function(){ pbiFallbackCopy(url); flash(); });
  } else { pbiFallbackCopy(url); flash(); }
}
function pbiFallbackCopy(text){
  try {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.focus(); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta);
  } catch(e){}
}
function drawPbiConnectors(){
  var flow = document.getElementById('pbiFlow'), svg = document.getElementById('pbiConnectors');
  if(!flow || !svg) return;
  var a = document.getElementById('pbiOptA'), bnode = document.getElementById('pbiOptB'), c = document.getElementById('pbiConfig');
  if(!a || !bnode || !c) return;
  if(window.innerWidth <= 900){ svg.innerHTML = ''; return; }
  var fr = flow.getBoundingClientRect();
  if(!fr.width) return;
  svg.setAttribute('width', fr.width); svg.setAttribute('height', fr.height);
  svg.setAttribute('viewBox', '0 0 ' + fr.width + ' ' + fr.height);
  var ra = a.getBoundingClientRect(), rb = bnode.getBoundingClientRect(), rc = c.getBoundingClientRect();
  var ax = ra.right - fr.left, ay = ra.top + ra.height/2 - fr.top;
  var bx = rb.right - fr.left, by = rb.top + rb.height/2 - fr.top;
  var tx = rc.left - fr.left, tcy = rc.top + rc.height/2 - fr.top;
  function seg(sx, sy, ex, ey){ var dx = Math.max(48, (ex - sx) * 0.55); return 'M ' + sx + ' ' + sy + ' C ' + (sx+dx) + ' ' + sy + ' ' + (ex-dx) + ' ' + ey + ' ' + ex + ' ' + ey; }
  var S = '#8a8a8a';
  svg.innerHTML =
    '<defs><marker id="pbiArrow" markerWidth="9" markerHeight="9" refX="6.5" refY="4" orient="auto" markerUnits="userSpaceOnUse">'
    + '<path d="M1,1 L6.5,4 L1,7" fill="none" stroke="' + S + '" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>'
    + '<path d="' + seg(ax, ay, tx, tcy - 14) + '" fill="none" stroke="' + S + '" stroke-width="1.6" marker-end="url(#pbiArrow)"/>'
    + '<path d="' + seg(bx, by, tx, tcy + 14) + '" fill="none" stroke="' + S + '" stroke-width="1.6" marker-end="url(#pbiArrow)"/>';
}
var _pbiResizeT;
window.addEventListener('resize', function(){
  clearTimeout(_pbiResizeT);
  _pbiResizeT = setTimeout(function(){
    var el = document.getElementById('page-pbi');
    if(el && el.style.display !== 'none') drawPbiConnectors();
  }, 120);
});
function closePowerBIModal(){ showPage('leaders'); }
function switchRole(role){
  if(role === userRole) return;
  userRole = role;
  buildTabsForRole(role);
  try {
    var s = JSON.parse(sessionStorage.getItem('mlaudit-session') || 'null') || {};
    s.role = role;
    sessionStorage.setItem('mlaudit-session', JSON.stringify(s));
  } catch(e){}
  closeSettingsModal();
  showPage(role === 'admin' ? 'leaders' : 'authors');
  renderNotifBell();
}
function logout(){
  try { if(typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.remove('auditKey'); } catch(e){}
  try { sessionStorage.removeItem('mlaudit-session'); } catch(e){}
  userRole = null;
  closeSettingsModal();
  var np = document.getElementById('notifPanel'); if(np) np.style.display = 'none';
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  showLoginError('');
  pickRole('admin');
}

// ---- in-app notifications (new 404s) — read state is per browser ----
function notifSeenKey(){ return 'mlaudit-notif-seen:' + reportHost(); }
function getNotifSeenAt(){ try { return localStorage.getItem(notifSeenKey()) || ''; } catch(e){ return ''; } }
function setNotifSeenAt(v){ try { localStorage.setItem(notifSeenKey(), v); } catch(e){} }
function unreadNotifs(){
  if(!sitemap404 || !sitemap404.urls) return [];
  var seen = getNotifSeenAt(), out = [];
  Object.keys(sitemap404.urls).forEach(function(u){
    var fs = sitemap404.urls[u].firstSeen || '';
    if(!seen || fs > seen) out.push({ url:u, firstSeen:fs });
  });
  out.sort(function(a,b){ return (b.firstSeen||'').localeCompare(a.firstSeen||''); });
  return out;
}
function renderNotifBell(){
  var btn = document.getElementById('notifBtn'); if(!btn) return;
  if(userRole !== 'admin'){ btn.style.display='none'; var p=document.getElementById('notifPanel'); if(p) p.style.display='none'; return; }
  btn.style.display='inline-flex';
  var n = unreadNotifs().length, dot = document.getElementById('notifDot');
  if(dot){ if(n>0){ dot.style.display='block'; dot.textContent = n>99 ? '99+' : String(n); } else { dot.style.display='none'; } }
  var pan = document.getElementById('notifPanel');
  if(pan && pan.style.display === 'block') renderNotifPanel();
}
function renderNotifPanel(){
  var list = document.getElementById('notifList'); if(!list) return;
  var items = unreadNotifs();
  if(!items.length){ list.innerHTML = '<div class="notif-empty">No new 404s. You\u2019re all caught up.</div>'; return; }
  var cap = items.slice(0, 12);
  var html = cap.map(function(it){
    var when = it.firstSeen ? new Date(it.firstSeen).toLocaleString() : 'recently';
    return '<div class="notif-item"><span class="nt">NEW 404</span>'
      + '<span class="nu">' + escapeHtml(it.url) + '</span>'
      + '<span class="nd">detected ' + escapeHtml(when) + '</span></div>';
  }).join('');
  if(items.length > cap.length) html += '<div class="notif-empty">+' + (items.length - cap.length) + ' more</div>';
  list.innerHTML = html;
}
function toggleNotifPanel(e){
  if(e && e.stopPropagation) e.stopPropagation();
  var p = document.getElementById('notifPanel'); if(!p) return;
  if(p.style.display !== 'block'){ renderNotifPanel(); p.style.display='block'; }
  else { p.style.display='none'; }
}
function markNotifsRead(){ setNotifSeenAt(new Date().toISOString()); renderNotifBell(); renderNotifPanel(); }
function viewNotifsInDash(){
  var p=document.getElementById('notifPanel'); if(p) p.style.display='none';
  markNotifsRead();
  showPage('leaders');
}
document.addEventListener('click', function(e){
  var p=document.getElementById('notifPanel'); if(!p || p.style.display!=='block') return;
  var btn=document.getElementById('notifBtn');
  if(!p.contains(e.target) && !(btn && btn.contains(e.target))) p.style.display='none';
});

var currentPageId = 'leaders';
function showPage(p){
  currentPageId = p;
  setTimeout(maybeOpenAepPrompt, 120);
  document.querySelectorAll('#pageTabs .ptab').forEach(function(b){ b.classList.toggle('active', b.dataset.page === p); });
  var gen = (p === 'generate');
  var pbi = (p === 'pbi');
  var aep = (p === 'aep');
  document.getElementById('page-generate').style.display = gen ? 'block' : 'none';
  var pbiEl = document.getElementById('page-pbi'); if(pbiEl) pbiEl.style.display = pbi ? 'block' : 'none';
  var aepEl = document.getElementById('page-aep'); if(aepEl) aepEl.style.display = aep ? 'block' : 'none';
  document.getElementById('page-dash').style.display = (gen || pbi || aep) ? 'none' : 'block';
  if(pbi){ requestAnimationFrame(drawPbiConnectors); setTimeout(drawPbiConnectors, 130); }
  if(aep){ aepRenderAll(); }
  if(!gen && !pbi && !aep){
    currentDashTab = (p === 'leaders') ? 'leaders' : 'authors';
    var has = dashHasData();
    document.getElementById('dashEmpty').style.display = has ? 'none' : 'block';
    document.getElementById('dashFrame').style.display = has ? 'block' : 'none';
    if(has) ensureDashFrame(currentDashTab);
    if(has) setStoreStatus();
    if(storeMode === 'remote') loadSharedState();
  }
  try { window.scrollTo({ top:0, behavior:'smooth' }); } catch(e){ window.scrollTo(0,0); }
}
function refreshDashIfVisible(){
  if(document.getElementById('page-dash').style.display !== 'none' && dashHasData()){
    document.getElementById('dashEmpty').style.display = 'none';
    document.getElementById('dashFrame').style.display = 'block';
    ensureDashFrame(currentDashTab);
  }
}
/* back-compat shim */
function showView(v){ showPage(v === 'leaders' ? 'leaders' : 'authors'); }
function buildDashboardHtml(){
  const data = currentDashData() || buildDashboardData();
  let json = JSON.stringify(data).replace(/<\/script>/gi, '<\\/script>');
  return '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
    + '<title>Audit dashboard — ' + escapeHtml(data.meta.host) + '</title>'
    + '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    + '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">'
    + '<style>' + dashboardCss() + '</style></head><body><div class="wrap" id="app"></div>'
    + (EXT_MODE
        ? '<script src="actions.js"><\/script><script src="tour.js"><\/script><script src="dashview.js"><\/script>'
        : '<script>window.__DASH_DATA__=' + json + ';(' + dashboardApp.toString() + ')();<\/script>')
    + '</body></html>';
}
function exportReport(){ exportDashboard(); } // back-compat
function exportDashboard(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  downloadBlob(buildDashboardHtml(), 'text/html', 'audit-dashboard-' + reportHost() + '-' + new Date().toISOString().slice(0,10) + '.html');
  setReportStatus('Dashboard saved' + (baseline ? ' (with trend vs the loaded baseline).' : '. Tip: load a baseline snapshot to add trend tracking.'));
}

/* ---- PDF report (light, print-friendly; differs by current dashboard) ---- */
function openReportTab(html, label){
  try {
    var blob = new Blob([html], { type: 'text/html' });
    var url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setReportStatus(label + ' report opened in a new tab \u2014 use Print and choose \u201cSave as PDF\u201d.');
    setTimeout(function(){ URL.revokeObjectURL(url); }, 60000);
  } catch(e) {
    setReportStatus('Could not open the report.', true);
  }
}
function exportReportPDF(viewArg){
  if(!dashHasData()){ setReportStatus('Run an audit first.', true); return; }
  var view = (viewArg === 'leaders' || viewArg === 'authors') ? viewArg : ((currentDashTab === 'leaders') ? 'leaders' : 'authors');
  var html = buildReportHtml(view);
  var label = (view === 'leaders' ? 'Admin' : 'Author');
  // The report used to carry an inline <script> that called print(). The extension
  // content security policy blocks inline script, so nothing happened. Print is now
  // driven from here, with a visible tab as the fallback.
  var old = document.getElementById('reportPrintFrame'); if(old) old.remove();
  var f = document.createElement('iframe');
  f.id = 'reportPrintFrame';
  f.setAttribute('aria-hidden', 'true');
  f.style.cssText = 'position:fixed;left:-10000px;top:0;width:960px;height:1200px;border:0;';
  f.onload = function(){
    try {
      var w = f.contentWindow, d = w.document;
      var st = d.createElement('style');
      st.textContent = '@page{size:' + d.documentElement.scrollWidth + 'px ' + d.documentElement.scrollHeight + 'px;margin:0}';
      d.head.appendChild(st);
      w.focus();
      w.print();
      setReportStatus(label + ' report sent to the print dialog \u2014 choose \u201cSave as PDF\u201d as the destination.');
    } catch(err) {
      openReportTab(html, label);
    }
  };
  document.body.appendChild(f);
  f.srcdoc = html;
  setTimeout(function(){ var fr = document.getElementById('reportPrintFrame'); if(fr) fr.remove(); }, 60000);
}
function reportCss(){
  return [
    "*{box-sizing:border-box}",
    "body{margin:0;background:#fafafa;color:#1a1a1a;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;font-weight:400;line-height:1.55;font-size:13px;-webkit-print-color-adjust:exact;print-color-adjust:exact}",
    ".rep{max-width:960px;margin:0 auto;padding:2.5rem 2.2rem}",
    ".eyebrow{color:#b9770e;text-transform:uppercase;letter-spacing:.13em;font-size:.66rem;font-weight:600;margin:0 0 .4rem}",
    "h1{font-weight:300;font-size:2rem;margin:0 0 .3rem;letter-spacing:-.5px}",
    ".meta{color:#666;font-size:.82rem;margin:0}",
    ".repkind{color:#1a1a1a;font-weight:500;font-size:1rem;margin:.45rem 0 0}",
    "section.block{margin-top:1.9rem;break-inside:avoid;page-break-inside:avoid}",
    "h2.sect{font-size:.72rem;text-transform:uppercase;letter-spacing:.1em;color:#b9770e;font-weight:600;margin:0 0 .8rem;padding-bottom:.4rem;border-bottom:1px solid #e0e0e0}",
    ".kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:.8rem}",
    ".kpi{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:.9rem 1rem}",
    ".kpi .n{font-size:1.8rem;font-weight:300;line-height:1}",
    ".kpi .l{font-size:.62rem;text-transform:uppercase;letter-spacing:.06em;color:#666;margin-top:.35rem}",
    ".kpi.c .n{color:#c0392b}.kpi.w .n{color:#b9770e}",
    "table{width:100%;border-collapse:collapse;font-size:.8rem;background:#fff;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden}",
    "th{text-align:left;font-size:.62rem;text-transform:uppercase;letter-spacing:.05em;color:#888;font-weight:600;padding:.5rem .7rem;border-bottom:1px solid #e0e0e0;background:#f4f4f4}",
    "td{padding:.5rem .7rem;border-bottom:1px solid #eee;vertical-align:top}tr:last-child td{border-bottom:none}",
    "td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}",
    ".sevb{display:inline-flex;align-items:center;gap:.35rem;font-size:.66rem;text-transform:uppercase;letter-spacing:.03em;font-weight:600;white-space:nowrap}.sevb .dot{width:7px;height:7px;border-radius:50%}",
    ".sevb.c{color:#c0392b}.sevb.c .dot{background:#c0392b}.sevb.w{color:#b9770e}.sevb.w .dot{background:#b9770e}.sevb.i{color:#777}.sevb.i .dot{background:#aaa}",
    ".pgblock{margin-top:1.1rem;break-inside:avoid;page-break-inside:avoid}",
    ".pghead{display:flex;align-items:baseline;gap:.55rem;flex-wrap:wrap;margin-bottom:.45rem}",
    ".pgname{font-size:1rem;font-weight:500}.pgpath{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.72rem;color:#888}",
    ".pill{font-size:.62rem;padding:.1rem .45rem;border-radius:20px;border:1px solid #ddd;color:#666}",
    ".pill.c{color:#c0392b;border-color:#e2b3ae}.pill.w{color:#b9770e;border-color:#e3cd9c}.pill.i{color:#777}",
    ".sugg{color:#2e7d4f}.muted{color:#888}",
    ".trend{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;text-align:center;background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:1.1rem}",
    ".trend .d{font-size:1.7rem;font-weight:300}.trend .dl{font-size:.64rem;text-transform:uppercase;letter-spacing:.06em;color:#666;margin-top:.2rem}",
    ".foot{margin-top:2.5rem;padding-top:1rem;border-top:1px solid #e0e0e0;color:#999;font-size:.7rem}",
    "@media print{body{background:#fff}.rep{padding:1.2rem}}"
  ].join('');
}
function buildReportHtml(view){
  var D = currentDashData() || buildDashboardData();
  var TRI = D.triage || {};
  var allFindings = D.findings || [];
  var openF = allFindings.filter(function(f){ return !(TRI[f.key] && TRI[f.key].status); });
  var resolvedN = allFindings.length - openF.length;
  function _cb(arr, p){ var o={}; arr.forEach(function(x){ var k=x[p]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; }
  D = Object.assign({}, D, {
    findings: openF,
    rollups: { byLang:_cb(openF,'lang'), byCategory:_cb(openF,'category'), byDir:_cb(openF,'dir'), bySeverity:_cb(openF,'severity') },
    summary: {
      pages: D.summary.pages,
      critical: openF.filter(function(f){ return f.severity==='critical' && f.category!=='broken link'; }).length,
      warning: openF.filter(function(f){ return f.severity==='warning'; }).length,
      info: openF.filter(function(f){ return f.severity==='info'; }).length,
      broken: openF.filter(function(f){ return f.category==='broken link'; }).length
    }
  });
  var E = escapeHtml;
  var sevRank = { critical:0, warning:1, info:2 };
  function sevc(s){ return s==='critical'?'c':s==='warning'?'w':'i'; }
  function sevb(s){ return '<span class="sevb '+sevc(s)+'"><span class="dot"></span>'+E(s)+'</span>'; }
  function sect(title, inner){ return '<section class="block"><h2 class="sect">'+E(title)+'</h2>'+inner+'</section>'; }
  function fmtAge(days){ if(days==null) return ''; if(days<60) return days+'d'; var mo=Math.floor(days/30.44); if(mo<24) return mo+'mo'; return (days/365).toFixed(1)+'y'; }
  function pd(s){ if(!s) return null; var d=new Date(s); return isNaN(d)?null:d; }
  var cdByKey={};
  function normKey(p){ return (p||'').toLowerCase().replace(/^\/+|\/+$/g,'').replace(/\s+/g,'-'); }
  (D.contentDates||[]).forEach(function(r){ cdByKey[normKey(r.path)]=r; });
  function pageDate(path){ return cdByKey[normKey((path||'').replace(/^(es|zh)\//,''))]||null; }
  function rollTable(obj, label){
    var keys=Object.keys(obj||{}).sort(function(a,b){ return obj[b]-obj[a]; });
    if(!keys.length) return '<p class="muted">No findings.</p>';
    var rows=keys.map(function(k){ return '<tr><td>'+E(k)+'</td><td class="num">'+obj[k]+'</td></tr>'; }).join('');
    return '<table><thead><tr><th>'+E(label)+'</th><th class="num">Findings</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }

  var body='';
  if(view === 'leaders'){
    function kpi(n,l,cls){ return '<div class="kpi '+(cls||'')+'"><div class="n">'+n+'</div><div class="l">'+E(l)+'</div></div>'; }
    var kpis='<div class="kpis">'+kpi(D.summary.pages,'Pages')+kpi(D.summary.critical,'Critical','c')
      +kpi(D.summary.warning,'Warnings','w')+kpi(D.summary.broken,'Broken links',D.summary.broken?'c':'')
      +kpi(D.findings.length,'Total findings')+'</div>';
    var bs=D.rollups.bySeverity||{}, stot=(bs.critical||0)+(bs.warning||0)+(bs.info||0);
    var sevRows=['critical','warning','info'].map(function(k){ var n=bs[k]||0, p=stot?Math.round(n/stot*100):0;
      return '<tr><td>'+sevb(k)+'</td><td class="num">'+n+'</td><td class="num">'+p+'%</td></tr>'; }).join('');
    var sevTable='<table><thead><tr><th>Severity</th><th class="num">Count</th><th class="num">Share</th></tr></thead><tbody>'+sevRows+'</tbody></table>';
    var trendBlock='';
    var t=D.trend;
    if(t && t.hasBaseline){
      trendBlock=sect('Change since last audit',
        '<div class="trend"><div><div class="d" style="color:#2e7d4f">'+t.resolved+'</div><div class="dl">Resolved</div></div>'
        +'<div><div class="d" style="color:#c0392b">'+t.added+'</div><div class="dl">New</div></div>'
        +'<div><div class="d" style="color:#b9770e">'+t.persisting+'</div><div class="dl">Still open</div></div></div>'
        +'<p class="meta" style="text-align:center;margin-top:.8rem">Since '+E(new Date(t.date).toLocaleDateString())+': '+t.wasTotal+' \u2192 '+t.nowTotal+'</p>');
    }
    var cov=D.coverage;
    var covMissing=cov.missing.length
      ? '<table><thead><tr><th>Language</th><th class="num">Missing / errored</th></tr></thead><tbody>'+cov.missing.map(function(m){ return '<tr><td>'+E(m.lang)+'</td><td class="num">'+m.count+'</td></tr>'; }).join('')+'</tbody></table>'
      : '<p class="muted">Every audited page returned a version in all languages.</p>';
    var coverageBlock=sect('Translation coverage', '<p class="meta" style="margin-bottom:.7rem">'+cov.audited+' of '+cov.discovered+' discovered page(s) audited.</p>'+covMissing);
    var staleBlock='';
    if(D.contentDates && D.contentDates.length){
      var now=D.now||Date.now(), cutoff=now-12*30.44*86400000;
      var rows=D.contentDates.map(function(r){ return { path:r.path, by:r.updatedBy, d:pd(r.updated) }; }).filter(function(r){ return r.d; }).sort(function(a,b){ return a.d-b.d; });
      var staleN=rows.filter(function(r){ return r.d.getTime()<cutoff; }).length;
      var tb=rows.map(function(r){ var age=Math.floor((now-r.d.getTime())/86400000), stale=r.d.getTime()<cutoff;
        return '<tr><td>/'+E(r.path)+'</td><td>'+E(r.by||'\u2014')+'</td><td>'+E(r.d.toISOString().slice(0,10))+'</td><td class="num">'+fmtAge(age)+'</td><td>'+(stale?'<span class="sevb c"><span class="dot"></span>stale</span>':'<span class="muted">current</span>')+'</td></tr>'; }).join('');
      staleBlock=sect('Stale content', '<p class="meta" style="margin-bottom:.7rem">'+staleN+' of '+rows.length+' page(s) not updated in over 12 months.</p>'
        +'<table><thead><tr><th>Page</th><th>Updated by</th><th>Last updated</th><th class="num">Age</th><th>Status</th></tr></thead><tbody>'+tb+'</tbody></table>');
    }
    var syncBlock='';
    if(D.sync && D.sync.hasBaseline){
      var staleF=D.findings.filter(function(f){ return f.category==='source changed, translation stale'; });
      var apprOn=D.sync.approvedAt ? ' (approved '+E(new Date(D.sync.approvedAt).toLocaleDateString())+')' : '';
      if(staleF.length){
        var srows=staleF.slice().sort(function(a,b){ return a.page.localeCompare(b.page); }).map(function(f){
          return '<tr><td>'+E(f.page)+'<br><span class="pgpath" style="font-size:.68rem">/'+E(f.path)+'</span></td><td>'+E(f.lang)+'</td><td>'+E(f.detail)+'</td></tr>'; }).join('');
        syncBlock=sect('Stale because English changed'+apprOn,
          '<p class="meta" style="margin-bottom:.7rem">'+staleF.length+' translated page(s) where the English source changed after approval and the translation has not been updated.</p>'
          +'<table><thead><tr><th>Page</th><th>Locale</th><th>What changed</th></tr></thead><tbody>'+srows+'</tbody></table>');
      } else {
        syncBlock=sect('Source sync'+apprOn, '<p class="muted">No stale translations \u2014 every approved translation still matches its English source.</p>');
      }
    }
    body=sect('At a glance', kpis)
      + syncBlock
      + sect('Severity breakdown', sevTable)
      + trendBlock
      + sect('Findings by category', rollTable(D.rollups.byCategory,'Category'))
      + sect('Findings by language', rollTable(D.rollups.byLang,'Language'))
      + sect('Findings by section / directory', rollTable(D.rollups.byDir,'Section'))
      + coverageBlock
      + staleBlock;
  } else {
    if(!D.findings.length){
      body='<section class="block"><p class="muted">No findings — every audited page passed.</p></section>';
    } else {
      var groups={}; D.findings.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
      var keys=Object.keys(groups);
      function weight(list){ var w=0; list.forEach(function(f){ w += f.severity==='critical'?100:f.severity==='warning'?10:1; }); return w; }
      keys.sort(function(a,b){ return weight(groups[b])-weight(groups[a]); });
      var now=D.now||Date.now();
      var pagesHtml=keys.map(function(k){
        var items=groups[k].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity])||a.lang.localeCompare(b.lang); });
        var head=k.split('||'), name=head[0], path=head[1];
        var cc=items.filter(function(f){return f.severity==='critical';}).length;
        var wc=items.filter(function(f){return f.severity==='warning';}).length;
        var ic=items.filter(function(f){return f.severity==='info';}).length;
        var cd=pageDate(path), dateStr='';
        if(cd && cd.updated){ var d=pd(cd.updated); if(d){ var age=Math.floor((now-d.getTime())/86400000); dateStr='<span class="pill">updated '+E(d.toISOString().slice(0,10))+' \u00B7 '+fmtAge(age)+(cd.updatedBy?' \u00B7 '+E(cd.updatedBy):'')+'</span>'; } }
        var rows=items.map(function(f){ return '<tr><td>'+sevb(f.severity)+'</td><td>'+E(f.lang)+'</td><td>'+E(f.category)+'</td><td>'+E(f.detail)+(f.suggestion?'<br><span class="sugg">\u2192 '+E(f.suggestion)+'</span>':'')+'</td></tr>'; }).join('');
        return '<div class="pgblock"><div class="pghead"><span class="pgname">'+E(name)+'</span><span class="pgpath">/'+E(path)+'</span>'
          +(cc?'<span class="pill c">'+cc+' critical</span>':'')+(wc?'<span class="pill w">'+wc+' warning</span>':'')+(ic?'<span class="pill i">'+ic+' info</span>':'')+dateStr+'</div>'
          +'<table><thead><tr><th>Severity</th><th>Language</th><th>Category</th><th>Issue &amp; suggestion</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
      }).join('');
      body='<section class="block"><p class="meta">'+D.findings.length+' finding(s) across '+keys.length+' page(s), ordered by severity.</p></section>'+pagesHtml;
    }
  }

  var header='<p class="eyebrow">Localization QA Report</p><h1>'+E(D.meta.host)+'</h1>'
    + '<p class="meta">Generated '+E(D.meta.generated)+' \u00B7 '+E((D.meta.langs||[]).join(', '))+' \u00B7 translation check: '+E(D.meta.translationCheck)+'</p>'
    + '<p class="repkind">'+(view==='leaders'?'Admin summary':'Author work list')+(resolvedN?' \u00B7 <span style="font-weight:400;color:#888">open items only ('+resolvedN+' resolved hidden)</span>':'')+'</p>';
  var foot='<div class="foot">Multilingual Site Audit \u00B7 '+E(D.meta.host)+' \u00B7 '+(view==='leaders'?'Admin':'Author')+' report</div>';
  var printScript = '';   // print is driven from the parent; inline script is blocked by CSP
  return '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>'
    + E(D.meta.host)+' \u2014 '+(view==='leaders'?'Admin':'Author')+' report</title><style>'+reportCss()+'</style></head><body><div class="rep">'
    + header+body+foot+'</div>'+printScript+'</body></html>';
}
function dashboardCss(){
  return [
    ':root{--bg:#1a1a1a;--card:#242424;--card-alt:#1e1e1e;--border:#2e2e2e;--text:#f0f0f0;--muted:#888;--muted2:#666;--accent:#FFBE5F;--crit:#d98a84;--warn:#d8a24a;--ok:#7dbf82}',
    '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;font-weight:300;line-height:1.6}',
    '.wrap{max-width:1440px;margin:0 auto;padding:2.5rem 1.5rem}',
    '.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:.13em;font-size:.7rem;font-weight:500;margin:0}',
    'h1{font-weight:300;font-size:2rem;margin:.2rem 0}.sub{color:var(--muted);font-size:.88rem;margin:.3rem 0 0}',
    '.tabs{display:flex;gap:.4rem;margin:2rem 0 1.5rem;border-bottom:1px solid var(--border)}',
    '.tab{background:none;border:none;color:var(--muted);padding:.7rem 1.1rem;cursor:pointer;font-size:.95rem;border-bottom:2px solid transparent;font-family:inherit}',
    '.tab.active{color:var(--accent);border-bottom-color:var(--accent)}',
    '.card{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:1.5rem;margin-bottom:1.5rem}',
    '.label{color:var(--accent);text-transform:uppercase;letter-spacing:.1em;font-size:.7rem;font-weight:500;margin:0 0 1rem}',
    '.grid{display:grid;gap:1rem}.stats{grid-template-columns:repeat(auto-fit,minmax(110px,1fr))}',
    '.stat{background:var(--card-alt);border:1px solid var(--border);border-radius:8px;padding:.9rem 1rem;cursor:pointer;transition:border-color .2s}',
    '.stat:hover{border-color:var(--accent)}.stat .n{font-size:1.9rem;font-weight:300;line-height:1}.stat .l{color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;margin-top:.3rem}',
    '.crit{color:var(--crit)}.warn{color:var(--warn)}.ok{color:var(--ok)}.accent{color:var(--accent)}.muted{color:var(--muted)}',
    'table{width:100%;border-collapse:collapse;font-size:.86rem}th,td{text-align:left;padding:.5rem .6rem;border-bottom:1px solid var(--border)}',
    'th{color:var(--muted);font-weight:500;text-transform:uppercase;font-size:.68rem;letter-spacing:.06em}td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}',
    '.filters{display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:1.2rem;align-items:center}',
    'select,input{background:var(--card-alt);border:1px solid #333;color:var(--text);border-radius:6px;padding:.5rem .7rem;font-size:.85rem;font-family:inherit}',
    '.finding{border:1px solid var(--border);border-left:3px solid var(--muted2);border-radius:6px;margin:.5rem 0;background:var(--card-alt)}',
    '.finding.s-critical{border-left-color:var(--crit)}.finding.s-warning{border-left-color:var(--warn)}.finding.s-info{border-left-color:var(--muted2)}',
    '.finding .body{padding:.6rem .85rem}.cat{font-size:.68rem;text-transform:uppercase;letter-spacing:.06em;color:var(--accent)}',
    '.det{margin:.25rem 0 0;font-size:.9rem}.sugg{color:var(--ok);font-size:.82rem;margin-top:.35rem}.path-mini{color:var(--muted2);font-size:.72rem;margin-top:.35rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    '.finding details{margin:.1rem .85rem .7rem}.finding summary{cursor:pointer;color:var(--accent);font-size:.72rem;list-style:none}.finding summary::-webkit-details-marker{display:none}',
    'pre.src{font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.72rem;white-space:pre-wrap;word-break:break-word;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:.6rem;margin:.4rem 0 0}',
    '.trend{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;text-align:center}.delta{font-size:1.9rem;font-weight:300}',
    '.empty{color:var(--muted);font-size:.88rem}',
    '.ftable-wrap{overflow-x:auto;margin-top:.2rem}',
    'table.ft{width:100%;border-collapse:collapse;font-size:.83rem}',
    'table.ft th{text-align:left;color:var(--muted2);font-weight:500;text-transform:uppercase;font-size:.62rem;letter-spacing:.06em;padding:.35rem .55rem;border-bottom:1px solid var(--border);white-space:nowrap}',
    'table.ft td{padding:.5rem .55rem;border-bottom:1px solid var(--border);vertical-align:top}table.ft tbody tr.frow:last-of-type td{border-bottom:none}',
    'tr.frow{cursor:pointer;transition:background .12s}tr.frow:hover{background:#2a2a2a}tr.frow.open{background:#2a2a2a}',
    'table.ft th.sortable{cursor:pointer;user-select:none;white-space:nowrap}table.ft th.sortable:hover{color:var(--text)}',
    'table.ft th.sortable .sort-ind{margin-left:.3rem;font-size:.75em;opacity:.3}table.ft th.sortable .sort-ind::after{content:"\\2195"}',
    'table.ft th.sortable[data-dir] .sort-ind{opacity:1;color:var(--accent)}',
    'table.ft th.sortable[data-dir="asc"] .sort-ind::after{content:"\\2191"}table.ft th.sortable[data-dir="desc"] .sort-ind::after{content:"\\2193"}',
    '.sevb{display:inline-flex;align-items:center;gap:.4rem;font-size:.64rem;text-transform:uppercase;letter-spacing:.04em;font-weight:500;white-space:nowrap}.sevb .dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto}',
    '.sevb.c{color:var(--crit)}.sevb.c .dot{background:var(--crit)}.sevb.w{color:var(--warn)}.sevb.w .dot{background:var(--warn)}.sevb.i{color:var(--muted)}.sevb.i .dot{background:var(--muted2)}',
    '.ft .fc-pg{color:var(--text)}.ft .fc-path{display:block;color:var(--muted2);font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.68rem;margin-top:.1rem}',
    '.ft .fc-lang,.ft .fc-cat{color:var(--muted);white-space:nowrap}.ft .fc-issue{color:var(--text);display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:62ch}.drill-body .fc-issue{max-width:30ch}',
    '.ft .fc-exp{width:1.4rem;text-align:right;color:var(--muted2)}.fchev{display:inline-block;font-size:1rem;transition:transform .2s}tr.frow.open .fchev{transform:rotate(90deg)}',
    'tr.fdetail{display:none}tr.fdetail.show{display:table-row}tr.fdetail>td{padding:.1rem .55rem .7rem;background:#1b1b1b;border-bottom:1px solid var(--border)}',
    '.fd-inner{padding:.6rem .8rem;border-left:2px solid var(--accent);background:var(--card-alt);border-radius:0 6px 6px 0}',
    '.fd-sugg{color:var(--ok);font-size:.82rem;margin:0 0 .4rem}.fd-meta{color:var(--muted);font-size:.73rem;margin:0 0 .4rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    'details.drill{border-bottom:1px solid var(--border)}details.drill>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:.7rem;padding:.55rem 0;font-size:.88rem}details.drill>summary::-webkit-details-marker{display:none}',
    '.finding details.evidence{margin:.1rem .85rem .7rem}.finding details.evidence>summary{cursor:pointer;color:var(--accent);font-size:.72rem;list-style:none}.finding details.evidence>summary::-webkit-details-marker{display:none}',
    'ul.evlist{list-style:none;margin:.4rem 0 0;padding:0;border:1px solid var(--border);border-radius:6px;background:var(--bg);max-height:320px;overflow:auto}',
    'ul.evlist li{font-size:.78rem;padding:.35rem .6rem;border-bottom:1px solid var(--border);word-break:break-word;font-family:"SF Mono",Monaco,Consolas,monospace}ul.evlist li:last-child{border-bottom:none}',
    'ul.evlist li.evhead{font-family:Inter,sans-serif;color:var(--accent);text-transform:uppercase;letter-spacing:.05em;font-size:.66rem;background:var(--card-alt)}',
    'details.drill>summary:hover .drill-label{color:var(--accent)}.drill-label{min-width:170px}.drill-label .chev{color:var(--muted2);margin-right:.5rem;font-size:1rem;display:inline-block;width:1rem;transition:transform .2s}details.drill[open]>summary .chev{transform:rotate(90deg)}',
    '.bartrack{flex:1;height:9px;background:#33322f;border-radius:5px;overflow:hidden;max-width:none}.barfill{display:block;height:100%;background:linear-gradient(90deg,#ffce85,#f0a63a);border-radius:5px;min-width:3px}.drill-count{min-width:34px;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);font-weight:400}.rc-crit{color:var(--critical);font-size:.82em}',
    '.drill-body{padding:.3rem 0 .9rem}',
    'details.pagecard{border:1px solid var(--border);border-radius:8px;margin-bottom:.7rem;background:var(--card-alt)}details.pagecard>summary{list-style:none;cursor:pointer;padding:.8rem 1rem;display:flex;align-items:center;gap:.8rem;flex-wrap:wrap}details.pagecard>summary::-webkit-details-marker{display:none}',
    '.pc-name{font-weight:400;font-size:1rem;flex:1;min-width:160px}.pc-name .chev{color:var(--muted2);margin-right:.5rem;font-size:1rem;display:inline-block;transition:transform .2s}details.pagecard[open]>summary .pc-name .chev{transform:rotate(90deg)}',
    '.pc-path{color:var(--muted2);font-size:.72rem;font-family:"SF Mono",Monaco,Consolas,monospace;flex-basis:100%;margin-left:1.1rem}',
    '.pill{font-size:.7rem;padding:.12rem .5rem;border-radius:20px;border:1px solid var(--border)}.pill.c{color:var(--crit);border-color:var(--crit)}.pill.w{color:var(--warn);border-color:var(--warn)}.pill.i{color:var(--muted);border-color:var(--muted2)}.pill.date{color:var(--muted)}',
    '.pc-body{padding:0 1rem .8rem}',
    '.picker{border:1px solid var(--border);border-radius:8px;background:var(--card-alt);margin-bottom:1rem}',
    '.picker-head{cursor:pointer;padding:.85rem 1rem;display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;user-select:none}',
    '.picker-head .chev{color:var(--accent);font-size:1rem;display:inline-block;transition:transform .2s}.picker.open .picker-head .chev{transform:rotate(90deg)}',
    '.picker-head .pk-name{font-weight:400;font-size:1rem}.picker-head .pk-hint{color:var(--muted);font-size:.78rem;white-space:nowrap}',
    '.picker-list{display:none;border-top:1px solid var(--border);max-height:340px;overflow:auto}.picker.open .picker-list{display:block}',
    '.picker-opt{display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;padding:.6rem 1rem;cursor:pointer;border-bottom:1px solid var(--border);transition:background .12s}.picker-opt:last-child{border-bottom:none}.picker-opt:hover{background:#2a2a2a}.picker-opt.sel{background:#2a2a2a}',
    '.picker-opt .po-name{flex:1;min-width:150px}.picker-opt .pc-path{flex-basis:100%;margin-left:0}',
    'details.stale{border:1px solid var(--border);border-radius:8px;margin-bottom:.5rem;background:var(--card-alt)}details.stale.is-stale{border-left:3px solid var(--crit)}details.stale>summary{list-style:none;cursor:pointer;padding:.65rem 1rem;display:grid;grid-template-columns:1fr auto auto auto;gap:1rem;align-items:center;font-size:.85rem}details.stale>summary::-webkit-details-marker{display:none}',
    '.st-path{font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.78rem;overflow:hidden;text-overflow:ellipsis}.st-age{color:var(--muted);font-variant-numeric:tabular-nums;min-width:48px;text-align:right}.st-date{color:var(--muted);min-width:84px;text-align:right}',
    '.st-body{padding:.2rem 1rem .8rem;font-size:.82rem;color:var(--muted);display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:.5rem 1.5rem}.st-body .k{color:var(--muted2);text-transform:uppercase;font-size:.66rem;letter-spacing:.05em}.st-body .v{color:var(--text)}',
    '.headrow{display:grid;grid-template-columns:1fr auto auto auto;gap:1rem;padding:0 1rem .4rem;font-size:.66rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted2)}',
    '.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;margin-bottom:1.25rem}',
    '.kpi{appearance:none;text-align:left;background:var(--card);border:1px solid var(--border);border-left:3px solid var(--muted2);border-radius:10px;padding:1.1rem 1.2rem;cursor:pointer;font-family:inherit;display:flex;flex-direction:column;gap:.4rem;transition:border-color .2s,transform .2s,background .2s}',
    '.kpi:hover{transform:translateY(-2px);background:#2a2a2a}.kpi .kpi-n{font-size:2.3rem;font-weight:300;line-height:1;color:var(--text)}.kpi .kpi-l{color:var(--muted);font-size:.7rem;text-transform:uppercase;letter-spacing:.08em}',
    '.kpi.crit{border-left-color:var(--crit)}.kpi.crit:hover{border-color:var(--crit)}.kpi.crit .kpi-n{color:var(--crit)}',
    '.kpi.warn{border-left-color:var(--warn)}.kpi.warn:hover{border-color:var(--warn)}.kpi.warn .kpi-n{color:var(--warn)}',
    '.kpi.accent{border-left-color:var(--accent)}.kpi.accent:hover{border-color:var(--accent)}',
    '.dash-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;margin-bottom:1.25rem;align-items:start}.dash-grid .card{margin:0}',
    '.dash-split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;margin-bottom:1.25rem;align-items:start}.dash-split>.dash-col{display:flex;flex-direction:column;gap:1.25rem;min-width:0}.dash-split .card{margin:0}',
    '.dash-grid-eq{align-items:stretch}.dash-grid-eq>.card{display:flex;flex-direction:column}',
    '.s404-list{display:flex;flex-direction:column;gap:.5rem;max-height:320px;overflow:auto}',
    '.s404-row{display:flex;align-items:center;gap:.5rem;font-size:.82rem;border-bottom:1px solid var(--border);padding-bottom:.45rem}',
    '.s404-url{color:var(--text);text-decoration:none;word-break:break-all;flex:1 1 auto;min-width:0}.s404-url:hover{color:var(--accent);text-decoration:underline}',
    '.s404-seen{color:var(--muted2);font-size:.72rem;flex:0 0 auto;white-space:nowrap}',
    '.s404-new{flex:0 0 auto;background:var(--crit);color:#1a1a1a;font-weight:600;font-size:.62rem;letter-spacing:.04em;padding:.1rem .35rem;border-radius:4px}',
    '.card-404.has-dead{border-left:3px solid var(--crit)}',
    '.s404-group + .s404-group{margin-top:1.1rem;padding-top:1rem;border-top:1px solid var(--border)}',
    '.s404-grouphead{font-size:.75rem;font-weight:600;color:var(--text);margin:0 0 .5rem;letter-spacing:.01em}',
    '.card-404 .label{display:flex;align-items:center;gap:.5rem}',
    '.stale-summary{cursor:pointer;margin:0;list-style:none;user-select:none;display:flex;align-items:center;gap:.5rem}',
    '.stale-summary::-webkit-details-marker{display:none}',
    '.stale-summary .chev{margin-left:auto;color:var(--muted);font-size:1rem;transition:transform .2s ease}',
    '.stale-collapse[open] > .stale-summary{margin-bottom:1rem}',
    '.stale-collapse[open] .stale-summary .chev{transform:rotate(90deg)}',
    '.acc-summary{cursor:pointer;margin:0;list-style:none;user-select:none;display:flex;align-items:center;gap:.5rem}',
    '.acc-summary::-webkit-details-marker{display:none}',
    '.acc-summary .chev{margin-left:auto;color:var(--muted);font-size:1rem;transition:transform .2s ease}',
    '.acc-collapse[open] > .acc-summary{margin-bottom:1rem}',
    '.acc-collapse[open] .acc-summary .chev{transform:rotate(90deg)}',
    '.count-pill{display:inline-block;background:var(--crit);color:#1a1a1a;font-weight:700;font-size:.7rem;line-height:1;padding:.22rem .5rem;border-radius:10px}',
    '.card-404 .s404-list{max-height:300px}',
    '@media(min-width:760px){.card-404 .s404-list{display:grid;grid-template-columns:1fr 1fr;gap:.15rem 1.8rem}}',
    '.label{display:flex;align-items:center;gap:.5rem}.label::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--accent);display:inline-block;flex:0 0 auto}',
    '.sevmix{display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap}.donut{width:148px;height:148px;flex:0 0 auto}.donut-n{fill:var(--text);font-size:30px;font-weight:300}.donut-l{fill:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}',
    '.legend{display:flex;flex-direction:column;gap:.65rem;flex:1;min-width:130px}.legend-row{display:flex;align-items:center;gap:.6rem;font-size:.88rem}.swatch{width:11px;height:11px;border-radius:3px;flex:0 0 auto}.legend-row .ln{margin-left:auto;font-variant-numeric:tabular-nums;color:var(--text)}.legend-row .lt{color:var(--muted)}',
    '.covrow{display:flex;align-items:baseline;gap:.6rem;margin-bottom:.7rem}.covrow .big{font-size:1.8rem;font-weight:300;color:var(--accent);line-height:1}.barrow{display:flex;gap:.6rem;margin:.3rem 0;font-size:.85rem}',
    '@media(max-width:820px){.kpis{grid-template-columns:repeat(2,1fr)}.dash-grid{grid-template-columns:1fr}.dash-split{grid-template-columns:1fr}}',
    '.queue-stale{border-left:3px solid var(--warn);margin-bottom:1.25rem}.queue-stale .label{color:var(--warn)}.queue-stale .label::before{background:var(--warn)}',
    '.queue-ok{margin-bottom:1.25rem}',
    'tr.frow.resolved td{opacity:.45}tr.frow.resolved .fc-issue{text-decoration:line-through}.ftag{display:inline-block;font-size:.85rem;margin-right:.35rem;vertical-align:middle}.ftag.done{color:var(--ok)}.ftag.ignored{color:var(--muted2)}',
    '.tri-row{display:flex;gap:.5rem;align-items:center;margin-top:.7rem;flex-wrap:wrap}.tri-meta{color:var(--muted);font-size:.76rem;margin-right:.3rem}',
    '.tri-btn{appearance:none;border:1px solid var(--border);background:var(--card);color:var(--muted);font-family:inherit;font-size:.74rem;padding:.32rem .7rem;border-radius:6px;cursor:pointer;transition:color .15s,border-color .15s}.tri-btn:hover{color:var(--text);border-color:var(--muted2)}.tri-btn.done:hover{color:var(--ok);border-color:var(--ok)}.tri-btn.ignore:hover{color:var(--warn);border-color:var(--warn)}',
    '.f-toggle{display:inline-flex;align-items:center;gap:.35rem;color:var(--muted);font-size:.8rem;cursor:pointer;white-space:nowrap}.f-toggle input{accent-color:var(--accent)}',
    '.tprog{height:8px;background:#33322f;border-radius:5px;overflow:hidden;margin-top:.2rem}.tprog-bar{display:block;height:100%;background:linear-gradient(90deg,var(--ok),#5fae6a)}',
    '.dash-headrow{display:flex;align-items:baseline;justify-content:space-between;gap:1rem;flex-wrap:wrap}',
    '.pdf-link{display:inline-flex;align-items:center;gap:.4rem;color:var(--muted);font-size:.82rem;cursor:pointer;text-decoration:none;white-space:nowrap;transition:color .15s}.pdf-link:hover{color:var(--accent)}.pdf-link svg{flex:0 0 auto}',
    '.pub-actions{display:flex;gap:.6rem}',
    '.pub-btn{appearance:none;flex:1 1 0;min-width:0;border:1px solid var(--border);background:var(--card-alt);color:var(--text);font-family:inherit;font-size:.86rem;padding:.65rem 1rem;border-radius:8px;cursor:pointer;transition:border-color .15s,color .15s,background .15s,filter .15s}.pub-btn:hover{border-color:var(--muted2)}',
    '.pub-btn.pub-primary{background:var(--accent);color:#1a1a1a;border-color:var(--accent);font-weight:500}.pub-btn.pub-primary:hover{filter:brightness(1.05)}',
    '.pub-btn.pub-secondary{background:transparent;border-color:var(--accent);color:var(--accent);font-weight:500}.pub-btn.pub-secondary:hover{background:rgba(255,190,95,.08);border-color:var(--accent)}',
    '.pub-btn:disabled{opacity:.4;cursor:not-allowed;background:transparent;border-color:var(--border);color:var(--muted)}.pub-btn:disabled:hover{background:transparent;border-color:var(--border)}',
    '.pub-status{font-size:.78rem;color:var(--muted);margin-top:.7rem;min-height:1em}.pub-status.ok{color:var(--ok)}.pub-status.err{color:var(--crit)}',
    '.rank-label{display:flex;align-items:center;gap:.5rem;min-width:210px}',
    '.rank-name{display:flex;flex-direction:column;gap:1px;min-width:0}',
    '.rank-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;font-size:.88rem;color:var(--text)}',
    '.rank-path{display:block;color:var(--muted2);font-size:.68rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    '.lchart-legend{display:flex;flex-wrap:wrap;gap:14px;margin-top:.9rem;font-size:12px;color:var(--muted)}',
    '.lchart-legend .item{display:flex;align-items:center;gap:5px}',
    '.lchart-legend .item .n{color:var(--muted2)}'
  ].join('');
}
function dashboardApp(){
  var D = window.__DASH_DATA__;
  var esc = function(s){ return (s==null?'':String(s)).replace(/[&<>"]/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[m]; }); };
  var sevRank = { critical:0, warning:1, info:2 };
  var chev = '<span class="chev">\u25B6</span>';
  var app = document.getElementById('app');

  var TRIAGE = D.triage || {};
  function statusOf(f){ var t = TRIAGE[f.key]; return (t && t.status) ? t.status : 'open'; }
  function isOpen(f){ return statusOf(f) === 'open'; }
  function activeFindings(){ return (D.findings||[]).filter(isOpen); }
  function countByApp(arr, prop){ var o={}; arr.forEach(function(x){ var k=x[prop]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; }
  window.__triage = function(ek, status){
    var key = decodeURIComponent(ek);
    if(status === 'open'){ delete TRIAGE[key]; } else { TRIAGE[key] = { status:status, at:new Date().toISOString() }; }
    try { parent.postMessage({ __mlaudit:'triage', key:key, status:status }, '*'); } catch(e){}
    renderAuthors(); renderLeaders(); postHeight();
  };
  function triageActions(f){
    var k = encodeURIComponent(f.key||'');
    var st = statusOf(f);
    var btn = function(label, status, cls){ return '<button class="tri-btn '+(cls||'')+'" data-click="__triage(\''+k+'\',\''+status+'\')">'+label+'</button>'; };
    if(st === 'open') return '<div class="tri-row">'+btn('\u2713 Mark done','done','done')+btn('\u2298 Ignore','ignored','ignore')+'</div>';
    var when = (TRIAGE[f.key] && TRIAGE[f.key].at) ? esc(new Date(TRIAGE[f.key].at).toLocaleDateString()) : '';
    return '<div class="tri-row"><span class="tri-meta">'+(st==='done'?'Completed':'Ignored')+(when?' \u00B7 '+when:'')+'</span>'+btn('Reopen','open','')+'</div>';
  }

  function evidenceBlock(f){
    var out = '';
    if(f.items && f.items.length){
      var label = (f.evidenceLabel || 'items');
      var rows = f.items.map(function(it){
        var s = String(it);
        if(/^—.*—$/.test(s)) return '<li class="evhead">' + esc(s.replace(/—/g,'').trim()) + '</li>';
        return '<li>' + esc(s) + '</li>';
      }).join('');
      out += '<details class="evidence"><summary>\u25B8 ' + esc(label) + ' (' + f.items.length + ')</summary><ul class="evlist">' + rows + '</ul></details>';
    }
    if(f.snippet){
      out += '<details class="evidence"><summary>\u25B8 show source</summary><pre class="src">' + f.snippet + '</pre></details>';
    }
    return out;
  }
  function findingCard(f){
    return '<div class="finding s-' + f.severity + '"><div class="body">'
      + '<span class="cat">' + esc(f.lang) + ' \u00B7 ' + esc(f.category) + ' \u00B7 ' + f.severity + '</span>'
      + '<div class="det">' + esc(f.detail) + '</div>'
      + (f.suggestion ? '<div class="sugg">\u2192 ' + esc(f.suggestion) + '</div>' : '')
      + '<div class="path-mini">/' + esc(f.path) + '</div>'
      + '</div>'
      + evidenceBlock(f)
      + '</div>';
  }
  /* ---- compact, scannable findings table (replaces stacked cards) ---- */
  function sevAbbr(s){ return s==='critical'?'c':s==='warning'?'w':'i'; }
  function sevBadge(s){ return '<span class="sevb '+sevAbbr(s)+'"><span class="dot"></span>'+esc(s)+'</span>'; }
  var FCELL = {
    sev:  function(f){ return sevBadge(f.severity); },
    page: function(f){ return '<span class="fc-pg">'+esc(f.page)+'</span><span class="fc-path">/'+esc(f.path)+'</span>'; },
    lang: function(f){ return '<span class="fc-lang">'+esc(f.lang)+'</span>'; },
    cat:  function(f){ return '<span class="fc-cat">'+esc(f.category)+'</span>'; },
    issue:function(f){ return '<span class="fc-issue">'+esc(f.detail)+'</span>'; }
  };
  var FHEAD = { sev:'Severity', page:'Page', lang:'Language', cat:'Category', issue:'Issue' };
  function findingsTable(rows, cols){
    if(!rows || !rows.length) return '<p class="empty">No findings.</p>';
    var span = cols.length + 1;
    var thead = '<thead><tr>' + cols.map(function(k){ return '<th class="sortable" data-k="'+k+'">'+FHEAD[k]+'<span class="sort-ind"></span></th>'; }).join('') + '<th></th></tr></thead>';
    var body = rows.map(function(f){
      var st = statusOf(f);
      var rowCls = st === 'done' ? ' resolved done' : st === 'ignored' ? ' resolved ignored' : '';
      var tag = st === 'done' ? '<span class="ftag done" title="Completed">\u2713</span>'
              : st === 'ignored' ? '<span class="ftag ignored" title="Ignored">\u2298</span>' : '';
      var tds = cols.map(function(k){ return '<td>'+FCELL[k](f)+'</td>'; }).join('')
        + '<td class="fc-exp">'+tag+'<span class="fchev">\u25B8</span></td>';
      var sortAttrs = ' data-sev="'+(sevRank[f.severity]!=null?sevRank[f.severity]:9)+'"'
        + ' data-page="'+esc(((f.page||'')+' '+(f.path||'')).toLowerCase())+'"'
        + ' data-lang="'+esc((f.lang||'').toLowerCase())+'"'
        + ' data-cat="'+esc((f.category||'').toLowerCase())+'"'
        + ' data-issue="'+esc((f.detail||'').toLowerCase())+'"';
      var detail = '<div class="fd-inner">'
        + (f.suggestion ? '<div class="fd-sugg">\u2192 '+esc(f.suggestion)+'</div>' : '')
        + '<div class="fd-meta">'+esc(f.lang)+' \u00B7 '+esc(f.category)+' \u00B7 /'+esc(f.path)+'</div>'
        + evidenceBlock(f) + triageActions(f) + '</div>';
      return '<tr class="frow'+rowCls+'"'+sortAttrs+'>'+tds+'</tr><tr class="fdetail"><td colspan="'+span+'">'+detail+'</td></tr>';
    }).join('');
    return '<div class="ftable-wrap"><table class="ft">'+thead+'<tbody>'+body+'</tbody></table></div>';
  }

  app.innerHTML =
    '<p class="eyebrow">Localization QA dashboard</p>'
    + '<h1>' + esc(D.meta.host) + '</h1>'
    + '<div class="dash-headrow">'
      + '<p class="sub">Generated ' + esc(D.meta.generated) + ' \u00B7 ' + esc(D.meta.langs.join(', ')) + ' \u00B7 translation check: ' + esc(D.meta.translationCheck) + '</p>'
      + '<a class="pdf-link" id="pdfLink" data-click="__pdf()" title="Save as PDF">'
        + '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>'
        + '<span>Save as report PDF</span></a>'
    + '</div>'
    + '<div class="tabs"><button class="tab active" id="tab-authors">Authors</button><button class="tab" id="tab-leaders">Admin</button></div>'
    + '<div id="view-authors"></div><div id="view-leaders" style="display:none"></div>';

  var curView = 'authors';
  window.__pdf = function(){ try { parent.postMessage({ __mlaudit:'pdf', view: curView }, '*'); } catch(e){} };
  window.__exportcsv = function(){ try { parent.postMessage({ __mlaudit:'exportcsv' }, '*'); } catch(e){} };

  function show(t){
    curView = t;
    document.getElementById('view-authors').style.display = t==='authors'?'block':'none';
    document.getElementById('view-leaders').style.display = t==='leaders'?'block':'none';
    document.getElementById('tab-authors').className = 'tab' + (t==='authors'?' active':'');
    document.getElementById('tab-leaders').className = 'tab' + (t==='leaders'?' active':'');
  }
  document.getElementById('tab-authors').onclick = function(){ show('authors'); };
  document.getElementById('tab-leaders').onclick = function(){ show('leaders'); };

  // when embedded in the audit page (iframe), let the parent drive the tab and hide our own tab bar
  function postHeight(){ try { parent.postMessage({ dashHeight: document.body.scrollHeight }, '*'); } catch(e){} }
  window.__publishRun = function(){
    var s=document.getElementById('publishStatus'); if(s){ s.textContent='Publishing…'; s.className='pub-status'; }
    try { parent.postMessage({ __mlaudit:'publish' }, '*'); } catch(e){}
  };
  window.__genAudit = function(){ try { parent.postMessage({ __mlaudit:'runAudit' }, '*'); } catch(e){} };
  window.__scan404 = function(){
    var s=document.getElementById('s404-status'); if(s){ s.textContent='Scanning sitemap…'; }
    var btn=document.getElementById('s404-btn'); if(btn){ btn.disabled=true; }
    try { parent.postMessage({ __mlaudit:'scan404' }, '*'); } catch(e){}
  };
  window.addEventListener('message', function(e){
    var m = e.data;
    if(m === 'hidetabs'){ var tb = document.querySelector('.tabs'); if(tb) tb.style.display = 'none'; }
    else if(m === 'tab:authors'){ show('authors'); postHeight(); }
    else if(m === 'tab:leaders'){ show('leaders'); postHeight(); }
    else if(m && m.__mlaudit_ack === 'publish'){
      var s=document.getElementById('publishStatus');
      if(s){ s.textContent = m.ok ? ('Published \u2713 ' + new Date(m.at).toLocaleTimeString()) : 'Publish failed — check the connection.'; s.className = 'pub-status' + (m.ok?' ok':' err'); }
    }
    else if(m && m.__mlaudit_scan){
      var st=document.getElementById('s404-status'); var p=m.__mlaudit_scan;
      if(st){
        if(p.phase==='start') st.textContent='Scanning sitemap…';
        else if(p.phase==='progress') st.textContent='Checking '+p.done+' of '+p.total+'…';
        else if(p.phase==='done'){ st.textContent = p.rec && p.rec.error==='no-sitemap' ? 'No saved sitemap — run “Discover pages from sitemap” first.' : ''; }
      }
    }
  });
  if(window.ResizeObserver){ new ResizeObserver(postHeight).observe(document.body); }
  setTimeout(postHeight, 200);

  /* expand/collapse a findings-table row to show its detail */
  document.addEventListener('click', function(e){
    var row = e.target.closest ? e.target.closest('tr.frow') : null;
    if(!row) return;
    var det = row.nextElementSibling;
    if(det && det.className.indexOf('fdetail') !== -1){
      var willOpen = !det.classList.contains('show');
      det.classList.toggle('show', willOpen);
      row.classList.toggle('open', willOpen);
      postHeight();
    }
  });

  // Click a column header to sort that findings table (keeps each row's detail with it).
  document.addEventListener('click', function(e){
    var th = e.target.closest ? e.target.closest('th.sortable') : null;
    if(!th) return;
    var table = th.closest('table.ft'); if(!table) return;
    var tbody = table.querySelector('tbody'); if(!tbody) return;
    var k = th.getAttribute('data-k');
    var dir = (table.getAttribute('data-sk') === k && table.getAttribute('data-sd') === 'asc') ? 'desc' : 'asc';
    table.setAttribute('data-sk', k); table.setAttribute('data-sd', dir);
    var kids = Array.prototype.slice.call(tbody.children), pairs = [];
    for(var i=0;i<kids.length;i+=2){ pairs.push([kids[i], kids[i+1]]); }
    var numeric = (k === 'sev');
    pairs.sort(function(a,b){
      var va = a[0].getAttribute('data-'+k) || '', vb = b[0].getAttribute('data-'+k) || '', c;
      if(numeric){ c = (parseFloat(va)||0) - (parseFloat(vb)||0); }
      else { c = va < vb ? -1 : va > vb ? 1 : 0; }
      return dir === 'asc' ? c : -c;
    });
    pairs.forEach(function(p){ tbody.appendChild(p[0]); if(p[1]) tbody.appendChild(p[1]); });
    table.querySelectorAll('th.sortable').forEach(function(h){ h.removeAttribute('data-dir'); });
    th.setAttribute('data-dir', dir);
    postHeight();
  });

  /* content-date lookup (best-effort match of audited page -> Sitecore date) */
  var cdByKey = {};
  function normKey(p){ return (p||'').toLowerCase().replace(/^\/+|\/+$/g,'').replace(/\s+/g,'-'); }
  (D.contentDates||[]).forEach(function(r){ cdByKey[normKey(r.path)] = r; });
  function pageDate(path){ return cdByKey[normKey((path||'').replace(/^(es|zh)\//,''))] || null; }
  function ageDays(iso, now){ var d=new Date(iso); return isNaN(d)?null:Math.floor((now - d.getTime())/86400000); }
  function fmtAge(days){ if(days==null) return ''; if(days<60) return days+'d'; var mo=Math.floor(days/30.44); if(mo<24) return mo+'mo'; return (days/365).toFixed(1)+'y'; }

  /* ===== Authors: pages with all their findings, click to expand ===== */
  var langOpts = Array.from(new Set(D.findings.map(function(f){return f.lang;}))).sort();
  var catOpts = Array.from(new Set(D.findings.map(function(f){return f.category;}))).sort();
  var av = document.getElementById('view-authors');
  av.innerHTML =
    '<div class="card"><div class="filters">'
    + '<select id="f-lang"><option value="">All languages</option>' + langOpts.map(function(l){return '<option>'+esc(l)+'</option>';}).join('') + '</select>'
    + '<select id="f-sev"><option value="">All severities</option><option>critical</option><option>warning</option><option>info</option></select>'
    + '<select id="f-cat"><option value="">All categories</option>' + catOpts.map(function(c){return '<option>'+esc(c)+'</option>';}).join('') + '</select>'
    + '<input id="f-q" placeholder="Search text or page\u2026" style="flex:1;min-width:160px">'
    + '<label class="f-toggle"><input type="checkbox" id="f-resolved"> show resolved</label>'
    + '<span class="muted" id="f-count" style="font-size:.8rem"></span>'
    + '</div><div id="author-list"></div></div>';

  var authorSel = null;
  function pageMeta(key, items, now){
    var head=key.split('||'), name=head[0], path=head[1];
    var cc=items.filter(function(f){return f.severity==='critical';}).length;
    var wc=items.filter(function(f){return f.severity==='warning';}).length;
    var ic=items.filter(function(f){return f.severity==='info';}).length;
    var cd=pageDate(path), datePill='';
    if(cd && cd.updated){ var a=ageDays(cd.updated, now); datePill='<span class="pill date">updated '+esc(cd.updated.slice(0,10))+(a!=null?' \u00B7 '+fmtAge(a):'')+(cd.updatedBy?' \u00B7 '+esc(cd.updatedBy):'')+'</span>'; }
    var pills=(cc?'<span class="pill c">'+cc+' critical</span>':'')+(wc?'<span class="pill w">'+wc+' warning</span>':'')+(ic?'<span class="pill i">'+ic+' info</span>':'')+datePill;
    return { name:name, path:path, pills:pills };
  }
  function renderAuthors(){
    var l=document.getElementById('f-lang').value, s=document.getElementById('f-sev').value,
        c=document.getElementById('f-cat').value, q=document.getElementById('f-q').value.toLowerCase();
    var showRes = document.getElementById('f-resolved').checked;
    var matched = D.findings.filter(function(f){
      return (!l||f.lang===l) && (!s||f.severity===s) && (!c||f.category===c)
        && (!q || (f.detail+' '+f.page+' '+f.path).toLowerCase().indexOf(q)!==-1);
    });
    var rows = matched.filter(function(f){ return showRes || isOpen(f); });
    var resolvedHidden = matched.length - rows.length;
    document.getElementById('f-count').textContent = rows.length + ' ' + (showRes?'finding(s)':'open') + ' across ' + (new Set(rows.map(function(f){return f.path;}))).size + ' page(s)' + (!showRes && resolvedHidden ? ' \u00B7 ' + resolvedHidden + ' resolved hidden' : '');
    var groups={}; rows.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
    var keys=Object.keys(groups).sort(function(a,b){ return groups[b].length-groups[a].length; });
    var host=document.getElementById('author-list');
    if(!keys.length){ host.innerHTML='<p class="empty">No findings match these filters.</p>'; authorSel=null; return; }
    if(keys.indexOf(authorSel)===-1) authorSel=keys[0];
    var now=D.now||Date.now();
    var selItems=groups[authorSel].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity])||a.lang.localeCompare(b.lang); });
    var selMeta=pageMeta(authorSel, groups[authorSel], now);
    var opts=keys.map(function(k){
      var m=pageMeta(k, groups[k], now);
      return '<div class="picker-opt'+(k===authorSel?' sel':'')+'" data-key="'+encodeURIComponent(k)+'">'
        + '<span class="po-name">'+esc(m.name)+'</span>'+m.pills
        + '<span class="pc-path">/'+esc(m.path)+'</span></div>';
    }).join('');
    host.innerHTML =
      '<div class="picker" id="pk">'
        + '<div class="picker-head" id="pk-head">'+chev
          + '<span class="pk-name">'+esc(selMeta.name)+'</span>'+selMeta.pills
          + '<span class="pc-path">/'+esc(selMeta.path)+'</span>'
          + '<span class="spacer" style="flex:1"></span>'
          + '<span class="pk-hint">'+keys.length+' page(s) \u00B7 click to change</span>'
        + '</div>'
        + '<div class="picker-list" id="pk-list">'+opts+'</div>'
      + '</div>'
      + '<div class="picker-detail">'+findingsTable(selItems, ['sev','lang','cat','issue'])+'</div>';
    document.getElementById('pk-head').onclick=function(){ document.getElementById('pk').classList.toggle('open'); };
    document.getElementById('pk-list').onclick=function(e){
      var opt=e.target.closest ? e.target.closest('.picker-opt') : null; if(!opt) return;
      authorSel=decodeURIComponent(opt.getAttribute('data-key'));
      renderAuthors();
    };
  }
  ['f-lang','f-sev','f-cat','f-resolved'].forEach(function(id){ document.getElementById(id).onchange=renderAuthors; });
  document.getElementById('f-q').oninput=renderAuthors;
  renderAuthors();

  /* ===== Leaders ===== */
  function kpi(n, label, cls, sev){
    return '<button class="kpi ' + (cls||'') + '" data-click="__drillSev(\'' + (sev||'') + '\')">'
      + '<span class="kpi-n">' + n + '</span><span class="kpi-l">' + label + '</span></button>';
  }
  function donut(parts, total){
    var r=58, c=2*Math.PI*r, cx=74, cy=74, off=0;
    var segs = parts.filter(function(p){return p.n>0;}).map(function(p){
      var len = total ? c*(p.n/total) : 0;
      var s = '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="'+p.color+'" stroke-width="15" '
        + 'stroke-dasharray="'+len+' '+(c-len)+'" stroke-dashoffset="'+(-off)+'" transform="rotate(-90 '+cx+' '+cy+')"/>';
      off += len; return s;
    }).join('');
    return '<svg viewBox="0 0 148 148" class="donut">'
      + '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="var(--border)" stroke-width="15"/>'
      + (total ? segs : '')
      + '<text x="74" y="72" text-anchor="middle" class="donut-n">'+total+'</text>'
      + '<text x="74" y="90" text-anchor="middle" class="donut-l">findings</text></svg>';
  }
  function legRow(color, label, n, tot){
    var pct = tot ? Math.round(n/tot*100) : 0;
    return '<div class="legend-row"><span class="swatch" style="background:'+color+'"></span>'
      + '<span class="lt">'+label+'</span><span class="ln">'+n+' \u00B7 '+pct+'%</span></div>';
  }
  function panel(title, inner){
    return '<section class="card"><p class="label">'+title+'</p>'+inner+'</section>';
  }
  window.__drillSev = function(sev){
    show('authors');
    document.getElementById('f-sev').value = sev || '';
    renderAuthors();
    document.getElementById('view-authors').scrollIntoView({behavior:'smooth', block:'start'});
  };
  function drill(dim, list){
    var cols = ['sev','page','issue'];
    var src = list || D.findings;
    var groups={}; src.forEach(function(f){ var k=f[dim]||'\u2014'; (groups[k]=groups[k]||[]).push(f); });
    var keys=Object.keys(groups).sort(function(a,b){ return groups[b].length-groups[a].length; });
    if(!keys.length) return '<p class="empty">No open findings.</p>';
    var max=groups[keys[0]].length;
    return keys.map(function(k){
      var list2=groups[k].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity]); });
      var pct=Math.round(list2.length/max*100);
      return '<details class="drill"><summary><span class="drill-label">'+chev+esc(k)+'</span>'
        +'<span class="bartrack"><span class="barfill" style="width:'+pct+'%"></span></span>'
        +'<span class="drill-count">'+list2.length+'</span></summary>'
        +'<div class="drill-body">'+findingsTable(list2, cols)+'</div></details>';
    }).join('');
  }
  function topProblemPages(list, n){
    var groups={}; list.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
    var scored=Object.keys(groups).map(function(k){
      var items=groups[k], w=0, c=0, wn=0, inf=0;
      items.forEach(function(f){
        if(f.severity==='critical'){ w+=100; c++; }
        else if(f.severity==='warning'){ w+=10; wn++; }
        else { w+=1; inf++; }
      });
      var head=k.split('||');
      return { name:head[0], path:head[1], score:w, count:items.length, crit:c, warn:wn, info:inf,
               items:items.slice().sort(function(a,b){ return sevRank[a.severity]-sevRank[b.severity]; }) };
    });
    scored.sort(function(a,b){ return b.score-a.score; });
    var top=scored.slice(0, n||5);
    if(!top.length) return '<p class="empty">No open findings.</p>';
    var mx=top[0].score||1;
    return top.map(function(r){
      var pct=Math.round(r.score/mx*100);
      var mix=[]; if(r.crit) mix.push(r.crit+' critical'); if(r.warn) mix.push(r.warn+' warning'); if(r.info) mix.push(r.info+' info');
      var tip='Ranked by severity \u00B7 ' + mix.join(', ');
      return '<details class="drill"><summary title="'+esc(tip)+'"><span class="rank-label">'+chev+'<span class="rank-name"><span class="rank-title">'+esc(r.name)+'</span><span class="rank-path">/'+esc(r.path)+'</span></span></span>'
        +'<span class="bartrack"><span class="barfill" style="width:'+pct+'%"></span></span>'
        +'<span class="drill-count">'+r.count+(r.crit?'<span class="rc-crit"> \u00B7 '+r.crit+'C</span>':'')+'</span></summary>'
        +'<div class="drill-body">'+findingsTable(r.items, ['sev','lang','cat','issue'])+'</div></details>';
    }).join('');
  }
  function sevByLangLine(list){
    var byLang={};
    list.forEach(function(f){ var l=f.lang||'\u2014'; byLang[l]=byLang[l]||{critical:0,warning:0,info:0}; byLang[l][f.severity]=(byLang[l][f.severity]||0)+1; });
    var langs=Object.keys(byLang).sort(function(a,b){
      var ta=byLang[a].critical+byLang[a].warning+byLang[a].info, tb=byLang[b].critical+byLang[b].warning+byLang[b].info;
      return tb-ta;
    });
    if(!langs.length) return '<p class="empty">No open findings.</p>';
    var palette = ['var(--accent)','var(--ok)','#8aa9d9','#b48ae0','#e08ac0','#7fd0c9'];
    var cats = ['critical','warning','info'], catLabels = ['Critical','Warning','Info'];
    var maxV = 1;
    langs.forEach(function(l){ cats.forEach(function(c){ if(byLang[l][c] > maxV) maxV = byLang[l][c]; }); });
    var W=440, H=200, padL=30, padR=14, padT=14, padB=28;
    var plotW=W-padL-padR, plotH=H-padT-padB;
    function xFor(i){ return padL + plotW*i/(cats.length-1); }
    function yFor(v){ return padT + plotH - (plotH*v/maxV); }
    var yTicks=[0, Math.round(maxV/2), maxV];
    var gridSvg = yTicks.map(function(t){
      var y=yFor(t);
      return '<line x1="'+padL+'" y1="'+y+'" x2="'+(W-padR)+'" y2="'+y+'" stroke="var(--border)" stroke-width="1"/>'
        + '<text x="'+(padL-8)+'" y="'+(y+3)+'" text-anchor="end" font-size="10" fill="var(--muted2)">'+t+'</text>';
    }).join('');
    var xLabels = cats.map(function(c,i){
      return '<text x="'+xFor(i)+'" y="'+(H-8)+'" text-anchor="middle" font-size="10" fill="var(--muted)">'+catLabels[i]+'</text>';
    }).join('');
    var lines = langs.map(function(l, li){
      var color = palette[li % palette.length];
      var pts = cats.map(function(c,i){ return xFor(i)+','+yFor(byLang[l][c]); }).join(' ');
      var dots = cats.map(function(c,i){
        return '<circle cx="'+xFor(i)+'" cy="'+yFor(byLang[l][c])+'" r="3.5" fill="'+color+'"><title>'+esc(l)+' \u00B7 '+catLabels[i]+': '+byLang[l][c]+'</title></circle>';
      }).join('');
      return '<polyline points="'+pts+'" fill="none" stroke="'+color+'" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>'+dots;
    }).join('');
    var svg = '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto;display:block">'+gridSvg+xLabels+lines+'</svg>';
    var legend = '<div class="lchart-legend">'+langs.map(function(l, li){
      var color = palette[li % palette.length];
      var t = byLang[l].critical+byLang[l].warning+byLang[l].info;
      return '<span class="item"><span class="swatch" style="background:'+color+'"></span>'+esc(l)+' <span class="n">('+t+')</span></span>';
    }).join('')+'</div>';
    return svg + legend;
  }
  var staleMonths = '12';
  var findingsDim = 'category';

  var lv=document.getElementById('view-leaders');
  function renderLeaders(){
    var ACT = activeFindings();

    var bs = countByApp(ACT, 'severity');
    var sc=bs.critical||0, sw=bs.warning||0, si=bs.info||0, stot=sc+sw+si;
    var sevInner='<div class="sevmix">'
      + donut([{n:sc,color:'var(--crit)'},{n:sw,color:'var(--warn)'},{n:si,color:'var(--muted2)'}], stot)
      + '<div class="legend">'
        + legRow('var(--crit)','Critical',sc,stot)
        + legRow('var(--warn)','Warning',sw,stot)
        + legRow('var(--muted2)','Info',si,stot)
      + '</div></div>';

    var cov=D.coverage;
    var covMissing=cov.missing.length
      ? cov.missing.map(function(m){ return '<div class="barrow"><span style="min-width:150px">'+esc(m.lang)+'</span><span class="crit">'+m.count+' page(s) missing / errored</span></div>'; }).join('')
      : '<p class="ok" style="font-size:.85rem">Every audited page returned a version in all languages.</p>';
    var covInner='<div class="covrow"><span class="big">'+cov.audited+'</span><span class="muted">of '+cov.discovered+' discovered page(s) audited</span></div>'+covMissing;

    var sync = D.sync || {};
    var staleFindings = ACT.filter(function(f){ return f.category === 'source changed, translation stale'; });
    var queueHtml = '';
    if(sync.hasBaseline){
      var apprTxt = sync.approvedAt ? ' \u00B7 approved ' + esc(new Date(sync.approvedAt).toLocaleDateString()) : '';
      if(staleFindings.length){
        queueHtml = '<section class="card queue-stale"><p class="label">\u26A0 Stale because English changed \u00B7 retranslate these (' + staleFindings.length + ')' + apprTxt + '</p>'
          + findingsTable(staleFindings, ['sev','page','lang','issue']) + '</section>';
      } else {
        queueHtml = '<section class="card queue-ok"><p class="label">Source sync' + apprTxt + '</p>'
          + '<p class="ok" style="font-size:.88rem">No open stale translations — every approved translation still matches its English source.</p></section>';
      }
    }

    // triage progress
    var doneN=0, ignN=0;
    (D.findings||[]).forEach(function(f){ var st=statusOf(f); if(st==='done')doneN++; else if(st==='ignored')ignN++; });
    var totalN=(D.findings||[]).length, openN=ACT.length;
    var pctDone = totalN ? Math.round((doneN+ignN)/totalN*100) : 0;
    var triageInner = '<div class="covrow"><span class="big">'+openN+'</span><span class="muted">open of '+totalN+' finding(s)</span></div>'
      + '<div class="tprog"><span class="tprog-bar" style="width:'+pctDone+'%"></span></div>'
      + '<div class="barrow" style="margin-top:.6rem"><span class="ok">'+doneN+' completed</span><span class="muted">'+ignN+' ignored</span></div>';

    var modeLabel = (D.storeMode === 'remote') ? 'Shared store \u00B7 team-wide' : 'Local only \u00B7 this browser';
    var canPublish = !!D.hasLocalRun;
    var publishInner = '<p class="muted" style="font-size:.82rem;margin:0 0 .9rem">'+esc(modeLabel)+'</p>'
      + '<div class="pub-actions">'
        + '<button class="pub-btn pub-secondary"'+(canPublish?'':' disabled')+' data-click="__publishRun()">Publish run to team</button>'
        + (D.canRun ? '<button class="pub-btn pub-primary" data-click="__genAudit()">Generate new audit</button>' : '')
      + '</div>'
      + '<div id="publishStatus" class="pub-status">'+(canPublish?'':'Run a new audit to publish it to the team.')+'</div>';

    // Prefer the explicit missing-translations list; fall back to reconstructing from
    // findings so older runs still match the Findings box.
    var mtList = Array.isArray(D.missingTranslations) ? D.missingTranslations.slice()
      : (D.findings || []).filter(function(f){ return f.category === 'load error' && f.lang !== 'English (reference)'; })
          .map(function(f){ return { page:f.page, lang:f.lang, url:'', error:f.detail || 'failed to load' }; });

    var s404Inner = (function(){
      var out = '';

      // Group 1 — missing/broken foreign-language pages found by the last audit
      var mt = mtList.slice().sort(function(a,b){ return (a.page+a.lang).localeCompare(b.page+b.lang); });
      out += '<details class="acc-collapse s404-group" open><summary class="s404-grouphead acc-summary">Missing translations \u00B7 expected foreign-language pages that failed to load'
        + (mt.length? ' ('+mt.length+')':'') + '<span class="chev">\u25B8</span></summary>';
      if(!D.summary || !D.summary.pages){
        out += '<p class="muted" style="font-size:.82rem;margin:.1rem 0 .5rem">Run an audit to check whether each page\u2019s translated versions exist.</p>';
      } else if(!mt.length){
        out += '<p style="color:var(--ok);font-size:.85rem;margin:.1rem 0 .5rem">Every audited page returned a version in all languages.</p>';
      } else {
        var capN = 60, cap = mt.slice(0, capN);
        out += '<div class="s404-list">' + cap.map(function(m){
          var label = m.url ? m.url : (m.page + ' \u2014 ' + m.lang);
          var right = m.lang + ' \u00B7 ' + m.error;
          var inner = '<span class="s404-url">' + esc(label) + '</span>';
          if(m.url) inner = '<a class="s404-url" href="'+esc(m.url)+'" target="_blank" rel="noopener">'+esc(label)+'</a>';
          return '<div class="s404-row">' + inner + '<span class="s404-seen">'+esc(right)+'</span></div>';
        }).join('') + '</div>';
        if(mt.length > cap.length){
          out += '<p class="muted" style="font-size:.78rem;margin:.5rem 0 0">+' + (mt.length - cap.length)
            + ' more \u2014 see every one under <strong>Findings \u25B8 by language</strong>.</p>';
        }
      }
      out += '</details>';

      // Group 2 — sitemap monitor (internal pages the sitemap lists that 404)
      var s = D.sitemap404;
      out += '<details class="acc-collapse s404-group" open><summary class="s404-grouphead acc-summary">Sitemap monitor \u00B7 internal pages the sitemap lists that return 404<span class="chev">\u25B8</span></summary>';
      if(!s || !s.checked){
        out += '<p class="muted" style="margin:.1rem 0 .5rem;font-size:.82rem">Checks the saved sitemap for internal pages that return 404. The scheduled job also updates this list.</p>';
      } else {
        var deadUrls = Object.keys(s.urls || {});
        out += '<p class="muted" style="margin:.1rem 0 .5rem;font-size:.82rem">Last checked '+new Date(s.checked).toLocaleString()+' \u00B7 '+s.dead+' dead of '+s.total+' checked'+(s.newCount? ' \u00B7 '+s.newCount+' new':'')+'</p>';
        if(!deadUrls.length){
          out += '<p style="color:var(--ok);font-size:.85rem">No 404s — every page in the saved sitemap resolved.</p>';
        } else {
          out += '<div class="s404-list">' + deadUrls.sort(function(a,b){ return (s.urls[b].firstSeen||'').localeCompare(s.urls[a].firstSeen||''); }).map(function(u){
            var isNew = s.newUrls && s.newUrls.indexOf(u) !== -1;
            var seen = s.urls[u].firstSeen ? 'since '+new Date(s.urls[u].firstSeen).toLocaleDateString() : '';
            return '<div class="s404-row">'+(isNew?'<span class="s404-new">NEW</span>':'')
              + '<a class="s404-url" href="'+esc(u)+'" target="_blank" rel="noopener">'+esc(u)+'</a>'
              + '<span class="s404-seen">'+seen+'</span></div>';
          }).join('') + '</div>';
        }
      }
      if(D.canRun){
        out += '<div style="margin-top:.7rem;display:flex;align-items:center;gap:.6rem;flex-wrap:wrap">'
          + '<button id="s404-btn" class="pub-btn pub-secondary" style="flex:0 0 auto;width:auto;padding:.5rem .9rem" data-click="__scan404()">Check sitemap now</button>'
          + '<span id="s404-status" class="muted" style="font-size:.8rem"></span></div>';
      }
      out += '</details>';
      return out;
    })();

    var critK = ACT.filter(function(f){return f.severity==='critical' && f.category!=='broken link';}).length;
    var brokenK = ACT.filter(function(f){return f.category==='broken link';}).length;
    lv.innerHTML=
      '<div class="kpis">'
        + kpi(D.summary.pages,'Pages','accent','')
        + kpi(critK,'Critical','crit','critical')
        + kpi(sw,'Warnings','warn','warning')
        + kpi(brokenK,'Broken links',brokenK?'crit':'','')
        + kpi(openN,'Open findings','','')
        + '</div>'
      + '<div class="dash-grid dash-grid-eq">'
        + panel('Severity mix \u00B7 click a metric above to drill in', sevInner)
        + panel('Publish &amp; generate', publishInner)
        + '</div>'
      + queueHtml
      + panel('Top problem pages', topProblemPages(ACT, 5))
      + (function(){
          var dead = ((D.sitemap404 && D.sitemap404.urls) ? Object.keys(D.sitemap404.urls).length : 0)
                   + mtList.length;
          var pill = dead ? ' <span class="count-pill">'+dead+'</span>' : '';
          return '<section class="card card-404'+(dead?' has-dead':'')+'">'
            + '<p class="label">404 errors'+pill+'</p>'
            + s404Inner + '</section>';
        })()
      + '<div class="dash-grid dash-grid-eq">'
        + '<section class="card">'
          + '<details class="acc-collapse" open>'
            + '<summary class="label acc-summary">Findings<span class="chev">\u25B8</span></summary>'
            + '<div class="filters"><span class="muted">Group</span>'
            + '<select id="findings-dim">'
            + '<option value="category"'+(findingsDim==='category'?' selected':'')+'>by category</option>'
            + '<option value="lang"'+(findingsDim==='lang'?' selected':'')+'>by language</option>'
            + '<option value="dir"'+(findingsDim==='dir'?' selected':'')+'>by section / directory</option>'
            + '</select><span class="muted" style="font-size:.78rem">\u00B7 click a row to expand</span></div>'
            + '<div id="findings-drill">' + drill(findingsDim, ACT) + '</div>'
          + '</details>'
        + '</section>'
        + panel('Severity by language', sevByLangLine(ACT))
        + '</div>'
      + '<div class="dash-grid dash-grid-eq">'
        + panel('Triage progress', triageInner)
        + panel('Translation coverage', covInner)
        + '</div>'
      + '<section class="card">'
        + '<details class="stale-collapse" open>'
          + '<summary class="label stale-summary">Stale content<span class="chev">\u25B8</span></summary>'
          + '<div class="filters"><span class="muted">Flag pages not updated in over</span>'
          + '<select id="stale-threshold">'
          + ['3','6','12','18','24'].map(function(v){ return '<option value="'+v+'"'+(v===staleMonths?' selected':'')+'>'+v+' months</option>'; }).join('')
          + '</select></div>'
          + '<div id="stale-body"></div>'
        + '</details>'
      + '</section>';
    var sel=document.getElementById('stale-threshold');
    if(sel){ sel.onchange=function(){ staleMonths=sel.value; renderStale(); }; }
    var fdim=document.getElementById('findings-dim');
    if(fdim){ fdim.onchange=function(){ findingsDim=fdim.value; var fd=document.getElementById('findings-drill'); if(fd){ fd.innerHTML=drill(findingsDim, activeFindings()); } postHeight(); }; }
    renderStale();
  }

  function parseDate(s){
    if(!s) return null;
    var m=/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(s);
    if(m) return new Date(Date.UTC(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+m[6]));
    var t2=Date.parse(s); return isNaN(t2)?null:new Date(t2);
  }
  function renderStale(){
    var staleBody=document.getElementById('stale-body'); if(!staleBody) return; // panel disabled
    var months=+document.getElementById('stale-threshold').value;
    var now=D.now||Date.now();
    var cutoff=now-months*30.44*86400000;
    var useSc=D.contentDates && D.contentDates.length;
    var src=useSc
      ? D.contentDates.map(function(r){ return {path:r.path,by:r.updatedBy,created:r.created,createdBy:r.createdBy,date:parseDate(r.updated)}; })
      : (D.pages||[]).map(function(p){ return {path:p.path,by:'',date:parseDate(p.lastmod)}; });
    var dated=src.filter(function(r){return r.date;}).sort(function(a,b){return a.date-b.date;});
    var staleCount=dated.filter(function(r){return r.date.getTime()<cutoff;}).length;
    var html='<p class="sub">'+(useSc?'Real publish dates from Sitecore. ':'')
      +staleCount+' of '+dated.length+' page(s) not updated in over '+months+' month(s). Click a row for detail.</p>';
    if(!dated.length){
      document.getElementById('stale-body').innerHTML=html+'<p class="empty">No dates loaded. In the audit tool, click \u201cLoad content dates\u201d and pick your \u201cItems last updated\u201d export, then save the dashboard again.</p>';
      return;
    }
    var staleRows=dated.filter(function(r){return r.date.getTime()<cutoff;});
    if(!staleRows.length){
      document.getElementById('stale-body').innerHTML=html+'<p class="empty" style="color:var(--ok)">No pages are stale at this threshold.</p>';
      return;
    }
    html+='<div class="headrow"><span>Page</span><span>Updated</span><span>Age</span><span>Status</span></div>';
    html+=staleRows.map(function(r){
      var dAge=Math.floor((now-r.date.getTime())/86400000);
      var stale=r.date.getTime()<cutoff;
      var body='<div class="st-body">'
        + '<div><span class="k">Last updated</span><br><span class="v">'+esc(r.date.toISOString().slice(0,10))+'</span></div>'
        + (r.by?'<div><span class="k">Updated by</span><br><span class="v">'+esc(r.by)+'</span></div>':'')
        + (r.created?'<div><span class="k">Created</span><br><span class="v">'+esc((parseDate(r.created)||r.created).toISOString?parseDate(r.created).toISOString().slice(0,10):r.created)+'</span></div>':'')
        + (r.createdBy?'<div><span class="k">Created by</span><br><span class="v">'+esc(r.createdBy)+'</span></div>':'')
        + '<div><span class="k">Full path</span><br><span class="v">/'+esc(r.path)+'</span></div>'
        + '</div>';
      return '<details class="stale'+(stale?' is-stale':'')+'"><summary>'
        + '<span class="st-path">'+chev+' /'+esc(r.path)+'</span>'
        + '<span class="st-date">'+esc(r.date.toISOString().slice(0,10))+'</span>'
        + '<span class="st-age">'+fmtAge(dAge)+'</span>'
        + '<span>'+(stale?'<span class="crit">stale</span>':'<span class="ok">current</span>')+'</span>'
        + '</summary>'+body+'</details>';
    }).join('');
    document.getElementById('stale-body').innerHTML=html;
  }
  renderLeaders();
}

function collectRows(){
  const rows = [];
  (auditState && auditState.results || []).forEach(r => {
    const page = r.page.name;
    if(r.refError) rows.push({ page, lang:'English (reference)', section:'Fetch', severity:'critical', category:'load error', detail:r.refError, a:'', b:'' });
    if(r.refTech){
      r.refTech.code.forEach(c => rows.push({ page, lang:'English (reference)', section:'Code', severity:c.sev, category:'code', detail:c.text, a:'', b:'' }));
      r.refTech.links.forEach(l => rows.push({ page, lang:'English (reference)', section:'Links', severity:'critical', category:'broken link', detail:l.url, a:'', b:String(l.status||'no response') }));
    }
    (r.languages||[]).forEach(bk => {
      const lang = bk.lang.label;
      if(bk.error){ rows.push({ page, lang, section:'Fetch', severity:'critical', category:'load error', detail:bk.error, a:'', b:'' }); return; }
      const push = (arr, section) => (arr||[]).forEach(is => rows.push({ page, lang, section, severity:is.severity||'info', category:is.category||'', detail:is.explanation||'', a:is.reference||'', b:is.translation||'' }));
      if(bk.drift) push(bk.drift.issues, 'Drift from Google');
      if(bk.driftError) rows.push({ page, lang, section:'Drift from Google', severity:'info', category:'unavailable', detail:bk.driftError, a:'', b:'' });
      if(bk.ai) push(bk.ai.issues, 'Translation (Claude)');
      if(bk.aiError) rows.push({ page, lang, section:'Translation (Claude)', severity:'info', category:'unavailable', detail:bk.aiError, a:'', b:'' });
      push(bk.parity, 'Sections & parity');
      push(bk.content, 'Content & SEO');
      if(bk.tech){
        bk.tech.code.forEach(c => rows.push({ page, lang, section:'Code', severity:c.sev, category:'code', detail:c.text, a:'', b:'' }));
        bk.tech.links.forEach(l => rows.push({ page, lang, section:'Links', severity:'critical', category:'broken link', detail:l.url, a:'', b:String(l.status||'no response') }));
      }
    });
  });
  return rows;
}
function csvCell(v){ v = (v==null?'':String(v)); return /[",\n]/.test(v) ? '"' + v.replace(/"/g,'""') + '"' : v; }
function exportCsv(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  const rows = collectRows();
  const header = ['Page','Language','Section','Severity','Category','Detail','Reference / link','Translation / status'];
  const lines = [header.join(',')];
  rows.forEach(r => lines.push([r.page, r.lang, r.section, r.severity, r.category, r.detail, r.a, r.b].map(csvCell).join(',')));
  downloadBlob('\ufeff' + lines.join('\r\n'), 'text/csv', `audit-issues-${reportHost()}-${new Date().toISOString().slice(0,10)}.csv`);
  setReportStatus(`Exported ${rows.length} issue row(s) to CSV.`);
}

/* ----------------------------- fetching ----------------------------- */
function proxify(target){
  const base = WORKER_URL.trim();
  try {
    const u = new URL(base);
    u.searchParams.set('url', target);
    return u.href;
  } catch(e){
    // fallback if base isn't a valid URL yet
    return base + (base.includes('?') ? '&' : '?') + 'url=' + encodeURIComponent(target);
  }
}
function fetchOpts(extra){
  const opts = Object.assign({ method:'GET' }, extra || {});
  const key = WORKER_KEY.trim();
  if(key){ opts.headers = Object.assign({}, opts.headers, { 'X-Audit-Key': key }); }
  return opts;
}
async function fetchPage(url){
  // In the extension, host_permissions let us fetch azblue.com directly — no proxy needed.
  const direct = (typeof EXT_MODE !== 'undefined') && EXT_MODE;
  const requested = direct ? url : proxify(url);
  // The Sitecore CM host sits behind a login — send the user's session cookie for it only.
  const needsAuth = /(^|\.)cm\.prod\.azblue\.com$/i.test((function(){ try { return new URL(requested).hostname; } catch(e){ return ''; } })());
  const directOpts = needsAuth ? { method:'GET', credentials:'include' } : { method:'GET' };
  try {
    const res = await fetch(requested, direct ? directOpts : fetchOpts());
    const text = await res.text();
    return { ok: res.ok, status: res.status, text, requested };
  } catch(e){
    return { ok:false, status:0, text:'', error: e.message, requested };
  }
}

async function testConnection(){
  const el = document.getElementById('testResult');
  const url = (document.getElementById('testUrl').value || '').trim();
  if(!url){ el.innerHTML = `<div class="err-note" style="margin-top:1rem;">Enter a page URL to test.</div>`; return; }
  el.innerHTML = `<div class="score" style="margin-top:1rem;">Requesting…</div>`;
  const r = await fetchPage(url);
  const snippet = (r.text||'').slice(0,300).replace(/\s+/g,' ').trim();
  const okClass = r.ok ? 'ok' : 'crit';
  el.innerHTML = `<div style="margin-top:1rem; border:1px solid var(--border); border-radius:8px; padding:1rem;">
    <div class="score">Tested address:</div>
    <div style="font-size:.8rem; word-break:break-all; margin:.25rem 0 .8rem;"><a href="${escapeAttr(url)}" target="_blank" rel="noopener" style="color:var(--accent-deep); text-decoration:none;">${escapeHtml(url)}</a></div>
    <div class="score">Response: <span class="pill ${okClass}">${r.error ? 'network error' : ('HTTP ' + r.status)}</span></div>
    ${r.error ? `<div class="err-note" style="margin-top:.6rem;">${escapeHtml(r.error)} — usually a CORS or unreachable-worker problem.</div>` : ''}
    ${snippet ? `<div class="score" style="margin-top:.8rem;">First bytes returned:</div><div style="font-size:.78rem; color:var(--muted); background:var(--card-alt); border:1px solid var(--border); border-radius:6px; padding:.5rem .6rem; margin-top:.3rem; word-break:break-all;">${escapeHtml(snippet)}…</div>` : ''}
    <div class="score" style="margin-top:.8rem;">A 200 means the page is reachable. A 403 from the worker means ACCESS_KEY in config.js doesn't match; other codes come from the site itself.</div>
  </div>`;
}
function siteHostName(){ try { return new URL(SITE_URL).hostname; } catch(e){ return ''; } }
function proxifyCheck(target){
  const base = WORKER_URL.trim();
  try { const u = new URL(base); u.searchParams.set('check','1'); u.searchParams.set('url', target); return u.href; }
  catch(e){ return base + (base.includes('?')?'&':'?') + 'check=1&url=' + encodeURIComponent(target); }
}
let linkCache = new Map();   // url -> Promise<result>, dedupes within a single run
let linkResults = new Map(); // url -> resolved {url,status,ok,...}, persists across runs + saved to file
function checkResource(url){
  const reverify = document.getElementById('reverify') && document.getElementById('reverify').checked;
  if(!reverify && linkResults.has(url)) return Promise.resolve(linkResults.get(url));
  if(linkCache.has(url)) return linkCache.get(url);
  const pr = (async () => {
    let r;
    try {
      const res = await fetch(proxifyCheck(url), fetchOpts());
      const ct = res.headers.get('content-type') || '';
      if(ct.includes('application/json')){
        const d = await res.json();
        r = { url, status: d.status||0, ok: !!d.ok, ts: Date.now() };
      } else {
        // worker's check endpoint not deployed yet — degrade gracefully
        let body=''; try { body = await res.text(); } catch(e){}
        if(res.status === 403 && /Target host not allowed/i.test(body)){
          r = { url, status: 0, ok:false, blocked:true, note:'worker check endpoint not enabled', ts: Date.now() };
        } else {
          r = { url, status: res.status, ok: res.status>=200 && res.status<400, ts: Date.now() };
        }
      }
    } catch(e){
      r = { url, status:0, ok:false, error:e.message, ts: Date.now() };
    }
    linkResults.set(url, r);
    return r;
  })();
  linkCache.set(url, pr);
  return pr;
}
async function pool(items, worker, concurrency){
  const out = []; let i = 0;
  const runners = Array.from({length: Math.min(concurrency, items.length||1)}, async () => {
    while(i < items.length){ const idx = i++; out[idx] = await worker(items[idx], idx); }
  });
  await Promise.all(runners);
  return out;
}

/* ----------------------------- parsing ----------------------------- */
function extract(html, baseUrl){
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const abs = (href) => { try { return new URL(href, baseUrl).href; } catch(e){ return null; } };

  const headings = [...doc.querySelectorAll('h1,h2,h3,h4,h5,h6')]
    .map(h => ({ level: +h.tagName[1], text: clean(h.textContent) })).filter(h=>h.text);

  const anchors = [...doc.querySelectorAll('a[href]')];
  const links = [];
  anchors.forEach(a => {
    const raw = a.getAttribute('href');
    if(!raw) return;
    if(/^(mailto:|tel:|javascript:|#)/i.test(raw)) return;
    const u = abs(raw);
    if(u && /^https?:/i.test(u)) links.push(u);
  });

  const images = [...doc.querySelectorAll('img')].map(img => ({
    src: abs(img.getAttribute('src')||''), alt: img.getAttribute('alt')
  }));

  // visible-ish text
  const bodyClone = doc.body ? doc.body.cloneNode(true) : doc.cloneNode(true);
  bodyClone.querySelectorAll('script,style,noscript,svg,template').forEach(n=>n.remove());
  const textContent = clean(bodyClone.textContent || '');

  // ordered text segments (for Pattern A drift comparison)
  const segments = [];
  doc.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li').forEach(el => {
    if(el.tagName === 'LI' && el.querySelector('li,ul,ol')) return; // outer list container; inner captured
    if(el.tagName === 'P' && el.querySelector('p')) return;
    const t = clean(el.textContent || '');
    if(t.length >= 3) segments.push(t);
  });

  const title = clean(doc.querySelector('title')?.textContent || '');
  const metaDesc = doc.querySelector('meta[name="description"]')?.getAttribute('content') || '';

  // hreflang alternates
  const hreflang = [...doc.querySelectorAll('link[rel="alternate"][hreflang]')]
    .map(l => ({ lang: (l.getAttribute('hreflang')||'').toLowerCase(), href: abs(l.getAttribute('href')||'') }));

  // canonical + robots
  const canonical = abs(doc.querySelector('link[rel="canonical"]')?.getAttribute('href') || '');
  const robotsMeta = (doc.querySelector('meta[name="robots"]')?.getAttribute('content') || '').toLowerCase();
  const noindex = /noindex/.test(robotsMeta);

  // structured data (JSON-LD)
  const schemaTypes = [];
  doc.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
    try {
      const j = JSON.parse(s.textContent || '{}');
      const collect = (o) => { if(!o) return; if(Array.isArray(o)) return o.forEach(collect); if(o['@type']) [].concat(o['@type']).forEach(t => schemaTypes.push(String(t))); if(o['@graph']) collect(o['@graph']); };
      collect(j);
    } catch(e){}
  });

  // headings detail
  const h1Count = headings.filter(h => h.level === 1).length;
  let skipped = false;
  for(let i=1;i<headings.length;i++){ if(headings[i].level - headings[i-1].level > 1){ skipped = true; break; } }

  // word count + placeholders
  const words = textContent ? textContent.split(/\s+/).filter(Boolean).length : 0;
  const placeholders = (textContent.match(/lorem ipsum|lipsum|\bTODO\b|coming soon|placeholder text|dummy text/gi) || []);

  return {
    title, metaDesc,
    titleLen: title.length, metaDescLen: metaDesc.length,
    htmlLang: doc.documentElement.getAttribute('lang') || '',
    hreflang, canonical, noindex,
    schemaTypes: [...new Set(schemaTypes)],
    h1Count, headingSkip: skipped,
    words, placeholders: [...new Set(placeholders.map(p=>p.toLowerCase()))],
    headings,
    links: [...new Set(links)],
    images,
    counts: {
      headings: headings.length,
      links: anchors.length,
      images: images.length,
      forms: doc.querySelectorAll('form').length,
      inputs: doc.querySelectorAll('input,textarea,select').length,
      buttons: doc.querySelectorAll('button').length
    },
    emptyLinks: anchors.filter(a => { const h=a.getAttribute('href'); return !h || h==='#' || h.trim()===''; }).length,
    missingAlt: images.filter(i => i.alt === null).length,
    duplicateIds: findDuplicateIds(doc),
    regions: detectRegions(doc),
    segments,
    rawHtml: html,
    baseUrl: baseUrl,
    textContent
  };
}

/* ---- HTML snippet helpers (context for issues) ---- */
function parseDoc(rawHtml){ try { return new DOMParser().parseFromString(rawHtml||'', 'text/html'); } catch(e){ return null; } }
function findByText(doc, text){
  if(!doc || !text) return null;
  const norm = normForCompare(text).slice(0, 140);
  if(norm.length < 3) return null;
  let best = null, bestLen = Infinity;
  doc.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li,a,button,label,td,th,figcaption,span,div').forEach(el => {
    const t = clean(el.textContent || ''); if(!t) return;
    if(normForCompare(t).includes(norm) && t.length < bestLen){ best = el; bestLen = t.length; }
  });
  return best;
}
function findAnchor(doc, url, baseUrl){
  if(!doc) return null;
  let found = null;
  doc.querySelectorAll('a[href]').forEach(a => {
    if(found) return;
    const raw = a.getAttribute('href'); if(!raw) return;
    try { if(new URL(raw, baseUrl || undefined).href === url) found = a; } catch(e){ if(raw === url) found = a; }
  });
  return found;
}
function srcSnippet(rawHtml, el){
  if(!rawHtml || !el) return '';
  // find where this element lives in the actual served source
  const cand = [];
  const href = el.getAttribute && el.getAttribute('href');
  const id = el.getAttribute && el.getAttribute('id');
  if(href){ cand.push('href="'+href+'"', "href='"+href+"'"); }
  if(id){ cand.push('id="'+id+'"', "id='"+id+"'"); }
  const txt = clean(el.textContent || '');
  if(txt) cand.push(txt.slice(0, 40));
  let idx = -1;
  for(const c of cand){ if(c && c.length >= 3){ idx = rawHtml.indexOf(c); if(idx !== -1) break; } }
  if(idx === -1) return '';
  // Open at the tag that owns the match so the offending element is always visible.
  // Previously this backed up 200 chars first, which often pushed the element itself
  // out of the excerpt and showed surrounding layout markup instead.
  let tagStart = rawHtml.lastIndexOf('<', idx);
  if(tagStart === -1) tagStart = Math.max(0, idx - 40);
  // include the element's closing tag when it's close by
  let tagEnd = rawHtml.indexOf('>', idx);
  const tagName = (rawHtml.slice(tagStart + 1, tagStart + 12).match(/^[a-zA-Z0-9]+/) || [''])[0];
  if(tagName){
    const close = rawHtml.indexOf('</' + tagName + '>', idx);
    if(close !== -1 && close - tagStart < 600) tagEnd = close + tagName.length + 3;
  }
  if(tagEnd === -1 || tagEnd < idx) tagEnd = Math.min(rawHtml.length, idx + 200);
  const ctxStart = Math.max(0, tagStart - 60);
  const ctxEnd = Math.min(rawHtml.length, Math.max(tagEnd, idx + 160) + 60);
  let slice = rawHtml.slice(ctxStart, ctxEnd);
  // trim to clean tag boundaries, but never past the element we came here to show
  const keepFrom = tagStart - ctxStart;
  const firstLt = slice.indexOf('<');
  if(firstLt > 0 && firstLt <= keepFrom) slice = slice.slice(firstLt);
  const lastGt = slice.lastIndexOf('>'); if(lastGt !== -1) slice = slice.slice(0, lastGt + 1);
  slice = slice.replace(/^\s+|\s+$/g, '');
  if(ctxStart > 0) slice = '…\n' + slice;
  if(ctxEnd < rawHtml.length) slice = slice + '\n…';
  return escapeHtml(slice);
}

/* ---- major page regions (landmarks) ---- */
const REGION_DEFS = [
  { key:'header', label:'Header',             sel:'header, [role="banner"]',                 cls:/(^|[-_ ])(site[-_]?header|page[-_]?header|masthead|header)([-_ ]|$)/i,  major:true },
  { key:'nav',    label:'Primary navigation', sel:'nav, [role="navigation"]',                cls:/(^|[-_ ])(primary[-_]?nav|main[-_]?nav|navbar|navigation|nav|menu)([-_ ]|$)/i, major:true },
  { key:'main',   label:'Main content',       sel:'main, [role="main"]',                    cls:/(^|[-_ ])(main[-_]?content|page[-_]?content|content[-_]?main|main|content)([-_ ]|$)/i, major:true },
  { key:'aside',  label:'Sidebar',            sel:'aside, [role="complementary"]',          cls:/(^|[-_ ])(sidebar|complementary|aside)([-_ ]|$)/i, major:false },
  { key:'footer', label:'Footer',             sel:'footer, [role="contentinfo"]',           cls:/(^|[-_ ])(site[-_]?footer|page[-_]?footer|footer)([-_ ]|$)/i, major:true },
  { key:'search', label:'Search',             sel:'[role="search"], form[role="search"]',   cls:/(^|[-_ ])(search[-_]?form|site[-_]?search|search)([-_ ]|$)/i, major:false }
];
function detectRegion(doc, def){
  let els = [...doc.querySelectorAll(def.sel)];
  if(!els.length){
    els = [...doc.querySelectorAll('div,section,header,footer,nav,aside')].filter(el => {
      const idc = (el.getAttribute('id')||'') + ' ' + (el.getAttribute('class')||'');
      return def.cls.test(idc);
    });
  }
  if(!els.length) return { present:false, textLen:0, links:0 };
  let best = els[0], bestLen = -1;
  els.forEach(el => {
    const l = clean(el.textContent||'').length;
    if(l > bestLen){ bestLen = l; best = el; }
  });
  return { present:true, textLen:bestLen, links:best.querySelectorAll('a[href]').length };
}
function detectRegions(doc){
  const out = {};
  REGION_DEFS.forEach(def => { out[def.key] = detectRegion(doc, def); });
  return out;
}
function regionElement(doc, def){
  if(!doc) return null;
  let els = [...doc.querySelectorAll(def.sel)];
  if(!els.length){
    els = [...doc.querySelectorAll('div,section,header,footer,nav,aside')].filter(el =>
      def.cls.test((el.getAttribute('id')||'') + ' ' + (el.getAttribute('class')||'')));
  }
  if(!els.length) return null;
  let best = els[0], bestLen = -1;
  els.forEach(el => { const l = clean(el.textContent||'').length; if(l > bestLen){ bestLen = l; best = el; } });
  return best;
}
function regionDiff(refRegions, transRegions, liveDoc, liveRawHtml){
  const issues = [];
  REGION_DEFS.forEach(def => {
    const r = refRegions[def.key], t = transRegions[def.key];
    if(!r || !r.present) return; // only compare regions that exist on the English page
    if(!t || !t.present){
      const words = Math.round(r.textLen / 6);
      issues.push({
        category:'missing',
        severity: def.major ? 'critical' : 'warning',
        explanation: `${def.label} is present on the English page but missing entirely from the translation — on English it holds ${r.links} link(s) and roughly ${words} word(s). This alone can explain element-count gaps below.`,
        suggestion: `Add the ${def.label.toLowerCase()} to the translated page so it mirrors English.`
      });
    } else if(r.textLen > 250 && t.textLen < r.textLen * 0.4){
      const el = regionElement(liveDoc, def);
      issues.push({
        category:'missing',
        severity:'warning',
        explanation: `${def.label} exists but is much smaller than English (about ${Math.round(t.textLen / Math.max(r.textLen,1) * 100)}% of its text). Part of it may be missing.`,
        suggestion: `Review the ${def.label.toLowerCase()} for dropped content.`,
        snippet: el ? srcSnippet(liveRawHtml, el) : ''
      });
    }
  });
  return issues;
}
function isLikelyEnglish(text){
  // crude heuristic: share of common English stopwords among the first words
  if(!text) return false;
  const words = text.toLowerCase().split(/\s+/).filter(Boolean).slice(0, 80);
  if(words.length < 10) return false;
  const stop = new Set(['the','and','to','of','a','in','for','is','on','that','with','your','you','our','we','this','are','or','from','at','by','an','be','as','it','will','more','about','have','can','if','all','not','what','when','how']);
  let hits = 0; words.forEach(w => { if(stop.has(w.replace(/[^a-z]/g,''))) hits++; });
  return hits / words.length > 0.2;
}
function contentChecks(refData, tData, lang, pg, opts){
  // opts.staging suppresses checks that are meaningless outside production —
  // staging is intentionally noindex, and its canonical/hreflang point elsewhere.
  const stagingMode = !!(opts && opts.staging);
  const issues = [];
  const add = (severity, category, explanation, suggestion, snippet, items, evidenceLabel) =>
    issues.push({ severity, category, explanation, suggestion: suggestion||'', snippet: snippet||'', items: items||null, evidenceLabel: evidenceLabel||'' });

  // lang attribute correctness
  const want = (lang.gcode||lang.dir||'').toLowerCase().split('-')[0];
  const got = (tData.htmlLang||'').toLowerCase().split('-')[0];
  if(!tData.htmlLang) add('warning','lang attribute',`<html> has no lang attribute. It should declare ${lang.label} (e.g. lang="${lang.gcode||lang.dir}").`,'Set the lang attribute so browsers and search engines know the page language.');
  else if(want && got && got !== want) add('warning','lang attribute',`<html lang="${tData.htmlLang}"> doesn't match the expected ${lang.label} ("${lang.gcode||lang.dir}").`,'Correct the lang attribute to the page\'s actual language.', '', ['Found: lang="'+tData.htmlLang+'"', 'Expected: lang="'+(lang.gcode||lang.dir)+'"'], 'Language attribute');

  // hreflang presence + self reference — skipped on staging, where alternates
  // legitimately point at production or are absent entirely
  if(!stagingMode){
  if(!tData.hreflang.length) add('warning','hreflang',`No hreflang alternate tags. Search engines won't know this is the ${lang.label} version of an English page.`,'Add reciprocal hreflang link tags across all language versions.');
  else {
    const codes = tData.hreflang.map(h=>h.lang);
    const wantCode = (lang.gcode||lang.dir||'').toLowerCase();
    const hasSelf = codes.some(c => c === wantCode || c.split('-')[0] === want);
    if(!hasSelf) add('info','hreflang',`hreflang tags are present but none point to this page's own language (${lang.gcode||lang.dir}).`,'Include a self-referential hreflang entry.', '', codes.map(c=>c||'(empty)'), 'hreflang codes present');
  }
  }

  // noindex — Chinese pages are intentionally noindex, so don't flag them
  var _lc = (lang.gcode || lang.dir || '').toLowerCase();
  var _isChinese = _lc.indexOf('zh') === 0 || /chinese/i.test(lang.label || '');
  if(!stagingMode && tData.noindex && !_isChinese) add('critical','indexing','This page is set to noindex — it will be excluded from search results.','Remove the noindex directive unless this exclusion is intentional.');

  // canonical — on staging these usually point at the production URL by design
  if(!stagingMode){
  if(tData.canonical && refData && refData.canonical && tData.canonical === refData.canonical && lang.dir){
    add('critical','canonical',`Canonical URL points to the English page. This tells search engines to ignore the ${lang.label} version.`,'Set the canonical to this page\'s own URL.', '', [tData.canonical], 'Canonical URL');
  } else if(tData.canonical && lang.dir && !tData.canonical.includes('/'+lang.dir)){
    add('warning','canonical',`Canonical URL doesn't include the ${lang.dir} path — verify it points to this translation, not English.`,'Point the canonical at the translated URL.', '', [tData.canonical], 'Canonical URL');
  }
  }

  // untranslated metadata
  if(refData){
    if(tData.title && refData.title && tData.title === refData.title) add('warning','metadata','The page title is identical to English — it may not be translated.','Translate the <title> for this language.', '', [tData.title], 'Title (same on both)');
    if(tData.metaDesc && refData.metaDesc && tData.metaDesc === refData.metaDesc) add('warning','metadata','The meta description is identical to English — it may not be translated.','Translate the meta description.', '', [tData.metaDesc], 'Meta description (same on both)');
  }
  if(!tData.title) add('critical','metadata','Missing page <title>.','Add a translated <title>.');
  else if(tData.titleLen > 65) add('info','metadata',`Title is ${tData.titleLen} characters — may be truncated in search beyond ~60.`,'Shorten the title.', '', [tData.title], 'Current title');
  if(!tData.metaDesc) add('info','metadata','No meta description.','Add a translated meta description (~150 chars).');
  else if(tData.metaDescLen > 165) add('info','metadata',`Meta description is ${tData.metaDescLen} characters — may be truncated beyond ~160.`,'Trim the meta description.', '', [tData.metaDesc], 'Current meta description');

  // untranslated body text
  if(lang.dir && isLikelyEnglish(tData.textContent)){
    const sample = (tData.textContent||'').slice(0, 400);
    add('warning','untranslated',`Body text reads as mostly English on a ${lang.label} page — sections may be untranslated.`,'Review the page for English content that should be translated.', '', [sample + ((tData.textContent||'').length > 400 ? '…' : '')], 'English-looking text on this page');
  }

  // schema parity vs English
  if(refData){
    const refS = refData.schemaTypes||[], tS = tData.schemaTypes||[];
    if(refS.length && !tS.length) add('warning','structured data',`English has structured data but this translation has none.`,'Mirror the schema.org markup on the translated page.', '', refS, 'Schema types on English (missing here)');
    else {
      const missing = refS.filter(t => !tS.includes(t));
      if(missing.length) add('info','structured data',`Translation is missing schema types present on English.`,'Add the missing structured-data types.', '', missing, 'Missing schema types');
    }
  }

  // heading hierarchy
  if(tData.h1Count === 0) add('warning','headings','No H1 heading on the page.','Add a single, descriptive H1.');
  else if(tData.h1Count > 1) add('info','headings',`${tData.h1Count} H1 headings — there should usually be one.`,'Use a single H1 and demote the rest.', '', (tData.headings||[]).filter(h=>h.level===1).map(h=>h.text), 'H1 headings on this page');
  if(tData.headingSkip) add('info','headings','Heading levels skip (e.g. H2 → H4), which hurts structure and accessibility.','Use sequential heading levels.', '', (tData.headings||[]).map(h=>'H'+h.level+': '+h.text), 'Heading outline');

  // word-count parity
  if(refData && refData.words > 120 && tData.words < refData.words * 0.5){
    add('warning','content volume',`This page has ${tData.words} words vs ${refData.words} on English (${Math.round(tData.words/Math.max(refData.words,1)*100)}%). Content may be missing.`,'Compare against English for dropped sections.');
  }

  // placeholders
  if(tData.placeholders.length) add('warning','placeholder text',`Placeholder/boilerplate text found.`,'Replace placeholder text with real translated content.', '', tData.placeholders, 'Placeholder text found');

  return issues;
}
function findDuplicateIds(doc){
  const seen = {}, dups = new Set();
  doc.querySelectorAll('[id]').forEach(el => {
    const id = el.id; if(seen[id]) dups.add(id); else seen[id]=1;
  });
  return [...dups];
}

/* ----------------------------- AI analysis ----------------------------- */
/* ----------------------------- Pattern A: drift from Google source ----------------------------- */
function passKey(){ return WORKER_KEY.trim(); }
function getNoTranslateTerms(){
  const raw = (document.getElementById('noTranslate') && document.getElementById('noTranslate').value) || '';
  return raw.split(/\r?\n/).map(s=>s.trim()).filter(Boolean).sort((a,b)=> b.length - a.length); // longest first
}
function escapeRegex(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function stripTags(s){ return (s||'').replace(/<[^>]+>/g, ''); }
function decodeEntities(s){
  try { return new DOMParser().parseFromString(s, 'text/html').documentElement.textContent || s; }
  catch(e){ return s; }
}
function protectTerms(text, terms){
  let t = text;
  terms.forEach(term => { if(term) t = t.replace(new RegExp(escapeRegex(term), 'gi'), m => `<span class="notranslate">${m}</span>`); });
  return t;
}
function normForCompare(s){ return (s||'').toLowerCase().replace(/\s+/g,'').replace(/[.,!?;:'"()\[\]{}«»¡¿…\-–—]/g,''); }
function similarity(a, b){
  a = normForCompare(a); b = normForCompare(b);
  if(a === b) return 1;
  if(a.length < 2 || b.length < 2) return a === b ? 1 : 0;
  const grams = s => { const g = new Map(); for(let i=0;i<s.length-1;i++){ const k=s.slice(i,i+2); g.set(k,(g.get(k)||0)+1); } return g; };
  const ga = grams(a), gb = grams(b);
  let inter = 0; ga.forEach((c,k)=>{ if(gb.has(k)) inter += Math.min(c, gb.get(k)); });
  const total = (a.length-1) + (b.length-1);
  return total ? (2*inter)/total : 0;
}

async function googleTranslate(segments, target){
  let tUrl;
  try { const u = new URL(WORKER_URL); u.searchParams.set('translate','1'); tUrl = u.href; }
  catch(e){ tUrl = WORKER_URL + (WORKER_URL.includes('?')?'&':'?') + 'translate=1'; }
  const key = passKey();
  const out = [];
  const CHUNK = 100;
  for(let i=0;i<segments.length;i+=CHUNK){
    const chunk = segments.slice(i, i+CHUNK);
    const res = await fetch(tUrl, {
      method:'POST',
      headers: Object.assign({ 'Content-Type':'application/json' }, key ? { 'X-Audit-Key': key } : {}),
      body: JSON.stringify({ q: chunk, source: SOURCE_GCODE, target, format: 'html' })
    });
    if(!res.ok){
      let d=''; try { d = (await res.text()).slice(0,160); } catch(e){}
      throw new Error('Translate request failed (HTTP ' + res.status + (d?'): '+d:')'));
    }
    const data = await res.json();
    if(data && data.error){ throw new Error('Google error: ' + (data.error.message || 'unknown')); }
    const trs = (data && data.data && data.data.translations) || [];
    chunk.forEach((_, j) => out.push(stripTags(decodeEntities((trs[j] && trs[j].translatedText) || ''))));
  }
  return out;
}

async function driftCheck(refData, transData, lang){
  const terms = getNoTranslateTerms();
  const enSegs = refData.segments || [];
  const liveSegs = transData.segments || [];
  if(!enSegs.length) return { error: 'No comparable text found on the English page.' };

  const toTranslate = terms.length ? enSegs.map(s => protectTerms(s, terms)) : enSegs;
  const expected = await googleTranslate(toTranslate, lang.gcode);

  const issues = [];
  const liveDoc = parseDoc(transData.rawHtml);
  const n = Math.min(expected.length, liveSegs.length);
  let matched = 0;
  const THRESH = 0.6;
  for(let i=0;i<n;i++){
    const sim = similarity(expected[i], liveSegs[i]);
    if(sim >= THRESH){ matched++; }
    else {
      issues.push({
        category:'drift', severity:'warning',
        reference: expected[i].slice(0,300),
        translation: liveSegs[i].slice(0,300),
        explanation:`Published text differs from the Google translation of the English source (about ${Math.round(sim*100)}% similar).`,
        suggestion:'',
        snippet: srcSnippet(transData.rawHtml, findByText(liveDoc, liveSegs[i]))
      });
    }
  }
  if(expected.length !== liveSegs.length){
    issues.unshift({
      category:'drift', severity:'warning',
      explanation:`Segment count differs — ${expected.length} text block(s) expected from the source vs ${liveSegs.length} on the published page. A section may have been added or dropped.`
    });
  }
  const denom = Math.max(expected.length, liveSegs.length) || 1;
  const score = Math.round(matched / denom * 100);
  return { parityScore: score, summary: `${matched} of ${denom} text block(s) match the Google translation of the source.`, issues, engine:'google' };
}

async function analyzeTranslation(refData, transData, refLabel, transLabel){
  const cap = (s) => (s||'').slice(0, 6000);
  const refBlock = 'Headings:\n' + refData.headings.map(h=>'  '.repeat(h.level-1)+'- '+h.text).join('\n') +
    '\n\nBody text:\n' + cap(refData.textContent);
  const transBlock = 'Headings:\n' + transData.headings.map(h=>'  '.repeat(h.level-1)+'- '+h.text).join('\n') +
    '\n\nBody text:\n' + cap(transData.textContent);

  const system = `You are a localization QA reviewer. Compare a reference page (in ${refLabel}) with its ${transLabel} translation. Find: mistranslations, awkward or inaccurate phrasing, tone or register inconsistencies, strings left untranslated in ${refLabel}, content present in the reference but missing from the translation, and content added that is not in the reference. Reply with ONLY a JSON object, no markdown fences and no commentary. Schema: {"parityScore": <0-100 integer>, "summary": "<one or two sentences>", "issues": [{"category": "translation"|"tone"|"untranslated"|"missing"|"added", "severity": "critical"|"warning"|"info", "reference": "<short ${refLabel} snippet or empty>", "translation": "<short ${transLabel} snippet or empty>", "explanation": "<what's wrong>", "suggestion": "<how to fix, or empty>"}]}. If the translation is sound, return an empty issues array and a high parityScore.`;

  const userMsg = `=== REFERENCE (${refLabel}) ===\n${refBlock}\n\n=== TRANSLATION (${transLabel}) ===\n${transBlock}`;

  // Route through the worker (it holds the Anthropic API key and adds CORS).
  let aiUrl;
  try { const u = new URL(WORKER_URL); u.searchParams.set('ai', '1'); aiUrl = u.href; }
  catch(e){ aiUrl = WORKER_URL + (WORKER_URL.includes('?') ? '&' : '?') + 'ai=1'; }

  const key = WORKER_KEY.trim();
  const res = await fetch(aiUrl, {
    method:'POST',
    headers: Object.assign({ 'Content-Type':'application/json' }, key ? { 'X-Audit-Key': key } : {}),
    body: JSON.stringify({
      model: AI_MODEL,
      max_tokens: 2048,
      system,
      messages: [{ role:'user', content: userMsg }]
    })
  });
  if(!res.ok){
    let detail = '';
    try { detail = (await res.text()).slice(0,160); } catch(e){}
    throw new Error('AI request failed (HTTP ' + res.status + (detail ? '): ' + detail : ')'));
  }
  const data = await res.json();
  if(data && data.type === 'error'){ throw new Error('AI error: ' + (data.error && data.error.message || 'unknown')); }
  const txt = (data.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('\n');
  const cleaned = txt.replace(/```json/gi,'').replace(/```/g,'').trim();
  const parsed = JSON.parse(cleaned);
  const liveDoc = parseDoc(transData.rawHtml);
  (parsed.issues||[]).forEach(is => {
    const el = findByText(liveDoc, is.translation || is.reference);
    if(el) is.snippet = srcSnippet(transData.rawHtml, el);
  });
  return parsed;
}

/* ----------------------------- orchestration ----------------------------- */
let auditState = null;

function flagPassphrase(msg){
  const err = document.getElementById('passError');
  if(err){ err.textContent = msg; err.style.display = 'block'; err.scrollIntoView({ behavior:'smooth', block:'center' }); }
}

function runAudit(){ requestRunAudit(); }
function requestRunAudit(){
  var m = document.getElementById('runModal');
  var c = document.getElementById('runConfirm'), pr = document.getElementById('runProgress');
  if(c) c.style.display = '';
  if(pr) pr.style.display = 'none';
  if(m){ m.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
}
function cancelRunAudit(){ closeRunModal(); }
function confirmRunAudit(){
  var c = document.getElementById('runConfirm'), pr = document.getElementById('runProgress');
  if(c) c.style.display = 'none';
  if(pr) pr.style.display = '';
  setBar(0);
  executeAudit();
}
async function executeAudit(){
  if(!WORKER_URL || WORKER_URL.includes('your-worker')){
    closeRunModal(); setProgress('Set WORKER_URL in the config block at the top of this file before running.', true); return;
  }
  if(!SITE_URL){ closeRunModal(); setProgress('Set SITE_URL in the config block at the top of this file before running.', true); return; }
  const site = SITE_URL;
  const activePages = getAuditPages();
  if(!activePages.length){ closeRunModal(); setProgress('Discover pages or add at least one page.', true); return; }

  // access key comes from config.js now
  const key = WORKER_KEY.trim();
  if(!key){ closeRunModal(); flagPassphrase('Access key is not configured — set ACCESS_KEY in config.js.'); return; }
  setProgress('Checking access…');
  const pf = await fetchPage(SITE_URL);
  if(pf.status === 403 && /passphrase|forbidden/i.test(pf.text || '')){
    closeRunModal();
    flagPassphrase('The worker rejected this passphrase. Check that it matches the worker’s AUDIT_KEY.');
    setProgress('');
    return;
  }

  const refLang = langs.find(l=>l.ref);
  const transLangs = langs.filter(l=>!l.ref);
  const conc = 2;
  const exclDirs = getExcludeDirs();
  try { statePut('excludeDirs', { dirs: exclDirs, updated: new Date().toISOString() }).catch(function(){}); } catch(e){}

  var _rb = document.getElementById('runBtn'); if(_rb) _rb.disabled = true;
  document.getElementById('results').innerHTML = '';
  var _gd = document.getElementById('genDone'); if(_gd) _gd.style.display = 'none';
  var _bw = document.getElementById('barWrap'); if(_bw) _bw.style.display = 'block';

  auditState = { results: [], crit:0, warn:0, info:0, broken:0, pages:0 };
  linkCache.clear();

  const totalUnits = activePages.length;
  let done = 0;
  let auditOk = true;

  try {
  for(const pg of activePages){
    setProgress(`Auditing “${pg.name}”…`);
    const result = { page: pg, languages: [], refData: null, refError: null };

    // fetch reference
    let refData = null;
    const refUrl = buildUrl(site, refLang.dir, pg.path);
    {
      const r = await fetchPage(refUrl);
      if(r.ok){ refData = extract(r.text, refUrl); }
      else { result.refError = r.error ? r.error : ('HTTP ' + r.status); }
      result.refData = refData;
      result.enFp = refData ? contentFingerprint(refData) : null;
      result.refStatus = r.status;
      result.refUrl = refUrl;
    }

    // reference technical pass (links + code)
    if(refData){
      result.refTech = await technicalPass(refData, refLang.label, conc, auditState);
    }

    // English-only sections (e.g. newsroom): audit English/technical only, skip translations
    result.englishOnly = pathIsExcluded(pg.path, exclDirs);

    // each translation
    if(!result.englishOnly)
    for(const tl of transLangs){
      const url = buildUrl(site, tl.dir, pg.path);
      setProgress(`Auditing “${pg.name}” — ${tl.label}…`);
      const block = { lang: tl, url };
      const tr = await fetchPage(url);
      if(!tr.ok){ block.error = tr.error ? tr.error : ('HTTP ' + tr.status); result.languages.push(block); auditState.crit++; continue; }
      block.status = tr.status;
      const tData = extract(tr.text, url);
      block.data = tData;
      block.trFp = contentFingerprint(tData);

      // technical pass for this language
      block.tech = await technicalPass(tData, tl.label, conc, auditState);

      // structural parity vs reference: regions first, then counts
      if(refData){
        const regionIssues = regionDiff(refData.regions, tData.regions, parseDoc(tData.rawHtml), tData.rawHtml);
        const missingMajor = regionIssues.some(i => i.severity === 'critical');
        const countIssues = structuralDiff(refData, tData, missingMajor);
        block.parity = [...regionIssues, ...countIssues];
        block.parity.forEach(i => bump(auditState, i.severity));
      }

      // content-quality checks (SEO, metadata, freshness, coverage signals)
      block.content = contentChecks(refData, tData, tl, pg);
      block.content.forEach(i => bump(auditState, i.severity));

      // translation analysis — Google drift (Pattern A) and/or Claude
      const transOn = document.getElementById('transToggle') && document.getElementById('transToggle').checked;
      if(refData && transOn){
        const engine = (document.getElementById('engine') && document.getElementById('engine').value) || 'google';
        if(engine === 'google' || engine === 'both'){
          try {
            const d = await driftCheck(refData, tData, tl);
            if(d.error){ block.driftError = d.error; }
            else { block.drift = d; (d.issues||[]).forEach(i => bump(auditState, i.severity)); }
          } catch(e){ block.driftError = e.message; }
        }
        if(engine === 'claude' || engine === 'both'){
          try {
            const ai = await analyzeTranslation(refData, tData, refLang.label, tl.label);
            block.ai = ai;
            (ai.issues||[]).forEach(i => bump(auditState, i.severity));
          } catch(e){ block.aiError = e.message; }
        }
      } else if(transOn && !refData){
        block.driftError = 'No English reference page to compare against.';
      }
      result.languages.push(block);
    }

    auditState.results.push(result);
    auditState.pages++;
    renderResult(result, refLang);
    done++;
    setBar(done/totalUnits*100);
  }

  setProgress('Audit complete — ' + auditState.pages + ' page(s) reviewed.');
  setBar(100);
  } catch(err){
    auditOk = false;
    setProgress('Audit stopped: ' + (err && err.message ? err.message : String(err)), true);
  } finally {
    var _rb2 = document.getElementById('runBtn'); if(_rb2) _rb2.disabled = false;
    closeRunModal();
  }
  if(auditOk) renderSummary();
}

function bump(s, sev){ if(sev==='critical') s.crit++; else if(sev==='warning') s.warn++; else s.info++; }

async function technicalPass(data, label, conc, state){
  const tech = { code: [], links: [] };
  const doc = parseDoc(data.rawHtml);
  const firstEmptyLink = doc ? [...doc.querySelectorAll('a')].find(a => { const h=a.getAttribute('href'); return !h || h==='#' || h.trim()===''; }) : null;
  const pushCode = (sev, text, el, items, evidenceLabel) => tech.code.push({ sev, text, snippet: el ? srcSnippet(data.rawHtml, el) : '', items: items||null, evidenceLabel: evidenceLabel||'' });
  // code-level issues
  if(data.emptyLinks){
    const empties = doc ? [...doc.querySelectorAll('a')].filter(a => { const h=a.getAttribute('href'); return !h || h==='#' || h.trim()===''; }).map(a => (clean(a.textContent) || '(empty link text)')) : null;
    pushCode('warning', data.emptyLinks + ' empty or placeholder link(s) (href="#" or blank).', firstEmptyLink, empties, 'Empty links (by their text)');
  }
  if(data.missingAlt){
    const noAlt = (data.images || []).filter(i => i.alt === null).map(i => imgName(i.src));
    pushCode('warning', data.missingAlt + ' image(s) without alt text.', doc && doc.querySelector('img:not([alt])'), noAlt, 'Images missing alt text');
  }
  if(data.duplicateIds.length) pushCode('warning', data.duplicateIds.length + ' duplicate id attribute(s).', doc && doc.getElementById(data.duplicateIds[0]), data.duplicateIds, 'Duplicate ids');
  if(!data.title) pushCode('critical', 'Missing <title>.', null);
  if(!data.metaDesc) pushCode('info', 'No meta description.', null);
  if(!data.htmlLang) pushCode('warning', 'Missing lang attribute on <html>.', null);
  tech.code.forEach(c => bump(state, c.sev));

  // link verification — report only genuinely broken links; ignore auth/blocked (401/403/429)
  const broken = [];
  if(data.links.length){
    const checked = await pool(data.links, checkResource, conc);
    checked.forEach(c => {
      if(c.ok) return;
      if(c.status === 401 || c.status === 403 || c.status === 429 || c.blocked) return; // responded but refused us — ignore
      broken.push(Object.assign({}, c, { snippet: srcSnippet(data.rawHtml, findAnchor(doc, c.url, data.baseUrl)) })); // 404, 410, 5xx, no response
    });
  }
  tech.links = broken;
  tech.linksChecked = data.links.length;
  tech.linksTotal = data.links.length;
  state.broken += broken.length;
  return tech;
}

function imgName(src){
  if(!src) return '(no src)';
  try { const u = new URL(src); src = u.pathname; } catch(e){}
  const base = src.split('/').filter(Boolean).pop() || src;
  return base.split('?')[0];
}
function structuralDiff(ref, trans, hasMissingRegion){
  const issues = [];
  const fields = [
    ['headings','headings'], ['images','images'], ['links','links'],
    ['forms','forms'], ['inputs','form fields'], ['buttons','buttons']
  ];
  fields.forEach(([key, name]) => {
    const a = ref.counts[key], b = trans.counts[key];
    if(a !== b){
      const missing = a - b;
      let severity = Math.abs(missing) >= Math.max(2, a*0.3) ? 'warning' : 'info';
      let note = '';
      if(hasMissingRegion && missing > 0){ severity = 'info'; note = ' (likely accounted for by the missing section above)'; }

      // attach the actual evidence where we can identify specific items
      let items = null, evidenceLabel = '';
      if(key === 'links'){
        const tSet = new Set(trans.links || []);
        const rSet = new Set(ref.links || []);
        const onlyEn = (ref.links || []).filter(u => !tSet.has(u));
        const onlyTr = (trans.links || []).filter(u => !rSet.has(u));
        if(missing > 0 && onlyEn.length){ items = onlyEn; evidenceLabel = 'Links on English but not on this page'; }
        else if(missing < 0 && onlyTr.length){ items = onlyTr; evidenceLabel = 'Links on this page but not on English'; }
      } else if(key === 'images'){
        const tNames = (trans.images || []).map(i => imgName(i.src));
        const rNames = (ref.images || []).map(i => imgName(i.src));
        const tSet = new Set(tNames), rSet = new Set(rNames);
        const onlyEn = rNames.filter(n => !tSet.has(n));
        const onlyTr = tNames.filter(n => !rSet.has(n));
        if(missing > 0 && onlyEn.length){ items = onlyEn; evidenceLabel = 'Images on English but not on this page'; }
        else if(missing < 0 && onlyTr.length){ items = onlyTr; evidenceLabel = 'Images on this page but not on English'; }
      } else if(key === 'headings'){
        // heading text differs by language, so show both lists rather than a diff
        const rH = (ref.headings || []).map(h => 'H' + h.level + ': ' + h.text);
        const tH = (trans.headings || []).map(h => 'H' + h.level + ': ' + h.text);
        items = ['— English (' + rH.length + ') —', ...rH, '— This page (' + tH.length + ') —', ...tH];
        evidenceLabel = 'Headings on both pages';
      }

      issues.push({
        category:'count',
        severity,
        explanation: missing > 0
          ? `Translation has ${b} ${name} vs ${a} in English — ${missing} fewer${note}.`
          : `Translation has ${b} ${name} vs ${a} in English — ${-missing} extra.`,
        items, evidenceLabel
      });
    }
  });
  return issues;
}

/* ----------------------------- result rendering ----------------------------- */
function renderResult(result, refLang){
  const wrap = document.getElementById('results');
  const det = document.createElement('details');
  det.className = 'page-result';
  det.open = false;

  // count issues for this page
  let c=0,w=0,i=0,broken=0;
  const tally = (sev) => { if(sev==='critical')c++; else if(sev==='warning')w++; else i++; };
  if(result.refTech){ result.refTech.code.forEach(x=>tally(x.sev)); broken += result.refTech.links.length; }
  result.languages.forEach(b => {
    if(b.error) c++;
    if(b.tech){ b.tech.code.forEach(x=>tally(x.sev)); broken += b.tech.links.length; }
    (b.parity||[]).forEach(x=>tally(x.severity));
    (b.content||[]).forEach(x=>tally(x.severity));
    (b.ai && b.ai.issues || []).forEach(x=>tally(x.severity));
  });

  const pills = [];
  if(c) pills.push(`<span class="pill crit">${c} critical</span>`);
  if(w) pills.push(`<span class="pill warn">${w} warnings</span>`);
  if(broken) pills.push(`<span class="pill crit">${broken} broken links</span>`);
  if(!c && !w && !broken) pills.push(`<span class="pill ok">clean</span>`);

  const summary = document.createElement('summary');
  summary.innerHTML = `<span class="chev">▶</span>
    <span><span class="title">${escapeHtml(result.page.name)}</span></span>
    <span class="spacer"></span>${pills.join(' ')}`;
  det.appendChild(summary);

  const body = document.createElement('div');
  body.className = 'result-body';

  // reference page block (technical only)
  if(result.refError){
    body.innerHTML += `<div class="lang-block"><h4>${escapeHtml(refLang.label)} (reference)</h4>
      <div class="err-note">Could not load reference page: ${escapeHtml(result.refError)}</div></div>`;
  } else if(result.refData){
    body.innerHTML += `<div class="lang-block"><h4>${escapeHtml(refLang.label)} (reference)</h4>
      <div class="url-sub">${escapeHtml(result.refUrl)}</div>
      ${renderTech(result.refTech)}</div>`;
  }

  // translation blocks
  result.languages.forEach(b => {
    let html = `<div class="lang-block"><h4>${escapeHtml(b.lang.label)}</h4>`;
    html += `<div class="url-sub">${escapeHtml(b.url)}</div>`;
    if(b.error){
      html += `<div class="err-note">Could not load page: ${escapeHtml(b.error)}</div></div>`;
      body.innerHTML += html; return;
    }

    // Google drift (Pattern A)
    if(b.drift || b.driftError){
      html += `<div class="section-label">Drift from Google source</div>`;
      if(b.driftError){
        html += `<div class="err-note">Check unavailable: ${escapeHtml(b.driftError)}</div>`;
      } else if(b.drift){
        html += `<div class="score">Match score: ${b.drift.parityScore}/100 — ${escapeHtml(b.drift.summary||'')}</div>`;
        const di = b.drift.issues||[];
        if(di.length){ di.forEach(is => html += renderIssue(is)); }
        else { html += `<div class="clean">Published page matches the Google translation of the source.</div>`; }
      }
    }

    // Claude analysis
    if(b.ai || b.aiError){
      html += `<div class="section-label">Translation &amp; tone (Claude)</div>`;
      if(b.aiError){
        html += `<div class="err-note">Analysis unavailable: ${escapeHtml(b.aiError)}</div>`;
      } else if(b.ai){
        if(typeof b.ai.parityScore === 'number'){
          html += `<div class="score">Parity score: ${b.ai.parityScore}/100 — ${escapeHtml(b.ai.summary||'')}</div>`;
        }
        const aiIssues = (b.ai.issues||[]);
        if(aiIssues.length){ aiIssues.forEach(is => html += renderIssue(is)); }
        else { html += `<div class="clean">No translation issues found.</div>`; }
      }
    }

    // content parity
    html += `<div class="section-label">Page sections &amp; content parity</div>`;
    if(b.parity && b.parity.length){
      b.parity.forEach(is => html += renderIssue(is));
    } else {
      html += `<div class="clean">All major sections present and element counts match English.</div>`;
    }

    // content & SEO quality
    html += `<div class="section-label">Content &amp; SEO</div>`;
    if(b.content && b.content.length){
      b.content.forEach(is => html += renderIssue(is));
    } else {
      html += `<div class="clean">No metadata, hreflang, indexing, or content-quality issues found.</div>`;
    }

    // technical
    html += renderTech(b.tech);
    html += `</div>`;
    body.innerHTML += html;
  });

  det.appendChild(body);
  wrap.appendChild(det);
}

function renderTech(tech){
  if(!tech) return '';
  let html = `<div class="section-label">Code &amp; rendering</div>`;
  if(tech.code.length){
    tech.code.forEach(c => html += renderIssue({ category:'code', severity:c.sev, explanation:c.text, snippet:c.snippet }));
  } else {
    html += `<div class="clean">No code-level issues detected.</div>`;
  }
  html += `<div class="section-label">Links${tech.linksChecked!=null?` (checked ${tech.linksChecked})`:''}</div>`;
  if(tech.links && tech.links.length){
    html += `<ul class="tech">`;
    tech.links.forEach(l => {
      const code = l.status ? l.status : 'no response';
      const row = `<span class="code bad">${code}</span><a href="${escapeAttr(l.url)}" target="_blank" rel="noopener">${escapeHtml(l.url)}</a>`;
      if(l.snippet){
        html += `<li><details class="snip-d"><summary>${row}<span class="snip-hint">▸ markup</span></summary><pre class="snip">${l.snippet}</pre></details></li>`;
      } else {
        html += `<li>${row}</li>`;
      }
    });
    html += `</ul>`;
  } else {
    html += `<div class="clean">${tech.linksChecked? 'All links resolved (no 404s or server errors).' : 'No outbound links to check.'}</div>`;
  }
  return html;
}

function renderIssue(is){
  const sev = is.severity || 'info';
  let inner = `<div class="ihead"><span class="cat">${escapeHtml(is.category||'issue')}</span></div>`;
  inner += `<p class="exp">${escapeHtml(is.explanation||'')}</p>`;
  if(is.suggestion) inner += `<div class="sugg">→ ${escapeHtml(is.suggestion)}</div>`;
  if(is.snippet){
    return `<details class="issue ${sev} snip-issue"><summary>${inner}<span class="snip-hint">▸ show source</span></summary><pre class="snip">${is.snippet}</pre></details>`;
  }
  return `<div class="issue ${sev}">${inner}</div>`;
}

function renderSummary(){
  const s = auditState;
  markDashStale();
  const done = document.getElementById('genDone');
  if(done){
    done.style.display = 'block';
    done.innerHTML = 'Audit complete — <strong>' + s.pages + '</strong> page(s) reviewed · '
      + s.crit + ' critical · ' + s.warn + ' warning · ' + s.broken + ' broken link(s). '
      + 'Open your <a data-click="showPage(\'leaders\')">Admin dashboard</a> &middot; '
      + '<a data-click="showPage(\'authors\')">Authors dashboard</a>.';
  }
  showPage('leaders');
}

/* ===================== AEP LAUNCH =====================
   Two independent workflows over one shared engine:
     pre  — production vs staging: what will change when we deploy?
     post — production vs production: did the deploy actually land?
   The diff buckets mean opposite things in each, so each track renders them
   with its own labels, ordering and emphasis.
   NOTE: worker keys must match /^mlaudit:<host>:[\w.\-]+$/ — no colons. */
let aepTrack = 'pre';
let aepAuditState = null;
let aepRunning = false, aepCancel = false;
let aepEnv = 'production';
let aepSnapIndex = [];
let aepSkipAuthCheck = false;   // set when the operator overrides a wrong sign-in check

function aepKeyIndex(){ return 'aep-index'; }
function aepKeySnap(id){ return 'aep-snap-' + id; }
function aepBaseUrl(){ return aepEnv === 'cm' ? CM_URL : (aepEnv === 'staging' ? STAGING_URL : SITE_URL); }
function aepIsCandidate(env){ return env === 'cm' || env === 'staging'; }
function aepEnvLabel(env){ return env === 'cm' ? 'cm.prod' : (env === 'staging' ? 'staging' : 'production'); }
function aepHostOf(u){ try { return new URL(u).hostname; } catch(e){ return u; } }
function aepUi(name){
  // Each track owns its own progress/bar elements. Without the review case this fell
  // through to the hidden post-launch panel, so a capture ran with no visible output.
  const pfx = aepTrack === 'pre' ? 'Pre' : (aepTrack === 'review' ? 'Rev' : 'Post');
  return document.getElementById('aep' + pfx + name);
}
function aepStatus(msg, err){
  const el = document.getElementById('aepSaveStatus'); if(!el) return;
  el.textContent = msg; el.style.color = err ? 'var(--critical)' : 'var(--muted)';
}
function aepScrollTo(id){
  const el = document.getElementById(id); if(!el) return;
  try { el.scrollIntoView({ behavior:'smooth', block:'start' }); } catch(e){ el.scrollIntoView(); }
}
function aepPickTrack(t){
  if(aepRunning) return;
  aepTrack = t;
  document.querySelectorAll('.aep-track-btn').forEach(function(b){ b.classList.toggle('active', b.dataset.track === t); });
  const pre = document.getElementById('aepTrackPre'), post = document.getElementById('aepTrackPost');
  const review = document.getElementById('aepTrackReview');
  if(pre) pre.style.display = (t === 'pre') ? 'block' : 'none';
  if(post) post.style.display = (t === 'post') ? 'block' : 'none';
  if(review) review.style.display = (t === 'review') ? 'block' : 'none';
  // the shared scope and snapshot cards are capture tools; the review track reads
  // existing snapshots instead of making them
  // the review track still captures the current state, so scope stays visible;
  // only the pre/post step cards are hidden
  const steps = document.getElementById('aepStepsWrap');
  if(steps) steps.style.display = (t === 'review') ? 'none' : '';
  if(t === 'review') aepUpdateCdStatus();
  aepRenderRunSummary();
  aepRenderPickers();
  requestAnimationFrame(drawAepConnectors);
  setTimeout(drawAepConnectors, 140);
}

/* ---- flow connectors, same technique as the Power BI page ---- */
function drawAepConnectors(){
  if(aepTrack === 'review') return;  const id = (aepTrack === 'pre') ? 'Pre' : 'Post';
  const flow = document.getElementById('aepFlow' + id), svg = document.getElementById('aepConn' + id);
  if(!flow || !svg) return;
  if(window.innerWidth <= 1000){ svg.innerHTML = ''; return; }
  const fr = flow.getBoundingClientRect();
  if(!fr.width) return;
  const steps = Array.prototype.slice.call(flow.querySelectorAll('.aep-step'));
  if(steps.length < 2){ svg.innerHTML = ''; return; }
  svg.setAttribute('width', fr.width); svg.setAttribute('height', fr.height);
  svg.setAttribute('viewBox', '0 0 ' + fr.width + ' ' + fr.height);
  const S = '#8a8a8a';
  let paths = '';
  for(let i = 0; i < steps.length - 1; i++){
    const a = steps[i].getBoundingClientRect(), b = steps[i+1].getBoundingClientRect();
    const sx = a.right - fr.left, ex = b.left - fr.left;
    const y = a.top + a.height/2 - fr.top;
    paths += '<path d="M ' + (sx + 6) + ' ' + y + ' L ' + (ex - 10) + ' ' + y
      + '" fill="none" stroke="' + S + '" stroke-width="1.6" marker-end="url(#aepArrow)"/>';
  }
  svg.innerHTML =
    '<defs><marker id="aepArrow" markerWidth="9" markerHeight="9" refX="6.5" refY="4" orient="auto" markerUnits="userSpaceOnUse">'
    + '<path d="M1,1 L6.5,4 L1,7" fill="none" stroke="' + S + '" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>'
    + paths;
}
var _aepResizeT;
window.addEventListener('resize', function(){
  clearTimeout(_aepResizeT);
  _aepResizeT = setTimeout(function(){
    var el = document.getElementById('page-aep');
    if(el && el.style.display !== 'none') drawAepConnectors();
  }, 120);
});

/* ---- scope ---- */
function aepGetScope(){
  const raw = (document.getElementById('aepScope') && document.getElementById('aepScope').value) || '';
  return raw.split(/[\n,]+/).map(s => s.trim().replace(/^\/+|\/+$/g,'').toLowerCase()).filter(Boolean);
}
function aepInScope(path, dirs){
  if(!dirs || !dirs.length) return true;
  const pth = normPath(path).toLowerCase();
  return dirs.some(d => pth === d || pth.indexOf(d + '/') === 0);
}
let _aepScopeTimer = null;
function aepScopeChanged(){
  aepUpdateScopeCount();
  clearTimeout(_aepScopeTimer);
  _aepScopeTimer = setTimeout(function(){ statePut('aep-scope', { dirs: aepGetScope() }).catch(function(){}); }, 600);
}
async function aepLoadScope(){
  const el = document.getElementById('aepScope');
  if(!el) return;
  try {
    const s = await stateGet('aep-scope');
    if(s && Array.isArray(s.dirs)){ el.value = s.dirs.join('\n'); return; }
  } catch(e){}
  if(!el.value) el.value = 'medicare';
}
function aepPageList(){
  const dirs = aepGetScope();
  return getAuditPages().filter(pg => aepInScope(pg.path, dirs));
}
function aepSource(){
  if(aepAuditState && aepAuditState.results && aepAuditState.results.length) return { st: aepAuditState, kind:'scoped' };
  if(auditState && auditState.results && auditState.results.length) return { st: auditState, kind:'site' };
  return null;
}
function aepUpdateScopeCount(){
  // The match counter was removed \u2014 AEP discovers pages on the environment it is
  // capturing, so a count against the production list was misleading anyway.
  const sh = document.getElementById('aepStgHost');
  if(sh) sh.textContent = aepHostOf(CM_URL);
  const sh2 = document.getElementById('aepStgHost2');
  if(sh2) sh2.textContent = aepHostOf(STAGING_URL);
}

/* ---- run + capture (one guided step) ---- */
function aepSetRunProgress(msg, err){
  const el = aepUi('Progress');
  if(el){ el.textContent = msg || ''; el.style.color = err ? 'var(--critical)' : 'var(--muted)'; }
}
function aepSetBar(pct){ const el = aepUi('Bar'); if(el) el.style.width = pct + '%'; }
function aepCancelRun(){ if(aepRunning){ aepCancel = true; aepSetRunProgress('Stopping after the current page\u2026'); } }

let aepPendingSave = null; // { label, btn } — the capture waiting to be retried
async function aepRunAndCapture(env, labelPrefix, btn){
  const ok = await aepRunAudit(env);
  if(!ok) return;
  const stamp = new Date().toLocaleString([], { month:'short', day:'numeric', hour:'numeric', minute:'2-digit' });
  const label = labelPrefix + ' \u00B7 ' + stamp;
  const saved = await aepSaveSnapshot(label);
  if(saved){ flashBtnOk(btn, 'Captured'); return; }
  aepPendingSave = { label, btn };
  aepOpenSaveFailModal();
}
function aepOpenSaveFailModal(){
  const m = document.getElementById('aepSaveFailModal'); if(!m) return;
  const r = document.getElementById('aepSaveFailReason');
  if(r) r.textContent = aepLastSaveError || 'Unknown error.';
  const rb = document.getElementById('aepRetrySaveBtn');
  if(rb){ rb.disabled = false; rb.textContent = 'Retry save'; }
  m.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function aepCloseSaveFailModal(){
  const m = document.getElementById('aepSaveFailModal'); if(m) m.style.display = 'none';
  document.body.style.overflow = '';
  aepPendingSave = null;
}
async function aepRetrySave(){
  if(!aepPendingSave) { aepCloseSaveFailModal(); return; }
  const rb = document.getElementById('aepRetrySaveBtn');
  if(rb){ rb.disabled = true; rb.textContent = 'Retrying\u2026'; }
  const { label, btn } = aepPendingSave;
  const saved = await aepSaveSnapshot(label);
  if(saved){
    aepCloseSaveFailModal();
    flashBtnOk(btn, 'Captured');
  } else {
    const r = document.getElementById('aepSaveFailReason');
    if(r) r.textContent = aepLastSaveError || 'Unknown error.';
    if(rb){ rb.disabled = false; rb.textContent = 'Retry save'; }
  }
}

function aepLooksSignedOut(res, expectHost){
  if(!res) return true;
  if(res.status === 401 || res.status === 403) return true;
  const url = String(res.requested || '');
  const body = String(res.text || '');
  // Landed on a login or identity endpoint. This is the reliable signal: the
  // request finished somewhere other than where it was sent.
  if(/\/sitecore\/login|\/adfs\/|login\.microsoftonline|okta\.com|\/oauth2\/authorize/i.test(url)) return true;
  // An actual login FORM in the response \u2014 not merely a link to one, which any
  // authoring page may carry in its chrome.
  const hasLoginForm = /name=["']?__RequestVerificationToken/i.test(body)
    && /<form[^>]*>/i.test(body)
    && /type=["']?password/i.test(body);
  if(hasLoginForm) return true;
  if(/id=["']?LoginForm\b/i.test(body)) return true;
  // Near-empty response with no page content at all. Deliberately strict: a short
  // real page must not be mistaken for an interstitial.
  const looksLikeAPage = /<(main|article|h1|nav|footer)\b/i.test(body) || body.length >= 1200;
  if(res.status === 200 && !looksLikeAPage && body.length < 400) return true;
  return false;
}
function aepOpenCmLogin(){
  try { window.open(CM_URL + '/sitecore/login', '_blank'); } catch(e){}
}
async function aepRunAudit(env){
  if(aepRunning) return false;
  aepEnv = env || 'production';
  const dirs = aepGetScope();
  // One source of truth: the page list discovered from production's sitemap, filtered
  // by scope. The same paths are requested on whichever host we are capturing, so a
  // page that is absent there simply shows up as not found in the comparison.
  await loadDiscovered();
  let list = aepPageList();
  if(!list.length){
    aepSetRunProgress('No pages in scope on ' + aepHostOf(aepBaseUrl()) + '. Check the scope prefix, or run \u201cDiscover pages from sitemap\u201d in Audit Settings.', true);
    return false;
  }
  const key = (WORKER_KEY || '').trim();
  if(!key){
    aepSetRunProgress('Set ACCESS_KEY in the extension\u2019s config.js, then reload the extension.', true);
    return false;
  }

  const site = aepBaseUrl();
  const staging = aepIsCandidate(aepEnv);   // skip prod-only checks on any candidate source

  aepSetRunProgress('Checking access to ' + aepHostOf(site) + '\u2026');
  // Probe a real page from the scoped list. The host root on an authoring server is
  // often a stub or a redirect, which made this read as \u201csigned out\u201d incorrectly.
  const probePath = (list[0] && list[0].path) || '';
  const pre = await fetchPage(buildUrl(site, '', probePath));
  const direct = (typeof EXT_MODE !== 'undefined') && EXT_MODE;
  if(direct && (pre.status === 0 || pre.error)){
    // No proxy in extension mode — an unreachable host is almost always a missing
    // host_permissions entry, which needs a manifest edit plus an extension reload.
    aepSetRunProgress('Could not reach ' + aepHostOf(site)
      + ' \u2014 add "' + site + '/*" to host_permissions in manifest.json, then reload the extension.', true);
    return false;
  }
  if(!direct && pre.status === 403 && /Target host not allowed/i.test(pre.text || '')){
    aepSetRunProgress('The proxy worker is refusing ' + aepHostOf(site)
      + ' \u2014 add it to ALLOWED_HOSTS in the worker and redeploy.', true);
    return false;
  }
  if(pre.status === 403 && /passphrase|forbidden/i.test(pre.text || '')){
    aepSetRunProgress('The access key was rejected.', true); return false;
  }
  // cm.prod sits behind a Sitecore login. Without a session every page would come
  // back as a login stub, so stop here and say so rather than capturing garbage.
  if(aepEnv === 'cm' && aepLooksSignedOut(pre) && !aepSkipAuthCheck){
    aepSetRunProgress('Not signed in to Sitecore on ' + aepHostOf(CM_URL)
      + '. Sign in, then run this again.', true);
    const el = aepUi('Progress');
    if(el){
      const b = document.createElement('button');
      b.className = 'btn-secondary';
      b.style.marginTop = '.6rem';
      b.textContent = 'Open Sitecore login';
      b.addEventListener('click', aepOpenCmLogin);
      el.appendChild(document.createElement('br'));
      el.appendChild(b);
      // If the check is wrong \u2014 and it can be \u2014 let them proceed anyway.
      const b2 = document.createElement('button');
      b2.className = 'btn-secondary';
      b2.style.marginTop = '.6rem';
      b2.style.marginLeft = '.5rem';
      b2.textContent = 'I am signed in \u2014 run anyway';
      b2.addEventListener('click', function(){
        aepSkipAuthCheck = true;
        aepRunAudit('cm');
      });
      el.appendChild(b2);
      const note = document.createElement('div');
      note.className = 'hint';
      note.style.marginTop = '.5rem';
      note.textContent = 'Probed ' + aepHostOf(site) + '/' + probePath
        + ' \u00B7 HTTP ' + (pre.status || 'no response') + ' \u00B7 ' + ((pre.text || '').length) + ' bytes.';
      el.appendChild(note);
    }
    return false;
  }

  aepRunning = true; aepCancel = false;
  const bw = aepUi('BarWrap'); if(bw) bw.style.display = 'block';
  const sm = aepUi('Summary'); if(sm) sm.innerHTML = '';
  aepSetBar(0);

  const refLang = langs.find(l => l.ref);
  const transLangs = langs.filter(l => !l.ref);
  const exclDirs = getExcludeDirs();
  const conc = 2;
  const st = { results: [], crit:0, warn:0, info:0, broken:0, pages:0,
               scope: aepGetScope().join(','), env: aepEnv, host: aepHostOf(site), at: null };
  let done = 0, completed = false;
  linkCache.clear();

  try {
    for(const pg of list){
      if(aepCancel) break;
      aepSetRunProgress('Auditing \u201c' + pg.name + '\u201d on ' + aepHostOf(site) + '\u2026 (' + (done+1) + ' of ' + list.length + ')');
      const tally = { critical:0, warning:0, info:0, broken:0 };
      const mark = () => ({ c:st.crit, w:st.warn, i:st.info, b:st.broken });
      const absorb = (b) => {
        tally.critical += st.crit - b.c; tally.warning += st.warn - b.w;
        tally.info += st.info - b.i;     tally.broken  += st.broken - b.b;
      };
      const result = { page: pg, languages: [], refData: null, refError: null };
      const refUrl = buildUrl(site, refLang.dir, pg.path);
      const r = await fetchPage(refUrl);
      let refData = null;
      if(r.ok){ refData = extract(r.text, refUrl); }
      else { result.refError = r.error ? r.error : ('HTTP ' + r.status); st.crit++; tally.critical++; }
      result.refData = refData;
      result.enFp = refData ? contentFingerprint(refData) : null;
      result.refUrl = refUrl; result.refStatus = r.status;

      if(refData){ const b0 = mark(); result.refTech = await technicalPass(refData, refLang.label, conc, st); absorb(b0); }

      result.englishOnly = pathIsExcluded(pg.path, exclDirs);
      if(!result.englishOnly){
        for(const tl of transLangs){
          if(aepCancel) break;
          const url = buildUrl(site, tl.dir, pg.path);
          aepSetRunProgress('Auditing \u201c' + pg.name + '\u201d \u2014 ' + tl.label + '\u2026');
          const block = { lang: tl, url };
          const tr = await fetchPage(url);
          if(!tr.ok){
            block.error = tr.error ? tr.error : ('HTTP ' + tr.status);
            result.languages.push(block); st.crit++; tally.critical++; continue;
          }
          block.status = tr.status;
          const tData = extract(tr.text, url);
          block.data = tData;
          block.trFp = contentFingerprint(tData);
          const b1 = mark();
          block.tech = await technicalPass(tData, tl.label, conc, st);
          if(refData){
            const regionIssues = regionDiff(refData.regions, tData.regions, parseDoc(tData.rawHtml), tData.rawHtml);
            const missingMajor = regionIssues.some(i => i.severity === 'critical');
            block.parity = [].concat(regionIssues, structuralDiff(refData, tData, missingMajor));
            block.parity.forEach(i => bump(st, i.severity));
          }
          block.content = contentChecks(refData, tData, tl, pg, { staging: staging });
          block.content.forEach(i => bump(st, i.severity));
          absorb(b1);
          result.languages.push(block);
        }
      }
      result.sevTally = tally;
      st.results.push(result);
      st.pages++; done++;
      aepSetBar(done / list.length * 100);
    }
    st.at = new Date().toISOString();
    aepAuditState = st;
    completed = st.pages > 0;
    aepSetRunProgress(aepCancel
      ? 'Stopped \u2014 ' + st.pages + ' of ' + list.length + ' page(s) audited on ' + st.host + '.'
      : 'Audited ' + st.pages + ' page(s) on ' + st.host + '.');
  } catch(e){
    aepSetRunProgress('Audit stopped: ' + (e && e.message ? e.message : String(e)), true);
  } finally {
    aepRunning = false;
  }
  aepRenderRunSummary();
  aepUpdateScopeCount();
  return completed;
}
function aepRenderRunSummary(){
  const host = aepUi('Summary'); if(!host) return;
  const st = aepAuditState;
  if(!st || !st.results.length){ host.innerHTML = ''; return; }
  let miss = 0;
  st.results.forEach(r => (r.languages||[]).forEach(b => { if(b.error) miss++; }));
  const rows = st.results.slice().sort((a,b) => {
    const t = x => x.sevTally.critical*100 + x.sevTally.warning*10 + x.sevTally.info;
    return t(b) - t(a);
  }).slice(0, 12).map(r => {
    const t = r.sevTally;
    const pills = (t.critical ? '<span class="pill crit">' + t.critical + ' critical</span> ' : '')
                + (t.warning ? '<span class="pill warn">' + t.warning + ' warning</span> ' : '')
                + (t.broken ? '<span class="pill crit">' + t.broken + ' broken</span> ' : '')
                + (!t.critical && !t.warning && !t.broken ? '<span class="pill ok">clean</span>' : '');
    return '<tr><td>' + escapeHtml(r.page.name) + '</td>'
      + '<td style="font-size:.76rem;color:var(--muted-2);word-break:break-all;">/' + escapeHtml(r.page.path || '') + '</td>'
      + '<td>' + pills + '</td></tr>';
  }).join('');
  const more = st.results.length > 12 ? '<p class="hint" style="margin:.6rem 0 0;">Showing the 12 worst of ' + st.results.length + ' page(s).</p>' : '';
  host.innerHTML =
    '<div class="summary-grid">'
      + '<div class="stat"><div class="num">' + st.pages + '</div><div class="lbl">Pages</div></div>'
      + '<div class="stat crit"><div class="num">' + st.crit + '</div><div class="lbl">Critical</div></div>'
      + '<div class="stat warn"><div class="num">' + st.warn + '</div><div class="lbl">Warnings</div></div>'
      + '<div class="stat crit"><div class="num">' + st.broken + '</div><div class="lbl">Broken links</div></div>'
      + '<div class="stat ' + (miss ? 'crit' : 'ok') + '"><div class="num">' + miss + '</div><div class="lbl">Missing translations</div></div>'
    + '</div>'
    + '<div class="section-label" style="margin-top:1.25rem;">Pages by severity \u00B7 ' + escapeHtml(st.host) + '</div>'
    + '<div style="overflow-x:auto;"><table class="pages"><tr><th>Page</th><th>Path</th><th>Findings</th></tr>' + rows + '</table></div>'
    + more;
}

/* ---- snapshots ---- */
// A document link, for the "what documents changed" view — SBCs, EOCs, formularies,
// anything that gets swapped for a dated filename rather than edited in place.
function aepIsDocLink(u){ return /\.(pdf|docx?|xlsx?|pptx?)(?:[?#]|$)/i.test(String(u||'')); }
// Cap what we persist per page so a handful of very long pages can't blow up a
// snapshot: keep the first N segments, and trim any single very long one.
function aepCapSegments(arr){
  if(!Array.isArray(arr)) return [];
  return arr.slice(0, 500).map(s => (s.length > 600 ? s.slice(0,600) + '\u2026' : s));
}
function aepBuildSnapshot(label){
  const dirs = aepGetScope();
  const EXCL = excludedManualPathSet();
  const src = aepSource();
  if(!src) return null;
  let bySev = null;
  if(src.kind === 'site'){
    bySev = {};
    flattenFindings().forEach(f => {
      const k = normPath(f.path);
      const t = bySev[k] || (bySev[k] = { critical:0, warning:0, info:0, broken:0 });
      if(f.category === 'broken link') t.broken++;
      else if(f.severity === 'critical') t.critical++;
      else if(f.severity === 'warning') t.warning++;
      else t.info++;
    });
  }
  const pagesOut = {};
  let n = 0;
  (src.st.results||[]).forEach(r => {
    const pth = normPath(r.page.path || '');
    if(EXCL.has(pth)) return;
    if(!aepInScope(pth, dirs)) return;
    const d = r.refData || null;
    const langsOut = {};
    (r.languages||[]).forEach(b => {
      langsOut[b.lang.label] = {
        fp: (b.trFp != null ? b.trFp : null),
        missing: !!b.error, error: b.error || '',
        title: (b.data && b.data.title) || '', words: (b.data && b.data.words) || 0,
        url: b.url || '',
        segments: b.data ? aepCapSegments(b.data.segments) : [],
        docLinks: b.data ? (b.data.links || []).filter(aepIsDocLink) : []
      };
    });
    pagesOut[pth] = {
      name: r.page.name || prettyName(pth),
      enFp: (r.enFp != null ? r.enFp : null),
      enError: r.refError || '',
      enUrl: r.refUrl || '',
      title: d ? (d.title || '') : '', metaDesc: d ? (d.metaDesc || '') : '',
      words: d ? (d.words || 0) : 0, counts: d ? d.counts : null,
      segments: d ? aepCapSegments(d.segments) : [],
      docLinks: d ? (d.links || []).filter(aepIsDocLink) : [],
      sev: r.sevTally || (bySev && bySev[pth]) || { critical:0, warning:0, info:0, broken:0 },
      langs: langsOut
    };
    n++;
  });
  // env/host come from the run itself, never a user choice
  const env = src.st.env || 'production';
  const host = src.st.host || reportHost();
  return {
    type:'aep-snapshot', version:2,
    id: 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2,6),
    label: label, env: env, host: host, scope: dirs.join(','), source: src.kind,
    at: new Date().toISOString(), pageCount: n, pages: pagesOut
  };
}
let aepLastSaveError = '';
async function aepSaveSnapshot(label){
  if(!aepSource()){ aepLastSaveError = 'No audit to snapshot yet.'; aepStatus(aepLastSaveError, true); return false; }
  const snap = aepBuildSnapshot(label);
  if(!snap){ aepLastSaveError = 'No audit to snapshot yet.'; aepStatus(aepLastSaveError, true); return false; }
  if(!snap.pageCount){ aepLastSaveError = 'No audited pages match that scope prefix.'; aepStatus(aepLastSaveError, true); return false; }
  try {
    await statePut(aepKeySnap(snap.id), snap);
    aepSnapIndex.push({ id:snap.id, label:snap.label, env:snap.env, host:snap.host,
                        scope:snap.scope, at:snap.at, pageCount:snap.pageCount, source:snap.source });
    await statePut(aepKeyIndex(), aepSnapIndex);
    aepRenderList(); aepRenderPickers();
    aepStatus('Captured \u201c' + snap.label + '\u201d \u00B7 ' + snap.pageCount + ' page(s) from ' + snap.host + '.');
    return true;
  } catch(e){
    aepLastSaveError = 'Could not save the snapshot: ' + e.message;
    aepStatus(aepLastSaveError, true);
    return false;
  }
}
async function aepDeleteSnapshot(id){
  aepSnapIndex = aepSnapIndex.filter(s => s.id !== id);
  try { await statePut(aepKeyIndex(), aepSnapIndex); } catch(e){}
  try { await statePut(aepKeySnap(id), null); } catch(e){}
  aepRenderList(); aepRenderPickers();
  aepStatus('Snapshot removed.');
}
async function aepRenameSnapshot(id, label){
  const s = aepSnapIndex.find(x => x.id === id); if(!s) return;
  s.label = label;
  try {
    await statePut(aepKeyIndex(), aepSnapIndex);
    const full = await stateGet(aepKeySnap(id));
    if(full){ full.label = label; await statePut(aepKeySnap(id), full); }
    aepRenderPickers();
  } catch(e){}
}
async function aepLoadIndex(){
  try { const idx = await stateGet(aepKeyIndex()); aepSnapIndex = Array.isArray(idx) ? idx : []; }
  catch(e){ aepSnapIndex = []; }
}
function aepEnvBadge(env){
  const isStg = aepIsCandidate(env);
  return '<span class="pill" style="' + (isStg ? 'color:var(--warning);border-color:rgba(216,162,74,.4);' : 'color:var(--ok);border-color:rgba(125,191,130,.4);') + '">'
    + escapeHtml(aepEnvLabel(env)) + '</span>';
}
function aepRenderList(){
  const host = document.getElementById('aepSnapList'); if(!host) return;
  if(!aepSnapIndex.length){
    host.innerHTML = '<p class="empty-msg">No snapshots yet. Use the numbered steps above to capture one.</p>';
    return;
  }
  const rows = aepSnapIndex.slice().sort((a,b)=> (b.at||'').localeCompare(a.at||'')).map(s =>
    '<tr><td><input type="text" value="' + escapeAttr(s.label || '') + '" style="font-size:.85rem;" '
      + 'data-change="aepRenameSnapshot(\'' + s.id + '\', this.value)"></td>'
    + '<td>' + aepEnvBadge(s.env) + '</td>'
    + '<td style="font-size:.78rem;color:var(--muted-2);">' + escapeHtml(s.host || '') + '</td>'
    + '<td style="font-size:.8rem;color:var(--muted);white-space:nowrap;">' + escapeHtml(new Date(s.at).toLocaleString()) + '</td>'
    + '<td style="font-size:.8rem;color:var(--muted);">' + (s.pageCount||0) + '</td>'
    + '<td><button class="tiny ghost" data-click="aepDeleteSnapshot(\'' + s.id + '\')">\u2715</button></td></tr>'
  ).join('');
  host.innerHTML = '<div style="overflow-x:auto;"><table class="pages">'
    + '<tr><th style="min-width:220px;">Label</th><th>Environment</th><th>Host</th><th>Captured</th><th>Pages</th><th></th></tr>'
    + rows + '</table></div>';
}
function aepOptsFor(envFilter){
  if(envFilter === 'candidate'){
    const list = aepSnapIndex.filter(s => aepIsCandidate(s.env))
      .sort((a,b) => (b.at||'').localeCompare(a.at||''));
    return list.map(s => '<option value="' + escapeHtml(s.id) + '">'
      + escapeHtml(aepEnvLabel(s.env)) + ' \u00b7 ' + escapeHtml(s.label || s.id) + '</option>').join('')
      || '<option value="">No candidate snapshots yet</option>';
  }
  const list = aepSnapIndex.filter(s => !envFilter || s.env === envFilter)
    .sort((a,b) => (a.at||'').localeCompare(b.at||''));
  if(!list.length) return '<option value="">(no ' + (envFilter || '') + ' snapshots yet)</option>';
  return list.map(s => '<option value="' + s.id + '">' + escapeAttr(s.label || '(untitled)')
    + ' \u00B7 ' + escapeAttr(new Date(s.at).toLocaleDateString()) + '</option>').join('');
}
function aepRenderPickers(){
  const set = (id, html, pickLast) => {
    const el = document.getElementById(id); if(!el) return;
    const prev = el.value;
    el.innerHTML = html;
    if(prev && el.querySelector('option[value="' + prev + '"]')) el.value = prev;
    else if(pickLast && el.options.length) el.selectedIndex = el.options.length - 1;
  };
  set('aepPreA', aepOptsFor('production'), false);
  set('aepPreB', aepOptsFor('candidate'), true);
  set('aepPostA', aepOptsFor('production'), false);
  set('aepPostB', aepOptsFor('production'), true);
  aepPostPickDefaults();
  ['aep3A','aep3B','aep3C'].forEach(function(id, n){
    const el = document.getElementById(id); if(!el) return;
    const keep = el.value;
    el.innerHTML = aepOptsFor(null) || '<option value="">No snapshots yet</option>';
    if(keep) { el.value = keep; return; }
    if(aepSnapIndex.length){
      const ordered = aepSnapIndex.slice().sort(function(a,b){ return new Date(a.at) - new Date(b.at); });
      const pick = n === 0 ? 0 : (n === 1 ? Math.min(1, ordered.length-1) : ordered.length-1);
      el.value = ordered[pick].id;
    }
  });
}
/* Post-launch compares production against itself, so it needs two production
   captures taken either side of the deploy. Default to oldest vs newest, and say
   plainly when there is only one. */
function aepPostPickDefaults(){
  const A = document.getElementById('aepPostA'), B = document.getElementById('aepPostB');
  const note = document.getElementById('aepPostPickNote');
  if(!A || !B) return;
  const prod = aepSnapIndex.filter(sn => sn.env === 'production')
    .slice().sort((x,y) => new Date(x.at) - new Date(y.at));
  if(prod.length >= 2){
    if(!A.dataset.touched) A.value = prod[0].id;
    if(!B.dataset.touched) B.value = prod[prod.length-1].id;
  }
  if(note){
    if(prod.length === 0){
      note.textContent = 'No production snapshots yet. Capture one before the deploy and one after.';
      note.style.display = 'block';
    } else if(prod.length === 1){
      note.textContent = 'Only one production snapshot exists, so both sides are the same capture. Take a second one after the deploy to compare against it.';
      note.style.display = 'block';
    } else if(A.value && A.value === B.value){
      note.textContent = 'Both sides are the same snapshot. Pick the before-deploy capture on the left and the after-deploy capture on the right.';
      note.style.display = 'block';
    } else {
      note.style.display = 'none';
    }
  }
}
async function aepRenderAll(){
  await aepLoadScope();
  await aepLoadIndex();
  aepUpdateScopeCount();
  aepRenderRunSummary();
  aepRenderList();
  aepRenderPickers();
  requestAnimationFrame(drawAepConnectors);
  setTimeout(drawAepConnectors, 140);
}

/* ---- diff ---- */
function aepDiff(A, B){
  const paths = Array.from(new Set(Object.keys(A.pages||{}).concat(Object.keys(B.pages||{})))).sort();
  const out = { changed:[], unchanged:[], added:[], removed:[], broke:[], lag:[], lostTrans:[], bMissing:[], unknown:[], docChanges:[] };
  // Every translation missing on the B side, irrespective of what A had. For a
  // pre-launch check this is the question that matters: is the candidate complete?
  Object.keys(B.pages||{}).forEach(pth => {
    const b = B.pages[pth];
    Object.keys(b.langs || {}).forEach(L => {
      if(b.langs[L] && b.langs[L].missing) out.bMissing.push({ path:pth, name:b.name, lang:L, error:b.langs[L].error });
    });
  });
  paths.forEach(pth => {
    const a = (A.pages||{})[pth], b = (B.pages||{})[pth];
    // A page recorded but failing to load counts as absent, not as incomparable —
    // otherwise a 404 on one side hides in a bucket nobody reads.
    const aOk = !!(a && a.enFp != null), bOk = !!(b && b.enFp != null);
    if(aOk && !bOk){
      // present and healthy before, gone or failing now
      if(b) out.broke.push({ path:pth, a:a, b:b, error: b.enError || 'failed to load' });
      else out.removed.push({ path:pth, a:a, b:null });
      return;
    }
    if(!aOk && bOk){
      // New only when the path is absent from the other snapshot entirely. There is
      // no prior content to diff, so it is listed rather than compared.
      if(!a) out.added.push({ path:pth, a:null, b:b });
      // Present on both sides but unreadable on one — nothing to compare, not an error report.
      else out.unknown.push({ path:pth, a:a, b:b });
      return;
    }
    if(!aOk && !bOk){ out.unknown.push({ path:pth, a:(a||null), b:(b||null) }); return; }
    const changed = (a.enFp !== b.enFp);
    const row = { path:pth, a:a, b:b, changed:changed };
    if(changed) out.changed.push(row); else out.unchanged.push(row);
    Object.keys(b.langs || {}).forEach(L => {
      const la = (a.langs || {})[L], lb = b.langs[L];
      if(!lb) return;
      if(lb.missing && la && !la.missing) out.lostTrans.push({ path:pth, name:b.name, lang:L, error:lb.error });
      if(changed === true && la && !la.missing && !lb.missing
         && la.fp != null && lb.fp != null && la.fp === lb.fp){
        out.lag.push({ path:pth, name:b.name, lang:L });
      }
    });
    // Linked documents (SBC/EOC/formulary-type files) that changed on this page,
    // across English and every translation — a filename swap here is easy to miss
    // in a word-count comparison but is exactly the kind of change AEP cares about.
    const dd = aepDocDiff(a, b);
    if(dd.added.length || dd.removed.length){
      out.docChanges.push({ path:pth, name:b.name, url:b.enUrl||a.enUrl||'', added:dd.added, removed:dd.removed });
    }
  });
  return out;
}
// Set-difference over every document-type link a page (or its translations) links
// to. Order doesn't matter for this — a document either is or isn't present.
function aepDocDiff(a, b){
  const collect = (p) => {
    const s = new Set();
    if(!p) return s;
    (p.docLinks||[]).forEach(u => s.add(u));
    Object.keys(p.langs||{}).forEach(L => (p.langs[L].docLinks||[]).forEach(u => s.add(u)));
    return s;
  };
  const A = collect(a), B = collect(b);
  const added = [...B].filter(u => !A.has(u));
  const removed = [...A].filter(u => !B.has(u));
  return { added, removed };
}
// Set-difference over English body-text segments. Order-insensitive by design —
// a paragraph that moved position isn't "changed", but a paragraph whose wording
// changed shows up as one removal (old wording) plus one addition (new wording),
// which is the useful signal for a reviewer.
function aepSegDiff(a, b){
  const comparable = !!(a && b && Array.isArray(a.segments) && Array.isArray(b.segments)
                         && (a.segments.length || b.segments.length || (a.words||0) === 0));
  if(!comparable) return { comparable:false, added:[], removed:[] };
  const A = new Set(a.segments), B = new Set(b.segments);
  return {
    comparable: true,
    added:   b.segments.filter(s => !A.has(s)),
    removed: a.segments.filter(s => !B.has(s))
  };
}
function aepNewPageTable(rows){
  if(!rows.length) return '<p class=\"empty-msg\">None.</p>';
  const body = rows.map(r => {
    const b = r.b || {};
    const url = b.enUrl || '';
    const name = escapeHtml(b.name || prettyName(r.path));
    const nameCell = url
      ? '<a href=\"' + escapeHtml(url) + '\" target=\"_blank\" rel=\"noopener\" class=\"aep-pagelink\">' + name + '</a>'
      : name;
    const langs = Object.keys(b.langs || {});
    const live = langs.filter(L => b.langs[L] && !b.langs[L].missing);
    const missing = langs.filter(L => b.langs[L] && b.langs[L].missing);
    const langCell = langs.length
      ? (live.join(', ') || '\u2014') + (missing.length ? ' <span style=\"color:var(--critical);\">(' + escapeHtml(missing.join(', ')) + ' missing)</span>' : '')
      : '\u2014';
    return '<tr><td>' + nameCell + '</td>'
      + '<td style=\"font-size:.76rem;color:var(--muted-2);word-break:break-all;\">/' + escapeHtml(r.path) + '</td>'
      + '<td style=\"font-size:.8rem;color:var(--muted);\">' + (b.words || 0) + '</td>'
      + '<td style=\"font-size:.8rem;color:var(--muted);\">' + langCell + '</td></tr>';
  }).join('');
  return '<div style=\"overflow-x:auto;\"><table class=\"pages\">'
    + '<tr><th>Page</th><th>Path</th><th>Words</th><th>Translations</th></tr>' + body + '</table></div>';
}
function aepPageTable(rows, opts){
  opts = opts || {};
  if(!rows.length) return '<p class="empty-msg">None.</p>';
  const body = rows.map(r => {
    const src = r.b || r.a;
    const url = (r.b && r.b.enUrl) || (r.a && r.a.enUrl) || '';
    let words = '';
    if(opts.showWords){
      const wa = r.a ? r.a.words : null, wb = r.b ? r.b.words : null;
      words = '<td style="font-size:.8rem;color:var(--muted);">'
        + (wa == null ? '\u2014' : wa) + ' \u2192 ' + (wb == null ? '\u2014' : wb) + '</td>';
    }
    let extra = '';
    if(opts.showSev){
      if(r.a && r.b){
        const d = (r.b.sev.critical + r.b.sev.warning) - (r.a.sev.critical + r.a.sev.warning);
        const cls = d > 0 ? 'var(--critical)' : d < 0 ? 'var(--ok)' : 'var(--muted-2)';
        extra = '<td style="color:' + cls + ';font-size:.8rem;">' + (d > 0 ? '+' + d : String(d)) + '</td>';
      } else extra = '<td style="color:var(--muted-2);font-size:.8rem;">\u2014</td>';
    }
    const nameCell = url
      ? '<a href="' + escapeHtml(url) + '" target="_blank" rel="noopener" class="aep-pagelink">' + escapeHtml(src.name || prettyName(r.path)) + '</a>'
      : escapeHtml(src.name || prettyName(r.path));
    return '<tr><td>' + nameCell + '</td>'
      + '<td style="font-size:.76rem;color:var(--muted-2);word-break:break-all;">/' + escapeHtml(r.path) + '</td>'
      + words + extra + '</tr>';
  }).join('');
  let head = '<tr><th>Page</th><th>Path</th>';
  if(opts.showWords) head += '<th>Words</th>';
  if(opts.showSev) head += '<th>Crit+Warn \u0394</th>';
  head += '</tr>';
  return '<div style="overflow-x:auto;"><table class="pages">' + head + body + '</table></div>';
}
// Rich per-page cards for the "changed" bucket — the thing a word-count delta can't
// show: what the content diff actually is, and which linked documents swapped.
function aepChangeCards(rows, labelA, labelB){
  if(!rows.length) return '<p class="empty-msg">None.</p>';
  return rows.map(r => {
    const a = r.a, b = r.b;
    const seg = aepSegDiff(a, b);
    const doc = aepDocDiff(a, b);
    const titleChanged = a.title !== b.title;
    const metaChanged = a.metaDesc !== b.metaDesc;

    const bits = [];
    if(seg.comparable) bits.push(seg.added.length + ' added, ' + seg.removed.length + ' removed');
    else bits.push((b.words||0) - (a.words||0) >= 0 ? '+' : '', Math.abs((b.words||0)-(a.words||0)) + ' word(s)');
    if(doc.added.length || doc.removed.length) bits.push(doc.added.length + ' document(s) changed');
    if(titleChanged) bits.push('title changed');

    const links = [];
    if(a.enUrl) links.push('<a href="'+escapeHtml(a.enUrl)+'" target="_blank" rel="noopener">View '+escapeHtml(labelA)+'</a>');
    if(b.enUrl) links.push('<a href="'+escapeHtml(b.enUrl)+'" target="_blank" rel="noopener">View '+escapeHtml(labelB)+'</a>');

    let body = '<div class="aep-change-links">' + links.join(' \u00B7 ') + '</div>';
    if(titleChanged){
      body += '<p class="aep-diff-line"><strong>Title</strong><br><span class="aep-del">' + escapeHtml(a.title||'(none)')
        + '</span><br><span class="aep-add">' + escapeHtml(b.title||'(none)') + '</span></p>';
    }
    if(metaChanged){
      body += '<p class="aep-diff-line"><strong>Meta description</strong><br><span class="aep-del">' + escapeHtml(a.metaDesc||'(none)')
        + '</span><br><span class="aep-add">' + escapeHtml(b.metaDesc||'(none)') + '</span></p>';
    }
    if(seg.comparable){
      if(seg.removed.length){
        body += '<p class="aep-diff-label">Removed (' + seg.removed.length + ')</p><ul class="aep-diff-list">'
          + seg.removed.slice(0,8).map(s => '<li class="aep-del">' + escapeHtml(s) + '</li>').join('') + '</ul>'
          + (seg.removed.length > 8 ? '<p class="hint" style="margin:.2rem 0 0;">+ ' + (seg.removed.length-8) + ' more</p>' : '');
      }
      if(seg.added.length){
        body += '<p class="aep-diff-label">Added (' + seg.added.length + ')</p><ul class="aep-diff-list">'
          + seg.added.slice(0,8).map(s => '<li class="aep-add">' + escapeHtml(s) + '</li>').join('') + '</ul>'
          + (seg.added.length > 8 ? '<p class="hint" style="margin:.2rem 0 0;">+ ' + (seg.added.length-8) + ' more</p>' : '');
      }
      if(!seg.removed.length && !seg.added.length){
        body += '<p class="hint" style="margin:.4rem 0 0;">Body text is identical \u2014 the change is in the title, metadata, or structure only.</p>';
      }
    } else {
      body += '<p class="hint" style="margin:.4rem 0 0;">This comparison includes a snapshot captured before content diffing was added, so only the word-count change is available here. Re-capture both sides to see the actual text diff.</p>';
    }
    if(doc.added.length || doc.removed.length){
      body += '<p class="aep-diff-label">Linked documents</p>' + aepDocPairsHtml(doc.removed, doc.added);
    }

    return '<details class="accordion aep-change-card"><summary><span class="chev">\u25B6</span> '
      + escapeHtml(b.name || a.name || prettyName(r.path))
      + '<span class="aep-change-sum">' + escapeHtml(bits.filter(Boolean).join(' \u00B7 ')) + '</span>'
      + '</summary><div class="accordion-body">' + body + '</div></details>';
  }).join('');
}
// Documents that changed independent of whether the surrounding page text did —
// a page can read identically while its linked PDF quietly points at a new file.
function aepDocPairsHtml(removed, added){
  if(!removed.length && !added.length) return '';
  var n = Math.min(removed.length, added.length);
  var rows = [];
  for(var i=0;i<n;i++){
    rows.push('<div class="aep-doc-pair">'
      + '<a href="'+escapeHtml(removed[i])+'" target="_blank" rel="noopener" class="aep-doc-link">'+window.AepDocThumb.slotHtml(removed[i])+'</a>'
      + '<span class="aep-doc-arrow">\u2192</span>'
      + '<a href="'+escapeHtml(added[i])+'" target="_blank" rel="noopener" class="aep-doc-link">'+window.AepDocThumb.slotHtml(added[i])+'</a>'
      + '</div>');
  }
  for(var j=n;j<removed.length;j++){
    rows.push('<div class="aep-doc-pair aep-doc-single"><a href="'+escapeHtml(removed[j])+'" target="_blank" rel="noopener" class="aep-doc-link">'
      + window.AepDocThumb.slotHtml(removed[j])+'</a><span class="aep-doc-tag aep-del">Removed</span></div>');
  }
  for(var k=n;k<added.length;k++){
    rows.push('<div class="aep-doc-pair aep-doc-single"><a href="'+escapeHtml(added[k])+'" target="_blank" rel="noopener" class="aep-doc-link">'
      + window.AepDocThumb.slotHtml(added[k])+'</a><span class="aep-doc-tag aep-add">Added</span></div>');
  }
  return '<div class="aep-doc-pairs">' + rows.join('') + '</div>';
}
function aepDocChangesTable(rows){
  if(!rows.length) return '<p class="empty-msg">None.</p>';
  return rows.map(r => {
    const head = '<div class="aep-docrow-head">'
      + (r.url ? '<a href="'+escapeHtml(r.url)+'" target="_blank" rel="noopener">'+escapeHtml(r.name)+'</a>' : escapeHtml(r.name))
      + '<span class="aep-path">/' + escapeHtml(r.path) + '</span></div>';
    const list = aepDocPairsHtml(r.removed, r.added);
    return '<div class="aep-docrow">' + head + list + '</div>';
  }).join('');
}
function aepLangTable(rows){
  if(!rows.length) return '<p class="empty-msg">None.</p>';
  const anyErr = rows.some(r=>r.error);
  const body = rows.map(r =>
    '<tr><td>' + escapeHtml(r.name || prettyName(r.path)) + '</td>'
    + '<td style="font-size:.76rem;color:var(--muted-2);word-break:break-all;">/' + escapeHtml(r.path) + '</td>'
    + '<td>' + escapeHtml(r.lang) + '</td>'
    + (anyErr ? '<td style="font-size:.8rem;color:var(--critical);">' + escapeHtml(r.error || '') + '</td>' : '')
    + '</tr>').join('');
  return '<div style="overflow-x:auto;"><table class="pages"><tr><th>Page</th><th>Path</th><th>Language</th>'
    + (anyErr ? '<th>Error</th>' : '') + '</tr>' + body + '</table></div>';
}

/* Self-contained interactive comparison report. Data is embedded as JSON and the
   page renders it client-side: filter box, collapsible sections, paginated tables,
   diffs expanded on demand. No network, no dependencies. */
/* Change governance report. Plots every Sitecore item against the release gates so
   late changes, authoring gaps and untouched pages are visually separable. */
/* Three-way release analysis.
   A = baseline (before the release touched anything)
   B = launched (what actually went live)
   C = current  (production now)
   The category of a post-launch change depends on whether the release touched that
   page at all, which a two-way diff cannot express. */
function aepDiff3(A, B, C){
  const out = {
    revised:[],      // in the release, changed again after launch
    offRelease:[],   // NOT in the release, changed after launch
    netNew:[],       // absent at baseline and at launch, present now
    delivered:[],    // in the release, untouched since
    untouched:[],    // never changed at any point
    droppedAfter:[], // live at launch, gone now
    newAtLaunch:[]   // arrived with the release and unchanged since
  };
  const key = o => (o && o.enFp != null) ? String(o.enFp) : null;
  const paths = Array.from(new Set(
    Object.keys(A.pages||{}).concat(Object.keys(B.pages||{}), Object.keys(C.pages||{}))
  )).sort();

  paths.forEach(pth => {
    const a = (A.pages||{})[pth], b = (B.pages||{})[pth], c = (C.pages||{})[pth];
    const ka = key(a), kb = key(b), kc = key(c);
    const inA = ka != null, inB = kb != null, inC = kc != null;

    if(!inC){
      if(inB) out.droppedAfter.push({ path:pth, a:a, b:b, c:null });
      return;                                   // not live now; nothing further to say
    }
    if(!inA && !inB){ out.netNew.push({ path:pth, a:null, b:null, c:c }); return; }

    const releaseTouched = inA ? (ka !== kb) : true;   // absent at baseline, present at launch = the release added it
    const changedSince   = inB ? (kb !== kc) : true;

    if(releaseTouched && changedSince) out.revised.push({ path:pth, a:a, b:b, c:c });
    else if(!releaseTouched && changedSince) out.offRelease.push({ path:pth, a:a, b:b, c:c });
    else if(releaseTouched && !changedSince){
      (inA ? out.delivered : out.newAtLaunch).push({ path:pth, a:a, b:b, c:c });
    }
    else out.untouched.push({ path:pth, a:a, b:b, c:c });
  });
  return out;
}

let aepLast3 = null;
function aepUpdateCdStatus(){
  const el = document.getElementById('aepCdStatus'); if(!el) return;
  if(contentDates && contentDates.length){
    const pages = contentDates.filter(function(r){ return !r.isComponent; }).length;
    el.textContent = contentDates.length + ' item(s) loaded \u2014 ' + pages + ' page(s) and '
      + (contentDates.length - pages) + ' component(s). Dates and authors will be included.';
    el.style.color = 'var(--muted)';
  } else {
    el.textContent = 'No change log loaded. The report will show what changed, but not when or by whom.';
    el.style.color = 'var(--warning)';
  }
}

async function aepCompare3(){
  const out = document.getElementById('aep3Out');
  const pick = id => (document.getElementById(id) || {}).value;
  const idA = pick('aep3A'), idB = pick('aep3B'), idC = pick('aep3C');
  if(!out) return;
  if(!idA || !idB || !idC){
    out.innerHTML = '<div class="err-note">Pick all three snapshots: the baseline from before the release, what went live, and production now.</div>';
    return;
  }
  if(new Set([idA, idB, idC]).size < 3){
    out.innerHTML = '<div class="err-note">The three snapshots must be different captures.</div>';
    return;
  }
  out.innerHTML = '<div class="score">Loading snapshots\u2026</div>';
  const [A, B, C] = await Promise.all([idA, idB, idC].map(id => stateGet(aepKeySnap(id))));
  if(!A || !B || !C){ out.innerHTML = '<div class="err-note">One of the snapshots could not be loaded.</div>'; return; }

  const d = aepDiff3(A, B, C);
  const val = function(id){ return (document.getElementById(id) || {}).value || ''; };
  aepLast3 = { A:A, B:B, C:C, d:d, gates: { freeze: val('govFreeze'), approval: val('govApproval'), launch: val('govLaunch') } };

  const scopes = [A.scope||'', B.scope||'', C.scope||''];
  const scopeWarn = (new Set(scopes)).size > 1
    ? '<div class="err-note">These captures used different scopes (' + scopes.map(s=>escapeHtml(s||'(all)')).join(', ')
      + '). Counts will not line up.</div>' : '';

  const stat = (n, label, cls) =>
    '<div class="stat' + (cls ? ' ' + cls : '') + '"><div class="num">' + n + '</div><div class="lbl">' + label + '</div></div>';

  out.innerHTML = scopeWarn
    + '<div class="stat-row">'
    +   stat(d.revised.length, 'Revised after launch')
    +   stat(d.offRelease.length, 'Changed off-release')
    +   stat(d.netNew.length, 'Net new since launch')
    +   stat(d.delivered.length, 'Delivered, unchanged')
    +   stat(d.newAtLaunch.length, 'New at launch')
    +   stat(d.droppedAfter.length, 'Removed since launch')
    + '</div>'
    + '<p class="hint" style="margin:.8rem 0 1rem">'
    +   '<b>' + escapeHtml(A.label) + '</b> (' + escapeHtml(A.host) + ', ' + new Date(A.at).toLocaleString() + ') \u2192 '
    +   '<b>' + escapeHtml(B.label) + '</b> (' + escapeHtml(B.host) + ', ' + new Date(B.at).toLocaleString() + ') \u2192 '
    +   '<b>' + escapeHtml(C.label) + '</b> (' + escapeHtml(C.host) + ', ' + new Date(C.at).toLocaleString() + ')</p>'
    + '<div class="aep-export-bar">'
    +   '<button class="btn-secondary" data-click="aepExport3HTML()">Save release review report</button>'
    + '</div>'
    + aepAcc('Revised after launch \u00b7 was part of the release', d.revised.length, aep3Table(d.revised, 'both'), false,
        'The release changed these, then they changed again. A revision to delivered content, not a miss.')
    + aepAcc('Changed off-release \u00b7 was not part of the release', d.offRelease.length, aep3Table(d.offRelease, 'since'), false,
        'The release left these alone and they changed after launch. Either a fix for something that broke, or work that was never in scope.')
    + aepAcc('Net new since launch', d.netNew.length, aep3Table(d.netNew, 'none'), false,
        'Did not exist at baseline or at launch. Should have been supplied before the release.')
    + aepAcc('Delivered and unchanged', d.delivered.length, aep3Table(d.delivered, 'release'), false,
        'Changed by the release and untouched since. Delivered correctly.')
    + aepAcc('New at launch, unchanged since', d.newAtLaunch.length, aep3Table(d.newAtLaunch, 'none'), false,
        'Arrived with the release and has not moved.')
    + aepAcc('Removed since launch', d.droppedAfter.length, aep3Table(d.droppedAfter, 'none'), false,
        'Live at launch, not present now.')
    + aepAcc('Untouched throughout', d.untouched.length, aep3Table(d.untouched, 'none'), false,
        'No change at any point.');
}

function aep3Table(rows, show){
  if(!rows.length) return '<p class="empty-msg">None.</p>';
  const dateFor = pth => {
    if(!contentDates) return null;
    const hit = contentDates.find(r => normPath(r.path) === normPath(pth));
    return hit && hit.updated ? hit : null;
  };
  return '<div style="overflow-x:auto;"><table class="pages">'
    + '<tr><th>Page</th><th>Path</th>'
    + (show !== 'none' ? '<th>Change</th>' : '')
    + (contentDates ? '<th>Last updated</th><th>By</th>' : '')
    + '</tr>'
    + rows.map(r => {
      const src = r.c || r.b || r.a || {};
      const cd = dateFor(r.path);
      let change = '';
      if(show === 'release' || show === 'both'){
        const s = aepSegDiff(r.a, r.b);
        change += s.comparable ? ('<span style="color:var(--muted)">release: +' + s.added.length + ' \u2212' + s.removed.length + '</span>') : '';
      }
      if(show === 'since' || show === 'both'){
        const s2 = aepSegDiff(r.b, r.c);
        if(change) change += '<br>';
        change += s2.comparable ? ('<span style="color:var(--warning)">since launch: +' + s2.added.length + ' \u2212' + s2.removed.length + '</span>') : '';
      }
      return '<tr><td>' + (src.enUrl
          ? '<a class="aep-pagelink" href="' + escapeHtml(src.enUrl) + '" target="_blank" rel="noopener">' + escapeHtml(src.name || prettyName(r.path)) + '</a>'
          : escapeHtml(src.name || prettyName(r.path))) + '</td>'
        + '<td style="font-size:.76rem;color:var(--muted-2);word-break:break-all;">/' + escapeHtml(r.path) + '</td>'
        + (show !== 'none' ? '<td style="font-size:.78rem;">' + (change || '\u2014') + '</td>' : '')
        + (contentDates ? '<td style="font-size:.78rem;color:var(--muted)">' + (cd ? new Date(cd.updated).toLocaleDateString() : '\u2014') + '</td>'
            + '<td style="font-size:.78rem;color:var(--muted)">' + escapeHtml(cd ? (cd.updatedBy || '\u2014') : '\u2014') + '</td>' : '')
        + '</tr>';
    }).join('')
    + '</table></div>';
}

/* Self-contained report for the three-way release analysis. */
function aepExport3HTML(){
  if(!aepLast3){ aepStatus('Run the analysis first.', true); return; }
  const { A, B, C, d } = aepLast3;

  const cdFor = pth => {
    if(!contentDates) return null;
    const hit = contentDates.find(r => normPath(r.path) === normPath(pth));
    return hit && hit.updated ? { updated: new Date(hit.updated).toISOString(), by: hit.updatedBy || '' } : null;
  };
  const G = aepLast3.gates || {};
  const tFreeze = G.freeze ? new Date(G.freeze + 'T23:59:59').getTime() : null;
  const tAppr   = G.approval ? new Date(G.approval + 'T23:59:59').getTime() : null;
  const tLaunch = G.launch ? new Date(G.launch + 'T23:59:59').getTime() : null;
  const gateOf = iso => {
    if(!iso || tAppr == null) return '';
    const t = new Date(iso).getTime();
    if(tLaunch != null && t > tLaunch) return 'postLaunch';
    if(t > tAppr) return 'afterApproval';
    if(tFreeze != null && t > tFreeze) return 'freezeToApproval';
    return 'beforeFreeze';
  };
  const row = r => {
    const src = r.c || r.b || r.a || {};
    const rel = aepSegDiff(r.a, r.b), since = aepSegDiff(r.b, r.c);
    const cd = cdFor(r.path);
    return {
      path: r.path, name: src.name || prettyName(r.path), url: src.enUrl || '',
      relAdded: rel.comparable ? rel.added : [], relRemoved: rel.comparable ? rel.removed : [],
      sinceAdded: since.comparable ? since.added : [], sinceRemoved: since.comparable ? since.removed : [],
      updated: cd ? cd.updated : null, by: cd ? cd.by : '',
      gate: cd ? gateOf(cd.updated) : ''
    };
  };

  const groups = [
    { id:'revised',    title:'Revised after launch',        note:'The release changed these, then they changed again. A revision to delivered content, not a missed item.', rows:d.revised.map(row) },
    { id:'offRelease', title:'Changed off-release',          note:'The release never touched these; they changed after launch. Either a fix for something that broke, or work that was never in scope.', rows:d.offRelease.map(row) },
    { id:'netNew',     title:'Net new since launch',         note:'Absent at baseline and at launch. Should have been supplied before the release.', rows:d.netNew.map(row) },
    { id:'delivered',  title:'Delivered and unchanged',      note:'Changed by the release and untouched since. Delivered correctly.', rows:d.delivered.map(row) },
    { id:'newAtLaunch',title:'New at launch, unchanged since',note:'Arrived with the release and has not moved.', rows:d.newAtLaunch.map(row) },
    { id:'droppedAfter',title:'Removed since launch',        note:'Live at launch, not present now.', rows:d.droppedAfter.map(row) },
    { id:'untouched',  title:'Untouched throughout',         note:'No change at any point.', rows:d.untouched.map(row) }
  ];

  const payload = {
    generated: new Date().toISOString(),
    host: B.host || C.host || '',
    scope: A.scope || B.scope || '',
    stages: [
      { k:'baseline', label:A.label, host:A.host, at:A.at },
      { k:'launched', label:B.label, host:B.host, at:B.at },
      { k:'current',  label:C.label, host:C.host, at:C.at }
    ],
    hasDates: !!contentDates,
    gates: { freeze: G.freeze || '', approval: G.approval || '', launch: G.launch || '' },
    groups: groups
  };

  const css = `
:root{--bg:#141414;--card:#1c1c1c;--inset:#202020;--line:rgba(255,255,255,.08);
--text:#f2f2f2;--muted:rgba(255,255,255,.55);--faint:rgba(255,255,255,.35);
--accent:#FFBE5F;--accent-line:rgba(255,190,95,.35);--del:#e07a72;--add:#7dbf82;--warn:#e0b45f;}
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;line-height:1.55;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.wrap{max-width:1180px;margin:0 auto;padding:2.5rem 2rem 5rem}
.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:.12em;font-size:.68rem;font-weight:500;margin:0 0 .4rem}
h1{font-weight:300;font-size:2rem;letter-spacing:-.02em;margin:0 0 .6rem}
h2{font-weight:300;font-size:1.2rem;margin:2.2rem 0 .9rem}
.flow{display:flex;align-items:stretch;gap:.6rem;flex-wrap:wrap;margin:1.4rem 0 1.8rem}
.stage{flex:1;min-width:210px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1rem 1.1rem}
.stage .k{font-size:.64rem;text-transform:uppercase;letter-spacing:.09em;color:var(--accent);margin-bottom:.3rem}
.stage .nm{font-size:.98rem;color:var(--text)}
.stage .sub{font-size:.76rem;color:var(--faint);margin-top:.25rem}
.arrow{display:flex;align-items:center;color:var(--faint);font-size:1.1rem}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:1rem;margin-bottom:1.6rem}
.c{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1rem 1.1rem;cursor:pointer;transition:border-color .3s ease}
.c:hover{border-color:var(--accent-line)}
.c .n{font-size:1.8rem;font-weight:300;line-height:1}
.c .l{font-size:.7rem;color:var(--muted);margin-top:.35rem;line-height:1.4}
.c.hot .n{color:var(--del)}.c.warn .n{color:var(--warn)}.c.ok .n{color:var(--add)}
.panel{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1.3rem;margin-bottom:1.2rem}
.panel h3{font-weight:400;font-size:.95rem;margin:0 0 .25rem;color:var(--text)}
.panel .sub{font-size:.8rem;color:var(--faint);margin:0 0 1.1rem}
.mx{display:grid;grid-template-columns:132px 1fr 1fr;gap:.6rem;align-items:stretch}
.mx .hd{font-size:.68rem;text-transform:uppercase;letter-spacing:.07em;color:var(--faint);display:flex;align-items:flex-end;justify-content:center;padding-bottom:.4rem;text-align:center}
.mx .rl{font-size:.74rem;color:var(--muted);display:flex;align-items:center;justify-content:flex-end;text-align:right;padding-right:.3rem;line-height:1.35}
.q{border:1px solid var(--line);border-radius:10px;padding:.9rem;cursor:pointer;transition:border-color .3s ease,background .3s ease;min-height:104px;display:flex;flex-direction:column;justify-content:center}
.q:hover{border-color:var(--accent-line);background:var(--inset)}
.q .n{font-size:1.7rem;font-weight:300;line-height:1}
.q .t{font-size:.78rem;color:var(--text);margin-top:.3rem}
.q .d{font-size:.7rem;color:var(--faint);margin-top:.25rem;line-height:1.4}
.q.hot{border-color:rgba(224,122,114,.35)}.q.hot .n{color:var(--del)}
.q.warn{border-color:rgba(224,180,95,.3)}.q.warn .n{color:var(--warn)}
.q.ok .n{color:var(--add)}.q.mute .n{color:var(--faint)}
.gchip{font-size:.68rem;border:1px solid;border-radius:20px;padding:.05rem .5rem;margin-left:.1rem}
.gbars{display:grid;gap:.5rem}
.gb{display:grid;grid-template-columns:140px 1fr 46px;gap:.8rem;align-items:center;font-size:.83rem}
.gl{color:var(--muted)}
.gt{background:var(--inset);border-radius:20px;height:16px;overflow:hidden}
.gf{display:block;height:100%}
.gc{text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}
.tl-legend{display:flex;gap:1.1rem;flex-wrap:wrap;font-size:.76rem;color:var(--muted);margin-bottom:.7rem}
.sw{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:.35rem;vertical-align:1px}
.tip{position:fixed;pointer-events:none;background:#2a2a2a;border:1px solid #3a3a3a;border-radius:8px;padding:.5rem .7rem;font-size:.78rem;color:var(--text);z-index:50;max-width:290px;display:none;box-shadow:0 8px 24px rgba(0,0,0,.5)}
.dot{cursor:pointer}svg{display:block;width:100%;height:auto}
details.sec{background:var(--card);border:1px solid var(--line);border-radius:12px;margin-bottom:.8rem;overflow:hidden}
details.sec>summary{list-style:none;cursor:pointer;padding:1rem 1.2rem;display:flex;align-items:center;gap:.7rem;font-size:.95rem;font-weight:500}
details.sec>summary::-webkit-details-marker{display:none}
details.sec>summary:hover{background:var(--inset)}
.chev{color:var(--faint);font-size:.7rem;transition:transform .3s ease}
details[open]>summary .chev{transform:rotate(90deg)}
.pill{margin-left:auto;background:var(--inset);border:1px solid var(--line);border-radius:20px;padding:.12rem .7rem;font-size:.75rem;color:var(--muted)}
.body{padding:0 1.2rem 1.2rem}
.note{color:var(--faint);font-size:.82rem;margin:.2rem 0 .9rem}
details.pg{border:1px solid var(--line);border-radius:10px;margin-bottom:.6rem;background:var(--inset)}
details.pg>summary{list-style:none;cursor:pointer;padding:.75rem .9rem;display:flex;gap:.7rem;align-items:baseline;flex-wrap:wrap}
details.pg>summary::-webkit-details-marker{display:none}
.pgn{font-size:.9rem;color:var(--text);font-weight:500}
.path{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.74rem;color:var(--faint);word-break:break-all}
.who{margin-left:auto;font-size:.74rem;color:var(--faint);white-space:nowrap}
.diff{padding:0 .9rem .9rem}
.lbl{font-size:.63rem;text-transform:uppercase;letter-spacing:.07em;color:var(--faint);margin:.9rem 0 .3rem}
.lbl.rel{color:var(--muted)}.lbl.since{color:var(--warn)}
.ln{padding:.3rem .55rem;border-radius:6px;font-size:.81rem;margin:.18rem 0;line-height:1.5}
.ln.del{background:rgba(224,122,114,.08);border-left:2px solid var(--del);color:#e8b4b0}
.ln.add{background:rgba(125,191,130,.08);border-left:2px solid var(--add);color:#b3d9b6}
.empty{color:var(--faint);font-size:.85rem;padding:.5rem 0}
.tools{display:flex;gap:.8rem;margin:1.4rem 0 1rem;flex-wrap:wrap}
input[type=search]{flex:1;min-width:240px;background:transparent;border:1px solid var(--line);border-radius:8px;padding:.7rem .9rem;color:var(--text);font:inherit;font-size:.9rem}
input[type=search]:focus{outline:none;border-color:var(--accent);background:rgba(255,255,255,.03)}
.pager{display:flex;gap:.6rem;align-items:center;justify-content:flex-end;padding-top:.8rem;font-size:.8rem;color:var(--muted)}
.pager button{background:transparent;border:1px solid var(--line);border-radius:6px;color:var(--muted);padding:.35rem .7rem;font:inherit;font-size:.8rem;cursor:pointer}
.pager button:disabled{opacity:.35;cursor:default}
.foot{margin-top:2.5rem;padding-top:1.2rem;border-top:1px solid var(--line);color:var(--faint);font-size:.78rem}
@media print{body{background:#fff;color:#111}.c,.stage,details.sec,details.pg{background:#fff;border-color:#ddd}.tools{display:none}}
`;

  const script = `
const D = window.__R3__;
const PAGE = 40;
const S = { q:'', page:{} };
const esc = s => String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmtD = t => t ? new Date(t).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}) : '';
const GATE = { beforeFreeze:['Before freeze','#7dbf82'], freezeToApproval:['Freeze\u2192approval','#e0b45f'],
               afterApproval:['After approval','#e07a72'], postLaunch:['After launch','#e07a72'] };

function rowsFor(g){
  const q = S.q.toLowerCase();
  return !q ? g.rows : g.rows.filter(r => (r.name+' '+r.path+' '+(r.by||'')).toLowerCase().includes(q));
}
function pageBlock(r, showRel, showSince){
  const bits = [];
  if(showRel && (r.relAdded.length||r.relRemoved.length)) bits.push('release +'+r.relAdded.length+' \\u2212'+r.relRemoved.length);
  if(showSince && (r.sinceAdded.length||r.sinceRemoved.length)) bits.push('since launch +'+r.sinceAdded.length+' \\u2212'+r.sinceRemoved.length);
  let body = '';
  if(showRel && (r.relAdded.length||r.relRemoved.length)){
    body += '<div class="lbl rel">What the release changed</div>'
      + r.relRemoved.map(t=>'<div class="ln del">'+esc(t)+'</div>').join('')
      + r.relAdded.map(t=>'<div class="ln add">'+esc(t)+'</div>').join('');
  }
  if(showSince && (r.sinceAdded.length||r.sinceRemoved.length)){
    body += '<div class="lbl since">What changed after launch</div>'
      + r.sinceRemoved.map(t=>'<div class="ln del">'+esc(t)+'</div>').join('')
      + r.sinceAdded.map(t=>'<div class="ln add">'+esc(t)+'</div>').join('');
  }
  if(!body) body = '<div class="empty">No text captured for this page.</div>';
  const who = (r.updated ? fmtD(r.updated) : '') + (r.by ? ' \\u00b7 ' + esc(r.by) : '');
  const gchip = (r.gate && GATE[r.gate])
    ? '<span class="gchip" style="color:'+GATE[r.gate][1]+';border-color:'+GATE[r.gate][1]+'55">'+GATE[r.gate][0]+'</span>' : '';
  return '<details class="pg"><summary><span class="pgn">'
    + (r.url ? '<a href="'+esc(r.url)+'" target="_blank" rel="noopener" style="color:inherit">'+esc(r.name)+'</a>' : esc(r.name))
    + '</span><span class="path">/'+esc(r.path)+'</span>'
    + (bits.length ? '<span class="path">'+esc(bits.join(' \\u00b7 '))+'</span>' : '')
    + gchip + (who ? '<span class="who">'+who+'</span>' : '')
    + '</summary><div class="diff">'+body+'</div></details>';
}
function render(g){
  const rows = rowsFor(g);
  const host = document.getElementById('b-'+g.id);
  document.getElementById('p-'+g.id).textContent = rows.length + (S.q && rows.length!==g.rows.length ? ' of '+g.rows.length : '');
  if(!rows.length){ host.innerHTML = '<div class="empty">'+(S.q?'Nothing matches the filter.':'None.')+'</div>'; return; }
  const showRel = ['revised','delivered'].includes(g.id);
  const showSince = ['revised','offRelease'].includes(g.id);
  const start = (S.page[g.id]||0)*PAGE;
  let h = rows.slice(start,start+PAGE).map(r=>pageBlock(r, showRel, showSince)).join('');
  const pages = Math.ceil(rows.length/PAGE);
  if(pages>1){
    const cur = S.page[g.id]||0;
    h += '<div class="pager"><span>'+(start+1)+'\\u2013'+Math.min(start+PAGE,rows.length)+' of '+rows.length+'</span>'
      + '<button data-g="'+g.id+'" data-d="-1"'+(cur===0?' disabled':'')+'>Previous</button>'
      + '<button data-g="'+g.id+'" data-d="1"'+(cur>=pages-1?' disabled':'')+'>Next</button></div>';
  }
  host.innerHTML = h;
}
function gateBars(){
  const items = []; D.groups.forEach(g => g.rows.forEach(r => { if(r.gate) items.push(r); }));
  if(!items.length) return '<p class="sub" style="margin:0">Load the change log and set an approval date to break changes down by gate.</p>';
  const order = ['beforeFreeze','freezeToApproval','afterApproval','postLaunch'];
  const by = {}; items.forEach(r => { by[r.gate] = (by[r.gate]||0)+1; });
  const total = items.length;
  return '<div class="gbars">' + order.filter(k=>by[k]).map(k =>
    '<div class="gb"><span class="gl">'+GATE[k][0]+'</span>'
    + '<span class="gt"><span class="gf" style="width:'+(by[k]/total*100).toFixed(1)+'%;background:'+GATE[k][1]+'"></span></span>'
    + '<span class="gc">'+by[k]+'</span></div>').join('') + '</div>';
}
function renderAll(){ D.groups.forEach(render); }

const COL = { revised:'#e0b45f', offRelease:'#e07a72', netNew:'#e07a72', delivered:'#7dbf82', newAtLaunch:'#7dbf82', untouched:'rgba(255,255,255,.3)' };
function cnt(id){ const g = D.groups.find(x=>x.id===id); return g ? g.rows.length : 0; }

function matrix(){
  const q = (id, cls, title, desc) =>
    '<div class="q '+cls+'" data-jump="'+id+'"><div class="n">'+cnt(id)+'</div>'
    + '<div class="t">'+title+'</div><div class="d">'+desc+'</div></div>';
  return '<div class="mx">'
    + '<div></div>'
    + '<div class="hd">Changed after launch</div>'
    + '<div class="hd">Unchanged since launch</div>'
    + '<div class="rl">Release changed<br>this page</div>'
    +   q('revised','warn','Revised','A second pass at content the release already delivered')
    +   q('delivered','ok','Delivered','Shipped and left alone')
    + '<div class="rl">Release did not<br>touch this page</div>'
    +   q('offRelease','hot','Off-release','Changed after launch although the release never touched it')
    +   q('untouched','mute','Untouched','No change at any point')
    + '</div>'
    + '<div class="mx" style="margin-top:.6rem">'
    + '<div class="rl">Did not exist<br>before launch</div>'
    +   q('netNew','hot','Net new','Appeared only after launch')
    +   q('newAtLaunch','ok','New at launch','Arrived with the release and stable since')
    + '</div>';
}

function timeline(){
  const dated = [];
  D.groups.forEach(g => g.rows.forEach(r => { if(r.updated) dated.push({ t:new Date(r.updated).getTime(), g:g.id, r:r }); }));
  if(!dated.length) return '<p class="sub" style="margin:0">Load the Sitecore items export to plot when each change landed.</p>';
  const stageTs = D.stages.map(s => new Date(s.at).getTime());
  let min = Math.min.apply(null, dated.map(d=>d.t).concat(stageTs));
  let max = Math.max.apply(null, dated.map(d=>d.t).concat(stageTs));
  const pad = Math.max((max-min)*0.06, 864e5); min -= pad; max += pad;
  const W=1100,H=250,L=20,R=20,T=28,Bm=44;
  const x = t => L + (t-min)/(max-min)*(W-L-R);
  const byDay = {};
  dated.forEach(d => { const k=new Date(d.t).toISOString().slice(0,10); (byDay[k]=byDay[k]||[]).push(d); });
  let dots='';
  Object.keys(byDay).forEach(k => {
    const cx = x(new Date(k+'T12:00:00').getTime());
    byDay[k].forEach((d,i) => {
      const cy = H-Bm-6-(i%20)*9.5;
      dots += '<circle class="dot" cx="'+cx.toFixed(1)+'" cy="'+cy.toFixed(1)+'" r="3.6" fill="'+(COL[d.g]||'#888')+'" fill-opacity=".85" '
        + 'data-n="'+esc(d.r.name)+'" data-p="'+esc(d.r.path)+'" data-b="'+esc(d.r.by||'unknown')+'" '
        + 'data-d="'+fmtD(d.r.updated)+'" data-g="'+esc((D.groups.find(g=>g.id===d.g)||{}).title||'')+'"></circle>';
    });
  });
  let marks='';
  D.stages.forEach((s,i) => {
    const gx = x(new Date(s.at).getTime());
    const col = i===1 ? '#FFBE5F' : 'rgba(255,255,255,.3)';
    marks += '<line x1="'+gx.toFixed(1)+'" y1="'+T+'" x2="'+gx.toFixed(1)+'" y2="'+(H-Bm)+'" stroke="'+col+'" stroke-width="'+(i===1?2:1)+'"'+(i===1?'':' stroke-dasharray="4 4"')+'/>'
      + '<text x="'+gx.toFixed(1)+'" y="'+(T-9)+'" fill="'+col+'" font-size="11" text-anchor="middle">'+['Baseline','Launched','Now'][i]+'</text>';
  });
  const launchX = x(new Date(D.stages[1].at).getTime());
  const shade = '<rect x="'+launchX.toFixed(1)+'" y="'+T+'" width="'+(W-R-launchX).toFixed(1)+'" height="'+(H-Bm-T)+'" fill="rgba(224,122,114,.06)"/>';
  const axis = '<line x1="'+L+'" y1="'+(H-Bm)+'" x2="'+(W-R)+'" y2="'+(H-Bm)+'" stroke="rgba(255,255,255,.15)"/>'
    + '<text x="'+L+'" y="'+(H-Bm+20)+'" fill="rgba(255,255,255,.35)" font-size="11">'+fmtD(min)+'</text>'
    + '<text x="'+(W-R)+'" y="'+(H-Bm+20)+'" fill="rgba(255,255,255,.35)" font-size="11" text-anchor="end">'+fmtD(max)+'</text>';
  return '<svg viewBox="0 0 '+W+' '+H+'" xmlns="http://www.w3.org/2000/svg">'+shade+marks+axis+dots+'</svg>';
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-g]');
  if(b){ const id=b.dataset.g; S.page[id]=(S.page[id]||0)+Number(b.dataset.d); render(D.groups.find(g=>g.id===id)); return; }
  const j = e.target.closest('[data-jump]');
  if(j){ const el=document.getElementById('s-'+j.dataset.jump); if(el){ el.open=true; el.scrollIntoView({behavior:'smooth',block:'start'}); } }
});
document.getElementById('q').addEventListener('input', e => {
  S.q=e.target.value.trim(); D.groups.forEach(g=>S.page[g.id]=0); renderAll();
  if(S.q) D.groups.forEach(g=>{ const el=document.getElementById('s-'+g.id); if(el) el.open = rowsFor(g).length>0; });
});
document.getElementById('mx').innerHTML = matrix();
const gbEl = document.getElementById('gb'); if(gbEl) gbEl.innerHTML = gateBars();
document.getElementById('tl').innerHTML = timeline();
const tip = document.getElementById('tip');
document.addEventListener('mouseover', e => {
  const d = e.target.closest('.dot'); if(!d) return;
  tip.innerHTML = '<b>'+d.dataset.n+'</b><br>/'+d.dataset.p+'<br>'+d.dataset.d+' \u00b7 '+d.dataset.b+'<br>'+d.dataset.g;
  tip.style.display='block';
});
document.addEventListener('mousemove', e => { if(tip.style.display==='block'){ tip.style.left=Math.min(e.clientX+14, innerWidth-310)+'px'; tip.style.top=(e.clientY+14)+'px'; } });
document.addEventListener('mouseout', e => { if(e.target.closest('.dot')) tip.style.display='none'; });
renderAll();
`;

  const cls = { revised:'warn', offRelease:'hot', netNew:'hot', delivered:'ok', newAtLaunch:'ok', droppedAfter:'', untouched:'' };
  const cards = payload.groups.map(g =>
    '<div class="c ' + (cls[g.id]||'') + '" data-jump="' + g.id + '"><div class="n">' + g.rows.length + '</div><div class="l">' + escapeHtml(g.title) + '</div></div>'
  ).join('');
  const stages = payload.stages.map((s,i) =>
    (i ? '<div class="arrow">\u2192</div>' : '')
    + '<div class="stage"><div class="k">' + ['Baseline','Launched','Current'][i] + '</div>'
    + '<div class="nm">' + escapeHtml(s.label) + '</div>'
    + '<div class="sub">' + escapeHtml(s.host) + ' \u00b7 ' + new Date(s.at).toLocaleString() + '</div></div>'
  ).join('');
  const secs = payload.groups.map(g =>
    '<details class="sec" id="s-' + g.id + '"><summary><span class="chev">\u25b6</span>' + escapeHtml(g.title)
    + '<span class="pill" id="p-' + g.id + '">' + g.rows.length + '</span></summary>'
    + '<div class="body"><p class="note">' + escapeHtml(g.note) + '</p><div id="b-' + g.id + '"></div></div></details>'
  ).join('');

  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">'
    + '<title>Release analysis \u00b7 ' + escapeHtml(payload.host) + '</title><style>' + css + '</style></head>'
    + '<body><div class="wrap">'
    + '<p class="eyebrow">Release analysis \u00b7 three-way</p>'
    + '<h1>' + escapeHtml(payload.host) + '</h1>'
    + (payload.scope ? '<p class="note">Scope: <b style="color:var(--text)">' + escapeHtml(payload.scope) + '</b></p>' : '')
    + '<div class="flow">' + stages + '</div>'
    + '<div class="cards">' + cards + '</div>'
    + '<div class="panel"><h3>Was the release responsible?</h3>'
    +   '<p class="sub">Every page placed by two facts: whether the release changed it, and whether it changed again afterwards.</p>'
    +   '<div id="mx"></div></div>'
    + '<div class="panel"><h3>When changes landed, against your gates</h3>'
    +   '<p class="sub">Every dated item placed relative to content freeze, approval and launch.</p>'
    +   '<div id="gb"></div></div>'
    + '<div class="panel"><h3>When each change landed</h3>'
    +   '<p class="sub">Each dot is one item, coloured by category. Everything right of the launch line moved after go-live.</p>'
    +   '<div class="tl-legend">'
    +     '<span><span class="sw" style="background:#e0b45f"></span>Revised after launch</span>'
    +     '<span><span class="sw" style="background:#e07a72"></span>Off-release / net new</span>'
    +     '<span><span class="sw" style="background:#7dbf82"></span>Delivered</span>'
    +   '</div><div id="tl"></div></div>'
    + '<div class="tools"><input type="search" id="q" placeholder="Filter by page, path or author\u2026" autocomplete="off"></div>'
    + secs
    + '<div class="foot">Generated ' + new Date().toLocaleString() + '. '
    + (payload.hasDates ? 'Dates and authors come from the Sitecore items export and reflect each item\u2019s most recent change only.' : 'Load the Sitecore items export to add dates and authors.')
    + '</div></div><div class="tip" id="tip"></div>'
    + '<script>window.__R3__=' + JSON.stringify(payload).replace(/</g,'\\u003c') + ';<\/script>'
    + '<script>' + script + '<\/script></body></html>';

  downloadBlob(html, 'text/html', 'release-analysis-' + (payload.host || 'report') + '-' + new Date().toISOString().slice(0,10) + '.html');
  aepStatus('Release analysis report saved.');
}

function exportGovernanceReport(){
  const st = (m, bad) => { const el = document.getElementById('govStatus'); if(el){ el.textContent = m; el.style.color = bad ? 'var(--critical)' : 'var(--muted)'; } };
  if(!contentDates || !contentDates.length){ st('Load the Sitecore content dates export first.', true); return; }

  const val = id => (document.getElementById(id) || {}).value || '';
  const freeze = val('govFreeze'), approval = val('govApproval'), launch = val('govLaunch');
  if(!approval){ st('Set the approval date \u2014 it is the line the report is built around.', true); return; }

  const tFreeze = freeze ? new Date(freeze + 'T23:59:59').getTime() : null;
  const tAppr = new Date(approval + 'T23:59:59').getTime();
  const tLaunch = launch ? new Date(launch + 'T23:59:59').getTime() : null;

  const scope = aepGetScope();
  const inScope = p => !scope.length || aepInScope(normPath(p), scope);

  // findings on each page, so an item can be shown as still having problems
  const probByPath = {};
  try {
    (flattenFindings() || []).forEach(f => {
      const k = normPath(f.path || '');
      if(!probByPath[k]) probByPath[k] = { critical:0, warning:0 };
      if(f.severity === 'critical') probByPath[k].critical++;
      else if(f.severity === 'warning') probByPath[k].warning++;
    });
  } catch(e){}

  const items = contentDates.filter(r => inScope(r.path)).map(r => {
    const t = r.updated ? new Date(r.updated).getTime() : null;
    let band = 'untouched';
    if(t != null){
      if(t > tAppr) band = 'after';
      else if(tFreeze != null && t > tFreeze) band = 'between';
      else band = 'before';
    }
    const prob = probByPath[normPath(r.path)] || { critical:0, warning:0 };
    return {
      name: r.name || prettyName(r.path), path: r.path,
      updated: r.updated ? new Date(r.updated).toISOString() : null,
      by: r.updatedBy || '', component: !!r.isComponent,
      band: band, critical: prob.critical, warning: prob.warning
    };
  });
  if(!items.length){ st('No items match the current scope.', true); return; }

  const payload = {
    generated: new Date().toISOString(),
    host: reportHost(),
    scope: scope.join(', '),
    gates: { freeze: tFreeze, approval: tAppr, launch: tLaunch,
             freezeLabel: freeze, approvalLabel: approval, launchLabel: launch },
    items: items
  };

  const css = `
:root{--bg:#141414;--card:#1c1c1c;--inset:#202020;--line:rgba(255,255,255,.08);
--text:#f2f2f2;--muted:rgba(255,255,255,.55);--faint:rgba(255,255,255,.35);
--accent:#FFBE5F;--accent-line:rgba(255,190,95,.35);--late:#e07a72;--mid:#e0b45f;--ok:#7dbf82;--none:rgba(255,255,255,.3);}
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;line-height:1.55;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.wrap{max-width:1180px;margin:0 auto;padding:2.5rem 2rem 5rem}
.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:.12em;font-size:.68rem;font-weight:500;margin:0 0 .4rem}
h1{font-weight:300;font-size:2rem;letter-spacing:-.02em;margin:0 0 .5rem}
h2{font-weight:300;font-size:1.2rem;margin:2.4rem 0 .9rem}
.meta{color:var(--muted);font-size:.86rem;margin:0}
.meta b{color:var(--text);font-weight:500}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:1rem;margin:1.8rem 0}
.c{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1.1rem 1.2rem;cursor:pointer;transition:border-color .3s ease,background .3s ease}
.c:hover{border-color:var(--accent-line)}.c.on{border-color:var(--accent);background:var(--inset)}
.c .n{font-size:2rem;font-weight:300;line-height:1}
.c .l{font-size:.72rem;letter-spacing:.04em;color:var(--muted);margin-top:.4rem}
.c .d{font-size:.72rem;color:var(--faint);margin-top:.3rem;line-height:1.45}
.c.late .n{color:var(--late)}.c.between .n{color:var(--mid)}.c.before .n{color:var(--ok)}.c.untouched .n{color:var(--none)}
.panel{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1.3rem}
.legend{display:flex;gap:1.2rem;flex-wrap:wrap;font-size:.78rem;color:var(--muted);margin-bottom:.9rem}
.sw{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:.4rem;vertical-align:1px}
.bars{display:grid;gap:.5rem}
.bar{display:grid;grid-template-columns:150px 1fr 54px;gap:.8rem;align-items:center;font-size:.84rem}
.bar .who{color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bar .track{background:var(--inset);border-radius:20px;height:16px;overflow:hidden;display:flex}
.bar .fill{height:100%}
.bar .ct{text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}
.tools{display:flex;gap:.8rem;align-items:center;flex-wrap:wrap;margin:1.6rem 0 1rem}
input[type=search]{flex:1;min-width:240px;background:transparent;border:1px solid var(--line);border-radius:8px;padding:.7rem .9rem;color:var(--text);font:inherit;font-size:.9rem}
input[type=search]:focus{outline:none;border-color:var(--accent);background:rgba(255,255,255,.03)}
.btn{background:transparent;border:1px solid var(--line);border-radius:8px;padding:.7rem 1rem;color:var(--muted);font:inherit;font-size:.85rem;cursor:pointer}
.btn:hover{color:var(--text);border-color:var(--accent-line)}
table{width:100%;border-collapse:collapse;font-size:.85rem}
th{text-align:left;font-size:.66rem;text-transform:uppercase;letter-spacing:.07em;color:var(--faint);padding:.5rem .6rem;border-bottom:1px solid var(--line);font-weight:500;cursor:pointer}
th:hover{color:var(--muted)}
td{padding:.5rem .6rem;border-bottom:1px solid rgba(255,255,255,.04);color:var(--muted);vertical-align:top}
td.nm{color:var(--text)}
.path{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.74rem;color:var(--faint);word-break:break-all}
.tag{display:inline-block;border-radius:20px;padding:.1rem .55rem;font-size:.7rem;border:1px solid}
.tag.after{color:var(--late);border-color:rgba(224,122,114,.4)}
.tag.between{color:var(--mid);border-color:rgba(224,180,95,.4)}
.tag.before{color:var(--ok);border-color:rgba(125,191,130,.4)}
.tag.untouched{color:var(--faint);border-color:var(--line)}
.cmp{font-size:.68rem;color:var(--faint);border:1px solid var(--line);border-radius:4px;padding:0 .3rem;margin-left:.4rem}
.pager{display:flex;gap:.6rem;align-items:center;justify-content:flex-end;padding-top:.9rem;font-size:.8rem;color:var(--muted)}
.pager button{background:transparent;border:1px solid var(--line);border-radius:6px;color:var(--muted);padding:.35rem .7rem;font:inherit;font-size:.8rem;cursor:pointer}
.pager button:disabled{opacity:.35;cursor:default}
.foot{margin-top:2.5rem;padding-top:1.2rem;border-top:1px solid var(--line);color:var(--faint);font-size:.78rem}
svg{display:block;width:100%;height:auto}
.dot{cursor:pointer}
.tip{position:fixed;pointer-events:none;background:#2a2a2a;border:1px solid #3a3a3a;border-radius:8px;padding:.5rem .7rem;font-size:.78rem;color:var(--text);z-index:50;max-width:280px;display:none;box-shadow:0 8px 24px rgba(0,0,0,.5)}
@media print{body{background:#fff;color:#111}.c,.panel{background:#fff;border-color:#ddd}.tools{display:none}}
`;

  const script = `
const D = window.__GOV__;
const PAGE = 50;
const S = { band:'all', q:'', page:0, sort:'updated', dir:-1 };
const esc = s => String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const COL = { after:'#e07a72', between:'#e0b45f', before:'#7dbf82', untouched:'rgba(255,255,255,.3)' };
const LBL = { after:'After approval', between:'Freeze to approval', before:'Before freeze', untouched:'No recorded change' };
const fmtD = t => t ? new Date(t).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}) : '\\u2014';

function rows(){
  return D.items.filter(i => (S.band==='all' || i.band===S.band)
    && (!S.q || (i.name+' '+i.path+' '+i.by).toLowerCase().includes(S.q.toLowerCase())));
}

/* ---- timeline ---- */
function timeline(){
  const dated = D.items.filter(i => i.updated);
  if(!dated.length) return '<p style="color:var(--faint)">No dated items.</p>';
  const ts = dated.map(i => new Date(i.updated).getTime());
  const gates = [D.gates.freeze, D.gates.approval, D.gates.launch].filter(Boolean);
  let min = Math.min.apply(null, ts.concat(gates)), max = Math.max.apply(null, ts.concat(gates));
  const padMs = Math.max((max-min)*0.06, 864e5);
  min -= padMs; max += padMs;
  const W = 1100, H = 300, L = 20, R = 20, T = 30, B = 46;
  const x = t => L + (t - min) / (max - min) * (W - L - R);

  // stack dots per day so overlaps are visible
  const byDay = {};
  dated.forEach(i => { const d = new Date(i.updated); const k = d.toISOString().slice(0,10); (byDay[k]=byDay[k]||[]).push(i); });
  let dots = '';
  Object.keys(byDay).forEach(k => {
    const list = byDay[k].sort((a,b)=>a.band.localeCompare(b.band));
    const cx = x(new Date(k+'T12:00:00').getTime());
    list.forEach((i, n) => {
      const cy = H - B - 6 - (n % 26) * 9.5;
      dots += '<circle class="dot" cx="'+cx.toFixed(1)+'" cy="'+cy.toFixed(1)+'" r="3.6" fill="'+COL[i.band]+'" fill-opacity=".85" '
        + 'data-i="'+esc(i.name)+'" data-p="'+esc(i.path)+'" data-b="'+esc(i.by||'unknown')+'" data-d="'+esc(fmtD(i.updated))+'" data-band="'+i.band+'"></circle>';
    });
  });
  let marks = '';
  [['freeze','Content freeze'],['approval','Approval'],['launch','Launch']].forEach(([k,label]) => {
    const t = D.gates[k]; if(!t) return;
    const gx = x(t);
    const col = k==='approval' ? '#FFBE5F' : 'rgba(255,255,255,.35)';
    marks += '<line x1="'+gx.toFixed(1)+'" y1="'+T+'" x2="'+gx.toFixed(1)+'" y2="'+(H-B)+'" stroke="'+col+'" stroke-width="'+(k==='approval'?2:1)+'" stroke-dasharray="'+(k==='approval'?'':'4 4')+'"/>'
      + '<text x="'+gx.toFixed(1)+'" y="'+(T-10)+'" fill="'+col+'" font-size="11" text-anchor="middle">'+label+'</text>';
  });
  // shade the post-approval region
  let shade = '';
  if(D.gates.approval){
    const gx = x(D.gates.approval);
    shade = '<rect x="'+gx.toFixed(1)+'" y="'+T+'" width="'+(W-R-gx).toFixed(1)+'" height="'+(H-B-T)+'" fill="rgba(224,122,114,.07)"/>';
  }
  const axis = '<line x1="'+L+'" y1="'+(H-B)+'" x2="'+(W-R)+'" y2="'+(H-B)+'" stroke="rgba(255,255,255,.15)"/>'
    + '<text x="'+L+'" y="'+(H-B+20)+'" fill="rgba(255,255,255,.35)" font-size="11">'+fmtD(min)+'</text>'
    + '<text x="'+(W-R)+'" y="'+(H-B+20)+'" fill="rgba(255,255,255,.35)" font-size="11" text-anchor="end">'+fmtD(max)+'</text>';
  return '<svg viewBox="0 0 '+W+' '+H+'" xmlns="http://www.w3.org/2000/svg">'+shade+marks+axis+dots+'</svg>';
}

/* ---- who changed what after approval ---- */
function authors(){
  const late = D.items.filter(i => i.band==='after' || i.band==='between');
  if(!late.length) return '<p style="color:var(--faint);font-size:.85rem">No changes recorded after the content freeze.</p>';
  const by = {};
  late.forEach(i => { const k = i.by || 'unknown'; by[k] = by[k] || {after:0, between:0}; by[k][i.band]++; });
  const names = Object.keys(by).sort((a,b)=>(by[b].after+by[b].between)-(by[a].after+by[a].between));
  const max = Math.max.apply(null, names.map(n=>by[n].after+by[n].between));
  return '<div class="bars">' + names.map(n => {
    const a = by[n].after, b = by[n].between, tot = a+b;
    return '<div class="bar"><span class="who" title="'+esc(n)+'">'+esc(n)+'</span>'
      + '<span class="track">'
      +   (a?'<span class="fill" style="width:'+(a/max*100)+'%;background:'+COL.after+'"></span>':'')
      +   (b?'<span class="fill" style="width:'+(b/max*100)+'%;background:'+COL.between+'"></span>':'')
      + '</span><span class="ct">'+tot+'</span></div>';
  }).join('') + '</div>';
}

/* ---- table ---- */
function table(){
  const r = rows().slice().sort((a,b)=>{
    let va, vb;
    if(S.sort==='updated'){ va = a.updated?new Date(a.updated).getTime():0; vb = b.updated?new Date(b.updated).getTime():0; }
    else { va = String(a[S.sort]||'').toLowerCase(); vb = String(b[S.sort]||'').toLowerCase(); }
    return va < vb ? -S.dir : va > vb ? S.dir : 0;
  });
  const start = S.page * PAGE;
  const slice = r.slice(start, start+PAGE);
  let h = '<table><tr>'
    + '<th data-s="name">Item</th><th data-s="path">Path</th><th data-s="updated">Last updated</th>'
    + '<th data-s="by">By</th><th data-s="band">Relative to approval</th><th>Open findings</th></tr>'
    + slice.map(i => '<tr><td class="nm">'+esc(i.name)+(i.component?'<span class="cmp">component</span>':'')+'</td>'
      + '<td class="path">/'+esc(i.path)+'</td>'
      + '<td>'+fmtD(i.updated)+'</td><td>'+esc(i.by||'\\u2014')+'</td>'
      + '<td><span class="tag '+i.band+'">'+LBL[i.band]+'</span></td>'
      + '<td>'+((i.critical||i.warning)?(i.critical?i.critical+' critical ':'')+(i.warning?i.warning+' warning':''):'\\u2014')+'</td></tr>').join('')
    + '</table>';
  const pages = Math.ceil(r.length/PAGE);
  if(pages>1){
    h += '<div class="pager"><span>'+(start+1)+'\\u2013'+Math.min(start+PAGE,r.length)+' of '+r.length+'</span>'
      + '<button id="pv"'+(S.page===0?' disabled':'')+'>Previous</button>'
      + '<button id="nx"'+(S.page>=pages-1?' disabled':'')+'>Next</button></div>';
  } else h += '<div class="pager"><span>'+r.length+' item(s)</span></div>';
  return h;
}

function render(){
  document.getElementById('tl').innerHTML = timeline();
  document.getElementById('au').innerHTML = authors();
  document.getElementById('tb').innerHTML = table();
  document.querySelectorAll('.c').forEach(c => c.classList.toggle('on', c.dataset.band===S.band));
}

document.addEventListener('click', e => {
  const c = e.target.closest('.c');
  if(c){ S.band = (S.band===c.dataset.band) ? 'all' : c.dataset.band; S.page=0; render(); return; }
  const th = e.target.closest('th[data-s]');
  if(th){ const k=th.dataset.s; S.dir = (S.sort===k) ? -S.dir : -1; S.sort=k; S.page=0; render(); return; }
  if(e.target.id==='nx'){ S.page++; render(); return; }
  if(e.target.id==='pv'){ S.page--; render(); return; }
});
document.getElementById('q').addEventListener('input', e => { S.q=e.target.value.trim(); S.page=0; render(); });

const tip = document.getElementById('tip');
document.addEventListener('mouseover', e => {
  const d = e.target.closest('.dot'); if(!d) return;
  tip.innerHTML = '<b>'+d.dataset.i+'</b><br>/'+d.dataset.p+'<br>'+d.dataset.d+' \\u00b7 '+d.dataset.b+'<br><span style="color:'+COL[d.dataset.band]+'">'+LBL[d.dataset.band]+'</span>';
  tip.style.display='block';
});
document.addEventListener('mousemove', e => {
  if(tip.style.display==='block'){ tip.style.left=Math.min(e.clientX+14, innerWidth-300)+'px'; tip.style.top=(e.clientY+14)+'px'; }
});
document.addEventListener('mouseout', e => { if(e.target.closest('.dot')) tip.style.display='none'; });
render();
`;

  const counts = { after:0, between:0, before:0, untouched:0 };
  items.forEach(i => counts[i.band]++);
  const card = (band, label, desc) =>
    '<div class="c ' + (band==='after'?'late':band) + '" data-band="' + band + '"><div class="n">' + counts[band] + '</div>'
    + '<div class="l">' + label + '</div><div class="d">' + desc + '</div></div>';

  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">'
    + '<title>Change governance \u00b7 ' + escapeHtml(payload.host) + '</title><style>' + css + '</style></head>'
    + '<body><div class="wrap">'
    + '<p class="eyebrow">Change governance</p>'
    + '<h1>' + escapeHtml(payload.host) + '</h1>'
    + '<p class="meta">Every item measured against the approval gate on <b>' + escapeHtml(approval) + '</b>'
    + (freeze ? ' \u00b7 content freeze <b>' + escapeHtml(freeze) + '</b>' : '')
    + (launch ? ' \u00b7 launch <b>' + escapeHtml(launch) + '</b>' : '')
    + (payload.scope ? '<br>Scope: <b>' + escapeHtml(payload.scope) + '</b>' : '')
    + '<br>' + items.length + ' item(s) from the Sitecore export, including components.</p>'
    + '<div class="cards">'
    +   card('after','Changed after approval','Edited after sign-off. Not an authoring gap.')
    +   card('between','Changed between freeze and approval','Late but before sign-off.')
    +   card('before','Last changed before freeze','Delivered on time.')
    +   card('untouched','No recorded change','Never edited. Cannot be an authoring error.')
    + '</div>'
    + '<h2>When each item was last changed</h2>'
    + '<div class="panel"><div class="legend">'
    +   '<span><span class="sw" style="background:#e07a72"></span>After approval</span>'
    +   '<span><span class="sw" style="background:#e0b45f"></span>Freeze to approval</span>'
    +   '<span><span class="sw" style="background:#7dbf82"></span>Before freeze</span>'
    + '</div><div id="tl"></div></div>'
    + '<h2>Who made the late changes</h2><div class="panel" id="au"></div>'
    + '<h2>Every item</h2>'
    + '<div class="tools"><input type="search" id="q" placeholder="Filter by item, path or author\u2026" autocomplete="off"></div>'
    + '<div class="panel" id="tb"></div>'
    + '<div class="foot">Generated ' + new Date().toLocaleString() + ' from the Sitecore items export. '
    + 'Dates are each item\u2019s most recent change only.</div>'
    + '</div><div class="tip" id="tip"></div>'
    + '<script>window.__GOV__=' + JSON.stringify(payload).replace(/</g,'\\u003c') + ';<\/script>'
    + '<script>' + script + '<\/script></body></html>';

  downloadBlob(html, 'text/html', 'change-governance-' + payload.host + '-' + new Date().toISOString().slice(0,10) + '.html');
  st('Report saved \u2014 ' + counts.after + ' item(s) changed after approval.');
}

function aepExportHTML(){
  if(!aepLastCompare){ aepStatus('Run a comparison first.', true); return; }
  const C = aepLastCompare, A = C.A, B = C.B, d = C.d, pre = (C.track === 'pre');

  function pageRow(r){
    const src = r.b || r.a || {};
    return { path: r.path, name: src.name || prettyName(r.path), url: src.enUrl || '' };
  }
  function langRow(r){ return { path: r.path, name: r.name || prettyName(r.path), lang: r.lang }; }
  function changeRow(r){
    const seg = aepSegDiff(r.a, r.b), doc = aepDocDiff(r.a, r.b);
    return {
      path: r.path, name: (r.b && r.b.name) || prettyName(r.path),
      url: (r.b && r.b.enUrl) || '',
      titleA: (r.a && r.a.title) || '', titleB: (r.b && r.b.title) || '',
      descA: (r.a && r.a.metaDesc) || '', descB: (r.b && r.b.metaDesc) || '',
      comparable: !!seg.comparable,
      added: seg.comparable ? seg.added : [],
      removed: seg.comparable ? seg.removed : [],
      wordsA: (r.a && r.a.words) || 0, wordsB: (r.b && r.b.words) || 0,
      docsAdded: doc.added, docsRemoved: doc.removed
    };
  }

  const sections = pre ? [
    { id:'changed',  title:'Will change on deploy',        kind:'change', rows:d.changed.map(changeRow) },
    { id:'added',    title:'New pages going live',          kind:'page',   rows:d.added.map(pageRow) },
    { id:'lag',      title:'Translation not updated',       kind:'lang',   rows:d.lag.map(langRow) },
    { id:'bmissing', title:'Incomplete on the candidate',   kind:'lang',   rows:d.bMissing.map(langRow) },
    { id:'removed',  title:'In production, not on candidate', kind:'page', rows:d.removed.map(pageRow) },
    { id:'unchanged',title:'Untouched by this release',     kind:'page',   rows:d.unchanged.map(pageRow) }
  ] : [
    { id:'unchanged',title:'Unchanged \u00b7 possibly missed updates', kind:'page', rows:d.unchanged.map(pageRow) },
    { id:'changed',  title:'Updated',                       kind:'change', rows:d.changed.map(changeRow) },
    { id:'added',    title:'New pages',                     kind:'page',   rows:d.added.map(pageRow) },
    { id:'lag',      title:'Translation lag',               kind:'lang',   rows:d.lag.map(langRow) },
    { id:'lost',     title:'Lost translations',             kind:'lang',   rows:d.lostTrans.map(langRow) },
    { id:'removed',  title:'Removed',                       kind:'page',   rows:d.removed.map(pageRow) }
  ];

  const payload = {
    track: pre ? 'pre' : 'post',
    generated: new Date().toISOString(),
    a: { label:A.label, host:A.host, at:A.at, scope:A.scope||'', pageCount:A.pageCount||0 },
    b: { label:B.label, host:B.host, at:B.at, scope:B.scope||'', pageCount:B.pageCount||0 },
    sections: sections
  };

  const css = `
:root{--bg:#141414;--card:#1c1c1c;--inset:#202020;--line:rgba(255,255,255,.08);
--text:#f2f2f2;--muted:rgba(255,255,255,.55);--faint:rgba(255,255,255,.35);
--accent:#FFBE5F;--accent-line:rgba(255,190,95,.35);--del:#e07a72;--add:#7dbf82;}
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;font-weight:400;line-height:1.55;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.wrap{max-width:1180px;margin:0 auto;padding:2.5rem 2rem 5rem}
.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:.12em;font-size:.68rem;font-weight:500;margin:0 0 .4rem}
h1{font-weight:300;font-size:2rem;letter-spacing:-.02em;margin:0 0 .5rem}
.meta{color:var(--muted);font-size:.86rem;margin:0}
.meta b{color:var(--text);font-weight:500}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1rem;margin:2rem 0 1.5rem}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:1.1rem 1.2rem;cursor:pointer;transition:border-color .3s ease,background .3s ease}
.kpi:hover{border-color:var(--accent-line)}
.kpi.on{border-color:var(--accent);background:var(--inset)}
.kpi .n{font-size:1.9rem;font-weight:300;line-height:1}
.kpi .l{font-size:.68rem;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-top:.35rem}
.tools{display:flex;gap:.8rem;align-items:center;flex-wrap:wrap;margin-bottom:1.4rem}
input[type=search]{flex:1;min-width:240px;background:transparent;border:1px solid var(--line);border-radius:8px;padding:.7rem .9rem;color:var(--text);font:inherit;font-size:.9rem;transition:border-color .3s ease,background .3s ease}
input[type=search]:hover{border-color:rgba(255,255,255,.18)}
input[type=search]:focus{outline:none;border-color:var(--accent);background:rgba(255,255,255,.03)}
.btn{background:transparent;border:1px solid var(--line);border-radius:8px;padding:.7rem 1rem;color:var(--muted);font:inherit;font-size:.85rem;cursor:pointer;transition:color .3s ease,border-color .3s ease}
.btn:hover{color:var(--text);border-color:var(--accent-line)}
details.sec{background:var(--card);border:1px solid var(--line);border-radius:12px;margin-bottom:.8rem;overflow:hidden}
details.sec>summary{list-style:none;cursor:pointer;padding:1rem 1.2rem;display:flex;align-items:center;gap:.7rem;font-size:.95rem;font-weight:500;transition:background .3s ease}
details.sec>summary::-webkit-details-marker{display:none}
details.sec>summary:hover{background:var(--inset)}
.chev{color:var(--faint);font-size:.7rem;transition:transform .3s ease}
details[open]>summary .chev{transform:rotate(90deg)}
.pill{margin-left:auto;background:var(--inset);border:1px solid var(--line);border-radius:20px;padding:.12rem .7rem;font-size:.75rem;color:var(--muted);font-weight:400}
.pill.hot{border-color:var(--accent-line);color:var(--accent)}
.body{padding:0 1.2rem 1.2rem}
table{width:100%;border-collapse:collapse;font-size:.86rem}
th{text-align:left;font-size:.66rem;text-transform:uppercase;letter-spacing:.07em;color:var(--faint);padding:.5rem .6rem;border-bottom:1px solid var(--line);font-weight:500}
td{padding:.5rem .6rem;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:top;color:var(--muted)}
td a{color:var(--text);text-decoration:none;border-bottom:1px solid var(--accent-line)}
td a:hover{color:var(--accent)}
.path{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.76rem;color:var(--faint);word-break:break-all}
.pager{display:flex;gap:.6rem;align-items:center;justify-content:flex-end;padding-top:.9rem;font-size:.8rem;color:var(--muted)}
.pager button{background:transparent;border:1px solid var(--line);border-radius:6px;color:var(--muted);padding:.35rem .7rem;font:inherit;font-size:.8rem;cursor:pointer}
.pager button:disabled{opacity:.35;cursor:default}
.pager button:not(:disabled):hover{border-color:var(--accent-line);color:var(--text)}
details.pg{border:1px solid var(--line);border-radius:10px;margin-bottom:.6rem;background:var(--inset)}
details.pg>summary{list-style:none;cursor:pointer;padding:.75rem .9rem;display:flex;gap:.7rem;align-items:baseline}
details.pg>summary::-webkit-details-marker{display:none}
.pgn{font-size:.9rem;color:var(--text);font-weight:500}
.pgmeta{margin-left:auto;font-size:.74rem;color:var(--faint);white-space:nowrap}
.diff{padding:0 .9rem .9rem}
.lbl{font-size:.64rem;text-transform:uppercase;letter-spacing:.07em;color:var(--faint);margin:.8rem 0 .3rem}
.ln{padding:.3rem .55rem;border-radius:6px;font-size:.82rem;margin:.18rem 0;line-height:1.5}
.ln.del{background:rgba(224,122,114,.08);border-left:2px solid var(--del);color:#e8b4b0}
.ln.add{background:rgba(125,191,130,.08);border-left:2px solid var(--add);color:#b3d9b6}
.empty{color:var(--faint);font-size:.85rem;padding:.6rem 0}
.foot{margin-top:2.5rem;padding-top:1.2rem;border-top:1px solid var(--line);color:var(--faint);font-size:.78rem}
@media print{body{background:#fff;color:#111}.kpi,details.sec,details.pg{background:#fff;border-color:#ddd}.tools{display:none}}
`;

  const script = `
const D = window.__AEP__;
const PAGE = 50;
const state = { filter:'', page:{} };
const esc = s => String(s==null?'':s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt = t => { try { return new Date(t).toLocaleString(); } catch(e){ return t; } };

function matches(row, q){
  if(!q) return true;
  q = q.toLowerCase();
  return (row.path||'').toLowerCase().includes(q)
      || (row.name||'').toLowerCase().includes(q)
      || (row.lang||'').toLowerCase().includes(q);
}
function rowsFor(sec){ return sec.rows.filter(r => matches(r, state.filter)); }

function pageTable(rows, start){
  const slice = rows.slice(start, start + PAGE);
  return '<table><tr><th>Page</th><th>Path</th></tr>' + slice.map(r =>
    '<tr><td>' + (r.url ? '<a href="'+esc(r.url)+'" target="_blank" rel="noopener">'+esc(r.name)+'</a>' : esc(r.name)) + '</td>'
    + '<td class="path">/' + esc(r.path) + '</td></tr>').join('') + '</table>';
}
function langTable(rows, start){
  const slice = rows.slice(start, start + PAGE);
  return '<table><tr><th>Page</th><th>Path</th><th>Language</th></tr>' + slice.map(r =>
    '<tr><td>' + esc(r.name) + '</td><td class="path">/' + esc(r.path) + '</td><td>' + esc(r.lang) + '</td></tr>').join('') + '</table>';
}
function changeList(rows, start){
  const slice = rows.slice(start, start + PAGE);
  return slice.map(r => {
    const bits = [];
    if(r.comparable){ if(r.added.length) bits.push(r.added.length+' added'); if(r.removed.length) bits.push(r.removed.length+' removed'); }
    else bits.push(r.wordsA + ' \\u2192 ' + r.wordsB + ' words');
    if(r.titleA !== r.titleB) bits.push('title changed');
    if(r.docsAdded.length || r.docsRemoved.length) bits.push((r.docsAdded.length+r.docsRemoved.length)+' document(s)');
    let body = '';
    if(r.titleA !== r.titleB) body += '<div class="lbl">Title</div><div class="ln del">'+esc(r.titleA||'(none)')+'</div><div class="ln add">'+esc(r.titleB||'(none)')+'</div>';
    if(r.descA !== r.descB) body += '<div class="lbl">Meta description</div><div class="ln del">'+esc(r.descA||'(none)')+'</div><div class="ln add">'+esc(r.descB||'(none)')+'</div>';
    if(r.removed.length) body += '<div class="lbl">Removed ('+r.removed.length+')</div>' + r.removed.map(t=>'<div class="ln del">'+esc(t)+'</div>').join('');
    if(r.added.length) body += '<div class="lbl">Added ('+r.added.length+')</div>' + r.added.map(t=>'<div class="ln add">'+esc(t)+'</div>').join('');
    if(r.docsRemoved.length || r.docsAdded.length){
      body += '<div class="lbl">Linked documents</div>'
        + r.docsRemoved.map(u=>'<div class="ln del">'+esc(u)+'</div>').join('')
        + r.docsAdded.map(u=>'<div class="ln add">'+esc(u)+'</div>').join('');
    }
    if(!body) body = '<div class="empty">No textual change captured.</div>';
    return '<details class="pg"><summary><span class="pgn">' + (r.url ? '<a href="'+esc(r.url)+'" target="_blank" rel="noopener">'+esc(r.name)+'</a>' : esc(r.name)) + '</span>'
      + '<span class="path">/'+esc(r.path)+'</span><span class="pgmeta">'+esc(bits.join(' \\u00b7 '))+'</span></summary>'
      + '<div class="diff">'+body+'</div></details>';
  }).join('');
}

function renderSection(sec){
  const rows = rowsFor(sec);
  const start = (state.page[sec.id] || 0) * PAGE;
  const host = document.getElementById('body-'+sec.id);
  const pill = document.getElementById('pill-'+sec.id);
  pill.textContent = rows.length + (state.filter && rows.length !== sec.rows.length ? ' of ' + sec.rows.length : '');
  pill.className = 'pill' + (rows.length ? ' hot' : '');
  if(!rows.length){ host.innerHTML = '<div class="empty">' + (state.filter ? 'Nothing matches the filter.' : 'None.') + '</div>'; return; }
  let html = sec.kind === 'change' ? changeList(rows, start) : (sec.kind === 'lang' ? langTable(rows, start) : pageTable(rows, start));
  const pages = Math.ceil(rows.length / PAGE);
  if(pages > 1){
    const cur = (state.page[sec.id] || 0);
    html += '<div class="pager"><span>'+(start+1)+'\\u2013'+Math.min(start+PAGE, rows.length)+' of '+rows.length+'</span>'
      + '<button data-pg="'+sec.id+'" data-d="-1"'+(cur===0?' disabled':'')+'>Previous</button>'
      + '<button data-pg="'+sec.id+'" data-d="1"'+(cur>=pages-1?' disabled':'')+'>Next</button></div>';
  }
  host.innerHTML = html;
}
function renderAll(){ D.sections.forEach(renderSection); }

document.addEventListener('click', e => {
  const b = e.target.closest('[data-pg]');
  if(b){ const id=b.dataset.pg; state.page[id]=(state.page[id]||0)+Number(b.dataset.d); renderSection(D.sections.find(s=>s.id===id)); }
  const k = e.target.closest('[data-jump]');
  if(k){ const id=k.dataset.jump; const el=document.getElementById('sec-'+id); if(el){ el.open=true; el.scrollIntoView({behavior:'smooth',block:'start'}); } }
});
document.getElementById('q').addEventListener('input', e => {
  state.filter = e.target.value.trim();
  D.sections.forEach(s => state.page[s.id] = 0);
  renderAll();
  if(state.filter) D.sections.forEach(s => { const el=document.getElementById('sec-'+s.id); if(el) el.open = rowsFor(s).length>0; });
});
document.getElementById('expand').addEventListener('click', () => {
  const any = D.sections.some(s => !document.getElementById('sec-'+s.id).open);
  D.sections.forEach(s => document.getElementById('sec-'+s.id).open = any);
  document.getElementById('expand').textContent = any ? 'Collapse all' : 'Expand all';
});
renderAll();
`;

  const kpis = payload.sections.map(s =>
    '<div class="kpi" data-jump="' + s.id + '"><div class="n">' + s.rows.length + '</div><div class="l">' + escapeHtml(s.title) + '</div></div>'
  ).join('');
  const secs = payload.sections.map(s =>
    '<details class="sec" id="sec-' + s.id + '"><summary><span class="chev">\u25b6</span>' + escapeHtml(s.title)
    + '<span class="pill" id="pill-' + s.id + '">' + s.rows.length + '</span></summary>'
    + '<div class="body" id="body-' + s.id + '"></div></details>'
  ).join('');

  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">'
    + '<title>AEP ' + (pre ? 'pre-launch' : 'post-launch') + ' comparison \u00b7 ' + escapeHtml(B.host || '') + '</title>'
    + '<style>' + css + '</style></head><body><div class="wrap">'
    + '<p class="eyebrow">AEP ' + (pre ? 'pre-launch validation' : 'post-launch verification') + '</p>'
    + '<h1>' + escapeHtml(B.host || '') + '</h1>'
    + '<p class="meta"><b>' + escapeHtml(A.label) + '</b> \u00b7 ' + escapeHtml(A.host) + ' \u00b7 ' + new Date(A.at).toLocaleString()
    + '<br>compared against <b>' + escapeHtml(B.label) + '</b> \u00b7 ' + escapeHtml(B.host) + ' \u00b7 ' + new Date(B.at).toLocaleString()
    + (A.scope || B.scope ? '<br>Scope: <b>' + escapeHtml(A.scope || B.scope) + '</b>' : '') + '</p>'
    + '<div class="kpis">' + kpis + '</div>'
    + '<div class="tools"><input type="search" id="q" placeholder="Filter by page name, path or language\u2026" autocomplete="off">'
    + '<button class="btn" id="expand">Expand all</button></div>'
    + secs
    + '<div class="foot">Generated ' + new Date().toLocaleString() + ' by Multilingual Site Audit. Self-contained \u2014 no network needed.</div>'
    + '</div><script>window.__AEP__=' + JSON.stringify(payload).replace(/</g,'\\u003c') + ';<\/script>'
    + '<script>' + script + '<\/script></body></html>';

  const stamp = new Date().toISOString().slice(0,10);
  downloadBlob(html, 'text/html', 'aep-' + (pre ? 'prelaunch' : 'postlaunch') + '-' + (B.host || 'report') + '-' + stamp + '.html');
  aepStatus('Interactive report saved. Open it in any browser, or share the file.');
}

function aepExportPDF(){
  if(!aepLastCompare){ aepStatus('Run a comparison first.', true); return; }
  const C = aepLastCompare, A = C.A, B = C.B, d = C.d, pre = (C.track === 'pre');
  const E = escapeHtml;
  const when = (x) => E(new Date(x.at).toLocaleString());

  const counts = pre ? [
    ['Will change', d.changed.length], ['New pages', d.added.length],
    ['Translation not updated', d.lag.length], ['Untouched', d.unchanged.length],
    ['Missing from candidate', d.removed.length]
  ] : [
    ['Unchanged', d.unchanged.length], ['Updated', d.changed.length],
    ['New pages', d.added.length], ['Translation lag', d.lag.length],
    ['Removed', d.removed.length]
  ];
  const kpis = '<div class="kpis">' + counts.map(function(c){
    return '<div class="kpi"><div class="n">' + c[1] + '</div><div class="l">' + E(c[0]) + '</div></div>';
  }).join('') + '</div>';

  function pageRows(rows){
    if(!rows.length) return '<p class="muted">None.</p>';
    return '<table><thead><tr><th>Page</th><th>Path</th></tr></thead><tbody>'
      + rows.map(function(r){
          const src = r.b || r.a || {};
          return '<tr><td>' + E(src.name || r.path) + '</td><td>/' + E(r.path) + '</td></tr>';
        }).join('') + '</tbody></table>';
  }
  function langRows(rows){
    if(!rows.length) return '<p class="muted">None.</p>';
    return '<table><thead><tr><th>Page</th><th>Path</th><th>Language</th></tr></thead><tbody>'
      + rows.map(function(r){ return '<tr><td>' + E(r.name||r.path) + '</td><td>/' + E(r.path) + '</td><td>' + E(r.lang) + '</td></tr>'; }).join('')
      + '</tbody></table>';
  }
  function changeRows(rows){
    if(!rows.length) return '<p class="muted">None.</p>';
    return rows.map(function(r){
      const seg = aepSegDiff(r.a, r.b), doc = aepDocDiff(r.a, r.b);
      let body = '';
      if(r.a.title !== r.b.title){
        body += '<p class="ln"><strong>Title</strong><br><span class="del">' + E(r.a.title||'(none)') + '</span><br><span class="add">' + E(r.b.title||'(none)') + '</span></p>';
      }
      if(seg.comparable){
        if(seg.removed.length) body += '<p class="lbl">Removed (' + seg.removed.length + ')</p><ul>' + seg.removed.map(function(t){ return '<li class="del">' + E(t) + '</li>'; }).join('') + '</ul>';
        if(seg.added.length) body += '<p class="lbl">Added (' + seg.added.length + ')</p><ul>' + seg.added.map(function(t){ return '<li class="add">' + E(t) + '</li>'; }).join('') + '</ul>';
      } else {
        body += '<p class="muted">Word count ' + (r.a.words||0) + ' \u2192 ' + (r.b.words||0) + '.</p>';
      }
      if(doc.added.length || doc.removed.length){
        body += '<p class="lbl">Linked documents</p><ul>'
          + doc.removed.map(function(u){ return '<li class="del">' + E(u) + '</li>'; }).join('')
          + doc.added.map(function(u){ return '<li class="add">' + E(u) + '</li>'; }).join('') + '</ul>';
      }
      return '<div class="pg"><div class="pgh"><span class="pgn">' + E(r.b.name || r.path) + '</span><span class="pgp">/' + E(r.path) + '</span></div>' + (body || '<p class="muted">No textual change captured.</p>') + '</div>';
    }).join('');
  }
  function sect(t, inner){ return '<section><h2>' + E(t) + '</h2>' + inner + '</section>'; }

  const body = pre
    ? sect('Will change on deploy (' + d.changed.length + ')', changeRows(d.changed))
      + sect('New pages going live (' + d.added.length + ')', pageRows(d.added))
      + sect('Translation not updated (' + d.lag.length + ')', langRows(d.lag))
      + sect('Missing from candidate (' + d.removed.length + ')', pageRows(d.removed))
      + sect('Untouched (' + d.unchanged.length + ')', pageRows(d.unchanged))
    : sect('Unchanged \u00B7 possibly missed updates (' + d.unchanged.length + ')', pageRows(d.unchanged))
      + sect('Updated (' + d.changed.length + ')', changeRows(d.changed))
      + sect('New pages (' + d.added.length + ')', pageRows(d.added))
      + sect('Translation lag (' + d.lag.length + ')', langRows(d.lag))
      + sect('Removed (' + d.removed.length + ')', pageRows(d.removed));

  const css = "*{box-sizing:border-box}body{margin:0;background:#fff;color:#1a1a1a;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;font-size:13px;line-height:1.55;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
    + ".rep{max-width:960px;margin:0 auto;padding:2.2rem}"
    + ".eyebrow{color:#b9770e;text-transform:uppercase;letter-spacing:.12em;font-size:.66rem;font-weight:600;margin:0 0 .3rem}"
    + "h1{font-weight:300;font-size:1.8rem;margin:0 0 .3rem}"
    + ".meta{color:#666;font-size:.82rem;margin:0}"
    + ".kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:.7rem;margin:1.5rem 0}"
    + ".kpi{border:1px solid #e0e0e0;border-radius:8px;padding:.8rem}.kpi .n{font-size:1.6rem;font-weight:300;line-height:1}.kpi .l{font-size:.6rem;text-transform:uppercase;letter-spacing:.06em;color:#666;margin-top:.3rem}"
    + "section{margin-top:1.8rem;break-inside:avoid}h2{font-size:.72rem;text-transform:uppercase;letter-spacing:.1em;color:#b9770e;margin:0 0 .7rem;padding-bottom:.35rem;border-bottom:1px solid #e0e0e0}"
    + "table{width:100%;border-collapse:collapse;font-size:.8rem;border:1px solid #e0e0e0;border-radius:6px}"
    + "th{text-align:left;font-size:.6rem;text-transform:uppercase;letter-spacing:.05em;color:#888;padding:.45rem .6rem;background:#f4f4f4;border-bottom:1px solid #e0e0e0}"
    + "td{padding:.45rem .6rem;border-bottom:1px solid #eee}tr:last-child td{border-bottom:none}"
    + ".pg{border:1px solid #e0e0e0;border-radius:8px;padding:.9rem 1rem;margin-bottom:.7rem;break-inside:avoid}"
    + ".pgh{display:flex;gap:.6rem;align-items:baseline;margin-bottom:.5rem}.pgn{font-size:.95rem;font-weight:500}.pgp{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.7rem;color:#888}"
    + ".lbl{font-size:.62rem;text-transform:uppercase;letter-spacing:.06em;color:#666;margin:.7rem 0 .25rem}"
    + "ul{margin:.2rem 0;padding-left:1.1rem}li{margin:.15rem 0;font-size:.78rem}"
    + ".del{color:#c0392b}.add{color:#1c7a44}.ln{margin:.4rem 0}.muted{color:#888}"
    + "@media print{.rep{padding:1rem}}";

  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>AEP '
    + (pre ? 'pre-launch' : 'post-launch') + ' comparison</title><style>' + css + '</style></head><body><div class="rep">'
    + '<p class="eyebrow">AEP ' + (pre ? 'pre-launch validation' : 'post-launch verification') + '</p>'
    + '<h1>' + E(B.host || '') + '</h1>'
    + '<p class="meta">' + E(A.label) + ' \u00B7 ' + E(A.host) + ' (' + when(A) + ')<br>compared against ' + E(B.label) + ' \u00B7 ' + E(B.host) + ' (' + when(B) + ')'
    + (A.scope || B.scope ? '<br>Scope: ' + E(A.scope || B.scope) : '') + '</p>'
    + kpis + body + '</div></body></html>';

  const old = document.getElementById('aepPrintFrame'); if(old) old.remove();
  const f = document.createElement('iframe');
  f.id = 'aepPrintFrame';
  f.setAttribute('aria-hidden','true');
  f.style.cssText = 'position:fixed;left:-10000px;top:0;width:960px;height:1200px;border:0;';
  f.onload = function(){
    try {
      const w = f.contentWindow, dd = w.document;
      const st = dd.createElement('style');
      st.textContent = '@page{size:' + dd.documentElement.scrollWidth + 'px ' + dd.documentElement.scrollHeight + 'px;margin:0}';
      dd.head.appendChild(st);
      w.focus(); w.print();
      aepStatus('Comparison sent to the print dialog \u2014 choose \u201cSave as PDF\u201d.');
    } catch(err){
      try {
        const blob = new Blob([html], { type:'text/html' });
        const u = URL.createObjectURL(blob);
        window.open(u, '_blank');
        aepStatus('Comparison opened in a new tab \u2014 use Print and choose \u201cSave as PDF\u201d.');
        setTimeout(function(){ URL.revokeObjectURL(u); }, 60000);
      } catch(e2){ aepStatus('Could not build the report.', true); }
    }
  };
  document.body.appendChild(f);
  f.srcdoc = html;
  setTimeout(function(){ const fr = document.getElementById('aepPrintFrame'); if(fr) fr.remove(); }, 60000);
}
function aepAcc(title, count, inner, open, note){
  // Always collapsed on load: a comparison can contain hundreds of rows and an
  // open accordion makes the page unusable. The reader opens what they need.
  return '<details class="accordion"><summary><span class="chev">\u25B6</span> '
    + title + ' (' + count + ')</summary><div class="accordion-body">'
    + (note ? '<p class="hint" style="margin-top:0;">' + note + '</p>' : '') + inner + '</div></details>';
}
let aepLastCompare = null;
function aepPostPickChanged(which){
  const el = document.getElementById(which === 'a' ? 'aepPostA' : 'aepPostB');
  if(el) el.dataset.touched = '1';
  aepPostPickDefaults();
}
async function aepCompare(track){
  aepTrack = track;
  const out = document.getElementById(track === 'pre' ? 'aepPreOut' : 'aepPostOut');
  const aId = (document.getElementById(track === 'pre' ? 'aepPreA' : 'aepPostA')||{}).value;
  const bId = (document.getElementById(track === 'pre' ? 'aepPreB' : 'aepPostB')||{}).value;
  if(!aId || !bId){
    out.innerHTML = '<div class="err-note">' + (track === 'pre'
      ? 'You need one production snapshot and one staging snapshot. Use steps 1 and 2 above.'
      : 'You need two production snapshots. Use steps 1 and 3 above.') + '</div>';
    return;
  }
  if(aId === bId){ out.innerHTML = '<div class="err-note">Pick two different snapshots.</div>'; return; }
  out.innerHTML = '<div class="score">Loading snapshots\u2026</div>';
  let A, B;
  try { A = await stateGet(aepKeySnap(aId)); B = await stateGet(aepKeySnap(bId)); }
  catch(e){ out.innerHTML = '<div class="err-note">Could not load snapshots: ' + escapeHtml(e.message) + '</div>'; return; }
  if(!A || !B){ out.innerHTML = '<div class="err-note">One of those snapshots is missing from the store.</div>'; return; }

  if(aId && aId === bId){
    out.innerHTML = '<p class="empty-msg">Both sides are the same snapshot, so there is nothing to compare. '
      + 'Pick the capture from before the deploy on the left and the one from after it on the right.</p>';
    return;
  }
  const d = aepDiff(A, B);
  aepLastCompare = { A:A, B:B, d:d, track:track };
  const scopeNote = (A.scope || '') !== (B.scope || '')
    ? '<div class="err-note" style="margin-bottom:1rem;">These snapshots used different scopes ('
      + escapeHtml(A.scope || '(whole site)') + ' vs ' + escapeHtml(B.scope || '(whole site)')
      + '). New and removed counts will be misleading.</div>' : '';
  const header = '<p class="hint">Comparing <strong>' + escapeHtml(A.label) + '</strong> \u00B7 ' + escapeHtml(A.host)
    + ' (' + escapeHtml(new Date(A.at).toLocaleString()) + ') against <strong>' + escapeHtml(B.label) + '</strong> \u00B7 '
    + escapeHtml(B.host) + ' (' + escapeHtml(new Date(B.at).toLocaleString()) + ').</p>';

  const exportBar = '<div class="aep-export-bar">'
    + '<button class="btn-secondary" data-click="aepExportPDF()" title="Save this comparison as a PDF">'
    +   '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:.4rem"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>'
    +   'Save comparison as PDF</button>'
    + '<button class="btn-secondary" data-click="aepExportHTML()" title="Save an interactive report you can open in a browser or share" style="margin-left:.5rem">'
    +   '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:.4rem"><path d="M12 3v12"></path><path d="m7 10 5 5 5-5"></path><path d="M5 21h14"></path></svg>'
    +   'Save interactive report</button></div>';
  if(track === 'pre'){
    const willBreak = d.bMissing.length + d.broke.length;
    out.innerHTML = scopeNote
      + '<div class="summary-grid">'
        + '<div class="stat ok"><div class="num">' + d.changed.length + '</div><div class="lbl">Will change</div></div>'
        + '<div class="stat"><div class="num">' + d.added.length + '</div><div class="lbl">New pages</div></div>'
        + '<div class="stat ' + (willBreak ? 'crit' : 'ok') + '"><div class="num">' + willBreak + '</div><div class="lbl">Would launch broken</div></div>'
        + '<div class="stat warn"><div class="num">' + d.lag.length + '</div><div class="lbl">Translation not updated</div></div>'
        + '<div class="stat"><div class="num">' + d.unchanged.length + '</div><div class="lbl">Untouched</div></div>'
        + '<div class="stat warn"><div class="num">' + d.removed.length + '</div><div class="lbl">Missing from staging</div></div>'
      + '</div>' + header + exportBar
      + aepAcc('Incomplete on staging \u00B7 translations missing', d.bMissing.length, aepLangTable(d.bMissing), d.bMissing.length > 0,
          'A language version is absent or failing on staging. Whether or not it exists in production today, deploying this leaves it broken.')
      + aepAcc('Will change on deploy', d.changed.length, aepChangeCards(d.changed, A.env, B.env), true,
          'Your release contents \u2014 the actual text and document changes, not just a word count. Review this against what the release was supposed to touch.')
      + aepAcc('Linked documents changing', d.docChanges.length, aepDocChangesTable(d.docChanges), d.docChanges.length > 0,
          'SBCs, EOCs, formularies and similar files that point at a different document than what is currently live. Filename swaps like this do not show up as a text change.')
      + aepAcc('Translation not updated on staging', d.lag.length, aepLangTable(d.lag), false,
          'English changed on staging but this language did not \u2014 it will go live showing the old copy.')
      + aepAcc('New pages going live', d.added.length, aepNewPageTable(d.added), d.added.length > 0,
          'On the candidate only \u2014 nothing in production to compare against. Open each one to confirm it is meant to launch and that every language is present.')
      + aepAcc('In production but missing from staging', d.removed.length, aepPageTable(d.removed, {}), false,
          'In production but not on the candidate. Usually a deliberate removal or a rename \u2014 no action unless you expected it to still be there.')
      + aepAcc('Untouched by this release', d.unchanged.length, aepPageTable(d.unchanged, {}), false,
          'Identical on both. Normal \u2014 these pages simply are not part of the release.')
      + (d.unknown.length ? aepAcc('Not comparable', d.unknown.length, aepPageTable(d.unknown, {}), false,
          'Failed to load in one of the two snapshots.') : '');
  } else {
    out.innerHTML = scopeNote
      + '<div class="summary-grid">'
        + '<div class="stat warn"><div class="num">' + d.unchanged.length + '</div><div class="lbl">Unchanged</div></div>'
        + '<div class="stat ok"><div class="num">' + d.changed.length + '</div><div class="lbl">Updated</div></div>'
        + '<div class="stat"><div class="num">' + d.added.length + '</div><div class="lbl">New pages</div></div>'
        + '<div class="stat crit"><div class="num">' + d.broke.length + '</div><div class="lbl">Now failing</div></div>'
        + '<div class="stat warn"><div class="num">' + d.lag.length + '</div><div class="lbl">Translation lag</div></div>'
        + '<div class="stat crit"><div class="num">' + d.lostTrans.length + '</div><div class="lbl">Lost translations</div></div>'
      + '</div>' + header + exportBar
      + aepAcc('Unchanged \u00B7 possibly missed updates', d.unchanged.length, aepPageTable(d.unchanged, {}), true,
          'Byte-for-byte identical before and after. Cross-check against the pages the release was meant to update \u2014 anything on both lists was missed.')
      + aepAcc('Lost translations \u00B7 live before, failing now', d.lostTrans.length, aepLangTable(d.lostTrans), true,
          'These broke during the release. Fix first.')
      + aepAcc('Translation lag \u00B7 English updated, translation did not', d.lag.length, aepLangTable(d.lag), false,
          'Your retranslation queue.')
      + aepAcc('Updated', d.changed.length, aepChangeCards(d.changed, A.label, B.label), false,
          'The actual text and document changes for each updated page, not just a word count.')
      + aepAcc('Linked documents changed', d.docChanges.length, aepDocChangesTable(d.docChanges), d.docChanges.length > 0,
          'SBCs, EOCs, formularies and similar files that now point at a different document. A filename swap like this will not show up as a text change on the page.')
      + aepAcc('New pages', d.added.length, aepNewPageTable(d.added), d.added.length > 0,
          'Appeared with the release. Nothing to compare against \u2014 open each one to confirm it is correct and fully translated.')
      + aepAcc('Removed', d.removed.length, aepPageTable(d.removed, {}), false,
          'No longer present. Usually a deliberate retirement or a rename.')
      + (d.unknown.length ? aepAcc('Not comparable', d.unknown.length, aepPageTable(d.unknown, {}), false,
          'Failed to load in one of the two snapshots.') : '');
  }
}

/* ----------------------------- helpers ----------------------------- */
function clean(s){ return (s||'').replace(/\s+/g,' ').trim(); }
function escapeHtml(s){ return (s==null?'':String(s)).replace(/[&<>]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m])); }
function escapeAttr(s){ return (s==null?'':String(s)).replace(/[&<>"]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])); }
function setProgress(msg, warn){
  ['progress','modalProgress'].forEach(function(id){
    const el = document.getElementById(id);
    if(!el) return;
    if(id === 'modalProgress' && !warn && msg){ el.innerHTML = '<span class="run-spinner"></span>' + msg; }
    else { el.textContent = msg; }
    el.style.color = warn ? 'var(--critical)' : 'var(--muted)';
  });
}
function setBar(pct){
  ['bar','modalBar'].forEach(function(id){ var el=document.getElementById(id); if(el) el.style.width = pct + '%'; });
}
function scrollTopSmooth(){ try { window.scrollTo({ top:0, behavior:'smooth' }); } catch(e){ window.scrollTo(0,0); } }
function openRunModal(){
  var m = document.getElementById('runModal');
  if(m){ m.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
  setBar(0);
}
function closeRunModal(){
  var m = document.getElementById('runModal');
  if(m){ m.style.display = 'none'; }
  document.body.style.overflow = '';
}

/* ----------------------------- init ----------------------------- */
(function initConfigDisplay(){
  const siteEl = document.getElementById('cfgSite');
  try { siteEl.textContent = new URL(SITE_URL).host; } catch(e){ siteEl.textContent = SITE_URL || '(SITE_URL not set)'; }
})();
renderPages();
updateRunHint();
onTransToggle();
window.addEventListener('message', function(e){
  if(e.data && typeof e.data.dashHeight === 'number'){
    const f = document.getElementById('dashFrame');
    if(f) f.style.height = (e.data.dashHeight + 24) + 'px';
  }
  else if(e.data && e.data.__mlaudit === 'triage'){
    setTriage(e.data.key, e.data.status);
  }
  else if(e.data && e.data.__mlaudit === 'pdf'){
    exportReportPDF(e.data.view);
  }
  else if(e.data && e.data.__mlaudit === 'exportcsv'){
    exportPowerBICsv();
  }
  else if(e.data && e.data.__mlaudit === 'runAudit'){
    if(userRole === 'admin') runAudit();
  }
  else if(e.data && e.data.__mlaudit === 'publish'){
    publishRun().then(function(ok){ ackToFrame('publish', !!ok); });
  }
  else if(e.data && e.data.__mlaudit === 'scan404'){
    if(userRole === 'admin'){
      var fr = document.getElementById('dashFrame');
      function post(p){ try { fr && fr.contentWindow.postMessage({ __mlaudit_scan: p }, '*'); } catch(e){} }
      post({ phase:'start' });
      scanSitemap404s(function(done, total){ post({ phase:'progress', done:done, total:total }); })
        .then(function(rec){ post({ phase:'done', rec:rec }); });
    }
  }
});
function ackToFrame(action, ok){
  var f = document.getElementById('dashFrame');
  try { f && f.contentWindow.postMessage({ __mlaudit_ack: action, ok: ok, at: new Date().toISOString() }, '*'); } catch(e){}
}
(function restoreSession(){
  try {
    var s = JSON.parse(sessionStorage.getItem('mlaudit-session') || 'null');
    if(s && s.role){
      pickRole(s.role);
      enterApp(s.role);
      return;
    }
  } catch(e){}
})();
