/* Extension-only additions to the dashboard. No-ops when served as a plain web page. */
(function () {
  var IS_EXT = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;
  if (!IS_EXT) return;

  function addReviewButton() {
    var nav = document.getElementById('pageTabs');
    if (!nav || document.getElementById('reviewBtn')) return;
    var b = document.createElement('button');
    b.id = 'reviewBtn';
    b.className = 'pbi-btn';
    b.style.marginLeft = '.4rem';
    b.title = 'Open azblue.com with the review panel';
    b.innerHTML =
      '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" ' +
      'stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="3" y="4" width="18" height="16" rx="2"></rect><path d="M15 4v16"></path></svg>' +
      '<span>Review on site</span>';
    // sidePanel.open() must run synchronously in the gesture — no awaits before it.
    b.addEventListener('click', function () {
      try { chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT }); }
      catch (e) { console.warn('side panel:', e); }
      chrome.runtime.sendMessage({ type: 'openSite', url: 'https://www.azblue.com/' });
    });
    nav.appendChild(b);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', addReviewButton);
  else addReviewButton();
  // tabs are rebuilt on sign-in, so re-add then too
  var _bt = window.buildTabsForRole;
  if (typeof _bt === 'function') {
    window.buildTabsForRole = function () { _bt.apply(this, arguments); addReviewButton(); };
  }
})();
