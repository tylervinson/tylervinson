/* Before/after document thumbnails for the AEP tab.
   Renders page 1 of linked PDFs at a fixed height (aspect ratio preserved, never
   skewed). Anything that isn't a renderable PDF — a different office format, a
   404, a host we can't reach — gets a plain monochrome icon instead, so a slot
   never sits empty. Rendering happens lazily, the first time its <details>
   section is opened, and each URL is only ever fetched/rendered once per
   session (successes and failures are both cached). */
(function () {
  var THUMB_H = 132; // CSS px — every tile in a row is this tall, width follows its own aspect ratio

  var _pdfjsPromise = null;
  function ensureMapUpsertPolyfill () {
    // pdfjs-dist 5.x calls Map#getOrInsertComputed on every page render (via its
    // optional-content-groups check), even for a PDF with no layers at all. That
    // method comes from a JS proposal recent enough that not every Chrome version
    // has it yet — polyfill it rather than gate the feature on browser version.
    if (typeof Map.prototype.getOrInsertComputed !== 'function') {
      Map.prototype.getOrInsertComputed = function (key, cb) {
        if (this.has(key)) return this.get(key);
        var v = cb(key);
        this.set(key, v);
        return v;
      };
    }
  }
  function loadPdfJs () {
    if (_pdfjsPromise) return _pdfjsPromise;
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getURL) {
      _pdfjsPromise = Promise.reject(new Error('not running as an extension'));
      return _pdfjsPromise;
    }
    ensureMapUpsertPolyfill();
    _pdfjsPromise = import(chrome.runtime.getURL('vendor/pdfjs/build/pdf.min.mjs')).then(function (mod) {
      mod.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('vendor/pdfjs/build/pdf.worker.min.mjs');
      return mod;
    });
    return _pdfjsPromise;
  }

  function extOf (url) {
    var m = String(url || '').match(/\.([a-z0-9]+)(?:[?#]|$)/i);
    return m ? m[1].toLowerCase() : '';
  }

  // -------- monochrome icon set: one base page shape, distinguished by a small
  // badge (or, for other formats, a text tag) rather than color or a new pictogram --------
  var PAGE_PATH = 'M6 2.5h8.5L19 7v14.5H6z M14.5 2.5V7H19';
  function iconSvg (badge) {
    return '<svg viewBox="0 0 24 24" class="aep-doc-icon" aria-hidden="true">'
      + '<path d="' + PAGE_PATH + '" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"/>'
      + (badge || '')
      + '</svg>';
  }
  var ICONS = {
    // unavailable / removed — circle-slash over the page
    deleted: iconSvg('<circle cx="17" cy="18" r="4.4" fill="var(--card,#242424)" stroke="currentColor" stroke-width="1.3"/><line x1="14.6" y1="20.4" x2="19.4" y2="15.6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>'),
    // unreachable host — small box with an arrow escaping it (the standard "external" glyph)
    external: iconSvg('<rect x="13.3" y="14.3" width="6.4" height="6.4" fill="var(--card,#242424)" stroke="currentColor" stroke-width="1.2" rx=".5"/><path d="M15.6 17.4l3-3m0 0h-2m2 0v2" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>'),
    // fetched fine but couldn't be read as a PDF
    unknown: iconSvg('<circle cx="17" cy="18" r="4.4" fill="var(--card,#242424)" stroke="currentColor" stroke-width="1.3"/><text x="17" y="19.6" font-size="6" text-anchor="middle" fill="currentColor" font-family="inherit">?</text>'),
    // any non-PDF office format — plain page, the extension text underneath carries the meaning
    plain: iconSvg('')
  };
  var CAPTIONS = { deleted: 'No longer there', external: "Can't reach this", unknown: 'Couldn\u2019t open' };

  function tile (inner, caption) {
    return '<span class="aep-doc-tile">' + inner
      + (caption ? '<span class="aep-doc-caption">' + caption + '</span>' : '') + '</span>';
  }
  function iconTile (kind, extLabel) {
    var cap = extLabel ? extLabel.toUpperCase() : (CAPTIONS[kind] || '');
    return tile('<span class="aep-doc-iconwrap">' + (ICONS[kind] || ICONS.plain) + '</span>', cap);
  }

  // -------- fetch + classify + render --------
  var cache = new Map(); // url -> Promise<{status, dataUrl?, w?, h?}>

  async function classify (url) {
    var res, buf;
    try {
      res = await fetch(url);
      if (res.status === 404 || res.status === 410) return { status: 'deleted' };
      if (!res.ok) return { status: 'unknown' };
      buf = await res.arrayBuffer();
    } catch (e) {
      // fetch throwing is how a blocked/uncovered host or a network failure both
      // surface from an extension page — no reliable way to tell them apart further,
      // and "can't reach it" is an accurate description of both.
      return { status: 'external' };
    }
    return { status: 'ok', buf: buf };
  }

  async function renderPage1 (buf) {
    var pdfjsLib = await loadPdfJs();
    var doc = await pdfjsLib.getDocument({
      data: buf,
      standardFontDataUrl: chrome.runtime.getURL('vendor/pdfjs/standard_fonts/')
    }).promise;
    try {
      var page = await doc.getPage(1);
      var base = page.getViewport({ scale: 1 });
      var dpr = Math.min(2, window.devicePixelRatio || 1);
      var scale = (THUMB_H * dpr) / base.height;
      var vp = page.getViewport({ scale: scale });
      var canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(vp.width));
      canvas.height = Math.max(1, Math.round(vp.height));
      var ctx = canvas.getContext('2d');
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      return { status: 'ok', dataUrl: canvas.toDataURL('image/png'), w: vp.width / dpr, h: vp.height / dpr };
    } finally {
      doc.destroy();
    }
  }

  function fetchAndRender (url) {
    if (cache.has(url)) return cache.get(url);
    var p = (async function () {
      var c = await classify(url);
      if (c.status !== 'ok') return c;
      try { return await renderPage1(c.buf); }
      catch (e) { return { status: 'unknown' }; }
    })();
    cache.set(url, p);
    return p;
  }

  // -------- public: build a slot (sync) and resolve it later (async) --------
  // Non-PDF formats never attempt a fetch — there is nothing to render, so show
  // the identifying tag immediately rather than a slot that "loads" into an icon.
  function slotHtml (url) {
    var ext = extOf(url);
    if (ext !== 'pdf') return iconTile('plain', ext || 'file');
    return '<span class="aep-doc-tile aep-doc-pending" data-thumb-url="' + url.replace(/"/g, '&quot;') + '"></span>';
  }

  async function resolveSlot (el) {
    var url = el.getAttribute('data-thumb-url');
    if (!url) return;
    el.setAttribute('data-thumb-done', '1');
    var r;
    try { r = await fetchAndRender(url); } catch (e) { r = { status: 'unknown' }; }
    if (r.status === 'ok') {
      el.classList.remove('aep-doc-pending');
      el.innerHTML = '<img src="' + r.dataUrl + '" alt="" style="height:' + THUMB_H + 'px;width:auto;display:block;">';
    } else {
      el.outerHTML = iconTile(r.status || 'unknown');
    }
  }

  function renderThumbsIn (root) {
    var slots = root.querySelectorAll('[data-thumb-url]:not([data-thumb-done])');
    var i = 0, CONC = 3;
    function next () {
      if (i >= slots.length) return;
      var el = slots[i++];
      resolveSlot(el).then(next, next);
    }
    for (var k = 0; k < Math.min(CONC, slots.length); k++) next();
  }

  // A <details> "toggle" event does not reliably bubble across all Chrome
  // versions, but capture-phase delegation sees it regardless — the capture leg
  // of dispatch always runs on the way down to the target.
  document.addEventListener('toggle', function (e) {
    if (!(e.target instanceof HTMLDetailsElement) || !e.target.open) return;
    renderThumbsIn(e.target);
  }, true);

  window.AepDocThumb = { slotHtml: slotHtml, iconTile: iconTile, renderThumbsIn: renderThumbsIn, THUMB_H: THUMB_H };
})();
