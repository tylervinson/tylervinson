# AZ Blue Site Audit — Chrome extension

Packages the audit tool as an extension: the full dashboard plus a side panel
that shows findings for the azblue.com page you're currently viewing.

## Install (unpacked, for testing)

1. Chrome → `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. **Load unpacked** → select this folder
4. Pin the extension to the toolbar

## Use

- **Click the toolbar icon** → opens the full dashboard in a tab
- **"Review on site"** (in the dashboard tab bar) → opens azblue.com *and* the side panel
- The panel follows you as you browse and shows that page's findings
- **"Full dashboard"** in the panel → jumps back to the dashboard tab

Sign in once in the dashboard; the panel reads the same published run.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest |
| `background.js` | Toolbar click, per-tab panel availability, tab messaging |
| `dashboard.html` / `dashboard.js` | The tool (scripts externalised for MV3) |
| `actions.js` | Delegated handler dispatcher (replaces inline `onclick`) |
| `dashview.js` | Runs inside the dashboard iframe (generated from `dashboard.js`) |
| `sidepanel.html` / `sidepanel.js` | Per-page review panel |
| `content.js` | Highlights/scrolls to the element a finding refers to |
| `ext-glue.js` | Adds the "Review on site" button when running as an extension |

## Rebuilding after tool changes

`dashboard.js` and `dashview.js` are generated from the single-file tool:

```
python3 build_ext.py       # refactors the HTML, extracts scripts
python3 gen_dashview.py    # regenerates dashview.js
```

## Notes

- Expanding a finding in the panel highlights and scrolls to it on the page.
- The side panel can't auto-open — Chrome requires a user gesture, which is why
  the dashboard's "Review on site" button exists.
- Works in Edge too (same Chromium extension), but Chrome is the target.
