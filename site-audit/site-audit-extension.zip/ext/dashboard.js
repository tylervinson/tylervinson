var EXT_MODE = (typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id));

/* CONFIG — edit once. Passphrase is typed in the UI at runtime, not stored here.
   Languages are the `langs` list below. */
const WORKER_URL = 'https://schema-cors-proxy.bcbs-of-az.workers.dev/';
const SITE_URL   = 'https://www.azblue.com';
const WORKER_KEY = ''; // optional fallback; prefer typing the passphrase in the UI
const AI_MODEL   = 'claude-sonnet-4-6'; // model used for translation analysis (via your worker)
// Sitecore content root for the "Items last updated" export — used to turn item
// paths into clean relative paths in the stale-content view.
const SITECORE_ROOT = '/sitecore/content/bcbs az/azblue/home';
// Shared store: STATE_URL points at the KV Worker (audit-state-worker.js) so triage +
// runs are consistent for all users. Empty = local-only. Auth reuses the passphrase.
const STATE_URL = 'https://audit-state.bcbs-of-az.workers.dev/';
/* ===================================================================== */

/* ----------------------------- languages ----------------------------- */
// English is the reference (dir ''). Each translation is a path prefix.
// gcode = the Google Translate target code (e.g. 'es', 'zh-TW', 'fr', 'de').
const SOURCE_GCODE = 'en'; // source language Google translates FROM
let langs = [
  { id: 'ref', label: 'English', dir: '', ref: true, gcode: 'en' },
  { id: 'l1', label: 'Spanish', dir: 'es', ref: false, gcode: 'es' },
  { id: 'l2', label: 'Chinese Traditional', dir: 'zh', ref: false, gcode: 'zh-TW' }
];

/* ----------------------------- state ----------------------------- */
let pages = [
  { id: p(), name: 'Home', path: '', excluded: false }
];
let discovered = [];   // full sitemap list, kept in memory (not all rendered)
let dirInclude = {};   // directory -> included?
let pageExclude = {};  // path -> individually excluded?
function p(){ return 'p' + Math.random().toString(36).slice(2,8); }

/* ----------------------------- rendering inputs ----------------------------- */
function renderPages(){
  const tbl = document.getElementById('pagesTable');
  tbl.innerHTML = '';
  const head = document.createElement('tr');
  head.innerHTML = '<th style="min-width:140px;">Page name</th><th style="min-width:160px;">Path</th><th>Resolves to</th><th style="text-align:center;" title="Skip this page in the next audit run">Skip</th><th></th>';
  tbl.appendChild(head);
  pages.forEach(pg => {
    const tr = document.createElement('tr');
    if(pg.excluded) tr.style.opacity = '.45';
    const preview = langs.map(l => escapeHtml(buildUrl(SITE_URL, l.dir, pg.path))).join('<br>')
      + (pg.excluded ? '<br><span style="color:var(--critical);">Excluded from audit</span>' : '');
    tr.innerHTML =
      `<td class="name-cell"><input type="text" value="${escapeAttr(pg.name)}" data-input="updatePageName('${pg.id}', this.value)" placeholder="Page name"></td>` +
      `<td><input type="text" value="${escapeAttr(pg.path)}" placeholder="(home)" data-input="updatePagePath('${pg.id}', this.value)"></td>` +
      `<td style="font-size:.72rem;color:var(--muted);line-height:1.5;word-break:break-all;">${preview}</td>` +
      `<td style="text-align:center;"><input type="checkbox" ${pg.excluded?'checked':''} title="Skip this page in the next audit run" data-change="togglePageExcluded('${pg.id}', this.checked)"></td>` +
      `<td><button class="tiny ghost" data-click="removePage('${pg.id}')">✕</button></td>`;
    tbl.appendChild(tr);
  });
}
function updatePageName(id,v){ const pg = pages.find(x=>x.id===id); if(pg){ pg.name=v; updateRunHint(); saveManualPagesSoon(); } }
function updatePagePath(id,v){ const pg = pages.find(x=>x.id===id); if(pg){ pg.path=v.trim(); renderPages(); updateRunHint(); saveManualPagesSoon(); markDashStale(); refreshDashIfVisible(); } }
function addPage(){ pages.push({ id:p(), name:'Page ' + (pages.length+1), path:'', excluded:false }); renderPages(); updateRunHint(); saveManualPagesSoon(); }
function removePage(id){ pages = pages.filter(x=>x.id!==id); renderPages(); updateRunHint(); saveManualPagesSoon(); markDashStale(); refreshDashIfVisible(); }
function togglePageExcluded(id, checked){ const pg = pages.find(x=>x.id===id); if(pg){ pg.excluded = checked; renderPages(); updateRunHint(); saveManualPagesSoon(); markDashStale(); refreshDashIfVisible(); } }
let _manualPagesSaveTimer = null;
function saveManualPagesSoon(){
  clearTimeout(_manualPagesSaveTimer);
  _manualPagesSaveTimer = setTimeout(function(){
    statePut('manualPages', pages.map(function(pg){ return { name:pg.name, path:pg.path, excluded:!!pg.excluded }; })).catch(function(){});
  }, 600);
}
async function loadManualPages(){
  try {
    const mp = await stateGet('manualPages');
    if(Array.isArray(mp)){
      pages = mp.map(function(pg){ return { id:p(), name:pg.name||'', path:pg.path||'', excluded:!!pg.excluded }; });
      renderPages();
      updateRunHint();
    }
  } catch(e){}
}

function buildUrl(site, dir, path){
  let base = (site||'').replace(/\/+$/,'');
  dir = (dir||'').replace(/^\/+|\/+$/g,'');
  path = (path||'').replace(/^\/+|\/+$/g,'');
  let out = base;
  if(dir) out += '/' + dir;
  if(path) out += '/' + path;
  return out;
}

// ---- English-only section exclusions (skip translation checks + 404 monitor) ----
function getExcludeDirs(){
  var raw = (document.getElementById('excludeDirs') && document.getElementById('excludeDirs').value) || '';
  return raw.split(/[\n,]+/).map(function(s){ return s.trim().replace(/^\/+|\/+$/g,'').toLowerCase(); }).filter(Boolean);
}
function pathIsExcluded(path, dirs){
  var p = String(path == null ? '' : path).trim().replace(/^\/+|\/+$/g,'').toLowerCase();
  if(!p) return false;
  return (dirs||[]).some(function(d){ return d && (p === d || p.indexOf(d + '/') === 0); });
}

/* ----------------------------- sitemap discovery ----------------------------- */
const SKIP_EXT = /\.(pdf|jpe?g|png|gif|webp|svg|ico|css|js|json|xml|zip|gz|mp4|mp3|woff2?|ttf|eot)$/i;

function urlToPath(u){
  try {
    const url = new URL(u);
    let path = url.pathname.replace(/^\/+|\/+$/g,'');
    const dirs = langs.map(l=>l.dir).filter(Boolean); // e.g. ['es','zh']
    const parts = path ? path.split('/') : [];
    if(parts.length && dirs.includes(parts[0])) parts.shift(); // drop language prefix
    return parts.join('/');
  } catch(e){ return null; }
}
function prettyName(path){
  if(!path) return 'Home';
  const seg = path.split('/').pop();
  return seg.replace(/[-_]+/g,' ').replace(/\b\w/g, c=>c.toUpperCase());
}

async function discoverPages(){
  const status = document.getElementById('discoverStatus');
  const setS = (t) => { status.textContent = t; status.style.color = 'var(--muted)'; };
  const setErr = (t) => { status.textContent = t; status.style.color = 'var(--critical)'; };

  if(!WORKER_URL || WORKER_URL.includes('your-worker')){ setErr('Set WORKER_URL in the config block first.'); return; }
  document.getElementById('discoverDiag').innerHTML = '';
  setS('Looking for a sitemap…');

  const root = SITE_URL.replace(/\/+$/,'');
  const siteHost = (()=>{ try { return new URL(SITE_URL).hostname; } catch(e){ return ''; } })();
  const diag = []; // { url, status, note }
  const looksHtml = (t) => /^\s*<(!doctype html|html)\b/i.test(t||'');

  // 1) robots.txt → Sitemap: directives
  let sitemaps = [];
  try {
    const r = await fetchPage(root + '/robots.txt');
    if(r.ok && r.text && !looksHtml(r.text)){
      r.text.split(/\r?\n/).forEach(line => {
        const m = line.match(/^\s*sitemap:\s*(\S+)/i);
        if(m) sitemaps.push(m[1].trim());
      });
      diag.push({ url: root+'/robots.txt', status: r.status, note: sitemaps.length ? `${sitemaps.length} sitemap line(s) found` : 'loaded, but no Sitemap: line' });
    } else {
      diag.push({ url: root+'/robots.txt', status: r.status, note: r.error ? r.error : (looksHtml(r.text) ? 'returned HTML, not robots.txt' : 'not available') });
    }
  } catch(e){ diag.push({ url: root+'/robots.txt', status: 0, note: e.message }); }

  // 2) fallbacks
  const guessed = !sitemaps.length;
  if(guessed){ sitemaps = [root + '/sitemap.xml', root + '/sitemap_index.xml', root + '/sitemap-index.xml']; }

  const MAX_SITEMAPS = 60, MAX_URLS = 3000;
  const seenSm = new Set();
  const foundUrls = new Set();
  const lastmodMap = {};
  let queue = [...sitemaps];

  while(queue.length && seenSm.size < MAX_SITEMAPS && foundUrls.size < MAX_URLS){
    const sm = queue.shift();
    if(!sm || seenSm.has(sm)) continue;
    seenSm.add(sm);
    setS(`Reading sitemap ${seenSm.size}… (${foundUrls.size} pages found)`);
    let r;
    try { r = await fetchPage(sm); } catch(e){ diag.push({ url: sm, status: 0, note: e.message }); continue; }
    if(!r.ok || !r.text){ diag.push({ url: sm, status: r.status, note: r.error ? r.error : 'no content' }); continue; }
    const doc = new DOMParser().parseFromString(r.text, 'text/xml');
    if(doc.querySelector('parsererror')){
      diag.push({ url: sm, status: r.status, note: looksHtml(r.text) ? 'got an HTML page, not XML (WAF or error page?)' : 'not valid XML' });
      continue;
    }
    const rootTag = doc.documentElement ? doc.documentElement.tagName.toLowerCase() : '';
    const locs = [...doc.querySelectorAll('loc')].map(l => clean(l.textContent)).filter(Boolean);
    if(rootTag.indexOf('sitemapindex') !== -1){
      locs.forEach(u => { if(!seenSm.has(u)) queue.push(u); }); // child sitemaps
      diag.push({ url: sm, status: r.status, note: `sitemap index → ${locs.length} child sitemap(s)` });
    } else {
      [...doc.querySelectorAll('url')].forEach(node => {
        const loc = clean(node.querySelector('loc')?.textContent || '');
        if(!loc) return;
        foundUrls.add(loc);
        const lm = clean(node.querySelector('lastmod')?.textContent || '');
        if(lm) lastmodMap[loc] = lm;
      });
      // fallback if structure was flat
      locs.forEach(u => foundUrls.add(u));
      diag.push({ url: sm, status: r.status, note: `${locs.length} page URL(s)` });
    }
  }

  if(!foundUrls.size){
    renderDiscoverDiag(diag, guessed, siteHost);
    setErr('No pages found in a sitemap — see the breakdown below, or add pages manually.');
    return;
  }

  // normalize → unique paths on our host, minus assets
  const paths = new Set();
  const pathLastmod = {};
  const keptUrls = [];
  const truncated = foundUrls.size >= MAX_URLS;
  foundUrls.forEach(u => {
    try {
      const url = new URL(u);
      if(siteHost && url.hostname !== siteHost) return;
      if(SKIP_EXT.test(url.pathname)) return;
      const path = urlToPath(u);
      if(path !== null){
        paths.add(path);
        keptUrls.push(u);
        const lm = lastmodMap[u];
        if(lm && (!pathLastmod[path] || lm > pathLastmod[path])) pathLastmod[path] = lm;
      }
    } catch(e){}
  });

  const list = [...paths].sort((a,b)=> a.localeCompare(b));
  if(!list.length){ setErr('Sitemap had entries but none matched your site host.'); return; }

  // keep full list in memory; surface directory facets, not raw rows
  discovered = list.map(path => ({ path, lastmod: pathLastmod[path] || '' }));

  // persist the sitemap URL list for the 404 monitor — written ONLY on manual discovery,
  // so the dashboard box and the Cron worker both scan a fixed list until you discover again.
  try {
    var smUrls = Array.from(new Set(keptUrls));
    statePut('sitemap', { urls: smUrls, count: smUrls.length, updated: new Date().toISOString() })
      .catch(function(){});
  } catch(e){}
  const dirCounts = {};
  discovered.forEach(d => { const dir = dirOf(d.path); dirCounts[dir] = (dirCounts[dir]||0)+1; });
  dirInclude = {};
  Object.keys(dirCounts).forEach(dir => dirInclude[dir] = true);
  pageExclude = {};
  document.getElementById('discoveredPanel').style.display = 'block';
  document.getElementById('discoverDiag').innerHTML = '';
  renderDiscovered();
  updateRunHint();

  let msg = `Found ${discovered.length} page(s) across ${Object.keys(dirCounts).length} director${Object.keys(dirCounts).length===1?'y':'ies'}.`;
  if(truncated) msg += ' Very large sitemap — list may be partial.';
  setS(msg);
}

function renderDiscoverDiag(diag, guessed, siteHost){
  const box = document.getElementById('discoverDiag');
  if(!diag.length){ box.innerHTML = ''; return; }

  // work out the most likely cause for a targeted hint
  const statuses = diag.map(d => d.status);
  const all403 = diag.length && diag.every(d => d.status === 403);
  const anyHtml = diag.some(d => /HTML/i.test(d.note));
  const offHost = diag.find(d => { try { return new URL(d.url).hostname !== siteHost; } catch(e){ return false; } });
  let hint = '';
  if(all403){
    hint = 'Every request came back 403 — the worker is rejecting them. Check that the passphrase you typed matches the worker\'s AUDIT_KEY exactly.';
  } else if(offHost && (offHost.status === 403 || offHost.status === 0)){
    let host = ''; try { host = new URL(offHost.url).hostname; } catch(e){}
    hint = `Your sitemap lives on ${host}, which the worker\'s allowlist blocks. Add "${host}" to ALLOWED_HOSTS in the worker and redeploy.`;
  } else if(anyHtml){
    hint = 'A request returned an HTML page instead of XML — often a WAF challenge or a "not found" page dressed up as 200. Open the URL below via Test connection to see what the server actually sends.';
  } else if(guessed && statuses.every(s => s === 404 || s === 0)){
    hint = 'No sitemap at robots.txt or the common filenames. If you know the real sitemap URL, tell me and I can point discovery straight at it.';
  } else {
    hint = 'Discovery reached the server but found no page URLs. The breakdown below shows each attempt.';
  }

  const rows = diag.map(d => {
    const bad = !(d.status >= 200 && d.status < 300);
    return `<li><span class="code ${bad?'bad':''}">${d.status || '—'}</span><span style="word-break:break-all;">${escapeHtml(d.url)}</span><span style="margin-left:auto;color:var(--muted-2);">${escapeHtml(d.note)}</span></li>`;
  }).join('');

  box.innerHTML = `<div style="margin-top:.8rem; border:1px solid var(--border); border-radius:8px; padding:1rem;">
    <div class="err-note" style="margin-bottom:.8rem;">${escapeHtml(hint)}</div>
    <div class="section-label" style="margin-top:0;">What discovery tried</div>
    <ul class="tech">${rows}</ul>
  </div>`;
}

/* ---- directory facets over the discovered list ---- */
function dirOf(path){
  if(path === '') return '(home)';
  const segs = path.split('/');
  return segs.length === 1 ? '(top level)' : segs[0];
}
function pageIncluded(path){ return !!dirInclude[dirOf(path)] && !pageExclude[path]; }
function effectiveDiscovered(){ return discovered.filter(d => pageIncluded(d.path)); }

function toggleDir(dir, on){ dirInclude[dir] = on; renderDiscovered(); updateRunHint(); }
function setAllDirs(on){ Object.keys(dirInclude).forEach(d => dirInclude[d] = on); renderDiscovered(); updateRunHint(); }
function togglePage(path, on){ if(on) delete pageExclude[path]; else pageExclude[path] = true; renderDiscSummary(); renderDiscSearch(); updateRunHint(); }

function renderDiscovered(){
  const dirCounts = {};
  discovered.forEach(d => { const dir = dirOf(d.path); dirCounts[dir] = (dirCounts[dir]||0)+1; });
  const dirs = Object.keys(dirCounts).sort((a,b)=> dirCounts[b]-dirCounts[a] || a.localeCompare(b));
  document.getElementById('dirList').innerHTML = dirs.map(dir => {
    const on = dirInclude[dir];
    return `<label class="dir-row ${on?'':'off'}">
      <input type="checkbox" ${on?'checked':''} data-dir="${escapeAttr(dir)}" data-change="__toggleDir(this)">
      <span>${escapeHtml(dir)}</span>
      <span class="count">${dirCounts[dir]}</span>
    </label>`;
  }).join('');
  renderDiscSummary();
  renderDiscSearch();
}
function renderDiscSummary(){
  const total = discovered.length;
  const sel = effectiveDiscovered().length;
  const excl = Object.keys(pageExclude).filter(k=>pageExclude[k] && dirInclude[dirOf(k)]).length;
  document.getElementById('discSummary').innerHTML =
    `<strong>${sel}</strong> of ${total} discovered pages selected for audit` +
    (excl ? ` (${excl} individually excluded)` : '') + '.';
}
function renderDiscSearch(){
  const box = document.getElementById('discSearchResults');
  const q = (document.getElementById('discSearch').value||'').trim().toLowerCase();
  if(!q){ box.innerHTML = ''; return; }
  const matches = discovered.filter(d => ('/'+d.path).toLowerCase().includes(q));
  if(!matches.length){ box.innerHTML = `<div class="disc-results"><div class="res"><span class="path">No matching pages found.</span></div></div>`; return; }
  const CAP = 60;
  const rows = matches.slice(0, CAP).map(d => {
    const dirOn = !!dirInclude[dirOf(d.path)];
    const inc = pageIncluded(d.path);
    const tag = inc ? 'included' : (dirOn ? 'excluded' : 'directory off');
    return `<div class="res">
      <input type="checkbox" ${inc?'checked':''} ${dirOn?'':'disabled'} data-path="${escapeAttr(d.path)}" data-change="__togglePage(this)">
      <span class="path">/${escapeHtml(d.path)}</span>
      <span class="tag ${inc?'in':'out'}">${tag}</span>
    </div>`;
  }).join('');
  const more = matches.length > CAP ? `<div class="res"><span class="path">…and ${matches.length-CAP} more — refine your search.</span></div>` : '';
  box.innerHTML = `<div class="disc-results">${rows}${more}</div>`;
}

/* combined audit set: selected discovered pages + manual rows, deduped by path */
function getAuditPages(){
  const map = new Map();
  effectiveDiscovered().forEach(d => map.set(normPath(d.path), { name: prettyName(d.path), path: d.path, lastmod: d.lastmod || '' }));
  pages.forEach(pg => {
    if(!pg) return;
    const k = normPath(pg.path);
    if(pg.excluded){ map.delete(k); return; }
    if(pg.name) map.set(k, { name: pg.name, path: pg.path, lastmod: (map.get(k)||{}).lastmod || '' });
  });
  return [...map.values()];
}
function updateRunHint(){
  const n = getAuditPages().length;
  const t = langs.filter(l=>!l.ref).length;
  document.getElementById('runHint').textContent = n ? `Will audit ${n} page${n===1?'':'s'} × ${t} language${t===1?'':'s'}.` : '';
}

function onTransToggle(){
  const on = document.getElementById('transToggle').checked;
  document.getElementById('engine').disabled = !on;
  document.getElementById('transToggleLabel').textContent = on ? 'On' : 'Off';
}

/* ----------------------------- save / load to JSON ----------------------------- */
function setSaveStatus(msg, err){ const el = document.getElementById('saveStatus'); if(!el) return; el.textContent = msg; el.style.color = err ? 'var(--critical)' : 'var(--muted)'; }
function setReportStatus(msg, err){ ['reportStatus','inputStatus'].forEach(function(id){ var el = document.getElementById(id); if(el){ el.textContent = msg; el.style.color = err ? 'var(--critical)' : 'var(--muted)'; } }); }

function exportState(){
  const data = {
    version: 1,
    savedAt: new Date().toISOString(),
    site: SITE_URL,
    languages: langs.map(l => ({ label:l.label, dir:l.dir, ref:!!l.ref })),
    discovered: discovered,
    dirInclude: dirInclude,
    pageExclude: pageExclude,
    manualPages: pages.map(pg => ({ name:pg.name, path:pg.path, excluded:!!pg.excluded })),
    noTranslate: (document.getElementById('noTranslate') && document.getElementById('noTranslate').value) || '',
    excludeDirs: (document.getElementById('excludeDirs') && document.getElementById('excludeDirs').value) || '',
    linkResults: [...linkResults.entries()]
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type:'application/json' });
  const host = (()=>{ try { return new URL(SITE_URL).hostname; } catch(e){ return 'site'; } })();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `audit-${host}-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(a.href);
  setSaveStatus(`Saved ${discovered.length} page(s) and ${linkResults.size} link result(s).`);
}

function importState(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if(!data || typeof data !== 'object') throw new Error('bad file');
      discovered = Array.isArray(data.discovered) ? data.discovered : [];
      dirInclude = data.dirInclude && typeof data.dirInclude === 'object' ? data.dirInclude : {};
      pageExclude = data.pageExclude && typeof data.pageExclude === 'object' ? data.pageExclude : {};
      if(Array.isArray(data.manualPages)) pages = data.manualPages.map(pg => ({ id:p(), name:pg.name||'', path:pg.path||'', excluded:!!pg.excluded }));
      if(typeof data.noTranslate === 'string' && document.getElementById('noTranslate')) document.getElementById('noTranslate').value = data.noTranslate;
      if(typeof data.excludeDirs === 'string' && document.getElementById('excludeDirs')) document.getElementById('excludeDirs').value = data.excludeDirs;
      linkResults = new Map(Array.isArray(data.linkResults) ? data.linkResults : []);
      if(discovered.length){ document.getElementById('discoveredPanel').style.display = 'block'; renderDiscovered(); }
      renderPages();
      updateRunHint();
      const when = data.savedAt ? new Date(data.savedAt).toLocaleString() : 'unknown date';
      let note = `Loaded ${discovered.length} page(s) and ${linkResults.size} saved link result(s) from ${when}.`;
      if(data.site && data.site !== SITE_URL) note += ` (Saved site was ${data.site} — current is ${SITE_URL}.)`;
      setSaveStatus(note);
    } catch(e){
      setSaveStatus('Could not read that file — is it a saved audit JSON?', true);
    }
  };
  reader.readAsText(file);
}

/* ----------------------------- export results as a report ----------------------------- */
function downloadBlob(content, mime, filename){
  const blob = new Blob([content], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(a.href);
}
function reportHost(){ try { return new URL(SITE_URL).hostname; } catch(e){ return 'site'; } }

/* Power BI export: flattens the current audit into one-row-per-record CSV tables.
   Same shape the Worker endpoint serves. */
function csvCell(v){
  if(v === null || v === undefined) return '';
  var str = String(v);
  if(/[",\r\n]/.test(str)) return '"' + str.replace(/"/g, '""') + '"';
  return str;
}
function toCSV(columns, rows){
  var head = columns.map(function(c){ return csvCell(c.header); }).join(',');
  var body = rows.map(function(r){
    return columns.map(function(c){ return csvCell(c.get(r)); }).join(',');
  });
  return '\ufeff' + [head].concat(body).join('\r\n');   // BOM so Excel/Power BI read UTF-8
}
function powerBITables(){
  var D = currentDashData() || {};
  var host = (D.meta && D.meta.host) || reportHost();
  var triage = triageState || {};

  var findings = (D.findings || []).map(function(f){
    var t = triage[f.key]; var status = (t && t.status) ? t.status : 'open';
    return { host:host, page:f.page, path:f.path, section:f.dir, area:f.section,
             language:f.lang, issue:f.category, severity:f.severity, status:status,
             detail:f.detail || '' };
  });

  var s404 = [];
  var sm = sitemap404;
  if(sm && sm.urls){
    var newSet = {}; (sm.newUrls || []).forEach(function(u){ newSet[u] = 1; });
    Object.keys(sm.urls).forEach(function(u){
      s404.push({ host:host, url:u, first_seen:(sm.urls[u].firstSeen || ''),
                  is_new:(newSet[u] ? 'yes' : 'no'), last_checked:(sm.checked || '') });
    });
  }

  var cov = ((D.coverage && D.coverage.missing) || []).map(function(m){
    var disc = (D.coverage && D.coverage.discovered) || 0;
    return { host:host, language:m.lang, discovered:disc, missing:m.count, live:Math.max(0, disc - m.count) };
  });

  var stale = (D.contentDates || []).map(function(r){
    return { host:host, path:r.path, last_updated:(r.updated || ''), updated_by:(r.updatedBy || ''),
             created:(r.created || ''), created_by:(r.createdBy || '') };
  });

  return { findings:findings, sitemap_404:s404, coverage:cov, stale:stale };
}
function pbiSpecs(){
  var t = powerBITables();
  return [
    { name:'findings', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'page',get:function(r){return r.page;}},
      {header:'path',get:function(r){return r.path;}}, {header:'section',get:function(r){return r.section;}},
      {header:'area',get:function(r){return r.area;}}, {header:'language',get:function(r){return r.language;}},
      {header:'issue',get:function(r){return r.issue;}}, {header:'severity',get:function(r){return r.severity;}},
      {header:'status',get:function(r){return r.status;}}, {header:'detail',get:function(r){return r.detail;}}
    ], rows:t.findings },
    { name:'sitemap_404', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'url',get:function(r){return r.url;}},
      {header:'first_seen',get:function(r){return r.first_seen;}}, {header:'is_new',get:function(r){return r.is_new;}},
      {header:'last_checked',get:function(r){return r.last_checked;}}
    ], rows:t.sitemap_404 },
    { name:'coverage', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'language',get:function(r){return r.language;}},
      {header:'discovered',get:function(r){return r.discovered;}}, {header:'missing',get:function(r){return r.missing;}},
      {header:'live',get:function(r){return r.live;}}
    ], rows:t.coverage },
    { name:'stale', cols:[
      {header:'host',get:function(r){return r.host;}}, {header:'path',get:function(r){return r.path;}},
      {header:'last_updated',get:function(r){return r.last_updated;}}, {header:'updated_by',get:function(r){return r.updated_by;}},
      {header:'created',get:function(r){return r.created;}}, {header:'created_by',get:function(r){return r.created_by;}}
    ], rows:t.stale }
  ];
}
function downloadPBITable(name){
  var sp = pbiSpecs().filter(function(s){ return s.name === name; })[0];
  if(!sp) return;
  var stamp = new Date().toISOString().slice(0,10);
  downloadBlob(toCSV(sp.cols, sp.rows), 'text/csv;charset=utf-8', 'audit-' + sp.name + '-' + reportHost() + '-' + stamp + '.csv');
}
function exportPowerBICsv(){
  var specs = pbiSpecs();
  var host = reportHost();
  var stamp = new Date().toISOString().slice(0,10);
  var i = 0;
  (function next(){
    if(i >= specs.length){ setReportStatus('Exported ' + specs.length + ' CSV tables for Power BI.'); return; }
    var sp = specs[i++];
    downloadBlob(toCSV(sp.cols, sp.rows), 'text/csv;charset=utf-8', 'audit-' + sp.name + '-' + host + '-' + stamp + '.csv');
    setTimeout(next, 350);   // stagger so browsers don't block the batch
  })();
}

/* Cross-user store for triage marks and the latest run: KV endpoint when STATE_URL
   is set, else this browser's localStorage. */
let triageState = {};      // { findingKey: { status:'done'|'ignored', at } }
let sharedDash  = null;    // a published dashboard-data object (for viewers who didn't run locally)
let sitemap404  = null;    // { urls:{url:{firstSeen}}, checked, total, dead, newCount } — saved 404 list
let storeMode   = (STATE_URL && STATE_URL.trim()) ? 'remote' : 'local';
let _lastTriageSaveAt = 0;
function stateNs(){ return 'mlaudit:' + reportHost(); }
function stateEndpoint(key){
  const base = (STATE_URL || '').trim();
  try { const u = new URL(base); u.searchParams.set('key', stateNs() + ':' + key); return u.href; }
  catch(e){ return base + (base.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(stateNs() + ':' + key); }
}
async function stateGet(key){
  if(storeMode === 'local'){
    try { const v = localStorage.getItem(stateNs() + ':' + key); return v ? JSON.parse(v) : null; } catch(e){ return null; }
  }
  const res = await fetch(stateEndpoint(key), fetchOpts());
  if(res.status === 404) return null;
  if(!res.ok) throw new Error('HTTP ' + res.status);
  const txt = await res.text();
  return txt ? JSON.parse(txt) : null;
}
async function statePut(key, value){
  if(storeMode === 'local'){
    try { localStorage.setItem(stateNs() + ':' + key, JSON.stringify(value)); return true; } catch(e){ return false; }
  }
  const res = await fetch(stateEndpoint(key), fetchOpts({ method:'PUT', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(value) }));
  if(!res.ok) throw new Error('HTTP ' + res.status);
  return true;
}
let _triageSaveTimer = null;
function saveTriageSoon(){
  clearTimeout(_triageSaveTimer);
  _triageSaveTimer = setTimeout(function(){
    _lastTriageSaveAt = Date.now();
    statePut('triage', triageState).then(function(){ setStoreStatus(); }).catch(function(err){ setStoreStatus('save failed'); });
  }, 600);
}
function setTriage(key, status){
  if(!key) return;
  if(status === 'open'){ delete triageState[key]; }
  else { triageState[key] = { status: status, at: new Date().toISOString() }; }
  saveTriageSoon();
  setStoreStatus();
}
async function loadSharedState(force){
  // skip a remote re-pull right after we just saved (avoid clobbering our own change)
  if(!force && storeMode === 'remote' && Date.now() - _lastTriageSaveAt < 2000) return;
  function sig(){ return JSON.stringify(triageState) + '|' + (sharedDash && sharedDash.meta ? sharedDash.meta.generated : '') + '|' + (sitemap404 ? sitemap404.checked : ''); }
  var before = sig();
  try { const t = await stateGet('triage'); if(t && typeof t === 'object') triageState = t; } catch(e){}
  try { const s = await stateGet('sitemap404'); if(s && s.urls) sitemap404 = s; } catch(e){}
  if(!(auditState && auditState.results && auditState.results.length)){
    try { const r = await stateGet('run'); if(r && r.data) sharedDash = r.data; } catch(e){}
  }
  setStoreStatus();
  renderNotifBell();
  if(sig() !== before){            // only rebuild the iframe when something actually changed
    markDashStale();
    refreshDashIfVisible();
  }
}
async function publishRun(){
  if(!(auditState && auditState.results && auditState.results.length)){ setReportStatus('Run an audit first.', true); return false; }
  const payload = { type:'mlaudit-run', at:new Date().toISOString(), host:reportHost(), data: buildDashboardData() };
  try {
    await statePut('run', payload);
    setReportStatus(storeMode === 'remote'
      ? 'Run published to the shared store — everyone now sees this audit.'
      : 'Run saved to this browser. Set STATE_URL (see audit-state-worker.js) to share it across users.');
    return true;
  } catch(e){ setReportStatus('Could not publish the run: ' + e.message, true); return false; }
}
// ---- sitemap 404 monitor (uses the saved sitemap list; does NOT re-fetch the sitemap) ----
async function check404(url){
  try {
    const res = await fetch(proxifyCheck(url), fetchOpts());
    const ct = res.headers.get('content-type') || '';
    if(ct.includes('application/json')){ const d = await res.json(); return { url, status: d.status || 0 }; }
    return { url, status: res.status };
  } catch(e){ return { url, status: 0 }; }
}
async function scanSitemap404s(onProgress){
  // load the saved sitemap URL list (written only on manual discovery)
  let urls = [];
  try { const sm = await stateGet('sitemap'); if(sm && Array.isArray(sm.urls)) urls = sm.urls; } catch(e){}
  if(!urls.length && discovered && discovered.length){
    var baseU = SITE_URL.replace(/\/+$/,'');
    urls = discovered.map(function(d){ return d.path ? (baseU + '/' + d.path.replace(/^\/+/,'')) : baseU; });
  }
  if(!urls.length) return { error:'no-sitemap' };
  // drop English-only sections (e.g. newsroom) so they aren't 404-checked
  var exclDirs = getExcludeDirs();
  try { statePut('excludeDirs', { dirs: exclDirs, updated: new Date().toISOString() }).catch(function(){}); } catch(e){}
  if(exclDirs.length){ urls = urls.filter(function(u){ return !pathIsExcluded(urlToPath(u), exclDirs); }); }
  if(!urls.length) return { error:'no-sitemap' };
  let done = 0;
  const results = await pool(urls, async function(u){ const r = await check404(u); done++; if(onProgress) onProgress(done, urls.length); return r; }, 6);
  const dead = results.filter(function(r){ return r.status === 404; }).map(function(r){ return r.url; });
  // merge with the saved list, preserving firstSeen for ones we already knew
  let prev = {};
  try { const k = await stateGet('sitemap404'); if(k && k.urls) prev = k.urls; } catch(e){}
  const now = new Date().toISOString();
  const merged = {}; const newOnes = [];
  dead.forEach(function(u){ if(prev[u]){ merged[u] = prev[u]; } else { merged[u] = { firstSeen: now }; newOnes.push(u); } });
  const rec = { urls: merged, checked: now, total: urls.length, dead: dead.length, newCount: newOnes.length, newUrls: newOnes };
  sitemap404 = rec;
  try { await statePut('sitemap404', rec); } catch(e){}
  markDashStale(); refreshDashIfVisible(); renderNotifBell();
  return rec;
}

function setStoreStatus(extra){
  const el = document.getElementById('storeStatus'); if(!el) return;
  const done = vals.filter(function(t){ return t && t.status === 'done'; }).length;
  const ign  = vals.filter(function(t){ return t && t.status === 'ignored'; }).length;
  const mode = storeMode === 'remote' ? 'Shared store · team-wide' : 'Local only · this browser';
  el.textContent = mode + ' · ' + done + ' done · ' + ign + ' ignored' + (extra ? (' · ' + extra) : '');
}
function filterSharedDash(src){
  // Published runs are pre-computed; still drop pages later marked "Skip" and
  // recompute derived fields from what's left.
  const EXCL = excludedManualPathSet();
  if(!EXCL.size) return Object.assign({}, src);
  const d = JSON.parse(JSON.stringify(src));
  const keep = f => !EXCL.has(normPath(f.path));
  d.findings = (d.findings || []).filter(keep);
  if(Array.isArray(d.pages)) d.pages = d.pages.filter(p => !EXCL.has(normPath(p.path)));
  if(Array.isArray(d.missingTranslations)) d.missingTranslations = d.missingTranslations.filter(m => !EXCL.has(normPath(m.path)));
  // recompute summary + rollups from the filtered findings
  let c=0,w=0,i=0,b=0;
  d.findings.forEach(f => { if(f.category === 'broken link'){ b++; return; } if(f.severity==='critical')c++; else if(f.severity==='warning')w++; else i++; });
  d.summary = { critical:c, warning:w, info:i, broken:b, pages:(d.pages? d.pages.length : d.summary.pages) };
  const cb = (arr, prop) => { const o={}; arr.forEach(x=>{ const k=x[prop]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; };
  d.rollups = { byLang:cb(d.findings,'lang'), byCategory:cb(d.findings,'category'), byDir:cb(d.findings,'dir'), bySeverity:cb(d.findings,'severity') };
  if(d.coverage) d.coverage.audited = d.pages ? d.pages.length : d.coverage.audited;
  return d;
}
function currentDashData(){
  let d = null;
  if(auditState && auditState.results && auditState.results.length){ d = buildDashboardData(); }
  else if(sharedDash){ d = filterSharedDash(sharedDash); }
  if(d){ d.triage = triageState; d.storeMode = storeMode; d.canRun = (userRole === 'admin'); d.hasLocalRun = !!(auditState && auditState.results && auditState.results.length); d.sitemap404 = sitemap404; }
  return d;
}

/* ---- unified findings model (one normalized row per issue, with a stable key) ---- */
function findingSubject(f){
  if(f.section === 'Links') return f.detail;          // the URL identifies the link
  if(f.category === 'placeholder text') return f.detail;
  return '';                                           // otherwise the issue is category-level
}
function keyFor(f){
  return [f.path||'', f.lang||'', f.section||'', f.category||'', findingSubject(f)].join('||').toLowerCase();
}
/* Content fingerprints: a normalized hash of a page's visible text, so we can tell
   "English changed since the translation was approved" from ordinary QA drift. */
function cyrb53(str, seed){
  seed = seed || 0;
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for(let i = 0, ch; i < str.length; i++){
    ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
function contentFingerprint(data){
  if(!data) return null;
  // Title + meta + ordered content segments. Numbers/dates are intentionally KEPT
  // (a changed % or year is a meaningful English change we want to catch).
  const parts = [data.title || '', data.metaDesc || ''].concat(data.segments || []);
  let s = parts.join('\u0001');
  try { s = s.normalize('NFC'); } catch(e){}
  s = s.replace(/\s+/g, ' ').trim();
  return cyrb53(s);
}
function currentFingerprints(){
  const en = {}, tr = {};
  (auditState.results || []).forEach(r => {
    const pk = r.page.path || '';
    if(r.enFp != null) en[pk] = r.enFp;
    (r.languages || []).forEach(b => { if(b.trFp != null) tr[pk + '||' + b.lang.label] = b.trFp; });
  });
  return { en, tr };
}
function normPath(p){
  var s = String(p == null ? '' : p).trim();
  if(s === '(home)') return '';
  return s.replace(/^\/+|\/+$/g, '');
}
function excludedManualPathSet(){
  const s = new Set();
  pages.forEach(pg => { if(pg && pg.excluded) s.add(normPath(pg.path)); });
  return s;
}
function flattenFindings(){
  const out = [];
  const EXCL = excludedManualPathSet();
  (auditState.results||[]).forEach(r => {
    const path = r.page.path || '';
    if(EXCL.has(normPath(path))) return; // skipped in Audit Settings — treat as removed from current data
    const page = r.page.name;
    const dir = (dirOf(path) || '(top level)');
    const base = (lang, section, cat, sev, detail, suggestion, snippet, items, evidenceLabel) =>
      out.push({ page, path, dir, lang, section, category: cat, severity: sev, detail: detail||'', suggestion: suggestion||'', snippet: snippet||'', items: items||null, evidenceLabel: evidenceLabel||'' });
    const fromIssue = (lang, section, is) => {
      let items = is.items || null, label = is.evidenceLabel || '';
      if(!items && (is.reference || is.translation)){
        items = [];
        if(is.reference) items.push('Expected (source): ' + is.reference);
        if(is.translation) items.push('On the page: ' + is.translation);
        label = 'Compared text';
      }
      base(lang, section, is.category||section.toLowerCase(), is.severity||'info', is.explanation||'', is.suggestion||'', is.snippet||'', items, label);
    };

    if(r.refError) base('English (reference)','Fetch','load error','critical', r.refError);
    if(r.refTech){
      r.refTech.code.forEach(c => base('English (reference)','Code','code', c.sev, c.text, '', c.snippet, c.items, c.evidenceLabel));
      r.refTech.links.forEach(l => base('English (reference)','Links','broken link','critical', l.url, '', l.snippet));
    }
    (r.languages||[]).forEach(b => {
      const lang = b.lang.label;
      if(b.error){ base(lang,'Fetch','load error','critical', b.error); return; }
      if(b.drift) (b.drift.issues||[]).forEach(is => fromIssue(lang,'Drift', is));
      if(b.ai) (b.ai.issues||[]).forEach(is => fromIssue(lang,'Translation (Claude)', is));
      (b.parity||[]).forEach(is => fromIssue(lang,'Sections & parity', is));
      (b.content||[]).forEach(is => fromIssue(lang,'Content & SEO', is));
      if(b.tech){
        b.tech.code.forEach(c => base(lang,'Code','code', c.sev, c.text, '', c.snippet, c.items, c.evidenceLabel));
        b.tech.links.forEach(l => base(lang,'Links','broken link','critical', l.url, '', l.snippet));
      }
      // Source sync: did English change after this translation was approved?
      if(baseline && baseline.fp && baseline.fp.en){
        const baseEn = baseline.fp.en[path];
        const curEn = r.enFp;
        if(baseEn != null && curEn != null && curEn !== baseEn){
          const baseTr = (baseline.fp.tr || {})[path + '||' + lang];
          const curTr = b.trFp;
          const approvedOn = baseline.approvedAt ? (' on ' + new Date(baseline.approvedAt).toLocaleDateString()) : '';
          if(baseTr != null && curTr != null && curTr === baseTr){
            base(lang,'Source sync','source changed, translation stale','warning',
              'English changed after this translation was approved' + approvedOn + ', but the ' + lang + ' page has not been updated since.',
              'Re-translate this page to match the updated English source.');
          } else if(baseTr != null && curTr != null && curTr !== baseTr){
            base(lang,'Source sync','source & translation both changed','info',
              'Both the English source and the ' + lang + ' translation changed since the approved baseline' + approvedOn + '. Confirm the translation reflects the new English.',
              'Review to confirm the translation is in sync with the new English.');
          }
        }
      }
    });
  });
  out.forEach(f => f.key = keyFor(f));
  return out;
}
function countBy(arr, prop){ const o = {}; arr.forEach(x => { const k = x[prop]||'—'; o[k] = (o[k]||0)+1; }); return o; }

/* ---- snapshot save + baseline load for trend tracking ---- */
let baseline = null;
function buildSnapshotObj(){
  const f = flattenFindings();
  return {
    type:'audit-snapshot', version:1, site: reportHost(),
    date: new Date().toISOString(),
    counts: { critical:auditState.crit, warning:auditState.warn, info:auditState.info, broken:auditState.broken, pages:auditState.pages },
    total: f.length,
    keys: f.map(x => x.key),
    byCategory: countBy(f, 'category'),
    byLang: countBy(f, 'lang'),
    fp: currentFingerprints()
  };
}
function exportSnapshot(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  downloadBlob(JSON.stringify(buildSnapshotObj()), 'application/json', `audit-snapshot-${reportHost()}-${new Date().toISOString().slice(0,10)}.json`);
  setReportStatus('Snapshot saved. Load it as the baseline before your next audit to track what changed.');
}
function approveBaseline(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  const obj = buildSnapshotObj();
  obj.approved = true;
  obj.approvedAt = obj.date;
  const fpEn = Object.keys(obj.fp.en || {}).length;
  downloadBlob(JSON.stringify(obj), 'application/json', `audit-baseline-${reportHost()}-${new Date().toISOString().slice(0,10)}.json`);
  setReportStatus(`Approved baseline saved (${fpEn} page fingerprint(s)). Load it before your next audit to flag pages where English changed after approval.`);
}
function loadBaseline(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const j = JSON.parse(e.target.result);
      if(j.type !== 'audit-snapshot') throw new Error('bad type');
      baseline = j;
      markDashStale();
      refreshDashIfVisible();
      const fpN = (j.fp && j.fp.en) ? Object.keys(j.fp.en).length : 0;
      const appr = j.approved ? `Approved baseline from ${new Date(j.approvedAt || j.date).toLocaleDateString()}` : `Baseline from ${new Date(j.date).toLocaleDateString()}`;
      setReportStatus(`${appr} loaded — ${j.keys.length} prior finding(s)` + (fpN ? `, ${fpN} page fingerprint(s) for source-change detection` : '') + '. The dashboards will show what changed since then.');
    } catch(err){ setReportStatus('That isn’t a valid audit snapshot file.', true); }
  };
  reader.readAsText(file);
}
function trendVsBaseline(currentKeys){
  if(!baseline) return { hasBaseline:false };
  const cur = new Set(currentKeys), base = new Set(baseline.keys);
  let resolved = 0, persisting = 0, added = 0;
  base.forEach(k => { if(cur.has(k)) persisting++; else resolved++; });
  cur.forEach(k => { if(!base.has(k)) added++; });
  return { hasBaseline:true, date: baseline.date, resolved, persisting, added,
           wasTotal: baseline.total, nowTotal: currentKeys.length,
           wasCounts: baseline.counts };
}

/* ---- Sitecore content dates (from the "Items last updated" export) ---- */
let contentDates = null; // array of { name, path, updated, updatedBy, created, createdBy, isComponent }
function parseScDate(s){
  if(!s) return '';
  const d = new Date(s);                 // handles "6/1/2026 10:43:28 PM"
  return isNaN(d.getTime()) ? '' : d.toISOString();
}
function scRelPath(fullPath){
  let p = (fullPath||'').toLowerCase().replace(/\\/g,'/');
  if(p.startsWith(SITECORE_ROOT)) p = p.slice(SITECORE_ROOT.length);
  return p.replace(/^\/+|\/+$/g,'');
}
function loadContentDates(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const rows = JSON.parse(e.target.result);
      if(!Array.isArray(rows) || !rows.length || !('Updated' in rows[0]) || !('Path' in rows[0])) throw new Error('shape');
      contentDates = rows.map(r => {
        const rel = scRelPath(r.Path);
        return {
          name: r.Name || '',
          path: rel || '(home)',
          updated: parseScDate(r.Updated),
          updatedBy: (r['Updated by']||'').replace(/^sitecore\\/i,''),
          created: parseScDate(r.Created),
          createdBy: (r['Created by']||'').replace(/^sitecore\\/i,''),
          isComponent: /(^|\/)(page datasources|datasources)(\/|$)/.test(rel)
        };
      });
      const pages = contentDates.filter(r => !r.isComponent).length;
      markDashStale();
      refreshDashIfVisible();
      setReportStatus(`Loaded ${contentDates.length} Sitecore item(s) — ${pages} page(s) with real publish dates. They’ll drive the stale-content view in the dashboard.`);
    } catch(err){
      setReportStatus('That isn’t a valid "Items last updated" JSON export.', true);
    }
  };
  reader.readAsText(file);
}

/* ---- two-view dashboard (Authors + Leaders) ---- */
function buildDashboardData(){
  const findings = flattenFindings();
  const EXCL = excludedManualPathSet();
  const activeResults = (auditState.results||[]).filter(r => !EXCL.has(normPath(r.page.path)));
  const missing = {};
  activeResults.forEach(r => (r.languages||[]).forEach(b => { if(b.error) missing[b.lang.label] = (missing[b.lang.label]||0)+1; }));
  // Foreign-language pages that 404'd during the audit (missing translations). Derived
  // here, not by the sitemap monitor, so the 404 box can show them.
  const missingTranslations = [];
  activeResults.forEach(r => (r.languages||[]).forEach(b => {
    if(b.error) missingTranslations.push({
      page: r.page.name, path: r.page.path || '', lang: b.lang.label,
      url: b.url || '', error: b.error
    });
  }));
  const pages = activeResults.map(r => ({
    path: r.page.path || '(home)', name: r.page.name, lastmod: r.page.lastmod || ''
  }));
  // Recount from the filtered findings (not the live-run counters) so "Skip" takes
  // effect immediately without re-running.
  let sCrit=0, sWarn=0, sInfo=0, sBroken=0;
  findings.forEach(f => {
    if(f.category === 'broken link'){ sBroken++; return; }
    if(f.severity === 'critical') sCrit++; else if(f.severity === 'warning') sWarn++; else sInfo++;
  });
  return {
    meta: {
      host: reportHost(),
      generated: new Date().toLocaleString(),
      langs: langs.filter(l=>!l.ref).map(l=>l.label),
      translationCheck: (document.getElementById('transToggle') && document.getElementById('transToggle').checked)
        ? ((document.getElementById('engine')||{}).value || 'on') : 'off'
    },
    now: Date.now(),
    summary: { critical:sCrit, warning:sWarn, info:sInfo, broken:sBroken, pages:activeResults.length },
    findings,
    rollups: {
      byLang: countBy(findings, 'lang'),
      byCategory: countBy(findings, 'category'),
      byDir: countBy(findings, 'dir'),
      bySeverity: countBy(findings, 'severity')
    },
    coverage: {
      discovered: (discovered && discovered.length) || 0,
      audited: activeResults.length,
      missing: Object.keys(missing).map(k => ({ lang:k, count:missing[k] }))
    },
    pages,
    missingTranslations,
    contentDates: (contentDates ? contentDates.filter(r => !r.isComponent) : null),
    sync: {
      hasBaseline: !!(baseline && baseline.fp && baseline.fp.en),
      approvedAt: (baseline && baseline.approvedAt) || null,
      stale: findings.filter(f => f.category === 'source changed, translation stale').length,
      bothChanged: findings.filter(f => f.category === 'source & translation both changed').length
    },
    trend: trendVsBaseline(findings.map(f => f.key))
  };
}
/* on-page view switching between detailed results and the embedded dashboard */
let dashFrameStale = true;
function markDashStale(){ dashFrameStale = true; }
function ensureDashFrame(targetTab){
  const frame = document.getElementById('dashFrame');
  if(dashFrameStale){
    frame.onload = function(){
      try {
        frame.contentWindow.postMessage('hidetabs', '*');
        frame.contentWindow.postMessage('tab:' + targetTab, '*');
      } catch(e){}
    };
    window.__DASH_PAYLOAD__ = currentDashData() || buildDashboardData();
    frame.srcdoc = buildDashboardHtml();
    dashFrameStale = false;
  } else {
    try { frame.contentWindow.postMessage('tab:' + targetTab, '*'); } catch(e){}
  }
}
let currentDashTab = 'authors';
function dashHasData(){ return !!((auditState && auditState.results && auditState.results.length) || sharedDash); }
let userRole = null, loginRole = 'admin';
function pickRole(r){
  loginRole = r;
  document.querySelectorAll('#roleToggle .role-opt').forEach(function(b){ b.classList.toggle('active', b.dataset.role === r); });
}
function showLoginError(msg){ var e=document.getElementById('loginError'); if(e){ e.textContent=msg; e.style.display = msg ? 'block' : 'none'; } }
async function validatePassphrase(){
  // Best-effort: a clear 403 means wrong passphrase. Anything else, let them through
  // (downstream requests still enforce the key on every call).
  if(STATE_URL && STATE_URL.trim()){
    try { await stateGet('triage'); return true; }
    catch(e){ return false; }
  }
  try {
    var r = await fetchPage(SITE_URL);
    if(r && (r.status === 403 || /\b403\b|forbidden|passphrase|unauthor/i.test(r.error || ''))) return false;
    return true;
  } catch(e){ return true; }
}
async function submitLogin(){
  var btn = document.getElementById('loginBtn');
  var pass = (document.getElementById('pass').value || '').trim();
  showLoginError('');
  if(!pass){ showLoginError('Enter the access passphrase.'); return; }
  btn.disabled = true; btn.textContent = 'Checking…';
  var ok = await validatePassphrase();
  btn.disabled = false; btn.textContent = 'Sign in';
  if(!ok){ showLoginError('That passphrase was rejected. Check it and try again.'); return; }
  enterApp(loginRole);
}
function buildTabsForRole(role){
  var nav = document.getElementById('pageTabs');
  if(role === 'admin'){
    nav.style.display = '';
    nav.innerHTML =
        '<button class="ptab" data-page="leaders" data-click="showPage(\'leaders\')">Admin</button>'
      + '<button class="ptab" data-page="authors" data-click="showPage(\'authors\')">Authors</button>'
      + '<button class="ptab" data-page="generate" data-click="showPage(\'generate\')">Audit Settings</button>'
      + '<button class="pbi-btn" data-click="showPage(\'pbi\')" title="Power BI import instructions" aria-label="Power BI import instructions">'
      +   '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h11l5 5v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"></path><path d="M14 4v6h6"></path><path d="M8 13h8M8 17h5"></path></svg>'
      +   '<span>Power BI Import Instructions</span></button>';
  } else {
    nav.style.display = 'none';
  }
}
function enterApp(role){
  try {
    const k = ((document.getElementById('pass')||{}).value || '').trim();
    if(k && typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.set({ auditKey: k });
  } catch(e){}
  userRole = role;
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('appShell').style.display = 'block';
  buildTabsForRole(role);
  try { sessionStorage.setItem('mlaudit-session', JSON.stringify({ role: role, pass: (document.getElementById('pass').value || '') })); } catch(e){}
  loadSharedState(true);
  loadManualPages();
  showPage(role === 'admin' ? 'leaders' : 'authors');
}
function openSettingsModal(){
  var m=document.getElementById('settingsModal'); if(m) m.style.display='flex';
  var cr = document.getElementById('cfgRole'); if(cr) cr.textContent = userRole === 'admin' ? 'Admin' : 'Author';
  document.querySelectorAll('#settingsRoleToggle .role-opt').forEach(function(b){ b.classList.toggle('active', b.dataset.role === userRole); });
}
function closeSettingsModal(){ var m=document.getElementById('settingsModal'); if(m) m.style.display='none'; }
function openPowerBIModal(){ showPage('pbi'); }
function copyPBIUrl(table, btn){
  var url = 'https://audit-state.bcbs-of-az.workers.dev/?export=' + table + '&format=csv&token=powerbitoken';
  function flash(){
    var prev = btn.getAttribute('data-label') || btn.textContent;
    btn.setAttribute('data-label', prev);
    btn.textContent = 'Copied \u2713'; btn.classList.add('copied');
    setTimeout(function(){ btn.textContent = prev; btn.classList.remove('copied'); }, 1200);
  }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(url).then(flash, function(){ pbiFallbackCopy(url); flash(); });
  } else { pbiFallbackCopy(url); flash(); }
}
function pbiFallbackCopy(text){
  try {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.focus(); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta);
  } catch(e){}
}
function drawPbiConnectors(){
  var flow = document.getElementById('pbiFlow'), svg = document.getElementById('pbiConnectors');
  if(!flow || !svg) return;
  var a = document.getElementById('pbiOptA'), bnode = document.getElementById('pbiOptB'), c = document.getElementById('pbiConfig');
  if(!a || !bnode || !c) return;
  if(window.innerWidth <= 900){ svg.innerHTML = ''; return; }
  var fr = flow.getBoundingClientRect();
  if(!fr.width) return;
  svg.setAttribute('width', fr.width); svg.setAttribute('height', fr.height);
  svg.setAttribute('viewBox', '0 0 ' + fr.width + ' ' + fr.height);
  var ra = a.getBoundingClientRect(), rb = bnode.getBoundingClientRect(), rc = c.getBoundingClientRect();
  var ax = ra.right - fr.left, ay = ra.top + ra.height/2 - fr.top;
  var bx = rb.right - fr.left, by = rb.top + rb.height/2 - fr.top;
  var tx = rc.left - fr.left, tcy = rc.top + rc.height/2 - fr.top;
  function seg(sx, sy, ex, ey){ var dx = Math.max(48, (ex - sx) * 0.55); return 'M ' + sx + ' ' + sy + ' C ' + (sx+dx) + ' ' + sy + ' ' + (ex-dx) + ' ' + ey + ' ' + ex + ' ' + ey; }
  var S = '#8a8a8a';
  svg.innerHTML =
    '<defs><marker id="pbiArrow" markerWidth="9" markerHeight="9" refX="6.5" refY="4" orient="auto" markerUnits="userSpaceOnUse">'
    + '<path d="M1,1 L6.5,4 L1,7" fill="none" stroke="' + S + '" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>'
    + '<path d="' + seg(ax, ay, tx, tcy - 14) + '" fill="none" stroke="' + S + '" stroke-width="1.6" marker-end="url(#pbiArrow)"/>'
    + '<path d="' + seg(bx, by, tx, tcy + 14) + '" fill="none" stroke="' + S + '" stroke-width="1.6" marker-end="url(#pbiArrow)"/>';
}
var _pbiResizeT;
window.addEventListener('resize', function(){
  clearTimeout(_pbiResizeT);
  _pbiResizeT = setTimeout(function(){
    var el = document.getElementById('page-pbi');
    if(el && el.style.display !== 'none') drawPbiConnectors();
  }, 120);
});
function closePowerBIModal(){ showPage('leaders'); }
function switchRole(role){
  if(role === userRole) return;
  userRole = role;
  buildTabsForRole(role);
  try {
    var s = JSON.parse(sessionStorage.getItem('mlaudit-session') || 'null') || {};
    s.role = role;
    sessionStorage.setItem('mlaudit-session', JSON.stringify(s));
  } catch(e){}
  closeSettingsModal();
  showPage(role === 'admin' ? 'leaders' : 'authors');
  renderNotifBell();
}
function logout(){
  try { if(typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.remove('auditKey'); } catch(e){}
  try { sessionStorage.removeItem('mlaudit-session'); } catch(e){}
  userRole = null;
  closeSettingsModal();
  var np = document.getElementById('notifPanel'); if(np) np.style.display = 'none';
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  var passEl = document.getElementById('pass');
  if(passEl){ passEl.value = ''; passEl.classList.remove('input-error'); }
  showLoginError('');
  pickRole('admin');
}

// ---- in-app notifications (new 404s) — read state is per browser ----
function notifSeenKey(){ return 'mlaudit-notif-seen:' + reportHost(); }
function getNotifSeenAt(){ try { return localStorage.getItem(notifSeenKey()) || ''; } catch(e){ return ''; } }
function setNotifSeenAt(v){ try { localStorage.setItem(notifSeenKey(), v); } catch(e){} }
function unreadNotifs(){
  if(!sitemap404 || !sitemap404.urls) return [];
  var seen = getNotifSeenAt(), out = [];
  Object.keys(sitemap404.urls).forEach(function(u){
    var fs = sitemap404.urls[u].firstSeen || '';
    if(!seen || fs > seen) out.push({ url:u, firstSeen:fs });
  });
  out.sort(function(a,b){ return (b.firstSeen||'').localeCompare(a.firstSeen||''); });
  return out;
}
function renderNotifBell(){
  var btn = document.getElementById('notifBtn'); if(!btn) return;
  if(userRole !== 'admin'){ btn.style.display='none'; var p=document.getElementById('notifPanel'); if(p) p.style.display='none'; return; }
  btn.style.display='inline-flex';
  var n = unreadNotifs().length, dot = document.getElementById('notifDot');
  if(dot){ if(n>0){ dot.style.display='block'; dot.textContent = n>99 ? '99+' : String(n); } else { dot.style.display='none'; } }
  var pan = document.getElementById('notifPanel');
  if(pan && pan.style.display === 'block') renderNotifPanel();
}
function renderNotifPanel(){
  var list = document.getElementById('notifList'); if(!list) return;
  var items = unreadNotifs();
  if(!items.length){ list.innerHTML = '<div class="notif-empty">No new 404s. You\u2019re all caught up.</div>'; return; }
  var cap = items.slice(0, 12);
  var html = cap.map(function(it){
    var when = it.firstSeen ? new Date(it.firstSeen).toLocaleString() : 'recently';
    return '<div class="notif-item"><span class="nt">NEW 404</span>'
      + '<span class="nu">' + escapeHtml(it.url) + '</span>'
      + '<span class="nd">detected ' + escapeHtml(when) + '</span></div>';
  }).join('');
  if(items.length > cap.length) html += '<div class="notif-empty">+' + (items.length - cap.length) + ' more</div>';
  list.innerHTML = html;
}
function toggleNotifPanel(e){
  if(e && e.stopPropagation) e.stopPropagation();
  var p = document.getElementById('notifPanel'); if(!p) return;
  if(p.style.display !== 'block'){ renderNotifPanel(); p.style.display='block'; }
  else { p.style.display='none'; }
}
function markNotifsRead(){ setNotifSeenAt(new Date().toISOString()); renderNotifBell(); renderNotifPanel(); }
function viewNotifsInDash(){
  var p=document.getElementById('notifPanel'); if(p) p.style.display='none';
  markNotifsRead();
  showPage('leaders');
}
document.addEventListener('click', function(e){
  var p=document.getElementById('notifPanel'); if(!p || p.style.display!=='block') return;
  var btn=document.getElementById('notifBtn');
  if(!p.contains(e.target) && !(btn && btn.contains(e.target))) p.style.display='none';
});

function showPage(p){
  document.querySelectorAll('#pageTabs .ptab').forEach(function(b){ b.classList.toggle('active', b.dataset.page === p); });
  var gen = (p === 'generate');
  var pbi = (p === 'pbi');
  document.getElementById('page-generate').style.display = gen ? 'block' : 'none';
  var pbiEl = document.getElementById('page-pbi'); if(pbiEl) pbiEl.style.display = pbi ? 'block' : 'none';
  document.getElementById('page-dash').style.display = (gen || pbi) ? 'none' : 'block';
  if(pbi){ requestAnimationFrame(drawPbiConnectors); setTimeout(drawPbiConnectors, 130); }
  if(!gen && !pbi){
    currentDashTab = (p === 'leaders') ? 'leaders' : 'authors';
    var has = dashHasData();
    document.getElementById('dashEmpty').style.display = has ? 'none' : 'block';
    document.getElementById('dashFrame').style.display = has ? 'block' : 'none';
    if(has) ensureDashFrame(currentDashTab);
    if(has) setStoreStatus();
    if(storeMode === 'remote') loadSharedState();
  }
  try { window.scrollTo({ top:0, behavior:'smooth' }); } catch(e){ window.scrollTo(0,0); }
}
function refreshDashIfVisible(){
  if(document.getElementById('page-dash').style.display !== 'none' && dashHasData()){
    document.getElementById('dashEmpty').style.display = 'none';
    document.getElementById('dashFrame').style.display = 'block';
    ensureDashFrame(currentDashTab);
  }
}
/* back-compat shim */
function showView(v){ showPage(v === 'leaders' ? 'leaders' : 'authors'); }
function buildDashboardHtml(){
  const data = currentDashData() || buildDashboardData();
  let json = JSON.stringify(data).replace(/<\/script>/gi, '<\\/script>');
  return '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
    + '<title>Audit dashboard — ' + escapeHtml(data.meta.host) + '</title>'
    + '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    + '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">'
    + '<style>' + dashboardCss() + '</style></head><body><div class="wrap" id="app"></div>'
    + (EXT_MODE
        ? '<script src="dashview.js"><\/script>'
        : '<script>window.__DASH_DATA__=' + json + ';(' + dashboardApp.toString() + ')();<\/script>')
    + '</body></html>';
}
function exportReport(){ exportDashboard(); } // back-compat
function exportDashboard(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  downloadBlob(buildDashboardHtml(), 'text/html', 'audit-dashboard-' + reportHost() + '-' + new Date().toISOString().slice(0,10) + '.html');
  setReportStatus('Dashboard saved' + (baseline ? ' (with trend vs the loaded baseline).' : '. Tip: load a baseline snapshot to add trend tracking.'));
}

/* ---- PDF report (light, print-friendly; differs by current dashboard) ---- */
function exportReportPDF(viewArg){
  if(!dashHasData()){ setReportStatus('Run an audit first.', true); return; }
  var view = (viewArg === 'leaders' || viewArg === 'authors') ? viewArg : ((currentDashTab === 'leaders') ? 'leaders' : 'authors');
  var html = buildReportHtml(view);
  var old = document.getElementById('reportPrintFrame'); if(old) old.remove();
  var f = document.createElement('iframe');
  f.id = 'reportPrintFrame';
  f.setAttribute('aria-hidden', 'true');
  f.style.cssText = 'position:fixed;left:-10000px;top:0;width:960px;height:1200px;border:0;';
  document.body.appendChild(f);
  f.srcdoc = html;
  setReportStatus((view === 'leaders' ? 'Admin' : 'Author') + ' report sent to the print dialog — choose “Save as PDF” as the destination.');
  setTimeout(function(){ var fr = document.getElementById('reportPrintFrame'); if(fr) fr.remove(); }, 60000);
}
function reportCss(){
  return [
    "*{box-sizing:border-box}",
    "body{margin:0;background:#fafafa;color:#1a1a1a;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;font-weight:400;line-height:1.55;font-size:13px;-webkit-print-color-adjust:exact;print-color-adjust:exact}",
    ".rep{max-width:960px;margin:0 auto;padding:2.5rem 2.2rem}",
    ".eyebrow{color:#b9770e;text-transform:uppercase;letter-spacing:.13em;font-size:.66rem;font-weight:600;margin:0 0 .4rem}",
    "h1{font-weight:300;font-size:2rem;margin:0 0 .3rem;letter-spacing:-.5px}",
    ".meta{color:#666;font-size:.82rem;margin:0}",
    ".repkind{color:#1a1a1a;font-weight:500;font-size:1rem;margin:.45rem 0 0}",
    "section.block{margin-top:1.9rem;break-inside:avoid;page-break-inside:avoid}",
    "h2.sect{font-size:.72rem;text-transform:uppercase;letter-spacing:.1em;color:#b9770e;font-weight:600;margin:0 0 .8rem;padding-bottom:.4rem;border-bottom:1px solid #e0e0e0}",
    ".kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:.8rem}",
    ".kpi{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:.9rem 1rem}",
    ".kpi .n{font-size:1.8rem;font-weight:300;line-height:1}",
    ".kpi .l{font-size:.62rem;text-transform:uppercase;letter-spacing:.06em;color:#666;margin-top:.35rem}",
    ".kpi.c .n{color:#c0392b}.kpi.w .n{color:#b9770e}",
    "table{width:100%;border-collapse:collapse;font-size:.8rem;background:#fff;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden}",
    "th{text-align:left;font-size:.62rem;text-transform:uppercase;letter-spacing:.05em;color:#888;font-weight:600;padding:.5rem .7rem;border-bottom:1px solid #e0e0e0;background:#f4f4f4}",
    "td{padding:.5rem .7rem;border-bottom:1px solid #eee;vertical-align:top}tr:last-child td{border-bottom:none}",
    "td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}",
    ".sevb{display:inline-flex;align-items:center;gap:.35rem;font-size:.66rem;text-transform:uppercase;letter-spacing:.03em;font-weight:600;white-space:nowrap}.sevb .dot{width:7px;height:7px;border-radius:50%}",
    ".sevb.c{color:#c0392b}.sevb.c .dot{background:#c0392b}.sevb.w{color:#b9770e}.sevb.w .dot{background:#b9770e}.sevb.i{color:#777}.sevb.i .dot{background:#aaa}",
    ".pgblock{margin-top:1.1rem;break-inside:avoid;page-break-inside:avoid}",
    ".pghead{display:flex;align-items:baseline;gap:.55rem;flex-wrap:wrap;margin-bottom:.45rem}",
    ".pgname{font-size:1rem;font-weight:500}.pgpath{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.72rem;color:#888}",
    ".pill{font-size:.62rem;padding:.1rem .45rem;border-radius:20px;border:1px solid #ddd;color:#666}",
    ".pill.c{color:#c0392b;border-color:#e2b3ae}.pill.w{color:#b9770e;border-color:#e3cd9c}.pill.i{color:#777}",
    ".sugg{color:#2e7d4f}.muted{color:#888}",
    ".trend{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;text-align:center;background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:1.1rem}",
    ".trend .d{font-size:1.7rem;font-weight:300}.trend .dl{font-size:.64rem;text-transform:uppercase;letter-spacing:.06em;color:#666;margin-top:.2rem}",
    ".foot{margin-top:2.5rem;padding-top:1rem;border-top:1px solid #e0e0e0;color:#999;font-size:.7rem}",
    "@media print{body{background:#fff}.rep{padding:1.2rem}}"
  ].join('');
}
function buildReportHtml(view){
  var D = currentDashData() || buildDashboardData();
  var TRI = D.triage || {};
  var allFindings = D.findings || [];
  var openF = allFindings.filter(function(f){ return !(TRI[f.key] && TRI[f.key].status); });
  var resolvedN = allFindings.length - openF.length;
  function _cb(arr, p){ var o={}; arr.forEach(function(x){ var k=x[p]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; }
  D = Object.assign({}, D, {
    findings: openF,
    rollups: { byLang:_cb(openF,'lang'), byCategory:_cb(openF,'category'), byDir:_cb(openF,'dir'), bySeverity:_cb(openF,'severity') },
    summary: {
      pages: D.summary.pages,
      critical: openF.filter(function(f){ return f.severity==='critical' && f.category!=='broken link'; }).length,
      warning: openF.filter(function(f){ return f.severity==='warning'; }).length,
      info: openF.filter(function(f){ return f.severity==='info'; }).length,
      broken: openF.filter(function(f){ return f.category==='broken link'; }).length
    }
  });
  var E = escapeHtml;
  var sevRank = { critical:0, warning:1, info:2 };
  function sevc(s){ return s==='critical'?'c':s==='warning'?'w':'i'; }
  function sevb(s){ return '<span class="sevb '+sevc(s)+'"><span class="dot"></span>'+E(s)+'</span>'; }
  function sect(title, inner){ return '<section class="block"><h2 class="sect">'+E(title)+'</h2>'+inner+'</section>'; }
  function fmtAge(days){ if(days==null) return ''; if(days<60) return days+'d'; var mo=Math.floor(days/30.44); if(mo<24) return mo+'mo'; return (days/365).toFixed(1)+'y'; }
  function pd(s){ if(!s) return null; var d=new Date(s); return isNaN(d)?null:d; }
  var cdByKey={};
  function normKey(p){ return (p||'').toLowerCase().replace(/^\/+|\/+$/g,'').replace(/\s+/g,'-'); }
  (D.contentDates||[]).forEach(function(r){ cdByKey[normKey(r.path)]=r; });
  function pageDate(path){ return cdByKey[normKey((path||'').replace(/^(es|zh)\//,''))]||null; }
  function rollTable(obj, label){
    var keys=Object.keys(obj||{}).sort(function(a,b){ return obj[b]-obj[a]; });
    if(!keys.length) return '<p class="muted">No findings.</p>';
    var rows=keys.map(function(k){ return '<tr><td>'+E(k)+'</td><td class="num">'+obj[k]+'</td></tr>'; }).join('');
    return '<table><thead><tr><th>'+E(label)+'</th><th class="num">Findings</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }

  var body='';
  if(view === 'leaders'){
    function kpi(n,l,cls){ return '<div class="kpi '+(cls||'')+'"><div class="n">'+n+'</div><div class="l">'+E(l)+'</div></div>'; }
    var kpis='<div class="kpis">'+kpi(D.summary.pages,'Pages')+kpi(D.summary.critical,'Critical','c')
      +kpi(D.summary.warning,'Warnings','w')+kpi(D.summary.broken,'Broken links',D.summary.broken?'c':'')
      +kpi(D.findings.length,'Total findings')+'</div>';
    var bs=D.rollups.bySeverity||{}, stot=(bs.critical||0)+(bs.warning||0)+(bs.info||0);
    var sevRows=['critical','warning','info'].map(function(k){ var n=bs[k]||0, p=stot?Math.round(n/stot*100):0;
      return '<tr><td>'+sevb(k)+'</td><td class="num">'+n+'</td><td class="num">'+p+'%</td></tr>'; }).join('');
    var sevTable='<table><thead><tr><th>Severity</th><th class="num">Count</th><th class="num">Share</th></tr></thead><tbody>'+sevRows+'</tbody></table>';
    var trendBlock='';
    var t=D.trend;
    if(t && t.hasBaseline){
      trendBlock=sect('Change since last audit',
        '<div class="trend"><div><div class="d" style="color:#2e7d4f">'+t.resolved+'</div><div class="dl">Resolved</div></div>'
        +'<div><div class="d" style="color:#c0392b">'+t.added+'</div><div class="dl">New</div></div>'
        +'<div><div class="d" style="color:#b9770e">'+t.persisting+'</div><div class="dl">Still open</div></div></div>'
        +'<p class="meta" style="text-align:center;margin-top:.8rem">Since '+E(new Date(t.date).toLocaleDateString())+': '+t.wasTotal+' \u2192 '+t.nowTotal+'</p>');
    }
    var cov=D.coverage;
    var covMissing=cov.missing.length
      ? '<table><thead><tr><th>Language</th><th class="num">Missing / errored</th></tr></thead><tbody>'+cov.missing.map(function(m){ return '<tr><td>'+E(m.lang)+'</td><td class="num">'+m.count+'</td></tr>'; }).join('')+'</tbody></table>'
      : '<p class="muted">Every audited page returned a version in all languages.</p>';
    var coverageBlock=sect('Translation coverage', '<p class="meta" style="margin-bottom:.7rem">'+cov.audited+' of '+cov.discovered+' discovered page(s) audited.</p>'+covMissing);
    var staleBlock='';
    if(D.contentDates && D.contentDates.length){
      var now=D.now||Date.now(), cutoff=now-12*30.44*86400000;
      var rows=D.contentDates.map(function(r){ return { path:r.path, by:r.updatedBy, d:pd(r.updated) }; }).filter(function(r){ return r.d; }).sort(function(a,b){ return a.d-b.d; });
      var staleN=rows.filter(function(r){ return r.d.getTime()<cutoff; }).length;
      var tb=rows.map(function(r){ var age=Math.floor((now-r.d.getTime())/86400000), stale=r.d.getTime()<cutoff;
        return '<tr><td>/'+E(r.path)+'</td><td>'+E(r.by||'\u2014')+'</td><td>'+E(r.d.toISOString().slice(0,10))+'</td><td class="num">'+fmtAge(age)+'</td><td>'+(stale?'<span class="sevb c"><span class="dot"></span>stale</span>':'<span class="muted">current</span>')+'</td></tr>'; }).join('');
      staleBlock=sect('Stale content', '<p class="meta" style="margin-bottom:.7rem">'+staleN+' of '+rows.length+' page(s) not updated in over 12 months.</p>'
        +'<table><thead><tr><th>Page</th><th>Updated by</th><th>Last updated</th><th class="num">Age</th><th>Status</th></tr></thead><tbody>'+tb+'</tbody></table>');
    }
    var syncBlock='';
    if(D.sync && D.sync.hasBaseline){
      var staleF=D.findings.filter(function(f){ return f.category==='source changed, translation stale'; });
      var apprOn=D.sync.approvedAt ? ' (approved '+E(new Date(D.sync.approvedAt).toLocaleDateString())+')' : '';
      if(staleF.length){
        var srows=staleF.slice().sort(function(a,b){ return a.page.localeCompare(b.page); }).map(function(f){
          return '<tr><td>'+E(f.page)+'<br><span class="pgpath" style="font-size:.68rem">/'+E(f.path)+'</span></td><td>'+E(f.lang)+'</td><td>'+E(f.detail)+'</td></tr>'; }).join('');
        syncBlock=sect('Stale because English changed'+apprOn,
          '<p class="meta" style="margin-bottom:.7rem">'+staleF.length+' translated page(s) where the English source changed after approval and the translation has not been updated.</p>'
          +'<table><thead><tr><th>Page</th><th>Locale</th><th>What changed</th></tr></thead><tbody>'+srows+'</tbody></table>');
      } else {
        syncBlock=sect('Source sync'+apprOn, '<p class="muted">No stale translations \u2014 every approved translation still matches its English source.</p>');
      }
    }
    body=sect('At a glance', kpis)
      + syncBlock
      + sect('Severity breakdown', sevTable)
      + trendBlock
      + sect('Findings by category', rollTable(D.rollups.byCategory,'Category'))
      + sect('Findings by language', rollTable(D.rollups.byLang,'Language'))
      + sect('Findings by section / directory', rollTable(D.rollups.byDir,'Section'))
      + coverageBlock
      + staleBlock;
  } else {
    if(!D.findings.length){
      body='<section class="block"><p class="muted">No findings — every audited page passed.</p></section>';
    } else {
      var groups={}; D.findings.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
      var keys=Object.keys(groups);
      function weight(list){ var w=0; list.forEach(function(f){ w += f.severity==='critical'?100:f.severity==='warning'?10:1; }); return w; }
      keys.sort(function(a,b){ return weight(groups[b])-weight(groups[a]); });
      var now=D.now||Date.now();
      var pagesHtml=keys.map(function(k){
        var items=groups[k].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity])||a.lang.localeCompare(b.lang); });
        var head=k.split('||'), name=head[0], path=head[1];
        var cc=items.filter(function(f){return f.severity==='critical';}).length;
        var wc=items.filter(function(f){return f.severity==='warning';}).length;
        var ic=items.filter(function(f){return f.severity==='info';}).length;
        var cd=pageDate(path), dateStr='';
        if(cd && cd.updated){ var d=pd(cd.updated); if(d){ var age=Math.floor((now-d.getTime())/86400000); dateStr='<span class="pill">updated '+E(d.toISOString().slice(0,10))+' \u00B7 '+fmtAge(age)+(cd.updatedBy?' \u00B7 '+E(cd.updatedBy):'')+'</span>'; } }
        var rows=items.map(function(f){ return '<tr><td>'+sevb(f.severity)+'</td><td>'+E(f.lang)+'</td><td>'+E(f.category)+'</td><td>'+E(f.detail)+(f.suggestion?'<br><span class="sugg">\u2192 '+E(f.suggestion)+'</span>':'')+'</td></tr>'; }).join('');
        return '<div class="pgblock"><div class="pghead"><span class="pgname">'+E(name)+'</span><span class="pgpath">/'+E(path)+'</span>'
          +(cc?'<span class="pill c">'+cc+' critical</span>':'')+(wc?'<span class="pill w">'+wc+' warning</span>':'')+(ic?'<span class="pill i">'+ic+' info</span>':'')+dateStr+'</div>'
          +'<table><thead><tr><th>Severity</th><th>Language</th><th>Category</th><th>Issue &amp; suggestion</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
      }).join('');
      body='<section class="block"><p class="meta">'+D.findings.length+' finding(s) across '+keys.length+' page(s), ordered by severity.</p></section>'+pagesHtml;
    }
  }

  var header='<p class="eyebrow">Localization QA Report</p><h1>'+E(D.meta.host)+'</h1>'
    + '<p class="meta">Generated '+E(D.meta.generated)+' \u00B7 '+E((D.meta.langs||[]).join(', '))+' \u00B7 translation check: '+E(D.meta.translationCheck)+'</p>'
    + '<p class="repkind">'+(view==='leaders'?'Admin summary':'Author work list')+(resolvedN?' \u00B7 <span style="font-weight:400;color:#888">open items only ('+resolvedN+' resolved hidden)</span>':'')+'</p>';
  var foot='<div class="foot">Multilingual Site Audit \u00B7 '+E(D.meta.host)+' \u00B7 '+(view==='leaders'?'Admin':'Author')+' report</div>';
  var printScript='<scr'+'ipt>(function(){function go(){try{var w=document.documentElement.scrollWidth,h=document.documentElement.scrollHeight;var st=document.createElement("style");st.textContent="@page{size:"+w+"px "+h+"px;margin:0}";document.head.appendChild(st);}catch(e){}try{window.focus();window.print();}catch(e){}}if(document.readyState==="complete")setTimeout(go,350);else window.addEventListener("load",function(){setTimeout(go,350);});})();</scr'+'ipt>';
  return '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>'
    + E(D.meta.host)+' \u2014 '+(view==='leaders'?'Admin':'Author')+' report</title><style>'+reportCss()+'</style></head><body><div class="rep">'
    + header+body+foot+'</div>'+printScript+'</body></html>';
}
function dashboardCss(){
  return [
    ':root{--bg:#1a1a1a;--card:#242424;--card-alt:#1e1e1e;--border:#2e2e2e;--text:#f0f0f0;--muted:#888;--muted2:#666;--accent:#FFBE5F;--crit:#d98a84;--warn:#d8a24a;--ok:#7dbf82}',
    '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;font-weight:300;line-height:1.6}',
    '.wrap{max-width:1440px;margin:0 auto;padding:2.5rem 1.5rem}',
    '.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:.13em;font-size:.7rem;font-weight:500;margin:0}',
    'h1{font-weight:300;font-size:2rem;margin:.2rem 0}.sub{color:var(--muted);font-size:.88rem;margin:.3rem 0 0}',
    '.tabs{display:flex;gap:.4rem;margin:2rem 0 1.5rem;border-bottom:1px solid var(--border)}',
    '.tab{background:none;border:none;color:var(--muted);padding:.7rem 1.1rem;cursor:pointer;font-size:.95rem;border-bottom:2px solid transparent;font-family:inherit}',
    '.tab.active{color:var(--accent);border-bottom-color:var(--accent)}',
    '.card{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:1.5rem;margin-bottom:1.5rem}',
    '.label{color:var(--accent);text-transform:uppercase;letter-spacing:.1em;font-size:.7rem;font-weight:500;margin:0 0 1rem}',
    '.grid{display:grid;gap:1rem}.stats{grid-template-columns:repeat(auto-fit,minmax(110px,1fr))}',
    '.stat{background:var(--card-alt);border:1px solid var(--border);border-radius:8px;padding:.9rem 1rem;cursor:pointer;transition:border-color .2s}',
    '.stat:hover{border-color:var(--accent)}.stat .n{font-size:1.9rem;font-weight:300;line-height:1}.stat .l{color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.07em;margin-top:.3rem}',
    '.crit{color:var(--crit)}.warn{color:var(--warn)}.ok{color:var(--ok)}.accent{color:var(--accent)}.muted{color:var(--muted)}',
    'table{width:100%;border-collapse:collapse;font-size:.86rem}th,td{text-align:left;padding:.5rem .6rem;border-bottom:1px solid var(--border)}',
    'th{color:var(--muted);font-weight:500;text-transform:uppercase;font-size:.68rem;letter-spacing:.06em}td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}',
    '.filters{display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:1.2rem;align-items:center}',
    'select,input{background:var(--card-alt);border:1px solid #333;color:var(--text);border-radius:6px;padding:.5rem .7rem;font-size:.85rem;font-family:inherit}',
    '.finding{border:1px solid var(--border);border-left:3px solid var(--muted2);border-radius:6px;margin:.5rem 0;background:var(--card-alt)}',
    '.finding.s-critical{border-left-color:var(--crit)}.finding.s-warning{border-left-color:var(--warn)}.finding.s-info{border-left-color:var(--muted2)}',
    '.finding .body{padding:.6rem .85rem}.cat{font-size:.68rem;text-transform:uppercase;letter-spacing:.06em;color:var(--accent)}',
    '.det{margin:.25rem 0 0;font-size:.9rem}.sugg{color:var(--ok);font-size:.82rem;margin-top:.35rem}.path-mini{color:var(--muted2);font-size:.72rem;margin-top:.35rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    '.finding details{margin:.1rem .85rem .7rem}.finding summary{cursor:pointer;color:var(--accent);font-size:.72rem;list-style:none}.finding summary::-webkit-details-marker{display:none}',
    'pre.src{font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.72rem;white-space:pre-wrap;word-break:break-word;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:.6rem;margin:.4rem 0 0}',
    '.trend{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;text-align:center}.delta{font-size:1.9rem;font-weight:300}',
    '.empty{color:var(--muted);font-size:.88rem}',
    '.ftable-wrap{overflow-x:auto;margin-top:.2rem}',
    'table.ft{width:100%;border-collapse:collapse;font-size:.83rem}',
    'table.ft th{text-align:left;color:var(--muted2);font-weight:500;text-transform:uppercase;font-size:.62rem;letter-spacing:.06em;padding:.35rem .55rem;border-bottom:1px solid var(--border);white-space:nowrap}',
    'table.ft td{padding:.5rem .55rem;border-bottom:1px solid var(--border);vertical-align:top}table.ft tbody tr.frow:last-of-type td{border-bottom:none}',
    'tr.frow{cursor:pointer;transition:background .12s}tr.frow:hover{background:#2a2a2a}tr.frow.open{background:#2a2a2a}',
    'table.ft th.sortable{cursor:pointer;user-select:none;white-space:nowrap}table.ft th.sortable:hover{color:var(--text)}',
    'table.ft th.sortable .sort-ind{margin-left:.3rem;font-size:.75em;opacity:.3}table.ft th.sortable .sort-ind::after{content:"\\2195"}',
    'table.ft th.sortable[data-dir] .sort-ind{opacity:1;color:var(--accent)}',
    'table.ft th.sortable[data-dir="asc"] .sort-ind::after{content:"\\2191"}table.ft th.sortable[data-dir="desc"] .sort-ind::after{content:"\\2193"}',
    '.sevb{display:inline-flex;align-items:center;gap:.4rem;font-size:.64rem;text-transform:uppercase;letter-spacing:.04em;font-weight:500;white-space:nowrap}.sevb .dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto}',
    '.sevb.c{color:var(--crit)}.sevb.c .dot{background:var(--crit)}.sevb.w{color:var(--warn)}.sevb.w .dot{background:var(--warn)}.sevb.i{color:var(--muted)}.sevb.i .dot{background:var(--muted2)}',
    '.ft .fc-pg{color:var(--text)}.ft .fc-path{display:block;color:var(--muted2);font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.68rem;margin-top:.1rem}',
    '.ft .fc-lang,.ft .fc-cat{color:var(--muted);white-space:nowrap}.ft .fc-issue{color:var(--text);display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:62ch}.drill-body .fc-issue{max-width:30ch}',
    '.ft .fc-exp{width:1.4rem;text-align:right;color:var(--muted2)}.fchev{display:inline-block;font-size:1rem;transition:transform .2s}tr.frow.open .fchev{transform:rotate(90deg)}',
    'tr.fdetail{display:none}tr.fdetail.show{display:table-row}tr.fdetail>td{padding:.1rem .55rem .7rem;background:#1b1b1b;border-bottom:1px solid var(--border)}',
    '.fd-inner{padding:.6rem .8rem;border-left:2px solid var(--accent);background:var(--card-alt);border-radius:0 6px 6px 0}',
    '.fd-sugg{color:var(--ok);font-size:.82rem;margin:0 0 .4rem}.fd-meta{color:var(--muted);font-size:.73rem;margin:0 0 .4rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    'details.drill{border-bottom:1px solid var(--border)}details.drill>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:.7rem;padding:.55rem 0;font-size:.88rem}details.drill>summary::-webkit-details-marker{display:none}',
    '.finding details.evidence{margin:.1rem .85rem .7rem}.finding details.evidence>summary{cursor:pointer;color:var(--accent);font-size:.72rem;list-style:none}.finding details.evidence>summary::-webkit-details-marker{display:none}',
    'ul.evlist{list-style:none;margin:.4rem 0 0;padding:0;border:1px solid var(--border);border-radius:6px;background:var(--bg);max-height:320px;overflow:auto}',
    'ul.evlist li{font-size:.78rem;padding:.35rem .6rem;border-bottom:1px solid var(--border);word-break:break-word;font-family:"SF Mono",Monaco,Consolas,monospace}ul.evlist li:last-child{border-bottom:none}',
    'ul.evlist li.evhead{font-family:Inter,sans-serif;color:var(--accent);text-transform:uppercase;letter-spacing:.05em;font-size:.66rem;background:var(--card-alt)}',
    'details.drill>summary:hover .drill-label{color:var(--accent)}.drill-label{min-width:170px}.drill-label .chev{color:var(--muted2);margin-right:.5rem;font-size:1rem;display:inline-block;width:1rem;transition:transform .2s}details.drill[open]>summary .chev{transform:rotate(90deg)}',
    '.bartrack{flex:1;height:9px;background:#33322f;border-radius:5px;overflow:hidden;max-width:none}.barfill{display:block;height:100%;background:linear-gradient(90deg,#ffce85,#f0a63a);border-radius:5px;min-width:3px}.drill-count{min-width:34px;text-align:right;font-variant-numeric:tabular-nums;color:var(--text);font-weight:400}',
    '.drill-body{padding:.3rem 0 .9rem}',
    'details.pagecard{border:1px solid var(--border);border-radius:8px;margin-bottom:.7rem;background:var(--card-alt)}details.pagecard>summary{list-style:none;cursor:pointer;padding:.8rem 1rem;display:flex;align-items:center;gap:.8rem;flex-wrap:wrap}details.pagecard>summary::-webkit-details-marker{display:none}',
    '.pc-name{font-weight:400;font-size:1rem;flex:1;min-width:160px}.pc-name .chev{color:var(--muted2);margin-right:.5rem;font-size:1rem;display:inline-block;transition:transform .2s}details.pagecard[open]>summary .pc-name .chev{transform:rotate(90deg)}',
    '.pc-path{color:var(--muted2);font-size:.72rem;font-family:"SF Mono",Monaco,Consolas,monospace;flex-basis:100%;margin-left:1.1rem}',
    '.pill{font-size:.7rem;padding:.12rem .5rem;border-radius:20px;border:1px solid var(--border)}.pill.c{color:var(--crit);border-color:var(--crit)}.pill.w{color:var(--warn);border-color:var(--warn)}.pill.i{color:var(--muted);border-color:var(--muted2)}.pill.date{color:var(--muted)}',
    '.pc-body{padding:0 1rem .8rem}',
    '.picker{border:1px solid var(--border);border-radius:8px;background:var(--card-alt);margin-bottom:1rem}',
    '.picker-head{cursor:pointer;padding:.85rem 1rem;display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;user-select:none}',
    '.picker-head .chev{color:var(--accent);font-size:1rem;display:inline-block;transition:transform .2s}.picker.open .picker-head .chev{transform:rotate(90deg)}',
    '.picker-head .pk-name{font-weight:400;font-size:1rem}.picker-head .pk-hint{color:var(--muted);font-size:.78rem;white-space:nowrap}',
    '.picker-list{display:none;border-top:1px solid var(--border);max-height:340px;overflow:auto}.picker.open .picker-list{display:block}',
    '.picker-opt{display:flex;align-items:center;gap:.7rem;flex-wrap:wrap;padding:.6rem 1rem;cursor:pointer;border-bottom:1px solid var(--border);transition:background .12s}.picker-opt:last-child{border-bottom:none}.picker-opt:hover{background:#2a2a2a}.picker-opt.sel{background:#2a2a2a}',
    '.picker-opt .po-name{flex:1;min-width:150px}.picker-opt .pc-path{flex-basis:100%;margin-left:0}',
    'details.stale{border:1px solid var(--border);border-radius:8px;margin-bottom:.5rem;background:var(--card-alt)}details.stale.is-stale{border-left:3px solid var(--crit)}details.stale>summary{list-style:none;cursor:pointer;padding:.65rem 1rem;display:grid;grid-template-columns:1fr auto auto auto;gap:1rem;align-items:center;font-size:.85rem}details.stale>summary::-webkit-details-marker{display:none}',
    '.st-path{font-family:"SF Mono",Monaco,Consolas,monospace;font-size:.78rem;overflow:hidden;text-overflow:ellipsis}.st-age{color:var(--muted);font-variant-numeric:tabular-nums;min-width:48px;text-align:right}.st-date{color:var(--muted);min-width:84px;text-align:right}',
    '.st-body{padding:.2rem 1rem .8rem;font-size:.82rem;color:var(--muted);display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:.5rem 1.5rem}.st-body .k{color:var(--muted2);text-transform:uppercase;font-size:.66rem;letter-spacing:.05em}.st-body .v{color:var(--text)}',
    '.headrow{display:grid;grid-template-columns:1fr auto auto auto;gap:1rem;padding:0 1rem .4rem;font-size:.66rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted2)}',
    '.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;margin-bottom:1.25rem}',
    '.kpi{appearance:none;text-align:left;background:var(--card);border:1px solid var(--border);border-left:3px solid var(--muted2);border-radius:10px;padding:1.1rem 1.2rem;cursor:pointer;font-family:inherit;display:flex;flex-direction:column;gap:.4rem;transition:border-color .2s,transform .2s,background .2s}',
    '.kpi:hover{transform:translateY(-2px);background:#2a2a2a}.kpi .kpi-n{font-size:2.3rem;font-weight:300;line-height:1;color:var(--text)}.kpi .kpi-l{color:var(--muted);font-size:.7rem;text-transform:uppercase;letter-spacing:.08em}',
    '.kpi.crit{border-left-color:var(--crit)}.kpi.crit:hover{border-color:var(--crit)}.kpi.crit .kpi-n{color:var(--crit)}',
    '.kpi.warn{border-left-color:var(--warn)}.kpi.warn:hover{border-color:var(--warn)}.kpi.warn .kpi-n{color:var(--warn)}',
    '.kpi.accent{border-left-color:var(--accent)}.kpi.accent:hover{border-color:var(--accent)}',
    '.dash-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;margin-bottom:1.25rem;align-items:start}.dash-grid .card{margin:0}',
    '.dash-split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;margin-bottom:1.25rem;align-items:start}.dash-split>.dash-col{display:flex;flex-direction:column;gap:1.25rem;min-width:0}.dash-split .card{margin:0}',
    '.dash-grid-eq{align-items:stretch}.dash-grid-eq>.card{display:flex;flex-direction:column}',
    '.s404-list{display:flex;flex-direction:column;gap:.5rem;max-height:320px;overflow:auto}',
    '.s404-row{display:flex;align-items:center;gap:.5rem;font-size:.82rem;border-bottom:1px solid var(--border);padding-bottom:.45rem}',
    '.s404-url{color:var(--text);text-decoration:none;word-break:break-all;flex:1 1 auto;min-width:0}.s404-url:hover{color:var(--accent);text-decoration:underline}',
    '.s404-seen{color:var(--muted2);font-size:.72rem;flex:0 0 auto;white-space:nowrap}',
    '.s404-new{flex:0 0 auto;background:var(--crit);color:#1a1a1a;font-weight:600;font-size:.62rem;letter-spacing:.04em;padding:.1rem .35rem;border-radius:4px}',
    '.card-404.has-dead{border-left:3px solid var(--crit)}',
    '.s404-group + .s404-group{margin-top:1.1rem;padding-top:1rem;border-top:1px solid var(--border)}',
    '.s404-grouphead{font-size:.75rem;font-weight:600;color:var(--text);margin:0 0 .5rem;letter-spacing:.01em}',
    '.card-404 .label{display:flex;align-items:center;gap:.5rem}',
    '.stale-summary{cursor:pointer;margin:0;list-style:none;user-select:none;display:flex;align-items:center;gap:.5rem}',
    '.stale-summary::-webkit-details-marker{display:none}',
    '.stale-summary .chev{margin-left:auto;color:var(--muted);font-size:1rem;transition:transform .2s ease}',
    '.stale-collapse[open] > .stale-summary{margin-bottom:1rem}',
    '.stale-collapse[open] .stale-summary .chev{transform:rotate(90deg)}',
    '.acc-summary{cursor:pointer;margin:0;list-style:none;user-select:none;display:flex;align-items:center;gap:.5rem}',
    '.acc-summary::-webkit-details-marker{display:none}',
    '.acc-summary .chev{margin-left:auto;color:var(--muted);font-size:1rem;transition:transform .2s ease}',
    '.acc-collapse[open] > .acc-summary{margin-bottom:1rem}',
    '.acc-collapse[open] .acc-summary .chev{transform:rotate(90deg)}',
    '.count-pill{display:inline-block;background:var(--crit);color:#1a1a1a;font-weight:700;font-size:.7rem;line-height:1;padding:.22rem .5rem;border-radius:10px}',
    '.card-404 .s404-list{max-height:300px}',
    '@media(min-width:760px){.card-404 .s404-list{display:grid;grid-template-columns:1fr 1fr;gap:.15rem 1.8rem}}',
    '.label{display:flex;align-items:center;gap:.5rem}.label::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--accent);display:inline-block;flex:0 0 auto}',
    '.sevmix{display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap}.donut{width:148px;height:148px;flex:0 0 auto}.donut-n{fill:var(--text);font-size:30px;font-weight:300}.donut-l{fill:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}',
    '.legend{display:flex;flex-direction:column;gap:.65rem;flex:1;min-width:130px}.legend-row{display:flex;align-items:center;gap:.6rem;font-size:.88rem}.swatch{width:11px;height:11px;border-radius:3px;flex:0 0 auto}.legend-row .ln{margin-left:auto;font-variant-numeric:tabular-nums;color:var(--text)}.legend-row .lt{color:var(--muted)}',
    '.covrow{display:flex;align-items:baseline;gap:.6rem;margin-bottom:.7rem}.covrow .big{font-size:1.8rem;font-weight:300;color:var(--accent);line-height:1}.barrow{display:flex;gap:.6rem;margin:.3rem 0;font-size:.85rem}',
    '@media(max-width:820px){.kpis{grid-template-columns:repeat(2,1fr)}.dash-grid{grid-template-columns:1fr}.dash-split{grid-template-columns:1fr}}',
    '.queue-stale{border-left:3px solid var(--warn);margin-bottom:1.25rem}.queue-stale .label{color:var(--warn)}.queue-stale .label::before{background:var(--warn)}',
    '.queue-ok{margin-bottom:1.25rem}',
    'tr.frow.resolved td{opacity:.45}tr.frow.resolved .fc-issue{text-decoration:line-through}.ftag{display:inline-block;font-size:.85rem;margin-right:.35rem;vertical-align:middle}.ftag.done{color:var(--ok)}.ftag.ignored{color:var(--muted2)}',
    '.tri-row{display:flex;gap:.5rem;align-items:center;margin-top:.7rem;flex-wrap:wrap}.tri-meta{color:var(--muted);font-size:.76rem;margin-right:.3rem}',
    '.tri-btn{appearance:none;border:1px solid var(--border);background:var(--card);color:var(--muted);font-family:inherit;font-size:.74rem;padding:.32rem .7rem;border-radius:6px;cursor:pointer;transition:color .15s,border-color .15s}.tri-btn:hover{color:var(--text);border-color:var(--muted2)}.tri-btn.done:hover{color:var(--ok);border-color:var(--ok)}.tri-btn.ignore:hover{color:var(--warn);border-color:var(--warn)}',
    '.f-toggle{display:inline-flex;align-items:center;gap:.35rem;color:var(--muted);font-size:.8rem;cursor:pointer;white-space:nowrap}.f-toggle input{accent-color:var(--accent)}',
    '.tprog{height:8px;background:#33322f;border-radius:5px;overflow:hidden;margin-top:.2rem}.tprog-bar{display:block;height:100%;background:linear-gradient(90deg,var(--ok),#5fae6a)}',
    '.dash-headrow{display:flex;align-items:baseline;justify-content:space-between;gap:1rem;flex-wrap:wrap}',
    '.pdf-link{display:inline-flex;align-items:center;gap:.4rem;color:var(--muted);font-size:.82rem;cursor:pointer;text-decoration:none;white-space:nowrap;transition:color .15s}.pdf-link:hover{color:var(--accent)}.pdf-link svg{flex:0 0 auto}',
    '.pub-actions{display:flex;gap:.6rem}',
    '.pub-btn{appearance:none;flex:1 1 0;min-width:0;border:1px solid var(--border);background:var(--card-alt);color:var(--text);font-family:inherit;font-size:.86rem;padding:.65rem 1rem;border-radius:8px;cursor:pointer;transition:border-color .15s,color .15s,background .15s,filter .15s}.pub-btn:hover{border-color:var(--muted2)}',
    '.pub-btn.pub-primary{background:var(--accent);color:#1a1a1a;border-color:var(--accent);font-weight:500}.pub-btn.pub-primary:hover{filter:brightness(1.05)}',
    '.pub-btn.pub-secondary{background:transparent;border-color:var(--accent);color:var(--accent);font-weight:500}.pub-btn.pub-secondary:hover{background:rgba(255,190,95,.08);border-color:var(--accent)}',
    '.pub-btn:disabled{opacity:.4;cursor:not-allowed;background:transparent;border-color:var(--border);color:var(--muted)}.pub-btn:disabled:hover{background:transparent;border-color:var(--border)}',
    '.pub-status{font-size:.78rem;color:var(--muted);margin-top:.7rem;min-height:1em}.pub-status.ok{color:var(--ok)}.pub-status.err{color:var(--crit)}',
    '.rank-label{display:flex;align-items:center;gap:.5rem;min-width:210px}',
    '.rank-name{display:flex;flex-direction:column;gap:1px;min-width:0}',
    '.rank-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;font-size:.88rem;color:var(--text)}',
    '.rank-path{display:block;color:var(--muted2);font-size:.68rem;font-family:"SF Mono",Monaco,Consolas,monospace}',
    '.lchart-legend{display:flex;flex-wrap:wrap;gap:14px;margin-top:.9rem;font-size:12px;color:var(--muted)}',
    '.lchart-legend .item{display:flex;align-items:center;gap:5px}',
    '.lchart-legend .item .n{color:var(--muted2)}'
  ].join('');
}
function dashboardApp(){
  var D = window.__DASH_DATA__;
  var esc = function(s){ return (s==null?'':String(s)).replace(/[&<>"]/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[m]; }); };
  var sevRank = { critical:0, warning:1, info:2 };
  var chev = '<span class="chev">\u25B6</span>';
  var app = document.getElementById('app');

  var TRIAGE = D.triage || {};
  function statusOf(f){ var t = TRIAGE[f.key]; return (t && t.status) ? t.status : 'open'; }
  function isOpen(f){ return statusOf(f) === 'open'; }
  function activeFindings(){ return (D.findings||[]).filter(isOpen); }
  function countByApp(arr, prop){ var o={}; arr.forEach(function(x){ var k=x[prop]||'\u2014'; o[k]=(o[k]||0)+1; }); return o; }
  window.__triage = function(ek, status){
    var key = decodeURIComponent(ek);
    if(status === 'open'){ delete TRIAGE[key]; } else { TRIAGE[key] = { status:status, at:new Date().toISOString() }; }
    try { parent.postMessage({ __mlaudit:'triage', key:key, status:status }, '*'); } catch(e){}
    renderAuthors(); renderLeaders(); postHeight();
  };
  function triageActions(f){
    var k = encodeURIComponent(f.key||'');
    var st = statusOf(f);
    var btn = function(label, status, cls){ return '<button class="tri-btn '+(cls||'')+'" data-click="__triage(\''+k+'\',\''+status+'\')">'+label+'</button>'; };
    if(st === 'open') return '<div class="tri-row">'+btn('\u2713 Mark done','done','done')+btn('\u2298 Ignore','ignored','ignore')+'</div>';
    var when = (TRIAGE[f.key] && TRIAGE[f.key].at) ? esc(new Date(TRIAGE[f.key].at).toLocaleDateString()) : '';
    return '<div class="tri-row"><span class="tri-meta">'+(st==='done'?'Completed':'Ignored')+(when?' \u00B7 '+when:'')+'</span>'+btn('Reopen','open','')+'</div>';
  }

  function evidenceBlock(f){
    var out = '';
    if(f.items && f.items.length){
      var label = (f.evidenceLabel || 'items');
      var rows = f.items.map(function(it){
        var s = String(it);
        if(/^—.*—$/.test(s)) return '<li class="evhead">' + esc(s.replace(/—/g,'').trim()) + '</li>';
        return '<li>' + esc(s) + '</li>';
      }).join('');
      out += '<details class="evidence"><summary>\u25B8 ' + esc(label) + ' (' + f.items.length + ')</summary><ul class="evlist">' + rows + '</ul></details>';
    }
    if(f.snippet){
      out += '<details class="evidence"><summary>\u25B8 show source</summary><pre class="src">' + f.snippet + '</pre></details>';
    }
    return out;
  }
  function findingCard(f){
    return '<div class="finding s-' + f.severity + '"><div class="body">'
      + '<span class="cat">' + esc(f.lang) + ' \u00B7 ' + esc(f.category) + ' \u00B7 ' + f.severity + '</span>'
      + '<div class="det">' + esc(f.detail) + '</div>'
      + (f.suggestion ? '<div class="sugg">\u2192 ' + esc(f.suggestion) + '</div>' : '')
      + '<div class="path-mini">/' + esc(f.path) + '</div>'
      + '</div>'
      + evidenceBlock(f)
      + '</div>';
  }
  /* ---- compact, scannable findings table (replaces stacked cards) ---- */
  function sevAbbr(s){ return s==='critical'?'c':s==='warning'?'w':'i'; }
  function sevBadge(s){ return '<span class="sevb '+sevAbbr(s)+'"><span class="dot"></span>'+esc(s)+'</span>'; }
  var FCELL = {
    sev:  function(f){ return sevBadge(f.severity); },
    page: function(f){ return '<span class="fc-pg">'+esc(f.page)+'</span><span class="fc-path">/'+esc(f.path)+'</span>'; },
    lang: function(f){ return '<span class="fc-lang">'+esc(f.lang)+'</span>'; },
    cat:  function(f){ return '<span class="fc-cat">'+esc(f.category)+'</span>'; },
    issue:function(f){ return '<span class="fc-issue">'+esc(f.detail)+'</span>'; }
  };
  var FHEAD = { sev:'Severity', page:'Page', lang:'Language', cat:'Category', issue:'Issue' };
  function findingsTable(rows, cols){
    if(!rows || !rows.length) return '<p class="empty">No findings.</p>';
    var span = cols.length + 1;
    var thead = '<thead><tr>' + cols.map(function(k){ return '<th class="sortable" data-k="'+k+'">'+FHEAD[k]+'<span class="sort-ind"></span></th>'; }).join('') + '<th></th></tr></thead>';
    var body = rows.map(function(f){
      var st = statusOf(f);
      var rowCls = st === 'done' ? ' resolved done' : st === 'ignored' ? ' resolved ignored' : '';
      var tag = st === 'done' ? '<span class="ftag done" title="Completed">\u2713</span>'
              : st === 'ignored' ? '<span class="ftag ignored" title="Ignored">\u2298</span>' : '';
      var tds = cols.map(function(k){ return '<td>'+FCELL[k](f)+'</td>'; }).join('')
        + '<td class="fc-exp">'+tag+'<span class="fchev">\u25B8</span></td>';
      var sortAttrs = ' data-sev="'+(sevRank[f.severity]!=null?sevRank[f.severity]:9)+'"'
        + ' data-page="'+esc(((f.page||'')+' '+(f.path||'')).toLowerCase())+'"'
        + ' data-lang="'+esc((f.lang||'').toLowerCase())+'"'
        + ' data-cat="'+esc((f.category||'').toLowerCase())+'"'
        + ' data-issue="'+esc((f.detail||'').toLowerCase())+'"';
      var detail = '<div class="fd-inner">'
        + (f.suggestion ? '<div class="fd-sugg">\u2192 '+esc(f.suggestion)+'</div>' : '')
        + '<div class="fd-meta">'+esc(f.lang)+' \u00B7 '+esc(f.category)+' \u00B7 /'+esc(f.path)+'</div>'
        + evidenceBlock(f) + triageActions(f) + '</div>';
      return '<tr class="frow'+rowCls+'"'+sortAttrs+'>'+tds+'</tr><tr class="fdetail"><td colspan="'+span+'">'+detail+'</td></tr>';
    }).join('');
    return '<div class="ftable-wrap"><table class="ft">'+thead+'<tbody>'+body+'</tbody></table></div>';
  }

  app.innerHTML =
    '<p class="eyebrow">Localization QA dashboard</p>'
    + '<h1>' + esc(D.meta.host) + '</h1>'
    + '<div class="dash-headrow">'
      + '<p class="sub">Generated ' + esc(D.meta.generated) + ' \u00B7 ' + esc(D.meta.langs.join(', ')) + ' \u00B7 translation check: ' + esc(D.meta.translationCheck) + '</p>'
      + '<a class="pdf-link" id="pdfLink" data-click="__pdf()" title="Save as PDF">'
        + '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>'
        + '<span>Save as report PDF</span></a>'
    + '</div>'
    + '<div class="tabs"><button class="tab active" id="tab-authors">Authors</button><button class="tab" id="tab-leaders">Admin</button></div>'
    + '<div id="view-authors"></div><div id="view-leaders" style="display:none"></div>';

  var curView = 'authors';
  window.__pdf = function(){ try { parent.postMessage({ __mlaudit:'pdf', view: curView }, '*'); } catch(e){} };
  window.__exportcsv = function(){ try { parent.postMessage({ __mlaudit:'exportcsv' }, '*'); } catch(e){} };

  function show(t){
    curView = t;
    document.getElementById('view-authors').style.display = t==='authors'?'block':'none';
    document.getElementById('view-leaders').style.display = t==='leaders'?'block':'none';
    document.getElementById('tab-authors').className = 'tab' + (t==='authors'?' active':'');
    document.getElementById('tab-leaders').className = 'tab' + (t==='leaders'?' active':'');
  }
  document.getElementById('tab-authors').onclick = function(){ show('authors'); };
  document.getElementById('tab-leaders').onclick = function(){ show('leaders'); };

  // when embedded in the audit page (iframe), let the parent drive the tab and hide our own tab bar
  function postHeight(){ try { parent.postMessage({ dashHeight: document.body.scrollHeight }, '*'); } catch(e){} }
  window.__publishRun = function(){
    var s=document.getElementById('publishStatus'); if(s){ s.textContent='Publishing…'; s.className='pub-status'; }
    try { parent.postMessage({ __mlaudit:'publish' }, '*'); } catch(e){}
  };
  window.__genAudit = function(){ try { parent.postMessage({ __mlaudit:'runAudit' }, '*'); } catch(e){} };
  window.__scan404 = function(){
    var s=document.getElementById('s404-status'); if(s){ s.textContent='Scanning sitemap…'; }
    var btn=document.getElementById('s404-btn'); if(btn){ btn.disabled=true; }
    try { parent.postMessage({ __mlaudit:'scan404' }, '*'); } catch(e){}
  };
  window.addEventListener('message', function(e){
    var m = e.data;
    if(m === 'hidetabs'){ var tb = document.querySelector('.tabs'); if(tb) tb.style.display = 'none'; }
    else if(m === 'tab:authors'){ show('authors'); postHeight(); }
    else if(m === 'tab:leaders'){ show('leaders'); postHeight(); }
    else if(m && m.__mlaudit_ack === 'publish'){
      var s=document.getElementById('publishStatus');
      if(s){ s.textContent = m.ok ? ('Published \u2713 ' + new Date(m.at).toLocaleTimeString()) : 'Publish failed — check the connection.'; s.className = 'pub-status' + (m.ok?' ok':' err'); }
    }
    else if(m && m.__mlaudit_scan){
      var st=document.getElementById('s404-status'); var p=m.__mlaudit_scan;
      if(st){
        if(p.phase==='start') st.textContent='Scanning sitemap…';
        else if(p.phase==='progress') st.textContent='Checking '+p.done+' of '+p.total+'…';
        else if(p.phase==='done'){ st.textContent = p.rec && p.rec.error==='no-sitemap' ? 'No saved sitemap — run “Discover pages from sitemap” first.' : ''; }
      }
    }
  });
  if(window.ResizeObserver){ new ResizeObserver(postHeight).observe(document.body); }
  setTimeout(postHeight, 200);

  /* expand/collapse a findings-table row to show its detail */
  document.addEventListener('click', function(e){
    var row = e.target.closest ? e.target.closest('tr.frow') : null;
    if(!row) return;
    var det = row.nextElementSibling;
    if(det && det.className.indexOf('fdetail') !== -1){
      var willOpen = !det.classList.contains('show');
      det.classList.toggle('show', willOpen);
      row.classList.toggle('open', willOpen);
      postHeight();
    }
  });

  // Click a column header to sort that findings table (keeps each row's detail with it).
  document.addEventListener('click', function(e){
    var th = e.target.closest ? e.target.closest('th.sortable') : null;
    if(!th) return;
    var table = th.closest('table.ft'); if(!table) return;
    var tbody = table.querySelector('tbody'); if(!tbody) return;
    var k = th.getAttribute('data-k');
    var dir = (table.getAttribute('data-sk') === k && table.getAttribute('data-sd') === 'asc') ? 'desc' : 'asc';
    table.setAttribute('data-sk', k); table.setAttribute('data-sd', dir);
    var kids = Array.prototype.slice.call(tbody.children), pairs = [];
    for(var i=0;i<kids.length;i+=2){ pairs.push([kids[i], kids[i+1]]); }
    var numeric = (k === 'sev');
    pairs.sort(function(a,b){
      var va = a[0].getAttribute('data-'+k) || '', vb = b[0].getAttribute('data-'+k) || '', c;
      if(numeric){ c = (parseFloat(va)||0) - (parseFloat(vb)||0); }
      else { c = va < vb ? -1 : va > vb ? 1 : 0; }
      return dir === 'asc' ? c : -c;
    });
    pairs.forEach(function(p){ tbody.appendChild(p[0]); if(p[1]) tbody.appendChild(p[1]); });
    table.querySelectorAll('th.sortable').forEach(function(h){ h.removeAttribute('data-dir'); });
    th.setAttribute('data-dir', dir);
    postHeight();
  });

  /* content-date lookup (best-effort match of audited page -> Sitecore date) */
  var cdByKey = {};
  function normKey(p){ return (p||'').toLowerCase().replace(/^\/+|\/+$/g,'').replace(/\s+/g,'-'); }
  (D.contentDates||[]).forEach(function(r){ cdByKey[normKey(r.path)] = r; });
  function pageDate(path){ return cdByKey[normKey((path||'').replace(/^(es|zh)\//,''))] || null; }
  function ageDays(iso, now){ var d=new Date(iso); return isNaN(d)?null:Math.floor((now - d.getTime())/86400000); }
  function fmtAge(days){ if(days==null) return ''; if(days<60) return days+'d'; var mo=Math.floor(days/30.44); if(mo<24) return mo+'mo'; return (days/365).toFixed(1)+'y'; }

  /* ===== Authors: pages with all their findings, click to expand ===== */
  var langOpts = Array.from(new Set(D.findings.map(function(f){return f.lang;}))).sort();
  var catOpts = Array.from(new Set(D.findings.map(function(f){return f.category;}))).sort();
  var av = document.getElementById('view-authors');
  av.innerHTML =
    '<div class="card"><div class="filters">'
    + '<select id="f-lang"><option value="">All languages</option>' + langOpts.map(function(l){return '<option>'+esc(l)+'</option>';}).join('') + '</select>'
    + '<select id="f-sev"><option value="">All severities</option><option>critical</option><option>warning</option><option>info</option></select>'
    + '<select id="f-cat"><option value="">All categories</option>' + catOpts.map(function(c){return '<option>'+esc(c)+'</option>';}).join('') + '</select>'
    + '<input id="f-q" placeholder="Search text or page\u2026" style="flex:1;min-width:160px">'
    + '<label class="f-toggle"><input type="checkbox" id="f-resolved"> show resolved</label>'
    + '<span class="muted" id="f-count" style="font-size:.8rem"></span>'
    + '</div><div id="author-list"></div></div>';

  var authorSel = null;
  function pageMeta(key, items, now){
    var head=key.split('||'), name=head[0], path=head[1];
    var cc=items.filter(function(f){return f.severity==='critical';}).length;
    var wc=items.filter(function(f){return f.severity==='warning';}).length;
    var ic=items.filter(function(f){return f.severity==='info';}).length;
    var cd=pageDate(path), datePill='';
    if(cd && cd.updated){ var a=ageDays(cd.updated, now); datePill='<span class="pill date">updated '+esc(cd.updated.slice(0,10))+(a!=null?' \u00B7 '+fmtAge(a):'')+(cd.updatedBy?' \u00B7 '+esc(cd.updatedBy):'')+'</span>'; }
    var pills=(cc?'<span class="pill c">'+cc+' critical</span>':'')+(wc?'<span class="pill w">'+wc+' warning</span>':'')+(ic?'<span class="pill i">'+ic+' info</span>':'')+datePill;
    return { name:name, path:path, pills:pills };
  }
  function renderAuthors(){
    var l=document.getElementById('f-lang').value, s=document.getElementById('f-sev').value,
        c=document.getElementById('f-cat').value, q=document.getElementById('f-q').value.toLowerCase();
    var showRes = document.getElementById('f-resolved').checked;
    var matched = D.findings.filter(function(f){
      return (!l||f.lang===l) && (!s||f.severity===s) && (!c||f.category===c)
        && (!q || (f.detail+' '+f.page+' '+f.path).toLowerCase().indexOf(q)!==-1);
    });
    var rows = matched.filter(function(f){ return showRes || isOpen(f); });
    var resolvedHidden = matched.length - rows.length;
    document.getElementById('f-count').textContent = rows.length + ' ' + (showRes?'finding(s)':'open') + ' across ' + (new Set(rows.map(function(f){return f.path;}))).size + ' page(s)' + (!showRes && resolvedHidden ? ' \u00B7 ' + resolvedHidden + ' resolved hidden' : '');
    var groups={}; rows.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
    var keys=Object.keys(groups).sort(function(a,b){ return groups[b].length-groups[a].length; });
    var host=document.getElementById('author-list');
    if(!keys.length){ host.innerHTML='<p class="empty">No findings match these filters.</p>'; authorSel=null; return; }
    if(keys.indexOf(authorSel)===-1) authorSel=keys[0];
    var now=D.now||Date.now();
    var selItems=groups[authorSel].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity])||a.lang.localeCompare(b.lang); });
    var selMeta=pageMeta(authorSel, groups[authorSel], now);
    var opts=keys.map(function(k){
      var m=pageMeta(k, groups[k], now);
      return '<div class="picker-opt'+(k===authorSel?' sel':'')+'" data-key="'+encodeURIComponent(k)+'">'
        + '<span class="po-name">'+esc(m.name)+'</span>'+m.pills
        + '<span class="pc-path">/'+esc(m.path)+'</span></div>';
    }).join('');
    host.innerHTML =
      '<div class="picker" id="pk">'
        + '<div class="picker-head" id="pk-head">'+chev
          + '<span class="pk-name">'+esc(selMeta.name)+'</span>'+selMeta.pills
          + '<span class="pc-path">/'+esc(selMeta.path)+'</span>'
          + '<span class="spacer" style="flex:1"></span>'
          + '<span class="pk-hint">'+keys.length+' page(s) \u00B7 click to change</span>'
        + '</div>'
        + '<div class="picker-list" id="pk-list">'+opts+'</div>'
      + '</div>'
      + '<div class="picker-detail">'+findingsTable(selItems, ['sev','lang','cat','issue'])+'</div>';
    document.getElementById('pk-head').onclick=function(){ document.getElementById('pk').classList.toggle('open'); };
    document.getElementById('pk-list').onclick=function(e){
      var opt=e.target.closest ? e.target.closest('.picker-opt') : null; if(!opt) return;
      authorSel=decodeURIComponent(opt.getAttribute('data-key'));
      renderAuthors();
    };
  }
  ['f-lang','f-sev','f-cat','f-resolved'].forEach(function(id){ document.getElementById(id).onchange=renderAuthors; });
  document.getElementById('f-q').oninput=renderAuthors;
  renderAuthors();

  /* ===== Leaders ===== */
  function kpi(n, label, cls, sev){
    return '<button class="kpi ' + (cls||'') + '" data-click="__drillSev(\'' + (sev||'') + '\')">'
      + '<span class="kpi-n">' + n + '</span><span class="kpi-l">' + label + '</span></button>';
  }
  function donut(parts, total){
    var r=58, c=2*Math.PI*r, cx=74, cy=74, off=0;
    var segs = parts.filter(function(p){return p.n>0;}).map(function(p){
      var len = total ? c*(p.n/total) : 0;
      var s = '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="'+p.color+'" stroke-width="15" '
        + 'stroke-dasharray="'+len+' '+(c-len)+'" stroke-dashoffset="'+(-off)+'" transform="rotate(-90 '+cx+' '+cy+')"/>';
      off += len; return s;
    }).join('');
    return '<svg viewBox="0 0 148 148" class="donut">'
      + '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="var(--border)" stroke-width="15"/>'
      + (total ? segs : '')
      + '<text x="74" y="72" text-anchor="middle" class="donut-n">'+total+'</text>'
      + '<text x="74" y="90" text-anchor="middle" class="donut-l">findings</text></svg>';
  }
  function legRow(color, label, n, tot){
    var pct = tot ? Math.round(n/tot*100) : 0;
    return '<div class="legend-row"><span class="swatch" style="background:'+color+'"></span>'
      + '<span class="lt">'+label+'</span><span class="ln">'+n+' \u00B7 '+pct+'%</span></div>';
  }
  function panel(title, inner){
    return '<section class="card"><p class="label">'+title+'</p>'+inner+'</section>';
  }
  window.__drillSev = function(sev){
    show('authors');
    document.getElementById('f-sev').value = sev || '';
    renderAuthors();
    document.getElementById('view-authors').scrollIntoView({behavior:'smooth', block:'start'});
  };
  function drill(dim, list){
    var cols = ['sev','page','issue'];
    var src = list || D.findings;
    var groups={}; src.forEach(function(f){ var k=f[dim]||'\u2014'; (groups[k]=groups[k]||[]).push(f); });
    var keys=Object.keys(groups).sort(function(a,b){ return groups[b].length-groups[a].length; });
    if(!keys.length) return '<p class="empty">No open findings.</p>';
    var max=groups[keys[0]].length;
    return keys.map(function(k){
      var list2=groups[k].slice().sort(function(a,b){ return (sevRank[a.severity]-sevRank[b.severity]); });
      var pct=Math.round(list2.length/max*100);
      return '<details class="drill"><summary><span class="drill-label">'+chev+esc(k)+'</span>'
        +'<span class="bartrack"><span class="barfill" style="width:'+pct+'%"></span></span>'
        +'<span class="drill-count">'+list2.length+'</span></summary>'
        +'<div class="drill-body">'+findingsTable(list2, cols)+'</div></details>';
    }).join('');
  }
  function topProblemPages(list, n){
    var groups={}; list.forEach(function(f){ var k=f.page+'||'+f.path; (groups[k]=groups[k]||[]).push(f); });
    var scored=Object.keys(groups).map(function(k){
      var items=groups[k], w=0; items.forEach(function(f){ w += f.severity==='critical'?100:f.severity==='warning'?10:1; });
      var head=k.split('||');
      return { name:head[0], path:head[1], score:w, items:items.slice().sort(function(a,b){ return sevRank[a.severity]-sevRank[b.severity]; }) };
    });
    scored.sort(function(a,b){ return b.score-a.score; });
    var top=scored.slice(0, n||5);
    if(!top.length) return '<p class="empty">No open findings.</p>';
    var mx=top[0].score||1;
    return top.map(function(r){
      var pct=Math.round(r.score/mx*100);
      return '<details class="drill"><summary><span class="rank-label">'+chev+'<span class="rank-name"><span class="rank-title">'+esc(r.name)+'</span><span class="rank-path">/'+esc(r.path)+'</span></span></span>'
        +'<span class="bartrack"><span class="barfill" style="width:'+pct+'%"></span></span>'
        +'<span class="drill-count">'+r.score+'</span></summary>'
        +'<div class="drill-body">'+findingsTable(r.items, ['sev','lang','cat','issue'])+'</div></details>';
    }).join('');
  }
  function sevByLangLine(list){
    var byLang={};
    list.forEach(function(f){ var l=f.lang||'\u2014'; byLang[l]=byLang[l]||{critical:0,warning:0,info:0}; byLang[l][f.severity]=(byLang[l][f.severity]||0)+1; });
    var langs=Object.keys(byLang).sort(function(a,b){
      var ta=byLang[a].critical+byLang[a].warning+byLang[a].info, tb=byLang[b].critical+byLang[b].warning+byLang[b].info;
      return tb-ta;
    });
    if(!langs.length) return '<p class="empty">No open findings.</p>';
    var palette = ['var(--accent)','var(--ok)','#8aa9d9','#b48ae0','#e08ac0','#7fd0c9'];
    var cats = ['critical','warning','info'], catLabels = ['Critical','Warning','Info'];
    var maxV = 1;
    langs.forEach(function(l){ cats.forEach(function(c){ if(byLang[l][c] > maxV) maxV = byLang[l][c]; }); });
    var W=440, H=200, padL=30, padR=14, padT=14, padB=28;
    var plotW=W-padL-padR, plotH=H-padT-padB;
    function xFor(i){ return padL + plotW*i/(cats.length-1); }
    function yFor(v){ return padT + plotH - (plotH*v/maxV); }
    var yTicks=[0, Math.round(maxV/2), maxV];
    var gridSvg = yTicks.map(function(t){
      var y=yFor(t);
      return '<line x1="'+padL+'" y1="'+y+'" x2="'+(W-padR)+'" y2="'+y+'" stroke="var(--border)" stroke-width="1"/>'
        + '<text x="'+(padL-8)+'" y="'+(y+3)+'" text-anchor="end" font-size="10" fill="var(--muted2)">'+t+'</text>';
    }).join('');
    var xLabels = cats.map(function(c,i){
      return '<text x="'+xFor(i)+'" y="'+(H-8)+'" text-anchor="middle" font-size="10" fill="var(--muted)">'+catLabels[i]+'</text>';
    }).join('');
    var lines = langs.map(function(l, li){
      var color = palette[li % palette.length];
      var pts = cats.map(function(c,i){ return xFor(i)+','+yFor(byLang[l][c]); }).join(' ');
      var dots = cats.map(function(c,i){
        return '<circle cx="'+xFor(i)+'" cy="'+yFor(byLang[l][c])+'" r="3.5" fill="'+color+'"><title>'+esc(l)+' \u00B7 '+catLabels[i]+': '+byLang[l][c]+'</title></circle>';
      }).join('');
      return '<polyline points="'+pts+'" fill="none" stroke="'+color+'" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>'+dots;
    }).join('');
    var svg = '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto;display:block">'+gridSvg+xLabels+lines+'</svg>';
    var legend = '<div class="lchart-legend">'+langs.map(function(l, li){
      var color = palette[li % palette.length];
      var t = byLang[l].critical+byLang[l].warning+byLang[l].info;
      return '<span class="item"><span class="swatch" style="background:'+color+'"></span>'+esc(l)+' <span class="n">('+t+')</span></span>';
    }).join('')+'</div>';
    return svg + legend;
  }
  var staleMonths = '12';
  var findingsDim = 'category';

  var lv=document.getElementById('view-leaders');
  function renderLeaders(){
    var ACT = activeFindings();

    var bs = countByApp(ACT, 'severity');
    var sc=bs.critical||0, sw=bs.warning||0, si=bs.info||0, stot=sc+sw+si;
    var sevInner='<div class="sevmix">'
      + donut([{n:sc,color:'var(--crit)'},{n:sw,color:'var(--warn)'},{n:si,color:'var(--muted2)'}], stot)
      + '<div class="legend">'
        + legRow('var(--crit)','Critical',sc,stot)
        + legRow('var(--warn)','Warning',sw,stot)
        + legRow('var(--muted2)','Info',si,stot)
      + '</div></div>';

    var cov=D.coverage;
    var covMissing=cov.missing.length
      ? cov.missing.map(function(m){ return '<div class="barrow"><span style="min-width:150px">'+esc(m.lang)+'</span><span class="crit">'+m.count+' page(s) missing / errored</span></div>'; }).join('')
      : '<p class="ok" style="font-size:.85rem">Every audited page returned a version in all languages.</p>';
    var covInner='<div class="covrow"><span class="big">'+cov.audited+'</span><span class="muted">of '+cov.discovered+' discovered page(s) audited</span></div>'+covMissing;

    var sync = D.sync || {};
    var staleFindings = ACT.filter(function(f){ return f.category === 'source changed, translation stale'; });
    var queueHtml = '';
    if(sync.hasBaseline){
      var apprTxt = sync.approvedAt ? ' \u00B7 approved ' + esc(new Date(sync.approvedAt).toLocaleDateString()) : '';
      if(staleFindings.length){
        queueHtml = '<section class="card queue-stale"><p class="label">\u26A0 Stale because English changed \u00B7 retranslate these (' + staleFindings.length + ')' + apprTxt + '</p>'
          + findingsTable(staleFindings, ['sev','page','lang','issue']) + '</section>';
      } else {
        queueHtml = '<section class="card queue-ok"><p class="label">Source sync' + apprTxt + '</p>'
          + '<p class="ok" style="font-size:.88rem">No open stale translations — every approved translation still matches its English source.</p></section>';
      }
    }

    // triage progress
    var doneN=0, ignN=0;
    (D.findings||[]).forEach(function(f){ var st=statusOf(f); if(st==='done')doneN++; else if(st==='ignored')ignN++; });
    var totalN=(D.findings||[]).length, openN=ACT.length;
    var pctDone = totalN ? Math.round((doneN+ignN)/totalN*100) : 0;
    var triageInner = '<div class="covrow"><span class="big">'+openN+'</span><span class="muted">open of '+totalN+' finding(s)</span></div>'
      + '<div class="tprog"><span class="tprog-bar" style="width:'+pctDone+'%"></span></div>'
      + '<div class="barrow" style="margin-top:.6rem"><span class="ok">'+doneN+' completed</span><span class="muted">'+ignN+' ignored</span></div>';

    var modeLabel = (D.storeMode === 'remote') ? 'Shared store \u00B7 team-wide' : 'Local only \u00B7 this browser';
    var canPublish = !!D.hasLocalRun;
    var publishInner = '<p class="muted" style="font-size:.82rem;margin:0 0 .9rem">'+esc(modeLabel)+'</p>'
      + '<div class="pub-actions">'
        + '<button class="pub-btn pub-secondary"'+(canPublish?'':' disabled')+' data-click="__publishRun()">Publish run to team</button>'
        + (D.canRun ? '<button class="pub-btn pub-primary" data-click="__genAudit()">Generate new audit</button>' : '')
      + '</div>'
      + '<div id="publishStatus" class="pub-status">'+(canPublish?'':'Run a new audit to publish it to the team.')+'</div>';

    // Prefer the explicit missing-translations list; fall back to reconstructing from
    // findings so older runs still match the Findings box.
    var mtList = Array.isArray(D.missingTranslations) ? D.missingTranslations.slice()
      : (D.findings || []).filter(function(f){ return f.category === 'load error' && f.lang !== 'English (reference)'; })
          .map(function(f){ return { page:f.page, lang:f.lang, url:'', error:f.detail || 'failed to load' }; });

    var s404Inner = (function(){
      var out = '';

      // Group 1 — missing/broken foreign-language pages found by the last audit
      var mt = mtList.slice().sort(function(a,b){ return (a.page+a.lang).localeCompare(b.page+b.lang); });
      out += '<details class="acc-collapse s404-group" open><summary class="s404-grouphead acc-summary">Missing translations \u00B7 expected foreign-language pages that failed to load'
        + (mt.length? ' ('+mt.length+')':'') + '<span class="chev">\u25B8</span></summary>';
      if(!D.summary || !D.summary.pages){
        out += '<p class="muted" style="font-size:.82rem;margin:.1rem 0 .5rem">Run an audit to check whether each page\u2019s translated versions exist.</p>';
      } else if(!mt.length){
        out += '<p style="color:var(--ok);font-size:.85rem;margin:.1rem 0 .5rem">Every audited page returned a version in all languages.</p>';
      } else {
        var capN = 60, cap = mt.slice(0, capN);
        out += '<div class="s404-list">' + cap.map(function(m){
          var label = m.url ? m.url : (m.page + ' \u2014 ' + m.lang);
          var right = m.lang + ' \u00B7 ' + m.error;
          var inner = '<span class="s404-url">' + esc(label) + '</span>';
          if(m.url) inner = '<a class="s404-url" href="'+esc(m.url)+'" target="_blank" rel="noopener">'+esc(label)+'</a>';
          return '<div class="s404-row">' + inner + '<span class="s404-seen">'+esc(right)+'</span></div>';
        }).join('') + '</div>';
        if(mt.length > cap.length){
          out += '<p class="muted" style="font-size:.78rem;margin:.5rem 0 0">+' + (mt.length - cap.length)
            + ' more \u2014 see every one under <strong>Findings \u25B8 by language</strong>.</p>';
        }
      }
      out += '</details>';

      // Group 2 — sitemap monitor (internal pages the sitemap lists that 404)
      var s = D.sitemap404;
      out += '<details class="acc-collapse s404-group" open><summary class="s404-grouphead acc-summary">Sitemap monitor \u00B7 internal pages the sitemap lists that return 404<span class="chev">\u25B8</span></summary>';
      if(!s || !s.checked){
        out += '<p class="muted" style="margin:.1rem 0 .5rem;font-size:.82rem">Checks the saved sitemap for internal pages that return 404. The scheduled job also updates this list.</p>';
      } else {
        var deadUrls = Object.keys(s.urls || {});
        out += '<p class="muted" style="margin:.1rem 0 .5rem;font-size:.82rem">Last checked '+new Date(s.checked).toLocaleString()+' \u00B7 '+s.dead+' dead of '+s.total+' checked'+(s.newCount? ' \u00B7 '+s.newCount+' new':'')+'</p>';
        if(!deadUrls.length){
          out += '<p style="color:var(--ok);font-size:.85rem">No 404s — every page in the saved sitemap resolved.</p>';
        } else {
          out += '<div class="s404-list">' + deadUrls.sort(function(a,b){ return (s.urls[b].firstSeen||'').localeCompare(s.urls[a].firstSeen||''); }).map(function(u){
            var isNew = s.newUrls && s.newUrls.indexOf(u) !== -1;
            var seen = s.urls[u].firstSeen ? 'since '+new Date(s.urls[u].firstSeen).toLocaleDateString() : '';
            return '<div class="s404-row">'+(isNew?'<span class="s404-new">NEW</span>':'')
              + '<a class="s404-url" href="'+esc(u)+'" target="_blank" rel="noopener">'+esc(u)+'</a>'
              + '<span class="s404-seen">'+seen+'</span></div>';
          }).join('') + '</div>';
        }
      }
      if(D.canRun){
        out += '<div style="margin-top:.7rem;display:flex;align-items:center;gap:.6rem;flex-wrap:wrap">'
          + '<button id="s404-btn" class="pub-btn pub-secondary" style="flex:0 0 auto;width:auto;padding:.5rem .9rem" data-click="__scan404()">Check sitemap now</button>'
          + '<span id="s404-status" class="muted" style="font-size:.8rem"></span></div>';
      }
      out += '</details>';
      return out;
    })();

    var critK = ACT.filter(function(f){return f.severity==='critical' && f.category!=='broken link';}).length;
    var brokenK = ACT.filter(function(f){return f.category==='broken link';}).length;
    lv.innerHTML=
      '<div class="kpis">'
        + kpi(D.summary.pages,'Pages','accent','')
        + kpi(critK,'Critical','crit','critical')
        + kpi(sw,'Warnings','warn','warning')
        + kpi(brokenK,'Broken links',brokenK?'crit':'','')
        + kpi(openN,'Open findings','','')
        + '</div>'
      + '<div class="dash-grid dash-grid-eq">'
        + panel('Severity mix \u00B7 click a metric above to drill in', sevInner)
        + panel('Publish &amp; generate', publishInner)
        + '</div>'
      + queueHtml
      + panel('Top problem pages', topProblemPages(ACT, 5))
      + (function(){
          var dead = ((D.sitemap404 && D.sitemap404.urls) ? Object.keys(D.sitemap404.urls).length : 0)
                   + mtList.length;
          var pill = dead ? ' <span class="count-pill">'+dead+'</span>' : '';
          return '<section class="card card-404'+(dead?' has-dead':'')+'">'
            + '<p class="label">404 errors'+pill+'</p>'
            + s404Inner + '</section>';
        })()
      + '<div class="dash-grid dash-grid-eq">'
        + '<section class="card">'
          + '<details class="acc-collapse" open>'
            + '<summary class="label acc-summary">Findings<span class="chev">\u25B8</span></summary>'
            + '<div class="filters"><span class="muted">Group</span>'
            + '<select id="findings-dim">'
            + '<option value="category"'+(findingsDim==='category'?' selected':'')+'>by category</option>'
            + '<option value="lang"'+(findingsDim==='lang'?' selected':'')+'>by language</option>'
            + '<option value="dir"'+(findingsDim==='dir'?' selected':'')+'>by section / directory</option>'
            + '</select><span class="muted" style="font-size:.78rem">\u00B7 click a row to expand</span></div>'
            + '<div id="findings-drill">' + drill(findingsDim, ACT) + '</div>'
          + '</details>'
        + '</section>'
        + panel('Severity by language', sevByLangLine(ACT))
        + '</div>'
      + '<div class="dash-grid dash-grid-eq">'
        + panel('Triage progress', triageInner)
        + panel('Translation coverage', covInner)
        + '</div>'
      + '<section class="card">'
        + '<details class="stale-collapse" open>'
          + '<summary class="label stale-summary">Stale content<span class="chev">\u25B8</span></summary>'
          + '<div class="filters"><span class="muted">Flag pages not updated in over</span>'
          + '<select id="stale-threshold">'
          + ['3','6','12','18','24'].map(function(v){ return '<option value="'+v+'"'+(v===staleMonths?' selected':'')+'>'+v+' months</option>'; }).join('')
          + '</select></div>'
          + '<div id="stale-body"></div>'
        + '</details>'
      + '</section>';
    var sel=document.getElementById('stale-threshold');
    if(sel){ sel.onchange=function(){ staleMonths=sel.value; renderStale(); }; }
    var fdim=document.getElementById('findings-dim');
    if(fdim){ fdim.onchange=function(){ findingsDim=fdim.value; var fd=document.getElementById('findings-drill'); if(fd){ fd.innerHTML=drill(findingsDim, activeFindings()); } postHeight(); }; }
    renderStale();
  }

  function parseDate(s){
    if(!s) return null;
    var m=/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(s);
    if(m) return new Date(Date.UTC(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+m[6]));
    var t2=Date.parse(s); return isNaN(t2)?null:new Date(t2);
  }
  function renderStale(){
    var staleBody=document.getElementById('stale-body'); if(!staleBody) return; // panel disabled
    var months=+document.getElementById('stale-threshold').value;
    var now=D.now||Date.now();
    var cutoff=now-months*30.44*86400000;
    var useSc=D.contentDates && D.contentDates.length;
    var src=useSc
      ? D.contentDates.map(function(r){ return {path:r.path,by:r.updatedBy,created:r.created,createdBy:r.createdBy,date:parseDate(r.updated)}; })
      : (D.pages||[]).map(function(p){ return {path:p.path,by:'',date:parseDate(p.lastmod)}; });
    var dated=src.filter(function(r){return r.date;}).sort(function(a,b){return a.date-b.date;});
    var staleCount=dated.filter(function(r){return r.date.getTime()<cutoff;}).length;
    var html='<p class="sub">'+(useSc?'Real publish dates from Sitecore. ':'')
      +staleCount+' of '+dated.length+' page(s) not updated in over '+months+' month(s). Click a row for detail.</p>';
    if(!dated.length){
      document.getElementById('stale-body').innerHTML=html+'<p class="empty">No dates loaded. In the audit tool, click \u201cLoad content dates\u201d and pick your \u201cItems last updated\u201d export, then save the dashboard again.</p>';
      return;
    }
    var staleRows=dated.filter(function(r){return r.date.getTime()<cutoff;});
    if(!staleRows.length){
      document.getElementById('stale-body').innerHTML=html+'<p class="empty" style="color:var(--ok)">No pages are stale at this threshold.</p>';
      return;
    }
    html+='<div class="headrow"><span>Page</span><span>Updated</span><span>Age</span><span>Status</span></div>';
    html+=staleRows.map(function(r){
      var dAge=Math.floor((now-r.date.getTime())/86400000);
      var stale=r.date.getTime()<cutoff;
      var body='<div class="st-body">'
        + '<div><span class="k">Last updated</span><br><span class="v">'+esc(r.date.toISOString().slice(0,10))+'</span></div>'
        + (r.by?'<div><span class="k">Updated by</span><br><span class="v">'+esc(r.by)+'</span></div>':'')
        + (r.created?'<div><span class="k">Created</span><br><span class="v">'+esc((parseDate(r.created)||r.created).toISOString?parseDate(r.created).toISOString().slice(0,10):r.created)+'</span></div>':'')
        + (r.createdBy?'<div><span class="k">Created by</span><br><span class="v">'+esc(r.createdBy)+'</span></div>':'')
        + '<div><span class="k">Full path</span><br><span class="v">/'+esc(r.path)+'</span></div>'
        + '</div>';
      return '<details class="stale'+(stale?' is-stale':'')+'"><summary>'
        + '<span class="st-path">'+chev+' /'+esc(r.path)+'</span>'
        + '<span class="st-date">'+esc(r.date.toISOString().slice(0,10))+'</span>'
        + '<span class="st-age">'+fmtAge(dAge)+'</span>'
        + '<span>'+(stale?'<span class="crit">stale</span>':'<span class="ok">current</span>')+'</span>'
        + '</summary>'+body+'</details>';
    }).join('');
    document.getElementById('stale-body').innerHTML=html;
  }
  renderLeaders();
}

function collectRows(){
  const rows = [];
  (auditState && auditState.results || []).forEach(r => {
    const page = r.page.name;
    if(r.refError) rows.push({ page, lang:'English (reference)', section:'Fetch', severity:'critical', category:'load error', detail:r.refError, a:'', b:'' });
    if(r.refTech){
      r.refTech.code.forEach(c => rows.push({ page, lang:'English (reference)', section:'Code', severity:c.sev, category:'code', detail:c.text, a:'', b:'' }));
      r.refTech.links.forEach(l => rows.push({ page, lang:'English (reference)', section:'Links', severity:'critical', category:'broken link', detail:l.url, a:'', b:String(l.status||'no response') }));
    }
    (r.languages||[]).forEach(bk => {
      const lang = bk.lang.label;
      if(bk.error){ rows.push({ page, lang, section:'Fetch', severity:'critical', category:'load error', detail:bk.error, a:'', b:'' }); return; }
      const push = (arr, section) => (arr||[]).forEach(is => rows.push({ page, lang, section, severity:is.severity||'info', category:is.category||'', detail:is.explanation||'', a:is.reference||'', b:is.translation||'' }));
      if(bk.drift) push(bk.drift.issues, 'Drift from Google');
      if(bk.driftError) rows.push({ page, lang, section:'Drift from Google', severity:'info', category:'unavailable', detail:bk.driftError, a:'', b:'' });
      if(bk.ai) push(bk.ai.issues, 'Translation (Claude)');
      if(bk.aiError) rows.push({ page, lang, section:'Translation (Claude)', severity:'info', category:'unavailable', detail:bk.aiError, a:'', b:'' });
      push(bk.parity, 'Sections & parity');
      push(bk.content, 'Content & SEO');
      if(bk.tech){
        bk.tech.code.forEach(c => rows.push({ page, lang, section:'Code', severity:c.sev, category:'code', detail:c.text, a:'', b:'' }));
        bk.tech.links.forEach(l => rows.push({ page, lang, section:'Links', severity:'critical', category:'broken link', detail:l.url, a:'', b:String(l.status||'no response') }));
      }
    });
  });
  return rows;
}
function csvCell(v){ v = (v==null?'':String(v)); return /[",\n]/.test(v) ? '"' + v.replace(/"/g,'""') + '"' : v; }
function exportCsv(){
  if(!auditState || !auditState.results || !auditState.results.length){ setReportStatus('Run an audit first.', true); return; }
  const rows = collectRows();
  const header = ['Page','Language','Section','Severity','Category','Detail','Reference / link','Translation / status'];
  const lines = [header.join(',')];
  rows.forEach(r => lines.push([r.page, r.lang, r.section, r.severity, r.category, r.detail, r.a, r.b].map(csvCell).join(',')));
  downloadBlob('\ufeff' + lines.join('\r\n'), 'text/csv', `audit-issues-${reportHost()}-${new Date().toISOString().slice(0,10)}.csv`);
  setReportStatus(`Exported ${rows.length} issue row(s) to CSV.`);
}

/* ----------------------------- fetching ----------------------------- */
function proxify(target){
  const base = WORKER_URL.trim();
  try {
    const u = new URL(base);
    u.searchParams.set('url', target);
    return u.href;
  } catch(e){
    // fallback if base isn't a valid URL yet
    return base + (base.includes('?') ? '&' : '?') + 'url=' + encodeURIComponent(target);
  }
}
function fetchOpts(extra){
  const opts = Object.assign({ method:'GET' }, extra || {});
  const key = ((document.getElementById('pass') && document.getElementById('pass').value) || WORKER_KEY || '').trim();
  if(key){ opts.headers = Object.assign({}, opts.headers, { 'X-Audit-Key': key }); }
  return opts;
}
async function fetchPage(url){
  // In the extension, host_permissions let us fetch azblue.com directly — no proxy needed.
  const direct = (typeof EXT_MODE !== 'undefined') && EXT_MODE;
  const requested = direct ? url : proxify(url);
  try {
    const res = await fetch(requested, direct ? { method:'GET' } : fetchOpts());
    const text = await res.text();
    return { ok: res.ok, status: res.status, text, requested };
  } catch(e){
    return { ok:false, status:0, text:'', error: e.message, requested };
  }
}

async function testConnection(){
  const el = document.getElementById('testResult');
  const url = (document.getElementById('testUrl').value || '').trim();
  if(!url){ el.innerHTML = `<div class="err-note" style="margin-top:1rem;">Enter a page URL to test.</div>`; return; }
  el.innerHTML = `<div class="score" style="margin-top:1rem;">Requesting…</div>`;
  const r = await fetchPage(url);
  const snippet = (r.text||'').slice(0,300).replace(/\s+/g,' ').trim();
  const okClass = r.ok ? 'ok' : 'crit';
  el.innerHTML = `<div style="margin-top:1rem; border:1px solid var(--border); border-radius:8px; padding:1rem;">
    <div class="score">Tested address:</div>
    <div style="font-size:.8rem; word-break:break-all; margin:.25rem 0 .8rem;"><a href="${escapeAttr(url)}" target="_blank" rel="noopener" style="color:var(--accent-deep); text-decoration:none;">${escapeHtml(url)}</a></div>
    <div class="score">Response: <span class="pill ${okClass}">${r.error ? 'network error' : ('HTTP ' + r.status)}</span></div>
    ${r.error ? `<div class="err-note" style="margin-top:.6rem;">${escapeHtml(r.error)} — usually a CORS or unreachable-worker problem.</div>` : ''}
    ${snippet ? `<div class="score" style="margin-top:.8rem;">First bytes returned:</div><div style="font-size:.78rem; color:var(--muted); background:var(--card-alt); border:1px solid var(--border); border-radius:6px; padding:.5rem .6rem; margin-top:.3rem; word-break:break-all;">${escapeHtml(snippet)}…</div>` : ''}
    <div class="score" style="margin-top:.8rem;">A 200 means the proxy and passphrase are working. A 403 means the passphrase doesn't match the worker; other codes come from the site itself.</div>
  </div>`;
}
function siteHostName(){ try { return new URL(SITE_URL).hostname; } catch(e){ return ''; } }
function proxifyCheck(target){
  const base = WORKER_URL.trim();
  try { const u = new URL(base); u.searchParams.set('check','1'); u.searchParams.set('url', target); return u.href; }
  catch(e){ return base + (base.includes('?')?'&':'?') + 'check=1&url=' + encodeURIComponent(target); }
}
let linkCache = new Map();   // url -> Promise<result>, dedupes within a single run
let linkResults = new Map(); // url -> resolved {url,status,ok,...}, persists across runs + saved to file
function checkResource(url){
  const reverify = document.getElementById('reverify') && document.getElementById('reverify').checked;
  if(!reverify && linkResults.has(url)) return Promise.resolve(linkResults.get(url));
  if(linkCache.has(url)) return linkCache.get(url);
  const pr = (async () => {
    let r;
    try {
      const res = await fetch(proxifyCheck(url), fetchOpts());
      const ct = res.headers.get('content-type') || '';
      if(ct.includes('application/json')){
        const d = await res.json();
        r = { url, status: d.status||0, ok: !!d.ok, ts: Date.now() };
      } else {
        // worker's check endpoint not deployed yet — degrade gracefully
        let body=''; try { body = await res.text(); } catch(e){}
        if(res.status === 403 && /Target host not allowed/i.test(body)){
          r = { url, status: 0, ok:false, blocked:true, note:'worker check endpoint not enabled', ts: Date.now() };
        } else {
          r = { url, status: res.status, ok: res.status>=200 && res.status<400, ts: Date.now() };
        }
      }
    } catch(e){
      r = { url, status:0, ok:false, error:e.message, ts: Date.now() };
    }
    linkResults.set(url, r);
    return r;
  })();
  linkCache.set(url, pr);
  return pr;
}
async function pool(items, worker, concurrency){
  const out = []; let i = 0;
  const runners = Array.from({length: Math.min(concurrency, items.length||1)}, async () => {
    while(i < items.length){ const idx = i++; out[idx] = await worker(items[idx], idx); }
  });
  await Promise.all(runners);
  return out;
}

/* ----------------------------- parsing ----------------------------- */
function extract(html, baseUrl){
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const abs = (href) => { try { return new URL(href, baseUrl).href; } catch(e){ return null; } };

  const headings = [...doc.querySelectorAll('h1,h2,h3,h4,h5,h6')]
    .map(h => ({ level: +h.tagName[1], text: clean(h.textContent) })).filter(h=>h.text);

  const anchors = [...doc.querySelectorAll('a[href]')];
  const links = [];
  anchors.forEach(a => {
    const raw = a.getAttribute('href');
    if(!raw) return;
    if(/^(mailto:|tel:|javascript:|#)/i.test(raw)) return;
    const u = abs(raw);
    if(u && /^https?:/i.test(u)) links.push(u);
  });

  const images = [...doc.querySelectorAll('img')].map(img => ({
    src: abs(img.getAttribute('src')||''), alt: img.getAttribute('alt')
  }));

  // visible-ish text
  const bodyClone = doc.body ? doc.body.cloneNode(true) : doc.cloneNode(true);
  bodyClone.querySelectorAll('script,style,noscript,svg,template').forEach(n=>n.remove());
  const textContent = clean(bodyClone.textContent || '');

  // ordered text segments (for Pattern A drift comparison)
  const segments = [];
  doc.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li').forEach(el => {
    if(el.tagName === 'LI' && el.querySelector('li,ul,ol')) return; // outer list container; inner captured
    if(el.tagName === 'P' && el.querySelector('p')) return;
    const t = clean(el.textContent || '');
    if(t.length >= 3) segments.push(t);
  });

  const title = clean(doc.querySelector('title')?.textContent || '');
  const metaDesc = doc.querySelector('meta[name="description"]')?.getAttribute('content') || '';

  // hreflang alternates
  const hreflang = [...doc.querySelectorAll('link[rel="alternate"][hreflang]')]
    .map(l => ({ lang: (l.getAttribute('hreflang')||'').toLowerCase(), href: abs(l.getAttribute('href')||'') }));

  // canonical + robots
  const canonical = abs(doc.querySelector('link[rel="canonical"]')?.getAttribute('href') || '');
  const robotsMeta = (doc.querySelector('meta[name="robots"]')?.getAttribute('content') || '').toLowerCase();
  const noindex = /noindex/.test(robotsMeta);

  // structured data (JSON-LD)
  const schemaTypes = [];
  doc.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
    try {
      const j = JSON.parse(s.textContent || '{}');
      const collect = (o) => { if(!o) return; if(Array.isArray(o)) return o.forEach(collect); if(o['@type']) [].concat(o['@type']).forEach(t => schemaTypes.push(String(t))); if(o['@graph']) collect(o['@graph']); };
      collect(j);
    } catch(e){}
  });

  // headings detail
  const h1Count = headings.filter(h => h.level === 1).length;
  let skipped = false;
  for(let i=1;i<headings.length;i++){ if(headings[i].level - headings[i-1].level > 1){ skipped = true; break; } }

  // word count + placeholders
  const words = textContent ? textContent.split(/\s+/).filter(Boolean).length : 0;
  const placeholders = (textContent.match(/lorem ipsum|lipsum|\bTODO\b|coming soon|placeholder text|dummy text/gi) || []);

  return {
    title, metaDesc,
    titleLen: title.length, metaDescLen: metaDesc.length,
    htmlLang: doc.documentElement.getAttribute('lang') || '',
    hreflang, canonical, noindex,
    schemaTypes: [...new Set(schemaTypes)],
    h1Count, headingSkip: skipped,
    words, placeholders: [...new Set(placeholders.map(p=>p.toLowerCase()))],
    headings,
    links: [...new Set(links)],
    images,
    counts: {
      headings: headings.length,
      links: anchors.length,
      images: images.length,
      forms: doc.querySelectorAll('form').length,
      inputs: doc.querySelectorAll('input,textarea,select').length,
      buttons: doc.querySelectorAll('button').length
    },
    emptyLinks: anchors.filter(a => { const h=a.getAttribute('href'); return !h || h==='#' || h.trim()===''; }).length,
    missingAlt: images.filter(i => i.alt === null).length,
    duplicateIds: findDuplicateIds(doc),
    regions: detectRegions(doc),
    segments,
    rawHtml: html,
    baseUrl: baseUrl,
    textContent
  };
}

/* ---- HTML snippet helpers (context for issues) ---- */
function parseDoc(rawHtml){ try { return new DOMParser().parseFromString(rawHtml||'', 'text/html'); } catch(e){ return null; } }
function findByText(doc, text){
  if(!doc || !text) return null;
  const norm = normForCompare(text).slice(0, 140);
  if(norm.length < 3) return null;
  let best = null, bestLen = Infinity;
  doc.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li,a,button,label,td,th,figcaption,span,div').forEach(el => {
    const t = clean(el.textContent || ''); if(!t) return;
    if(normForCompare(t).includes(norm) && t.length < bestLen){ best = el; bestLen = t.length; }
  });
  return best;
}
function findAnchor(doc, url, baseUrl){
  if(!doc) return null;
  let found = null;
  doc.querySelectorAll('a[href]').forEach(a => {
    if(found) return;
    const raw = a.getAttribute('href'); if(!raw) return;
    try { if(new URL(raw, baseUrl || undefined).href === url) found = a; } catch(e){ if(raw === url) found = a; }
  });
  return found;
}
function srcSnippet(rawHtml, el){
  if(!rawHtml || !el) return '';
  // find where this element lives in the actual served source
  const cand = [];
  const href = el.getAttribute && el.getAttribute('href');
  const id = el.getAttribute && el.getAttribute('id');
  if(href){ cand.push('href="'+href+'"', "href='"+href+"'"); }
  if(id){ cand.push('id="'+id+'"', "id='"+id+"'"); }
  const txt = clean(el.textContent || '');
  if(txt) cand.push(txt.slice(0, 40));
  let idx = -1;
  for(const c of cand){ if(c && c.length >= 3){ idx = rawHtml.indexOf(c); if(idx !== -1) break; } }
  if(idx === -1) return '';
  // start at the opening '<' of the tag holding this, plus some leading container context
  let tagStart = rawHtml.lastIndexOf('<', idx);
  if(tagStart === -1) tagStart = Math.max(0, idx - 40);
  const ctxStart = Math.max(0, tagStart - 200);
  const ctxEnd = Math.min(rawHtml.length, idx + 360);
  let slice = rawHtml.slice(ctxStart, ctxEnd);
  // trim to clean tag boundaries
  const firstLt = slice.indexOf('<'); if(firstLt > 0) slice = slice.slice(firstLt);
  const lastGt = slice.lastIndexOf('>'); if(lastGt !== -1) slice = slice.slice(0, lastGt + 1);
  slice = slice.replace(/^\s+|\s+$/g, '');
  if(ctxStart > 0) slice = '…\n' + slice;
  if(ctxEnd < rawHtml.length) slice = slice + '\n…';
  return escapeHtml(slice);
}

/* ---- major page regions (landmarks) ---- */
const REGION_DEFS = [
  { key:'header', label:'Header',             sel:'header, [role="banner"]',                 cls:/(^|[-_ ])(site[-_]?header|page[-_]?header|masthead|header)([-_ ]|$)/i,  major:true },
  { key:'nav',    label:'Primary navigation', sel:'nav, [role="navigation"]',                cls:/(^|[-_ ])(primary[-_]?nav|main[-_]?nav|navbar|navigation|nav|menu)([-_ ]|$)/i, major:true },
  { key:'main',   label:'Main content',       sel:'main, [role="main"]',                    cls:/(^|[-_ ])(main[-_]?content|page[-_]?content|content[-_]?main|main|content)([-_ ]|$)/i, major:true },
  { key:'aside',  label:'Sidebar',            sel:'aside, [role="complementary"]',          cls:/(^|[-_ ])(sidebar|complementary|aside)([-_ ]|$)/i, major:false },
  { key:'footer', label:'Footer',             sel:'footer, [role="contentinfo"]',           cls:/(^|[-_ ])(site[-_]?footer|page[-_]?footer|footer)([-_ ]|$)/i, major:true },
  { key:'search', label:'Search',             sel:'[role="search"], form[role="search"]',   cls:/(^|[-_ ])(search[-_]?form|site[-_]?search|search)([-_ ]|$)/i, major:false }
];
function detectRegion(doc, def){
  let els = [...doc.querySelectorAll(def.sel)];
  if(!els.length){
    els = [...doc.querySelectorAll('div,section,header,footer,nav,aside')].filter(el => {
      const idc = (el.getAttribute('id')||'') + ' ' + (el.getAttribute('class')||'');
      return def.cls.test(idc);
    });
  }
  if(!els.length) return { present:false, textLen:0, links:0 };
  let best = els[0], bestLen = -1;
  els.forEach(el => {
    const l = clean(el.textContent||'').length;
    if(l > bestLen){ bestLen = l; best = el; }
  });
  return { present:true, textLen:bestLen, links:best.querySelectorAll('a[href]').length };
}
function detectRegions(doc){
  const out = {};
  REGION_DEFS.forEach(def => { out[def.key] = detectRegion(doc, def); });
  return out;
}
function regionElement(doc, def){
  if(!doc) return null;
  let els = [...doc.querySelectorAll(def.sel)];
  if(!els.length){
    els = [...doc.querySelectorAll('div,section,header,footer,nav,aside')].filter(el =>
      def.cls.test((el.getAttribute('id')||'') + ' ' + (el.getAttribute('class')||'')));
  }
  if(!els.length) return null;
  let best = els[0], bestLen = -1;
  els.forEach(el => { const l = clean(el.textContent||'').length; if(l > bestLen){ bestLen = l; best = el; } });
  return best;
}
function regionDiff(refRegions, transRegions, liveDoc, liveRawHtml){
  const issues = [];
  REGION_DEFS.forEach(def => {
    const r = refRegions[def.key], t = transRegions[def.key];
    if(!r || !r.present) return; // only compare regions that exist on the English page
    if(!t || !t.present){
      const words = Math.round(r.textLen / 6);
      issues.push({
        category:'missing',
        severity: def.major ? 'critical' : 'warning',
        explanation: `${def.label} is present on the English page but missing entirely from the translation — on English it holds ${r.links} link(s) and roughly ${words} word(s). This alone can explain element-count gaps below.`,
        suggestion: `Add the ${def.label.toLowerCase()} to the translated page so it mirrors English.`
      });
    } else if(r.textLen > 250 && t.textLen < r.textLen * 0.4){
      const el = regionElement(liveDoc, def);
      issues.push({
        category:'missing',
        severity:'warning',
        explanation: `${def.label} exists but is much smaller than English (about ${Math.round(t.textLen / Math.max(r.textLen,1) * 100)}% of its text). Part of it may be missing.`,
        suggestion: `Review the ${def.label.toLowerCase()} for dropped content.`,
        snippet: el ? srcSnippet(liveRawHtml, el) : ''
      });
    }
  });
  return issues;
}
function isLikelyEnglish(text){
  // crude heuristic: share of common English stopwords among the first words
  if(!text) return false;
  const words = text.toLowerCase().split(/\s+/).filter(Boolean).slice(0, 80);
  if(words.length < 10) return false;
  const stop = new Set(['the','and','to','of','a','in','for','is','on','that','with','your','you','our','we','this','are','or','from','at','by','an','be','as','it','will','more','about','have','can','if','all','not','what','when','how']);
  let hits = 0; words.forEach(w => { if(stop.has(w.replace(/[^a-z]/g,''))) hits++; });
  return hits / words.length > 0.2;
}
function contentChecks(refData, tData, lang, pg){
  const issues = [];
  const add = (severity, category, explanation, suggestion, snippet, items, evidenceLabel) =>
    issues.push({ severity, category, explanation, suggestion: suggestion||'', snippet: snippet||'', items: items||null, evidenceLabel: evidenceLabel||'' });

  // lang attribute correctness
  const want = (lang.gcode||lang.dir||'').toLowerCase().split('-')[0];
  const got = (tData.htmlLang||'').toLowerCase().split('-')[0];
  if(!tData.htmlLang) add('warning','lang attribute',`<html> has no lang attribute. It should declare ${lang.label} (e.g. lang="${lang.gcode||lang.dir}").`,'Set the lang attribute so browsers and search engines know the page language.');
  else if(want && got && got !== want) add('warning','lang attribute',`<html lang="${tData.htmlLang}"> doesn't match the expected ${lang.label} ("${lang.gcode||lang.dir}").`,'Correct the lang attribute to the page\'s actual language.', '', ['Found: lang="'+tData.htmlLang+'"', 'Expected: lang="'+(lang.gcode||lang.dir)+'"'], 'Language attribute');

  // hreflang presence + self reference
  if(!tData.hreflang.length) add('warning','hreflang',`No hreflang alternate tags. Search engines won't know this is the ${lang.label} version of an English page.`,'Add reciprocal hreflang link tags across all language versions.');
  else {
    const codes = tData.hreflang.map(h=>h.lang);
    const wantCode = (lang.gcode||lang.dir||'').toLowerCase();
    const hasSelf = codes.some(c => c === wantCode || c.split('-')[0] === want);
    if(!hasSelf) add('info','hreflang',`hreflang tags are present but none point to this page's own language (${lang.gcode||lang.dir}).`,'Include a self-referential hreflang entry.', '', codes.map(c=>c||'(empty)'), 'hreflang codes present');
  }

  // noindex — Chinese pages are intentionally noindex, so don't flag them
  var _lc = (lang.gcode || lang.dir || '').toLowerCase();
  var _isChinese = _lc.indexOf('zh') === 0 || /chinese/i.test(lang.label || '');
  if(tData.noindex && !_isChinese) add('critical','indexing','This page is set to noindex — it will be excluded from search results.','Remove the noindex directive unless this exclusion is intentional.');

  // canonical
  if(tData.canonical && refData && refData.canonical && tData.canonical === refData.canonical && lang.dir){
    add('critical','canonical',`Canonical URL points to the English page. This tells search engines to ignore the ${lang.label} version.`,'Set the canonical to this page\'s own URL.', '', [tData.canonical], 'Canonical URL');
  } else if(tData.canonical && lang.dir && !tData.canonical.includes('/'+lang.dir)){
    add('warning','canonical',`Canonical URL doesn't include the ${lang.dir} path — verify it points to this translation, not English.`,'Point the canonical at the translated URL.', '', [tData.canonical], 'Canonical URL');
  }

  // untranslated metadata
  if(refData){
    if(tData.title && refData.title && tData.title === refData.title) add('warning','metadata','The page title is identical to English — it may not be translated.','Translate the <title> for this language.', '', [tData.title], 'Title (same on both)');
    if(tData.metaDesc && refData.metaDesc && tData.metaDesc === refData.metaDesc) add('warning','metadata','The meta description is identical to English — it may not be translated.','Translate the meta description.', '', [tData.metaDesc], 'Meta description (same on both)');
  }
  if(!tData.title) add('critical','metadata','Missing page <title>.','Add a translated <title>.');
  else if(tData.titleLen > 65) add('info','metadata',`Title is ${tData.titleLen} characters — may be truncated in search beyond ~60.`,'Shorten the title.', '', [tData.title], 'Current title');
  if(!tData.metaDesc) add('info','metadata','No meta description.','Add a translated meta description (~150 chars).');
  else if(tData.metaDescLen > 165) add('info','metadata',`Meta description is ${tData.metaDescLen} characters — may be truncated beyond ~160.`,'Trim the meta description.', '', [tData.metaDesc], 'Current meta description');

  // untranslated body text
  if(lang.dir && isLikelyEnglish(tData.textContent)){
    const sample = (tData.textContent||'').slice(0, 400);
    add('warning','untranslated',`Body text reads as mostly English on a ${lang.label} page — sections may be untranslated.`,'Review the page for English content that should be translated.', '', [sample + ((tData.textContent||'').length > 400 ? '…' : '')], 'English-looking text on this page');
  }

  // schema parity vs English
  if(refData){
    const refS = refData.schemaTypes||[], tS = tData.schemaTypes||[];
    if(refS.length && !tS.length) add('warning','structured data',`English has structured data but this translation has none.`,'Mirror the schema.org markup on the translated page.', '', refS, 'Schema types on English (missing here)');
    else {
      const missing = refS.filter(t => !tS.includes(t));
      if(missing.length) add('info','structured data',`Translation is missing schema types present on English.`,'Add the missing structured-data types.', '', missing, 'Missing schema types');
    }
  }

  // heading hierarchy
  if(tData.h1Count === 0) add('warning','headings','No H1 heading on the page.','Add a single, descriptive H1.');
  else if(tData.h1Count > 1) add('info','headings',`${tData.h1Count} H1 headings — there should usually be one.`,'Use a single H1 and demote the rest.', '', (tData.headings||[]).filter(h=>h.level===1).map(h=>h.text), 'H1 headings on this page');
  if(tData.headingSkip) add('info','headings','Heading levels skip (e.g. H2 → H4), which hurts structure and accessibility.','Use sequential heading levels.', '', (tData.headings||[]).map(h=>'H'+h.level+': '+h.text), 'Heading outline');

  // word-count parity
  if(refData && refData.words > 120 && tData.words < refData.words * 0.5){
    add('warning','content volume',`This page has ${tData.words} words vs ${refData.words} on English (${Math.round(tData.words/Math.max(refData.words,1)*100)}%). Content may be missing.`,'Compare against English for dropped sections.');
  }

  // placeholders
  if(tData.placeholders.length) add('warning','placeholder text',`Placeholder/boilerplate text found.`,'Replace placeholder text with real translated content.', '', tData.placeholders, 'Placeholder text found');

  return issues;
}
function findDuplicateIds(doc){
  const seen = {}, dups = new Set();
  doc.querySelectorAll('[id]').forEach(el => {
    const id = el.id; if(seen[id]) dups.add(id); else seen[id]=1;
  });
  return [...dups];
}

/* ----------------------------- AI analysis ----------------------------- */
/* ----------------------------- Pattern A: drift from Google source ----------------------------- */
function passKey(){ return ((document.getElementById('pass') && document.getElementById('pass').value) || WORKER_KEY || '').trim(); }
function getNoTranslateTerms(){
  const raw = (document.getElementById('noTranslate') && document.getElementById('noTranslate').value) || '';
  return raw.split(/\r?\n/).map(s=>s.trim()).filter(Boolean).sort((a,b)=> b.length - a.length); // longest first
}
function escapeRegex(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function stripTags(s){ return (s||'').replace(/<[^>]+>/g, ''); }
function decodeEntities(s){
  try { return new DOMParser().parseFromString(s, 'text/html').documentElement.textContent || s; }
  catch(e){ return s; }
}
function protectTerms(text, terms){
  let t = text;
  terms.forEach(term => { if(term) t = t.replace(new RegExp(escapeRegex(term), 'gi'), m => `<span class="notranslate">${m}</span>`); });
  return t;
}
function normForCompare(s){ return (s||'').toLowerCase().replace(/\s+/g,'').replace(/[.,!?;:'"()\[\]{}«»¡¿…\-–—]/g,''); }
function similarity(a, b){
  a = normForCompare(a); b = normForCompare(b);
  if(a === b) return 1;
  if(a.length < 2 || b.length < 2) return a === b ? 1 : 0;
  const grams = s => { const g = new Map(); for(let i=0;i<s.length-1;i++){ const k=s.slice(i,i+2); g.set(k,(g.get(k)||0)+1); } return g; };
  const ga = grams(a), gb = grams(b);
  let inter = 0; ga.forEach((c,k)=>{ if(gb.has(k)) inter += Math.min(c, gb.get(k)); });
  const total = (a.length-1) + (b.length-1);
  return total ? (2*inter)/total : 0;
}

async function googleTranslate(segments, target){
  let tUrl;
  try { const u = new URL(WORKER_URL); u.searchParams.set('translate','1'); tUrl = u.href; }
  catch(e){ tUrl = WORKER_URL + (WORKER_URL.includes('?')?'&':'?') + 'translate=1'; }
  const key = passKey();
  const out = [];
  const CHUNK = 100;
  for(let i=0;i<segments.length;i+=CHUNK){
    const chunk = segments.slice(i, i+CHUNK);
    const res = await fetch(tUrl, {
      method:'POST',
      headers: Object.assign({ 'Content-Type':'application/json' }, key ? { 'X-Audit-Key': key } : {}),
      body: JSON.stringify({ q: chunk, source: SOURCE_GCODE, target, format: 'html' })
    });
    if(!res.ok){
      let d=''; try { d = (await res.text()).slice(0,160); } catch(e){}
      throw new Error('Translate request failed (HTTP ' + res.status + (d?'): '+d:')'));
    }
    const data = await res.json();
    if(data && data.error){ throw new Error('Google error: ' + (data.error.message || 'unknown')); }
    const trs = (data && data.data && data.data.translations) || [];
    chunk.forEach((_, j) => out.push(stripTags(decodeEntities((trs[j] && trs[j].translatedText) || ''))));
  }
  return out;
}

async function driftCheck(refData, transData, lang){
  const terms = getNoTranslateTerms();
  const enSegs = refData.segments || [];
  const liveSegs = transData.segments || [];
  if(!enSegs.length) return { error: 'No comparable text found on the English page.' };

  const toTranslate = terms.length ? enSegs.map(s => protectTerms(s, terms)) : enSegs;
  const expected = await googleTranslate(toTranslate, lang.gcode);

  const issues = [];
  const liveDoc = parseDoc(transData.rawHtml);
  const n = Math.min(expected.length, liveSegs.length);
  let matched = 0;
  const THRESH = 0.6;
  for(let i=0;i<n;i++){
    const sim = similarity(expected[i], liveSegs[i]);
    if(sim >= THRESH){ matched++; }
    else {
      issues.push({
        category:'drift', severity:'warning',
        reference: expected[i].slice(0,300),
        translation: liveSegs[i].slice(0,300),
        explanation:`Published text differs from the Google translation of the English source (about ${Math.round(sim*100)}% similar).`,
        suggestion:'',
        snippet: srcSnippet(transData.rawHtml, findByText(liveDoc, liveSegs[i]))
      });
    }
  }
  if(expected.length !== liveSegs.length){
    issues.unshift({
      category:'drift', severity:'warning',
      explanation:`Segment count differs — ${expected.length} text block(s) expected from the source vs ${liveSegs.length} on the published page. A section may have been added or dropped.`
    });
  }
  const denom = Math.max(expected.length, liveSegs.length) || 1;
  const score = Math.round(matched / denom * 100);
  return { parityScore: score, summary: `${matched} of ${denom} text block(s) match the Google translation of the source.`, issues, engine:'google' };
}

async function analyzeTranslation(refData, transData, refLabel, transLabel){
  const cap = (s) => (s||'').slice(0, 6000);
  const refBlock = 'Headings:\n' + refData.headings.map(h=>'  '.repeat(h.level-1)+'- '+h.text).join('\n') +
    '\n\nBody text:\n' + cap(refData.textContent);
  const transBlock = 'Headings:\n' + transData.headings.map(h=>'  '.repeat(h.level-1)+'- '+h.text).join('\n') +
    '\n\nBody text:\n' + cap(transData.textContent);

  const system = `You are a localization QA reviewer. Compare a reference page (in ${refLabel}) with its ${transLabel} translation. Find: mistranslations, awkward or inaccurate phrasing, tone or register inconsistencies, strings left untranslated in ${refLabel}, content present in the reference but missing from the translation, and content added that is not in the reference. Reply with ONLY a JSON object, no markdown fences and no commentary. Schema: {"parityScore": <0-100 integer>, "summary": "<one or two sentences>", "issues": [{"category": "translation"|"tone"|"untranslated"|"missing"|"added", "severity": "critical"|"warning"|"info", "reference": "<short ${refLabel} snippet or empty>", "translation": "<short ${transLabel} snippet or empty>", "explanation": "<what's wrong>", "suggestion": "<how to fix, or empty>"}]}. If the translation is sound, return an empty issues array and a high parityScore.`;

  const userMsg = `=== REFERENCE (${refLabel}) ===\n${refBlock}\n\n=== TRANSLATION (${transLabel}) ===\n${transBlock}`;

  // Route through the worker (it holds the Anthropic API key and adds CORS).
  let aiUrl;
  try { const u = new URL(WORKER_URL); u.searchParams.set('ai', '1'); aiUrl = u.href; }
  catch(e){ aiUrl = WORKER_URL + (WORKER_URL.includes('?') ? '&' : '?') + 'ai=1'; }

  const key = ((document.getElementById('pass') && document.getElementById('pass').value) || WORKER_KEY || '').trim();
  const res = await fetch(aiUrl, {
    method:'POST',
    headers: Object.assign({ 'Content-Type':'application/json' }, key ? { 'X-Audit-Key': key } : {}),
    body: JSON.stringify({
      model: AI_MODEL,
      max_tokens: 2048,
      system,
      messages: [{ role:'user', content: userMsg }]
    })
  });
  if(!res.ok){
    let detail = '';
    try { detail = (await res.text()).slice(0,160); } catch(e){}
    throw new Error('AI request failed (HTTP ' + res.status + (detail ? '): ' + detail : ')'));
  }
  const data = await res.json();
  if(data && data.type === 'error'){ throw new Error('AI error: ' + (data.error && data.error.message || 'unknown')); }
  const txt = (data.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('\n');
  const cleaned = txt.replace(/```json/gi,'').replace(/```/g,'').trim();
  const parsed = JSON.parse(cleaned);
  const liveDoc = parseDoc(transData.rawHtml);
  (parsed.issues||[]).forEach(is => {
    const el = findByText(liveDoc, is.translation || is.reference);
    if(el) is.snippet = srcSnippet(transData.rawHtml, el);
  });
  return parsed;
}

/* ----------------------------- orchestration ----------------------------- */
let auditState = null;

function flagPassphrase(msg){
  const el = document.getElementById('pass');
  const err = document.getElementById('passError');
  if(err){ err.textContent = msg; err.style.display = 'block'; }
  if(el){
    el.classList.add('input-error');
    el.scrollIntoView({ behavior:'smooth', block:'center' });
    setTimeout(() => el.focus(), 300);
    el.addEventListener('input', () => {
      el.classList.remove('input-error');
      if(err) err.style.display = 'none';
    }, { once:true });
  }
}

function runAudit(){ requestRunAudit(); }
function requestRunAudit(){
  var m = document.getElementById('runModal');
  var c = document.getElementById('runConfirm'), pr = document.getElementById('runProgress');
  if(c) c.style.display = '';
  if(pr) pr.style.display = 'none';
  if(m){ m.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
}
function cancelRunAudit(){ closeRunModal(); }
function confirmRunAudit(){
  var c = document.getElementById('runConfirm'), pr = document.getElementById('runProgress');
  if(c) c.style.display = 'none';
  if(pr) pr.style.display = '';
  setBar(0);
  executeAudit();
}
async function executeAudit(){
  if(!WORKER_URL || WORKER_URL.includes('your-worker')){
    closeRunModal(); setProgress('Set WORKER_URL in the config block at the top of this file before running.', true); return;
  }
  if(!SITE_URL){ closeRunModal(); setProgress('Set SITE_URL in the config block at the top of this file before running.', true); return; }
  const site = SITE_URL;
  const activePages = getAuditPages();
  if(!activePages.length){ closeRunModal(); setProgress('Discover pages or add at least one page.', true); return; }

  // passphrase validation — empty, then verify the worker accepts it
  const passEl = document.getElementById('pass');
  const key = ((passEl && passEl.value) || WORKER_KEY || '').trim();
  if(!key){ closeRunModal(); flagPassphrase('Enter your access passphrase before running the audit.'); return; }
  setProgress('Checking access…');
  const pf = await fetchPage(SITE_URL);
  if(pf.status === 403 && /passphrase|forbidden/i.test(pf.text || '')){
    closeRunModal();
    flagPassphrase('The worker rejected this passphrase. Check that it matches the worker’s AUDIT_KEY.');
    setProgress('');
    return;
  }

  const refLang = langs.find(l=>l.ref);
  const transLangs = langs.filter(l=>!l.ref);
  const conc = 2;
  const exclDirs = getExcludeDirs();
  try { statePut('excludeDirs', { dirs: exclDirs, updated: new Date().toISOString() }).catch(function(){}); } catch(e){}

  var _rb = document.getElementById('runBtn'); if(_rb) _rb.disabled = true;
  document.getElementById('results').innerHTML = '';
  var _gd = document.getElementById('genDone'); if(_gd) _gd.style.display = 'none';
  var _bw = document.getElementById('barWrap'); if(_bw) _bw.style.display = 'block';

  auditState = { results: [], crit:0, warn:0, info:0, broken:0, pages:0 };
  linkCache.clear();

  const totalUnits = activePages.length;
  let done = 0;
  let auditOk = true;

  try {
  for(const pg of activePages){
    setProgress(`Auditing “${pg.name}”…`);
    const result = { page: pg, languages: [], refData: null, refError: null };

    // fetch reference
    let refData = null;
    const refUrl = buildUrl(site, refLang.dir, pg.path);
    {
      const r = await fetchPage(refUrl);
      if(r.ok){ refData = extract(r.text, refUrl); }
      else { result.refError = r.error ? r.error : ('HTTP ' + r.status); }
      result.refData = refData;
      result.enFp = refData ? contentFingerprint(refData) : null;
      result.refStatus = r.status;
      result.refUrl = refUrl;
    }

    // reference technical pass (links + code)
    if(refData){
      result.refTech = await technicalPass(refData, refLang.label, conc, auditState);
    }

    // English-only sections (e.g. newsroom): audit English/technical only, skip translations
    result.englishOnly = pathIsExcluded(pg.path, exclDirs);

    // each translation
    if(!result.englishOnly)
    for(const tl of transLangs){
      const url = buildUrl(site, tl.dir, pg.path);
      setProgress(`Auditing “${pg.name}” — ${tl.label}…`);
      const block = { lang: tl, url };
      const tr = await fetchPage(url);
      if(!tr.ok){ block.error = tr.error ? tr.error : ('HTTP ' + tr.status); result.languages.push(block); auditState.crit++; continue; }
      block.status = tr.status;
      const tData = extract(tr.text, url);
      block.data = tData;
      block.trFp = contentFingerprint(tData);

      // technical pass for this language
      block.tech = await technicalPass(tData, tl.label, conc, auditState);

      // structural parity vs reference: regions first, then counts
      if(refData){
        const regionIssues = regionDiff(refData.regions, tData.regions, parseDoc(tData.rawHtml), tData.rawHtml);
        const missingMajor = regionIssues.some(i => i.severity === 'critical');
        const countIssues = structuralDiff(refData, tData, missingMajor);
        block.parity = [...regionIssues, ...countIssues];
        block.parity.forEach(i => bump(auditState, i.severity));
      }

      // content-quality checks (SEO, metadata, freshness, coverage signals)
      block.content = contentChecks(refData, tData, tl, pg);
      block.content.forEach(i => bump(auditState, i.severity));

      // translation analysis — Google drift (Pattern A) and/or Claude
      const transOn = document.getElementById('transToggle') && document.getElementById('transToggle').checked;
      if(refData && transOn){
        const engine = (document.getElementById('engine') && document.getElementById('engine').value) || 'google';
        if(engine === 'google' || engine === 'both'){
          try {
            const d = await driftCheck(refData, tData, tl);
            if(d.error){ block.driftError = d.error; }
            else { block.drift = d; (d.issues||[]).forEach(i => bump(auditState, i.severity)); }
          } catch(e){ block.driftError = e.message; }
        }
        if(engine === 'claude' || engine === 'both'){
          try {
            const ai = await analyzeTranslation(refData, tData, refLang.label, tl.label);
            block.ai = ai;
            (ai.issues||[]).forEach(i => bump(auditState, i.severity));
          } catch(e){ block.aiError = e.message; }
        }
      } else if(transOn && !refData){
        block.driftError = 'No English reference page to compare against.';
      }
      result.languages.push(block);
    }

    auditState.results.push(result);
    auditState.pages++;
    renderResult(result, refLang);
    done++;
    setBar(done/totalUnits*100);
  }

  setProgress('Audit complete — ' + auditState.pages + ' page(s) reviewed.');
  setBar(100);
  } catch(err){
    auditOk = false;
    setProgress('Audit stopped: ' + (err && err.message ? err.message : String(err)), true);
  } finally {
    var _rb2 = document.getElementById('runBtn'); if(_rb2) _rb2.disabled = false;
    closeRunModal();
  }
  if(auditOk) renderSummary();
}

function bump(s, sev){ if(sev==='critical') s.crit++; else if(sev==='warning') s.warn++; else s.info++; }

async function technicalPass(data, label, conc, state){
  const tech = { code: [], links: [] };
  const doc = parseDoc(data.rawHtml);
  const firstEmptyLink = doc ? [...doc.querySelectorAll('a')].find(a => { const h=a.getAttribute('href'); return !h || h==='#' || h.trim()===''; }) : null;
  const pushCode = (sev, text, el, items, evidenceLabel) => tech.code.push({ sev, text, snippet: el ? srcSnippet(data.rawHtml, el) : '', items: items||null, evidenceLabel: evidenceLabel||'' });
  // code-level issues
  if(data.emptyLinks){
    const empties = doc ? [...doc.querySelectorAll('a')].filter(a => { const h=a.getAttribute('href'); return !h || h==='#' || h.trim()===''; }).map(a => (clean(a.textContent) || '(empty link text)')) : null;
    pushCode('warning', data.emptyLinks + ' empty or placeholder link(s) (href="#" or blank).', firstEmptyLink, empties, 'Empty links (by their text)');
  }
  if(data.missingAlt){
    const noAlt = (data.images || []).filter(i => i.alt === null).map(i => imgName(i.src));
    pushCode('warning', data.missingAlt + ' image(s) without alt text.', doc && doc.querySelector('img:not([alt])'), noAlt, 'Images missing alt text');
  }
  if(data.duplicateIds.length) pushCode('warning', data.duplicateIds.length + ' duplicate id attribute(s).', doc && doc.getElementById(data.duplicateIds[0]), data.duplicateIds, 'Duplicate ids');
  if(!data.title) pushCode('critical', 'Missing <title>.', null);
  if(!data.metaDesc) pushCode('info', 'No meta description.', null);
  if(!data.htmlLang) pushCode('warning', 'Missing lang attribute on <html>.', null);
  tech.code.forEach(c => bump(state, c.sev));

  // link verification — report only genuinely broken links; ignore auth/blocked (401/403/429)
  const broken = [];
  if(data.links.length){
    const checked = await pool(data.links, checkResource, conc);
    checked.forEach(c => {
      if(c.ok) return;
      if(c.status === 401 || c.status === 403 || c.status === 429 || c.blocked) return; // responded but refused us — ignore
      broken.push(Object.assign({}, c, { snippet: srcSnippet(data.rawHtml, findAnchor(doc, c.url, data.baseUrl)) })); // 404, 410, 5xx, no response
    });
  }
  tech.links = broken;
  tech.linksChecked = data.links.length;
  tech.linksTotal = data.links.length;
  state.broken += broken.length;
  return tech;
}

function imgName(src){
  if(!src) return '(no src)';
  try { const u = new URL(src); src = u.pathname; } catch(e){}
  const base = src.split('/').filter(Boolean).pop() || src;
  return base.split('?')[0];
}
function structuralDiff(ref, trans, hasMissingRegion){
  const issues = [];
  const fields = [
    ['headings','headings'], ['images','images'], ['links','links'],
    ['forms','forms'], ['inputs','form fields'], ['buttons','buttons']
  ];
  fields.forEach(([key, name]) => {
    const a = ref.counts[key], b = trans.counts[key];
    if(a !== b){
      const missing = a - b;
      let severity = Math.abs(missing) >= Math.max(2, a*0.3) ? 'warning' : 'info';
      let note = '';
      if(hasMissingRegion && missing > 0){ severity = 'info'; note = ' (likely accounted for by the missing section above)'; }

      // attach the actual evidence where we can identify specific items
      let items = null, evidenceLabel = '';
      if(key === 'links'){
        const tSet = new Set(trans.links || []);
        const rSet = new Set(ref.links || []);
        const onlyEn = (ref.links || []).filter(u => !tSet.has(u));
        const onlyTr = (trans.links || []).filter(u => !rSet.has(u));
        if(missing > 0 && onlyEn.length){ items = onlyEn; evidenceLabel = 'Links on English but not on this page'; }
        else if(missing < 0 && onlyTr.length){ items = onlyTr; evidenceLabel = 'Links on this page but not on English'; }
      } else if(key === 'images'){
        const tNames = (trans.images || []).map(i => imgName(i.src));
        const rNames = (ref.images || []).map(i => imgName(i.src));
        const tSet = new Set(tNames), rSet = new Set(rNames);
        const onlyEn = rNames.filter(n => !tSet.has(n));
        const onlyTr = tNames.filter(n => !rSet.has(n));
        if(missing > 0 && onlyEn.length){ items = onlyEn; evidenceLabel = 'Images on English but not on this page'; }
        else if(missing < 0 && onlyTr.length){ items = onlyTr; evidenceLabel = 'Images on this page but not on English'; }
      } else if(key === 'headings'){
        // heading text differs by language, so show both lists rather than a diff
        const rH = (ref.headings || []).map(h => 'H' + h.level + ': ' + h.text);
        const tH = (trans.headings || []).map(h => 'H' + h.level + ': ' + h.text);
        items = ['— English (' + rH.length + ') —', ...rH, '— This page (' + tH.length + ') —', ...tH];
        evidenceLabel = 'Headings on both pages';
      }

      issues.push({
        category:'count',
        severity,
        explanation: missing > 0
          ? `Translation has ${b} ${name} vs ${a} in English — ${missing} fewer${note}.`
          : `Translation has ${b} ${name} vs ${a} in English — ${-missing} extra.`,
        items, evidenceLabel
      });
    }
  });
  return issues;
}

/* ----------------------------- result rendering ----------------------------- */
function renderResult(result, refLang){
  const wrap = document.getElementById('results');
  const det = document.createElement('details');
  det.className = 'page-result';
  det.open = false;

  // count issues for this page
  let c=0,w=0,i=0,broken=0;
  const tally = (sev) => { if(sev==='critical')c++; else if(sev==='warning')w++; else i++; };
  if(result.refTech){ result.refTech.code.forEach(x=>tally(x.sev)); broken += result.refTech.links.length; }
  result.languages.forEach(b => {
    if(b.error) c++;
    if(b.tech){ b.tech.code.forEach(x=>tally(x.sev)); broken += b.tech.links.length; }
    (b.parity||[]).forEach(x=>tally(x.severity));
    (b.content||[]).forEach(x=>tally(x.severity));
    (b.ai && b.ai.issues || []).forEach(x=>tally(x.severity));
  });

  const pills = [];
  if(c) pills.push(`<span class="pill crit">${c} critical</span>`);
  if(w) pills.push(`<span class="pill warn">${w} warnings</span>`);
  if(broken) pills.push(`<span class="pill crit">${broken} broken links</span>`);
  if(!c && !w && !broken) pills.push(`<span class="pill ok">clean</span>`);

  const summary = document.createElement('summary');
  summary.innerHTML = `<span class="chev">▶</span>
    <span><span class="title">${escapeHtml(result.page.name)}</span></span>
    <span class="spacer"></span>${pills.join(' ')}`;
  det.appendChild(summary);

  const body = document.createElement('div');
  body.className = 'result-body';

  // reference page block (technical only)
  if(result.refError){
    body.innerHTML += `<div class="lang-block"><h4>${escapeHtml(refLang.label)} (reference)</h4>
      <div class="err-note">Could not load reference page: ${escapeHtml(result.refError)}</div></div>`;
  } else if(result.refData){
    body.innerHTML += `<div class="lang-block"><h4>${escapeHtml(refLang.label)} (reference)</h4>
      <div class="url-sub">${escapeHtml(result.refUrl)}</div>
      ${renderTech(result.refTech)}</div>`;
  }

  // translation blocks
  result.languages.forEach(b => {
    let html = `<div class="lang-block"><h4>${escapeHtml(b.lang.label)}</h4>`;
    html += `<div class="url-sub">${escapeHtml(b.url)}</div>`;
    if(b.error){
      html += `<div class="err-note">Could not load page: ${escapeHtml(b.error)}</div></div>`;
      body.innerHTML += html; return;
    }

    // Google drift (Pattern A)
    if(b.drift || b.driftError){
      html += `<div class="section-label">Drift from Google source</div>`;
      if(b.driftError){
        html += `<div class="err-note">Check unavailable: ${escapeHtml(b.driftError)}</div>`;
      } else if(b.drift){
        html += `<div class="score">Match score: ${b.drift.parityScore}/100 — ${escapeHtml(b.drift.summary||'')}</div>`;
        const di = b.drift.issues||[];
        if(di.length){ di.forEach(is => html += renderIssue(is)); }
        else { html += `<div class="clean">Published page matches the Google translation of the source.</div>`; }
      }
    }

    // Claude analysis
    if(b.ai || b.aiError){
      html += `<div class="section-label">Translation &amp; tone (Claude)</div>`;
      if(b.aiError){
        html += `<div class="err-note">Analysis unavailable: ${escapeHtml(b.aiError)}</div>`;
      } else if(b.ai){
        if(typeof b.ai.parityScore === 'number'){
          html += `<div class="score">Parity score: ${b.ai.parityScore}/100 — ${escapeHtml(b.ai.summary||'')}</div>`;
        }
        const aiIssues = (b.ai.issues||[]);
        if(aiIssues.length){ aiIssues.forEach(is => html += renderIssue(is)); }
        else { html += `<div class="clean">No translation issues found.</div>`; }
      }
    }

    // content parity
    html += `<div class="section-label">Page sections &amp; content parity</div>`;
    if(b.parity && b.parity.length){
      b.parity.forEach(is => html += renderIssue(is));
    } else {
      html += `<div class="clean">All major sections present and element counts match English.</div>`;
    }

    // content & SEO quality
    html += `<div class="section-label">Content &amp; SEO</div>`;
    if(b.content && b.content.length){
      b.content.forEach(is => html += renderIssue(is));
    } else {
      html += `<div class="clean">No metadata, hreflang, indexing, or content-quality issues found.</div>`;
    }

    // technical
    html += renderTech(b.tech);
    html += `</div>`;
    body.innerHTML += html;
  });

  det.appendChild(body);
  wrap.appendChild(det);
}

function renderTech(tech){
  if(!tech) return '';
  let html = `<div class="section-label">Code &amp; rendering</div>`;
  if(tech.code.length){
    tech.code.forEach(c => html += renderIssue({ category:'code', severity:c.sev, explanation:c.text, snippet:c.snippet }));
  } else {
    html += `<div class="clean">No code-level issues detected.</div>`;
  }
  html += `<div class="section-label">Links${tech.linksChecked!=null?` (checked ${tech.linksChecked})`:''}</div>`;
  if(tech.links && tech.links.length){
    html += `<ul class="tech">`;
    tech.links.forEach(l => {
      const code = l.status ? l.status : 'no response';
      const row = `<span class="code bad">${code}</span><a href="${escapeAttr(l.url)}" target="_blank" rel="noopener">${escapeHtml(l.url)}</a>`;
      if(l.snippet){
        html += `<li><details class="snip-d"><summary>${row}<span class="snip-hint">▸ markup</span></summary><pre class="snip">${l.snippet}</pre></details></li>`;
      } else {
        html += `<li>${row}</li>`;
      }
    });
    html += `</ul>`;
  } else {
    html += `<div class="clean">${tech.linksChecked? 'All links resolved (no 404s or server errors).' : 'No outbound links to check.'}</div>`;
  }
  return html;
}

function renderIssue(is){
  const sev = is.severity || 'info';
  let inner = `<div class="ihead"><span class="cat">${escapeHtml(is.category||'issue')}</span></div>`;
  inner += `<p class="exp">${escapeHtml(is.explanation||'')}</p>`;
  if(is.suggestion) inner += `<div class="sugg">→ ${escapeHtml(is.suggestion)}</div>`;
  if(is.snippet){
    return `<details class="issue ${sev} snip-issue"><summary>${inner}<span class="snip-hint">▸ show source</span></summary><pre class="snip">${is.snippet}</pre></details>`;
  }
  return `<div class="issue ${sev}">${inner}</div>`;
}

function renderSummary(){
  const s = auditState;
  markDashStale();
  const done = document.getElementById('genDone');
  if(done){
    done.style.display = 'block';
    done.innerHTML = 'Audit complete — <strong>' + s.pages + '</strong> page(s) reviewed · '
      + s.crit + ' critical · ' + s.warn + ' warning · ' + s.broken + ' broken link(s). '
      + 'Open your <a data-click="showPage(\'leaders\')">Admin dashboard</a> &middot; '
      + '<a data-click="showPage(\'authors\')">Authors dashboard</a>.';
  }
  showPage('leaders');
}

/* ----------------------------- helpers ----------------------------- */
function clean(s){ return (s||'').replace(/\s+/g,' ').trim(); }
function escapeHtml(s){ return (s==null?'':String(s)).replace(/[&<>]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m])); }
function escapeAttr(s){ return (s==null?'':String(s)).replace(/[&<>"]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])); }
function setProgress(msg, warn){
  ['progress','modalProgress'].forEach(function(id){
    const el = document.getElementById(id);
    if(!el) return;
    if(id === 'modalProgress' && !warn && msg){ el.innerHTML = '<span class="run-spinner"></span>' + msg; }
    else { el.textContent = msg; }
    el.style.color = warn ? 'var(--critical)' : 'var(--muted)';
  });
}
function setBar(pct){
  ['bar','modalBar'].forEach(function(id){ var el=document.getElementById(id); if(el) el.style.width = pct + '%'; });
}
function scrollTopSmooth(){ try { window.scrollTo({ top:0, behavior:'smooth' }); } catch(e){ window.scrollTo(0,0); } }
function openRunModal(){
  var m = document.getElementById('runModal');
  if(m){ m.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
  setBar(0);
}
function closeRunModal(){
  var m = document.getElementById('runModal');
  if(m){ m.style.display = 'none'; }
  document.body.style.overflow = '';
}

/* ----------------------------- init ----------------------------- */
(function initConfigDisplay(){
  const siteEl = document.getElementById('cfgSite');
  try { siteEl.textContent = new URL(SITE_URL).host; } catch(e){ siteEl.textContent = SITE_URL || '(SITE_URL not set)'; }
  if(WORKER_KEY) document.getElementById('pass').value = WORKER_KEY;
})();
renderPages();
updateRunHint();
onTransToggle();
window.addEventListener('message', function(e){
  if(e.data && typeof e.data.dashHeight === 'number'){
    const f = document.getElementById('dashFrame');
    if(f) f.style.height = (e.data.dashHeight + 24) + 'px';
  }
  else if(e.data && e.data.__mlaudit === 'triage'){
    setTriage(e.data.key, e.data.status);
  }
  else if(e.data && e.data.__mlaudit === 'pdf'){
    exportReportPDF(e.data.view);
  }
  else if(e.data && e.data.__mlaudit === 'exportcsv'){
    exportPowerBICsv();
  }
  else if(e.data && e.data.__mlaudit === 'runAudit'){
    if(userRole === 'admin') runAudit();
  }
  else if(e.data && e.data.__mlaudit === 'publish'){
    publishRun().then(function(ok){ ackToFrame('publish', !!ok); });
  }
  else if(e.data && e.data.__mlaudit === 'scan404'){
    if(userRole === 'admin'){
      var fr = document.getElementById('dashFrame');
      function post(p){ try { fr && fr.contentWindow.postMessage({ __mlaudit_scan: p }, '*'); } catch(e){} }
      post({ phase:'start' });
      scanSitemap404s(function(done, total){ post({ phase:'progress', done:done, total:total }); })
        .then(function(rec){ post({ phase:'done', rec:rec }); });
    }
  }
});
function ackToFrame(action, ok){
  var f = document.getElementById('dashFrame');
  try { f && f.contentWindow.postMessage({ __mlaudit_ack: action, ok: ok, at: new Date().toISOString() }, '*'); } catch(e){}
}
(function restoreSession(){
  try {
    var s = JSON.parse(sessionStorage.getItem('mlaudit-session') || 'null');
    if(s && s.role){
      var pf = document.getElementById('pass'); if(pf && s.pass) pf.value = s.pass;
      pickRole(s.role);
      enterApp(s.role);
      return;
    }
  } catch(e){}
  var pf2 = document.getElementById('pass'); if(pf2) pf2.focus();
})();
