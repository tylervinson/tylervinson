/* Toolbar click opens the dashboard (focusing it if already open).
   The side panel is opened from a button on the dashboard, which is a user gesture. */
const DASH = 'dashboard.html';
const SITE = 'https://www.azblue.com/';

chrome.action.onClicked.addListener(async (tab) => {
  const url = chrome.runtime.getURL(DASH);
  const open = await chrome.tabs.query({ url });
  if (open.length) {
    await chrome.tabs.update(open[0].id, { active: true });
    await chrome.windows.update(open[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
});

/* Panel is available on azblue.com and on our own pages; disabled elsewhere. */
async function syncPanel(tabId, url) {
  if (!url) return;
  const on = url.startsWith(SITE) || url.startsWith(chrome.runtime.getURL(''));
  try { await chrome.sidePanel.setOptions({ tabId, path: 'sidepanel.html', enabled: on }); }
  catch (e) { /* tab may be gone */ }
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'loading' || info.url) syncPanel(tabId, tab.url);
});
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try { const t = await chrome.tabs.get(tabId); syncPanel(tabId, t.url); } catch (e) {}
});

/* The dashboard asks us to open azblue.com; the panel asks us to open the dashboard. */
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg && msg.type === 'openSite') {
    chrome.tabs.create({ url: msg.url || SITE });
    respond({ ok: true });
  }
  if (msg && msg.type === 'openDashboard') {
    const url = chrome.runtime.getURL(DASH);
    chrome.tabs.query({ url }).then((open) => {
      if (open.length) chrome.tabs.update(open[0].id, { active: true });
      else chrome.tabs.create({ url });
    });
    respond({ ok: true });
  }
  return true;
});
