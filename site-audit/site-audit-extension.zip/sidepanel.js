/* Side panel — shows findings for the page in the active tab.
   Reads the published run from the state Worker; falls back to a clear empty state. */
const CFG = (typeof window !== 'undefined' && window.AUDIT_CONFIG) || {};
const STATE_URL = CFG.STATE_URL || 'https://audit-state.bcbs-of-az.workers.dev/';
const SITE = 'https://www.azblue.com';
const HOST = 'www.azblue.com';

const body = document.getElementById('panelBody');
let RUN = null, TRIAGE = {}, KEY = '';

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g,
  (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* azblue URL -> audit path (no leading slash, language prefix stripped) */
function toPath(url) {
  try {
    const u = new URL(url);
    if (u.hostname !== HOST && u.hostname !== 'azblue.com') return null;
    let p = u.pathname.replace(/^\/+|\/+$/g, '');
    const seg = p.split('/');
    if (seg.length && /^(es|zh|zh-hant|zh-hans)$/i.test(seg[0])) seg.shift();
    return seg.join('/');
  } catch (e) { return null; }
}
const norm = (p) => {
  const s = String(p == null ? '' : p).trim();
  return s === '(home)' ? '' : s.replace(/^\/+|\/+$/g, '');
};

async function loadState() {
  const stored = await chrome.storage.local.get(['auditKey']);
  KEY = CFG.ACCESS_KEY || stored.auditKey || '';
  if (!KEY || KEY === 'CHANGE_ME') return { needKey: true };
  const get = async (key) => {
    const r = await fetch(STATE_URL + '?key=mlaudit:' + HOST + ':' + key,
      { headers: { 'X-Audit-Key': KEY } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const t = await r.text();
    return t ? JSON.parse(t) : null;
  };
  const [run, triage] = await Promise.all([get('run').catch(() => null), get('triage').catch(() => ({}))]);
  RUN = run && run.data ? run.data : null;
  TRIAGE = triage || {};
  return { ok: !!RUN };
}

function findingsFor(path) {
  if (!RUN || !Array.isArray(RUN.findings)) return [];
  return RUN.findings.filter((f) => norm(f.path) === path);
}
function missingFor(path) {
  if (!RUN || !Array.isArray(RUN.missingTranslations)) return [];
  return RUN.missingTranslations.filter((m) => norm(m.path) === path);
}

const SEV = { critical: 'c', warning: 'w', info: 'i' };

function render(state, path, pageName) {
  if (state.needKey) return empty('Not configured',
    'Set ACCESS_KEY in the extension\u2019s config.js, then reload the extension.');
  if (path === null || path === undefined) return empty('Not an azblue.com page',
    'Browse to a page on azblue.com to see its findings here.');
  if (!RUN) return empty('No published run',
    'Publish a run from the dashboard to populate the panel.');

  const rows = findingsFor(path);
  const missing = missingFor(path);
  if (!rows.length && !missing.length) return empty('No findings',
    'This page came back clean in the last audit — or it wasn\u2019t part of the run.');

  const counts = { critical: 0, warning: 0, info: 0 };
  rows.forEach((f) => { if (counts[f.severity] != null) counts[f.severity]++; });

  const langs = [...new Set(rows.map((f) => f.lang).filter(Boolean))];
  const trHtml = langs.map((l) => {
    const bad = missing.some((m) => m.lang === l);
    return '<div class="tr"><span class="lg">' + esc(l) + '</span>'
      + '<span class="st ' + (bad ? 'bad' : 'ok') + '">' + (bad ? '404' : 'Live') + '</span></div>';
  }).join('');

  CURRENT_ROWS = rows;
  const fHtml = rows.map((f, i) => {
    const st = TRIAGE[f.key] && TRIAGE[f.key].status;
    const done = st === 'done' || st === 'ignored';
    return '<div class="f' + (done ? ' done' : '') + '" data-i="' + i + '">'
      + '<div class="f-top">'
      + '<span class="sev ' + (SEV[f.severity] || 'i') + '">' + esc(f.severity) + '</span>'
      + '<div class="f-mid"><div class="f-cat">' + esc(f.category) + '</div>'
      + '<div class="f-det">' + esc(f.detail || '') + '</div>'
      + (f.lang ? '<span class="f-lang">' + esc(f.lang) + '</span>' : '')
      + '</div><span class="f-chev">&#9654;</span></div>'
      + '<div class="f-body">'
      + (f.suggestion ? '<p class="f-sug">&rarr; ' + esc(f.suggestion) + '</p>' : '')
      + evidenceHtml(f)
      + '<div class="acts"><button class="act" data-done="' + esc(f.key) + '">'
      + (done ? 'Done \u2713' : 'Mark done') + '</button></div>'
      + '</div></div>';
  }).join('');

  body.innerHTML =
    '<div class="cur"><div class="cur-lab"><span class="dot"></span>Current page</div>'
    + '<div class="cur-nm">' + esc(pageName || path || 'Home') + '</div>'
    + '<div class="cur-pt">/' + esc(path) + '</div>'
    + '<div class="chips">'
    + (counts.critical ? '<span class="chip c">' + counts.critical + ' critical</span>' : '')
    + (counts.warning ? '<span class="chip w">' + counts.warning + ' warnings</span>' : '')
    + (counts.info ? '<span class="chip i">' + counts.info + ' info</span>' : '')
    + '</div></div>'
    + '<div class="body">'
    + (trHtml ? '<div class="sec"><div class="sec-h">Translations</div>' + trHtml + '</div>' : '')
    + '<div class="sec"><div class="sec-h">Findings <span class="n">' + rows.length + '</span></div>'
    + fHtml + '</div></div>';
}

function evidenceHtml(f) {
  const items = Array.isArray(f.items) ? f.items.filter(Boolean) : [];
  let out = '';
  if (items.length) {
    const shown = items.slice(0, 8);
    out += '<div class="f-ev-lab">' + esc(f.evidenceLabel || 'Found on the page') + '</div>'
      + '<ul class="f-ev-list">'
      + shown.map((i) => '<li>' + esc(String(i).slice(0, 160)) + '</li>').join('')
      + (items.length > shown.length ? '<li class="more">+' + (items.length - shown.length) + ' more</li>' : '')
      + '</ul>';
  }
  if (f.snippet) out += '<div class="f-ev">' + esc(String(f.snippet).slice(0, 400)) + '</div>';
  return out;
}

function empty(title, hint) {
  body.innerHTML = '<div class="empty-state">'
    + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16v.5"/></svg>'
    + '<p>' + esc(title) + '</p><div class="hintline">' + esc(hint) + '</div></div>';
}

async function refresh() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const path = tab ? toPath(tab.url) : null;
  let state = { ok: !!RUN };
  if (!RUN) { try { state = await loadState(); } catch (e) { state = { ok: false }; } }
  let name = '';
  if (RUN && Array.isArray(RUN.pages) && path !== null && path !== undefined) {
    const hit = RUN.pages.find((p) => norm(p.path) === path);
    if (hit) name = hit.name || hit.page || '';
  }
  render(state, path, name);
}

let CURRENT_ROWS = [];

/* Build a locator spec from a finding and ask the content script to highlight it. */
function specFor(f) {
  const urls = [];
  (f.items || []).forEach((it) => {
    const m = String(it).match(/https?:\/\/[^\s)"']+|\/[^\s)"']+/);
    if (m) urls.push(m[0]);
  });
  return { category: f.category || '', detail: f.detail || '', urls,
           items: (f.items || []).map((x) => String(x)), text: f.snippet || '' };
}
async function highlight(spec) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || toPath(tab.url) === null) return null;
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: 'sa-highlight', spec });
  } catch (e) {
    // page predates the install — inject on demand, then retry
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      return await chrome.tabs.sendMessage(tab.id, { type: 'sa-highlight', spec });
    } catch (e2) { return null; }
  }
}
async function clearHighlight() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try { await chrome.tabs.sendMessage(tab.id, { type: 'sa-highlight', clearOnly: true }); } catch (e) {}
}

/* expand / triage */
body.addEventListener('click', async (e) => {
  const doneBtn = e.target.closest('[data-done]');
  if (doneBtn) {
    e.stopPropagation();
    const key = doneBtn.getAttribute('data-done');
    const card = doneBtn.closest('.f');
    const now = !card.classList.contains('done');
    card.classList.toggle('done', now);
    doneBtn.textContent = now ? 'Done \u2713' : 'Mark done';
    if (now) TRIAGE[key] = { status: 'done', at: new Date().toISOString() };
    else delete TRIAGE[key];
    try {
      await fetch(STATE_URL + '?key=mlaudit:' + HOST + ':triage',
        { method: 'PUT', headers: { 'X-Audit-Key': KEY, 'Content-Type': 'application/json' },
          body: JSON.stringify(TRIAGE) });
    } catch (err) { console.warn('triage save failed', err); }
    return;
  }
  const top = e.target.closest('.f-top');
  if (top) {
    const card = top.parentElement;
    const opening = !card.classList.contains('open');
    body.querySelectorAll('.f.open').forEach((c) => { if (c !== card) c.classList.remove('open'); });
    card.classList.toggle('open', opening);
    if (!opening) { clearHighlight(); return; }
    const f = CURRENT_ROWS[+card.getAttribute('data-i')];
    if (!f) return;
    const hint = card.querySelector('.hl-note');
    if (hint) hint.remove();
    highlight(specFor(f)).then((res) => {
      const note = document.createElement('div');
      note.className = 'hl-note';
      if (res && res.count) {
        note.textContent = 'Highlighted ' + res.count + ' element' + (res.count === 1 ? '' : 's') + ' on the page';
      } else if (res) {
        note.textContent = (f.items && f.items.length)
          ? 'Couldn\u2019t find this on the page \u2014 the text above may have changed since the audit.'
          : 'This issue isn\u2019t tied to a visible element (check the page source or CMS).';
      } else {
        note.textContent = 'Open an azblue.com page to highlight this.';
      }
      const bodyEl = card.querySelector('.f-body');
      if (bodyEl) bodyEl.appendChild(note);
    });
  }
});

document.getElementById('refreshBtn').addEventListener('click', () => { RUN = null; refresh(); });
document.getElementById('dashBtn').addEventListener('click',
  () => chrome.runtime.sendMessage({ type: 'openDashboard' }));

chrome.tabs.onActivated.addListener(refresh);
chrome.tabs.onUpdated.addListener((id, info, tab) => { if (info.status === 'complete' && tab.active) refresh(); });
refresh();
