# AZ Blue Site Audit — Chrome extension (v3.1)

Packages the audit tool as an extension: the full dashboard, a side panel that
shows findings for the azblue.com page you're currently viewing, and the AEP
launch comparison workflow.

## Install (unpacked, for testing)

1. Chrome → `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. **Load unpacked** → select this folder
4. Pin the extension to the toolbar

## Use

- **Click the toolbar icon** → on azblue.com it docks the review panel; anywhere else it opens the dashboard
- **"Review on site"** (in the dashboard tab bar) → opens azblue.com *and* the side panel
- The panel follows you as you browse and shows that page's findings
- **"Full dashboard"** in the panel → jumps back to the dashboard tab

Pick Admin or Author on first load — no passphrase. The access key that
authenticates the state Worker lives in `config.js`.

**Before first use:** open `config.js` and set `ACCESS_KEY` to the Worker's
`AUDIT_KEY` value. The extension can't reach shared state until you do.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest |
| `background.js` | Toolbar click, per-tab panel availability, tab messaging |
| `dashboard.html` / `dashboard.js` | The tool (scripts externalised for MV3) |
| `actions.js` | Delegated handler dispatcher (replaces inline `onclick`) |
| `dashview.js` | Runs inside the dashboard iframe (generated from `dashboard.js`) |
| `sidepanel.html` / `sidepanel.js` | Per-page review panel |
| `config.js` | Access key + endpoints, shared by both surfaces |
| `content.js` | Highlights/scrolls to the element a finding refers to |
| `ext-glue.js` | Adds the "Review on site" button when running as an extension |

## AEP Launch (v3.1)

Admin-only tab with two independent workflows:

- **Pre-launch validation** — baseline production, audit staging, then review what
  the release will change and anything incomplete on staging.
- **Post-launch verification** — capture production before and after the deploy,
  then compare. The *Unchanged* list is the miss list.

Snapshots are stored in the shared KV store, so the team sees the same set. The
environment of a snapshot is recorded from the run that produced it, not chosen
by hand, so a staging capture can't be mislabeled as production.

**Staging requires a host permission.** `https://staging.azblue.com/*` is in
`manifest.json` → `host_permissions`, and `STAGING_URL` is in `config.js`. In
extension mode the tool fetches directly, so there is no proxy allowlist to
change — but a missing host permission shows up as an unreachable host, and the
tab says so explicitly. If the staging origin ever changes, both places need
updating and the extension needs reloading.

## Rebuilding after changes

`dashboard.js` is now the source of truth — hand-edit it directly.

The only thing that needs regenerating is `dashview.js` (the script that runs
inside the dashboard's iframe), and only when you've touched `dashboardApp()`
or `dashboardCss()`:

```
python3 build/gen_dashview.py
```

See `build/README.md` before running `build/build_ext.py` — that one is a
one-time migration script and re-running it would revert v3.0 changes.

## Notes

- Expanding a finding in the panel highlights and scrolls to it on the page.
- The side panel can't auto-open — Chrome requires a user gesture, which is why
  the dashboard's "Review on site" button exists.
- Works in Edge too (same Chromium extension), but Chrome is the target.
