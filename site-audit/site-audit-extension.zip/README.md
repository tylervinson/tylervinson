# AZ Blue Site Audit — Chrome extension (v3.5)

Packages the audit tool as an extension: the full dashboard, a side panel that
shows findings for the azblue.com page you're currently viewing, and the AEP
launch comparison workflow.

## Install (unpacked, for testing)

1. Chrome → `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. **Load unpacked** → select this folder
4. Pin the extension to the toolbar

## Use

- **Click the toolbar icon** → on azblue.com it docks the review panel; anywhere else it opens the dashboard
- **"Review on site"** (in the dashboard tab bar) → opens azblue.com *and* the side panel
- The panel follows you as you browse and shows that page's findings
- **"Full dashboard"** in the panel → jumps back to the dashboard tab

Pick Admin or Author on first load — no passphrase. The access key that
authenticates the state Worker lives in `config.js`.

**Before first use:** open `config.js` and set `ACCESS_KEY` to the Worker's
`AUDIT_KEY` value. The extension can't reach shared state until you do.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest |
| `background.js` | Toolbar click, per-tab panel availability, tab messaging |
| `dashboard.html` / `dashboard.js` | The tool (scripts externalised for MV3) |
| `actions.js` | Delegated handler dispatcher (replaces inline `onclick`) |
| `dashview.js` | Runs inside the dashboard iframe (generated from `dashboard.js`) |
| `sidepanel.html` / `sidepanel.js` | Per-page review panel |
| `config.js` | Access key + endpoints (production, cm.prod, staging), shared by both surfaces |
| `content.js` | Highlights/scrolls to the element a finding refers to |
| `ext-glue.js` | Adds the "Review on site" button when running as an extension |

## AEP Launch (v3.1)

Admin-only tab with two independent workflows:

- **Pre-launch validation** — baseline production, audit staging, then review what
  the release will change and anything incomplete on staging.
- **Post-launch verification** — capture production before and after the deploy,
  then compare. The *Unchanged* list is the miss list.

Snapshots are stored in the shared KV store, so the team sees the same set. The
environment of a snapshot is recorded from the run that produced it, not chosen
by hand, so a staging capture can't be mislabeled as production.

**Comparisons show the actual change, not just a word count.** Each snapshot
captures the page's text (as ordered segments) and any linked document files
(PDF/DOC/XLS/PPT — SBCs, EOCs, formularies). The "Updated" bucket expands per
page into: the old and new title/meta description, the specific paragraphs
added and removed, and any linked document that now points at a different
file — each with a direct link to view it. A dedicated "Linked documents
changed" section also catches a swapped PDF on a page whose surrounding text
didn't change at all.

Snapshots saved before this was added (or the one-off site-wide-audit fallback)
won't have this detail — comparisons against them fall back to the word-count
delta with a note explaining why, rather than showing an empty or misleading
diff.

**Linked PDFs render as actual before/after thumbnails**, not URLs — page 1,
rendered locally via a bundled copy of PDF.js (`vendor/pdfjs/`, ~2.4MB, no
network fetch, no CDN). Every thumbnail is a fixed height with its real aspect
ratio kept intact (a landscape formulary and a portrait SBC are never forced
to the same shape), and stays a live link to the actual document. Rendering
only happens the first time you open the section it's in, and each document
is only ever fetched once per session.

Non-PDF formats (DOC/XLS/PPT and their -X variants) never attempt a render —
there's no in-browser way to do that — and show a plain file icon with the
extension as text instead. A PDF that can't be shown gets one of three
monochrome icons rather than a blank slot: a circle-slash if it 404s (removed),
a box-with-escaping-arrow if the host can't be reached (e.g. not yet covered
by `host_permissions`), or a plain "?" if it fetched fine but wouldn't open.

One compatibility note if this ever needs debugging: this pdfjs-dist build
calls a very new `Map` method (`getOrInsertComputed`, from a JS proposal not
yet universal across Chrome versions) on every single render, even for a PDF
with no special features. `pdf-thumb.js` polyfills it defensively rather than
gating the feature on Chrome version — if PDFs start rendering as the "?"
icon across the board after a pdfjs-dist upgrade, check there first.

**Staging requires a host permission.** `https://staging.azblue.com/*` is in
`manifest.json` → `host_permissions`, and `STAGING_URL` is in `config.js`. In
extension mode the tool fetches directly, so there is no proxy allowlist to
change — but a missing host permission shows up as an unreachable host, and the
tab says so explicitly. If the staging origin ever changes, both places need
updating and the extension needs reloading.

## Rebuilding after changes

`dashboard.js` is now the source of truth — hand-edit it directly.

The only thing that needs regenerating is `dashview.js` (the script that runs
inside the dashboard's iframe), and only when you've touched `dashboardApp()`
or `dashboardCss()`:

```
python3 build/gen_dashview.py
```

See `build/README.md` before running `build/build_ext.py` — that one is a
one-time migration script and re-running it would revert v3.0 changes.

## Notes

- Expanding a finding in the panel highlights and scrolls to it on the page.
- The side panel can't auto-open — Chrome requires a user gesture, which is why
  the dashboard's "Review on site" button exists.
- Works in Edge too (same Chromium extension), but Chrome is the target.

## AEP pre-launch environments

Three environments, set in `config.js` and mirrored in `manifest.json` host permissions:

| Env | Used for | Notes |
|---|---|---|
| `production` | Baseline (left side of a comparison) | `www.azblue.com` |
| `cm.prod` | Candidate source | Behind a Sitecore login. Requests send the user's session cookie (`credentials: 'include'`), scoped to that host only. |
| `staging` | Candidate source | Kept as an alternative to cm.prod. |

Before a cm.prod run the tab probes one page. If the response looks like a login
stub, an SSO bounce, a 401/403, or is implausibly short, the run stops and offers
an **Open Sitecore login** button rather than capturing hundreds of login pages.

## Stakeholder review report (v3.5)

Both AEP tracks end with a **Stakeholder report** panel. *Download* produces one
self-contained HTML file to email to reviewers — nothing to install on their end.

The document is a page-by-page change manifest, not a findings dashboard:

- **Pages that changed** — one card per page, ordered problems first. Each shows
  the title before/after, the specific text blocks that changed, any linked
  document that was swapped (with filenames), per-language status, and links to
  view each language live.
- Anything wrong is stated **inline on the page it affects** ("Spanish not
  loading", "Chinese Traditional unchanged") rather than in a separate section,
  because that's where the reviewer is looking when they need it.
- **Pages not touched** — every one listed, so the reviewer can see the release
  didn't stray outside its scope.
- **Sign-off** — a signature line. One field: type a name, the date fills in,
  *Save signed copy* prints to PDF with their confirmations and comments baked in.

Each page carries **Looks right / Question / Needs fix** plus a comment box; the
card border and header update as the reviewer works, with a progress count in the
sticky header. Printing hides the controls but keeps the marks and typed comments.

The review controls are added by inline script, so the file must be **downloaded
and opened from disk**. Report pages opened inside the extension are blob: URLs
that inherit the extension CSP, which blocks inline script (verified) — there the
document stays a read-only preview and says so.

The in-app panel also records a sign-off to the shared store against a
*comparison reference* (a hash of both snapshot IDs and every finding count), so
an approval can't carry over to a different set of findings. Prior sign-offs are
printed in the report above the signature line.
