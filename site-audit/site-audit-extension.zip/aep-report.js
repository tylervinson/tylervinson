/* AEP stakeholder review report.
   ---------------------------------------------------------------------------
   Produces one self-contained HTML file from a comparison. A stakeholder opens
   it with nothing installed, walks the list of pages that changed, confirms each
   one, signs their name and saves it back as a PDF.

   Deliberately NOT a findings dashboard: the page-by-page list is the document.
   Anything the tool flagged (a translation that stopped loading, a language left
   on last year's copy) is stated inline on the page it affects rather than in a
   separate bucket, because that is where a reviewer is looking when they need it.

   The review controls are added by the inline script at the bottom. Report pages
   opened from inside the extension are blob: URLs that inherit the extension CSP,
   which blocks inline script — so there the document stays a clean read-only
   preview and says to download it. The downloaded file runs fine. */
(function () {

  function esc (s) {
    return (s == null ? '' : String(s)).replace(/[&<>"]/g, function (m) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[m];
    });
  }

  // ---------- comparison reference: binds a signature to one exact comparison ----------
  function fingerprint (A, B, d) {
    var parts = [A.id, B.id, A.at, B.at,
      d.changed.length, d.unchanged.length, d.added.length, d.removed.length,
      d.broke.length, d.lag.length, d.lostTrans.length, d.bMissing.length, d.unknown.length
    ].join('|');
    return ('0000000000000' + cyrb53(parts, 7).toString(16)).slice(-13);
  }
  function signoffKey (fp) { return 'aep-signoff-' + fp; }
  async function loadSignoffs (fp) {
    try { var v = await stateGet(signoffKey(fp)); return Array.isArray(v) ? v : []; }
    catch (e) { return []; }
  }
  async function addSignoff (fp, rec) {
    var list = await loadSignoffs(fp);
    list.push(rec);
    await statePut(signoffKey(fp), list);
    return list;
  }

  // ---------- per-page rendering ----------
  function segDiff (a, b) {
    var sa = (a && Array.isArray(a.segments)) ? a.segments : null;
    var sb = (b && Array.isArray(b.segments)) ? b.segments : null;
    if (!sa || !sb) return null;
    var A = {}, B = {};
    sa.forEach(function (s) { A[s] = 1; });
    sb.forEach(function (s) { B[s] = 1; });
    return {
      removed: sa.filter(function (s) { return !B[s]; }),
      added:   sb.filter(function (s) { return !A[s]; })
    };
  }
  function docDiff (a, b) {
    var da = (a && a.docLinks) || [], db = (b && b.docLinks) || [];
    var A = {}, B = {};
    da.forEach(function (u) { A[u] = 1; });
    db.forEach(function (u) { B[u] = 1; });
    return {
      removed: da.filter(function (u) { return !B[u]; }),
      added:   db.filter(function (u) { return !A[u]; })
    };
  }
  function fileName (u) {
    try { return decodeURIComponent(String(u).split('?')[0].split('#')[0].split('/').pop()) || u; }
    catch (e) { return u; }
  }
  var DOC_ICON = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4">'
    + '<path d="M6 2.5h8.5L19 7v14.5H6z" stroke-linejoin="round"/><path d="M14.5 2.5V7H19" stroke-linejoin="round"/></svg>';
  function docTile (u) {
    return '<a class="doc" href="' + esc(u) + '" target="_blank" rel="noopener">'
      + DOC_ICON + '<span class="fn">' + esc(fileName(u)) + '</span></a>';
  }

  // Language status, stated in plain terms. Anything wrong is said here, on the
  // page it affects, rather than collected into a separate section.
  function langStatus (a, b, enChanged) {
    var out = { updated: [], unchanged: [], broken: [], missing: [] };
    var labels = Object.keys((b && b.langs) || {});
    if (!labels.length && a) labels = Object.keys(a.langs || {});
    labels.forEach(function (L) {
      var la = (a && a.langs) ? a.langs[L] : null;
      var lb = (b && b.langs) ? b.langs[L] : null;
      if (!lb || lb.missing) {
        if (la && !la.missing) out.broken.push(L); else out.missing.push(L);
        return;
      }
      if (!la || la.missing) { out.updated.push(L); return; }
      if (la.fp != null && lb.fp != null && la.fp === lb.fp) {
        if (enChanged) out.unchanged.push(L);
      } else out.updated.push(L);
    });
    return out;
  }
  function langLine (a, b, enChanged) {
    var s = langStatus(a, b, enChanged);
    var bits = [];
    var all = s.updated.concat(s.unchanged, s.broken, s.missing);
    if (s.updated.length) {
      bits.push(s.updated.length === all.length
        ? 'English' + (s.updated.length ? ' and all translations' : '') + ' updated'
        : esc(s.updated.join(' and ')) + ' updated');
    }
    if (s.unchanged.length) bits.push('<span class="lang-warn">' + esc(s.unchanged.join(' and ')) + ' unchanged</span>');
    if (s.broken.length)   bits.push('<span class="lang-bad">' + esc(s.broken.join(' and ')) + ' not loading</span>');
    if (s.missing.length)  bits.push('<span class="lang-bad">' + esc(s.missing.join(' and ')) + ' not present</span>');
    return bits.length ? bits.join(' &middot; ') : 'English only';
  }

  // One-line plain summary of what happened to this page.
  function headline (row, kind) {
    if (kind === 'added')   return 'New page published with this promotion — did not exist in production before.';
    if (kind === 'removed') return 'This page was present before the promotion and is no longer there.';
    if (kind === 'broke')   return 'This page loaded before the promotion and is returning an error now.';
    var a = row.a || {}, b = row.b || {};
    var bits = [];
    if ((a.title || '') !== (b.title || '')) bits.push('title');
    var sd = segDiff(a, b);
    if (sd && (sd.added.length || sd.removed.length)) bits.push('body text');
    var dd = docDiff(a, b);
    if (dd.added.length || dd.removed.length) bits.push('linked document');
    if (!bits.length) return 'Content changed.';
    var s = bits.join(', ').replace(/, ([^,]*)$/, ' and $1');
    return s.charAt(0).toUpperCase() + s.slice(1) + ' updated.';
  }

  function pageCard (row, kind, idx) {
    var a = row.a, b = row.b, src = b || a || {};
    var enChanged = !!(a && b && a.enFp != null && b.enFp != null && a.enFp !== b.enFp);
    var s = langStatus(a, b, enChanged);
    var trouble = s.broken.length || s.missing.length || kind === 'broke' || kind === 'removed';
    var caution = s.unchanged.length;

    var rows = '';
    var add = function (dt, dd) { rows += '<dt>' + dt + '</dt><dd>' + dd + '</dd>'; };

    if (kind === 'added') {
      add('Status', '<span class="now">New page</span>');
      if (b && b.title) add('Title', '<span class="sm">' + esc(b.title) + '</span>');
    } else if (kind === 'removed' || kind === 'broke') {
      add('Status', '<span class="was-plain">' + (kind === 'removed' ? 'No longer in production' : 'Returning an error') + '</span>');
      if (a && a.title) add('Was titled', '<span class="sm">' + esc(a.title) + '</span>');
    } else {
      if ((a.title || '') !== (b.title || '')) {
        add('Title', '<span class="was">' + esc(a.title || '(none)') + '</span> &rarr; <span class="now">' + esc(b.title || '(none)') + '</span>');
      } else {
        add('Title', '<span class="sm dim">unchanged</span>');
      }
      var sd = segDiff(a, b);
      if (sd && (sd.removed.length || sd.added.length)) {
        var lines = sd.removed.slice(0, 6).map(function (t) { return '<p class="was">' + esc(t) + '</p>'; })
          .concat(sd.added.slice(0, 6).map(function (t) { return '<p class="now">' + esc(t) + '</p>'; })).join('');
        var extra = (sd.removed.length > 6 || sd.added.length > 6)
          ? '<p class="more">and ' + ((sd.removed.length > 6 ? sd.removed.length - 6 : 0) + (sd.added.length > 6 ? sd.added.length - 6 : 0)) + ' more block(s)</p>' : '';
        add('Body text', '<div class="txt">' + lines + extra + '</div>');
      } else if (sd) {
        add('Body text', '<span class="sm dim">unchanged</span>');
      }
      var dd = docDiff(a, b);
      if (dd.removed.length || dd.added.length) {
        var n = Math.min(dd.removed.length, dd.added.length), tiles = '';
        for (var i = 0; i < n; i++) tiles += docTile(dd.removed[i]) + '<span class="arw">&rarr;</span>' + docTile(dd.added[i]);
        for (var j = n; j < dd.removed.length; j++) tiles += docTile(dd.removed[j]) + '<span class="tag-out">removed</span>';
        for (var k = n; k < dd.added.length; k++) tiles += docTile(dd.added[k]) + '<span class="tag-in">added</span>';
        add('Document', '<div class="docs">' + tiles + '</div>');
      }
    }
    add('Languages', '<span class="sm">' + langLine(a, b, enChanged) + '</span>');

    var links = [];
    if (src.enUrl) links.push('<a href="' + esc(src.enUrl) + '" target="_blank" rel="noopener">English</a>');
    var lb = (b && b.langs) || (a && a.langs) || {};
    Object.keys(lb).forEach(function (L) {
      if (lb[L] && lb[L].url) links.push('<a href="' + esc(lb[L].url) + '" target="_blank" rel="noopener">' + esc(L) + '</a>');
    });

    return '<div class="pg' + (trouble ? ' has-trouble' : caution ? ' has-caution' : '') + '" data-pg="p' + idx + '"'
      + ' data-label="' + esc((src.name || row.path) + ' (/' + row.path + ')') + '">'
      + '<div class="pg-h"><span class="nm">' + esc(src.name || row.path) + '</span>'
      + '<span class="pt">/' + esc(row.path) + '</span><span class="st"></span></div>'
      + '<div class="pg-b">'
      + '<p class="chg">' + headline(row, kind) + '</p>'
      + '<dl class="dl">' + rows + '</dl>'
      + (links.length ? '<p class="links">View live: ' + links.join(' &middot; ') + '</p>' : '')
      + '</div></div>';
  }

  function css () {
    return [
      ":root{--bg:#1a1a1a;--card:#242424;--card-alt:#1e1e1e;--border:#2e2e2e;--border-soft:#2a2a2a;",
      "--text:#f0f0f0;--muted:#888;--muted-2:#666;--accent:#FFBE5F;--accent-hover:#FFD495;",
      "--critical:#d98a84;--warning:#d8a24a;--ok:#7dbf82}",
      "*{box-sizing:border-box}",
      "body{margin:0;background:var(--bg);color:var(--text);font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;font-weight:300;font-size:15px;line-height:1.6}",
      "a{color:var(--accent)}",
      ".bar{position:sticky;top:0;z-index:20;background:var(--bg);border-bottom:1px solid var(--border);padding:11px 32px;display:flex;align-items:center;gap:14px}",
      ".bar .prog{font-size:.85rem;color:var(--muted);margin-right:auto}",
      ".bar .prog b{color:var(--text);font-weight:500}",
      ".bar button{font:inherit;font-size:.85rem;padding:.5rem 1rem;border:1px solid var(--border);border-radius:8px;background:var(--card);color:var(--text);cursor:pointer;transition:border-color .2s,color .2s}",
      ".bar button:hover{border-color:var(--accent);color:var(--accent)}",
      ".wrap{max-width:940px;margin:0 auto;padding:2.6rem 2rem 6rem}",
      "h1{font-size:1.7rem;font-weight:300;margin:0 0 .3rem;letter-spacing:-.01em}",
      ".sub{color:var(--muted);font-size:.9rem;margin:0 0 2.4rem}",
      "h2{font-size:.72rem;font-weight:500;text-transform:uppercase;letter-spacing:.1em;color:var(--accent);margin:2.4rem 0 1rem;display:flex;align-items:center;gap:.5rem}",
      "h2::before{content:'';width:6px;height:6px;border-radius:50%;background:var(--accent);flex:0 0 auto}",
      ".pg{border:1px solid var(--border);border-radius:10px;margin-bottom:.9rem;overflow:hidden;background:var(--card)}",
      ".pg.done{border-color:rgba(125,191,130,.45)}",
      ".pg.flag{border-color:rgba(216,162,74,.45)}",
      ".pg.fix{border-color:rgba(217,138,132,.5)}",
      ".pg-h{display:flex;align-items:baseline;gap:.7rem;padding:.9rem 1.1rem;background:var(--card-alt);border-bottom:1px solid var(--border);flex-wrap:wrap}",
      ".pg-h .nm{font-size:1rem;font-weight:500}",
      ".pg-h .pt{font-size:.72rem;color:var(--muted-2);font-family:'SF Mono',Monaco,Consolas,monospace}",
      ".pg-h .st{margin-left:auto;font-size:.76rem;font-weight:500}",
      ".pg.done .st{color:var(--ok)}.pg.flag .st{color:var(--warning)}.pg.fix .st{color:var(--critical)}",
      ".pg-b{padding:1.1rem}",
      ".chg{font-size:.86rem;color:var(--muted);margin:0 0 1rem}",
      ".dl{display:grid;grid-template-columns:104px 1fr;gap:.5rem 1rem;font-size:.9rem;margin:0 0 1rem}",
      ".dl dt{font-size:.66rem;text-transform:uppercase;letter-spacing:.07em;color:var(--muted-2);font-weight:500;padding-top:.2rem}",
      ".dl dd{margin:0}",
      ".sm{font-size:.88rem}.dim{color:var(--muted-2)}",
      ".was{color:var(--critical);text-decoration:line-through;text-decoration-color:rgba(217,138,132,.5)}",
      ".was-plain{color:var(--critical)}",
      ".now{color:var(--ok)}",
      ".txt{border-left:2px solid var(--border);padding-left:.8rem}",
      ".txt p{margin:0 0 .3rem;font-size:.88rem}",
      ".more{color:var(--muted-2);font-size:.78rem}",
      ".docs{display:flex;align-items:center;gap:.8rem;flex-wrap:wrap}",
      ".doc{border:1px solid var(--border);border-radius:6px;height:104px;width:80px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.3rem;background:var(--card-alt);text-align:center;padding:.3rem;text-decoration:none}",
      ".doc:hover{border-color:var(--muted-2)}",
      ".doc .ic{width:26px;height:26px;color:var(--muted-2)}",
      ".doc .fn{font-family:'SF Mono',Monaco,Consolas,monospace;font-size:.56rem;word-break:break-all;line-height:1.3;color:var(--muted)}",
      ".arw{color:var(--muted-2)}",
      ".tag-out{font-size:.7rem;color:var(--critical)}.tag-in{font-size:.7rem;color:var(--ok)}",
      ".links{font-size:.84rem;margin:0}",
      ".lang-warn{color:var(--warning)}.lang-bad{color:var(--critical)}",
      ".rev{border-top:1px solid var(--border);padding:.75rem 1.1rem;display:flex;gap:.45rem;align-items:center;flex-wrap:wrap;background:var(--card-alt)}",
      ".rev button{font:inherit;font-size:.79rem;padding:.35rem .9rem;border:1px solid var(--border);border-radius:99px;background:var(--card);color:var(--muted);cursor:pointer;transition:.15s}",
      ".rev button:hover{border-color:var(--muted-2);color:var(--text)}",
      ".rev button.on-ok{background:rgba(125,191,130,.14);border-color:rgba(125,191,130,.5);color:var(--ok);font-weight:500}",
      ".rev button.on-q{background:rgba(216,162,74,.14);border-color:rgba(216,162,74,.5);color:var(--warning);font-weight:500}",
      ".rev button.on-fx{background:rgba(217,138,132,.14);border-color:rgba(217,138,132,.5);color:var(--critical);font-weight:500}",
      ".rev .cm{margin-left:auto;border:none;background:none;color:var(--muted);text-decoration:underline;font-size:.79rem}",
      ".rev .cm:hover{color:var(--accent)}",
      ".cbox{padding:0 1.1rem 1rem;background:var(--card-alt)}",
      ".cbox textarea{width:100%;font:inherit;font-size:.86rem;padding:.55rem .7rem;border:1px solid var(--border);border-radius:6px;min-height:58px;resize:vertical;background:var(--bg);color:var(--text)}",
      ".cbox textarea:focus{outline:none;border-color:var(--accent)}",
      ".untouched{border:1px solid var(--border);border-radius:10px;background:var(--card);padding:1rem 1.2rem}",
      ".untouched p.lead{font-size:.86rem;color:var(--muted);margin:0 0 .8rem}",
      ".ulist{list-style:none;margin:0;padding:0}",
      ".ulist li{font-size:.82rem;color:var(--muted);font-family:'SF Mono',Monaco,Consolas,monospace;padding:.32rem 0;border-bottom:1px solid var(--border-soft)}",
      ".ulist li:last-child{border-bottom:none}",
      ".sig{border:1px solid var(--border);border-radius:10px;background:var(--card);padding:1.6rem 1.8rem 1.4rem;margin-top:.6rem}",
      ".sig .intro{font-size:.88rem;color:var(--muted);margin:0 0 1.9rem}",
      ".prior{margin:0 0 1.6rem;padding:0 0 1.2rem;border-bottom:1px solid var(--border);list-style:none}",
      ".prior li{font-size:.86rem;color:var(--muted);margin-bottom:.3rem}",
      ".prior b{color:var(--text);font-weight:500}",
      ".sigrow{display:flex;gap:2.4rem;align-items:flex-end;flex-wrap:wrap}",
      ".sigfield{flex:1;min-width:240px}",
      ".sigfield input{width:100%;font-size:1.2rem;font-weight:300;color:var(--text);background:none;border:none;border-bottom:1px solid var(--muted-2);padding:.3rem 0 .5rem;font-family:Georgia,'Times New Roman',serif;font-style:italic}",
      ".sigfield input:focus{outline:none;border-bottom-color:var(--accent)}",
      ".sigfield input::placeholder{color:var(--muted-2);font-style:italic}",
      ".cap{font-size:.66rem;text-transform:uppercase;letter-spacing:.07em;color:var(--muted-2);font-weight:500;margin-top:.45rem}",
      ".sigdate{flex:0 0 190px}",
      ".sigdate .val{font-size:1.05rem;color:var(--text);border-bottom:1px solid var(--muted-2);padding:.42rem 0 .5rem;font-family:Georgia,'Times New Roman',serif}",
      ".sigline{border-bottom:1px solid var(--muted-2);height:1.9rem}",
      ".sig .acts{margin-top:1.7rem;display:flex;gap:.6rem;align-items:center;flex-wrap:wrap}",
      ".sig .acts button{font:inherit;font-size:.9rem;padding:.6rem 1.2rem;border-radius:8px;cursor:pointer;border:1px solid var(--accent);background:var(--accent);color:#1a1a1a;font-weight:500}",
      ".sig .acts button:hover{background:var(--accent-hover)}",
      ".sig .st{font-size:.84rem;color:var(--muted)}",
      ".dlnote{border:1px dashed var(--border);border-radius:8px;padding:.8rem 1rem;margin:0 0 1.4rem;font-size:.84rem;color:var(--muted);background:var(--card-alt)}",
      ".foot{margin-top:2.4rem;padding-top:1rem;border-top:1px solid var(--border);color:var(--muted-2);font-size:.74rem}",
      ".foot code{font-family:'SF Mono',Monaco,Consolas,monospace;color:var(--muted)}",
      ".empty{color:var(--muted-2);font-size:.88rem}",
      "@media print{",
      ":root{--bg:#fff;--card:#fff;--card-alt:#fff;--border:#ccc;--border-soft:#e8e8e8;--text:#111;--muted:#555;--muted-2:#777;--accent:#111}",
      "body{background:#fff;color:#111}",
      ".bar,.rev,.sig .acts,.dlnote{display:none}",
      ".wrap{max-width:none;padding:0}",
      ".pg{break-inside:avoid;border:1px solid #ccc}",
      ".cbox textarea{border:none;padding:0;background:none;color:#111}",
      "a{color:#111}h2{color:#111}h2::before{background:#111}",
      "}"
    ].join('');
  }

  function reviewScript () {
    var js = [
      '(function(){',
      'var note=document.getElementById("dlNote"); if(note) note.remove();',
      'var S=[["ok","Looks right"],["q","Question"],["fx","Needs fix"]];',
      'var pgs=Array.prototype.slice.call(document.querySelectorAll(".pg"));',
      'var store={};',
      'pgs.forEach(function(pg){',
      ' var id=pg.getAttribute("data-pg"); store[id]={state:"",note:""};',
      ' var rev=document.createElement("div"); rev.className="rev";',
      ' S.forEach(function(s){ var b=document.createElement("button"); b.type="button"; b.textContent=s[1];',
      '  b.setAttribute("data-s",s[0]); b.onclick=function(){ store[id].state=(store[id].state===s[0])?"":s[0]; paint(); };',
      '  rev.appendChild(b); });',
      ' var cm=document.createElement("button"); cm.className="cm"; cm.type="button"; cm.textContent="Add a comment";',
      ' rev.appendChild(cm);',
      ' var box=document.createElement("div"); box.className="cbox"; box.style.display="none";',
      ' var ta=document.createElement("textarea"); ta.placeholder="Comment for the web team about this page\\u2026";',
      ' ta.oninput=function(){ store[id].note=ta.value; }; box.appendChild(ta);',
      ' cm.onclick=function(){ box.style.display=(box.style.display==="none")?"block":"none"; if(box.style.display==="block") ta.focus(); };',
      ' pg.appendChild(rev); pg.appendChild(box);',
      ' pg._paint=function(){ var st=store[id];',
      '  rev.querySelectorAll("button[data-s]").forEach(function(b){ b.className=(st.state===b.getAttribute("data-s"))?("on-"+st.state):""; });',
      '  pg.className="pg"+(st.state==="ok"?" done":st.state==="q"?" flag":st.state==="fx"?" fix":"")',
      '   + (pg.getAttribute("data-trouble")?" has-trouble":"");',
      '  pg.querySelector(".pg-h .st").textContent = st.state==="ok"?"Confirmed":st.state==="q"?"Question raised":st.state==="fx"?"Needs fix":""; };',
      '});',
      'function paint(){ pgs.forEach(function(p){ p._paint(); });',
      ' var el=document.getElementById("pdone"); if(el) el.textContent=pgs.filter(function(p){return store[p.getAttribute("data-pg")].state;}).length; }',
      'var nm=document.getElementById("sName"), dt=document.getElementById("sDate");',
      'if(nm){ nm.oninput=function(){ dt.textContent=this.value.trim()?new Date().toLocaleDateString(undefined,{year:"numeric",month:"long",day:"numeric"}):"\\u2014"; }; }',
      'var sv=document.getElementById("bSave");',
      'if(sv){ sv.onclick=function(){ if(!nm.value.trim()){ document.getElementById("sStat").textContent="Type your name first."; nm.focus(); return; }',
      ' document.getElementById("sStat").textContent=""; window.print(); }; }',
      'var pr=document.getElementById("bPrint"); if(pr) pr.onclick=function(){ window.print(); };',
      'paint();',
      '})();'
    ].join('\n');
    return '<scr' + 'ipt>' + js + '</scr' + 'ipt>';
  }

  function build (o) {
    var d = o.diff;
    // Everything that needs a human to look at it, problems first.
    var cards = [], i = 0;
    d.broke.forEach(function (r) { cards.push(pageCard(r, 'broke', i++)); });
    d.removed.forEach(function (r) { cards.push(pageCard(r, 'removed', i++)); });
    d.changed.forEach(function (r) { cards.push(pageCard(r, 'changed', i++)); });
    d.added.forEach(function (r) { cards.push(pageCard(r, 'added', i++)); });
    d.unknown.forEach(function (r) { cards.push(pageCard(r, 'broke', i++)); });
    var nChanged = cards.length;

    var untouched = d.unchanged.slice().sort(function (a, b) { return a.path.localeCompare(b.path); });
    var total = nChanged + untouched.length;

    var when = function (t) {
      try { return new Date(t).toLocaleString(undefined,
        { month:'long', day:'numeric', year:'numeric', hour:'numeric', minute:'2-digit' }); }
      catch (e) { return String(t); }
    };
    var sameHost = o.A.host === o.B.host;
    var sub = sameHost
      ? esc(o.A.host) + ' compared before and after the promotion &middot; captured '
        + esc(when(o.A.at)) + ' and ' + esc(when(o.B.at))
      : esc(o.A.host) + ' (' + esc(when(o.A.at)) + ') compared against ' + esc(o.B.host) + ' (' + esc(when(o.B.at)) + ')';
    sub += ' &middot; ' + total + ' page' + (total === 1 ? '' : 's') + ' in '
      + esc(o.scope ? '/' + o.scope : 'the section') + ', ' + nChanged + ' changed';

    var prior = (o.signoffs && o.signoffs.length)
      ? '<ul class="prior">' + o.signoffs.map(function (s) {
          return '<li>Already reviewed by <b>' + esc(s.name) + '</b>'
            + (s.role ? ', ' + esc(s.role) : '') + ' on ' + esc(new Date(s.at).toLocaleDateString()) + '</li>';
        }).join('') + '</ul>'
      : '';

    return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
      + '<meta name="viewport" content="width=device-width,initial-scale=1">'
      + '<title>' + esc(o.title) + '</title><style>' + css() + '</style></head><body>'
      + '<div class="bar"><span class="prog"><b id="pdone">0</b> of <b>' + nChanged + '</b> pages reviewed</span>'
      + '<button id="bPrint">Print / Save as PDF</button></div>'
      + '<div class="wrap">'
      + '<h1>' + esc(o.title) + '</h1>'
      + '<p class="sub">' + sub + '</p>'
      + '<div class="dlnote" id="dlNote">Download this file and open it from your computer to confirm each page and '
      + 'sign it. Viewed inside the extension it stays read-only.</div>'
      + '<h2>Pages that changed &mdash; please confirm</h2>'
      + (cards.length ? cards.join('') : '<p class="empty">No pages changed between these two snapshots.</p>')
      + '<h2>' + untouched.length + ' page' + (untouched.length === 1 ? ' was' : 's were') + ' not touched by this promotion</h2>'
      + '<div class="untouched">'
        + '<p class="lead">Byte-for-byte identical before and after, which is what we expected.</p>'
        + (untouched.length
            ? '<ul class="ulist">' + untouched.map(function (r) { return '<li>/' + esc(r.path) + '</li>'; }).join('') + '</ul>'
            : '<p class="empty">Every page in scope changed.</p>')
      + '</div>'
      + '<h2>Sign-off</h2>'
      + '<div class="sig">'
        + '<p class="intro">By signing below you confirm you have reviewed the changes above.</p>'
        + prior
        + '<div class="sigrow">'
          + '<div class="sigfield"><input id="sName" placeholder="Type your name" autocomplete="name">'
            + '<div class="cap">Reviewed by</div></div>'
          + '<div class="sigdate"><div class="val" id="sDate">&mdash;</div><div class="cap">Date</div></div>'
        + '</div>'
        + '<div class="acts"><button id="bSave">Save signed copy</button><span class="st" id="sStat"></span></div>'
      + '</div>'
      + '<div class="foot">Comparison reference <code>' + esc(o.fp) + '</code> &middot; snapshots <code>'
      + esc(o.A.id) + '</code> &rarr; <code>' + esc(o.B.id) + '</code>.<br>'
      + 'This reference covers the exact set of pages and changes above. If the comparison is re-run and anything '
      + 'differs, the reference changes, so a sign-off cannot be mistaken for approval of a different set of changes.</div>'
      + '</div>' + reviewScript() + '</body></html>';
  }

  window.AepReport = {
    fingerprint: fingerprint, loadSignoffs: loadSignoffs, addSignoff: addSignoff, build: build
  };
})();
