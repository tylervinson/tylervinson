/* Guided tours. Self-contained — no library, no CSP concerns.
   Runs in the parent page and, for the dashboard, inside its iframe. */
(function () {
  var STEPS = {
    /* ---------- Admin dashboard (runs inside the iframe) ---------- */
    dash: [
      { t: 'Run totals',
        b: 'Counts for the current run: pages audited, critical findings, warnings, broken links, and findings not yet marked done or ignored.',
        s: '.kpis' },
      { t: '404 errors',
        b: 'Two groups. Missing translations are language versions that returned an error. The sitemap monitor lists URLs from the saved sitemap that now fail, re-checked twice a day.',
        s: '.card-404' },
      { t: 'Findings',
        b: 'Findings grouped by issue, language, or section. Each group expands to a sortable table of the affected pages.',
        s: '#findings-drill' },
      { t: 'Finding detail',
        b: 'Expanding a row shows the text or URL that triggered the finding, a suggested action, and buttons to mark it done or ignored.',
        s: '#findings-drill .drill' },
      { t: 'Top problem pages',
        b: 'Pages ranked by number of open findings.',
        s: '.dash-col' },
      { t: 'Publish',
        b: 'Generate new audit runs an audit. Publish run to team writes it to shared state. Until a run is published it is not visible to the side panel, other users, or the Power BI export.',
        s: '.pub-actions' }
    ],

    /* ---------- AEP Launch ---------- */
    aep: [
      { t: 'Workflow selection',
        b: 'Pre-launch compares production against the candidate environment. Post-launch compares production against itself, before and after a deploy.',
        s: '#aepTrackPre' },
      { t: 'Section scope',
        b: 'Limits the run to paths matching the entered section, across all three languages. The counter shows the number of matching pages.',
        s: '#aepScope' },
      { t: 'Capture steps',
        b: 'Each step runs a scoped audit and saves the result as a snapshot. Two snapshots are required for a comparison.',
        s: '#aepPreStep1' },
      { t: 'Snapshot library',
        b: 'Snapshots are stored in shared state with their environment, host, capture time, and page count. Labels are editable.',
        s: '#aepSnapList' },
      { t: 'Comparison',
        b: 'Select two snapshots to compare. Results are grouped into changed, unchanged, new, missing, failing, and translation lag.',
        s: '#aepPreCompare' }
    ],

    /* ---------- Audit Settings ---------- */
    generate: [
      { t: 'Page discovery',
        b: 'Reads the sitemap and builds the list of pages to audit. Re-run after the site structure changes.',
        s: '#discoveredPanel' },
      { t: 'Path lookup',
        b: 'Checks whether a given path is included in the current page list.',
        s: '#discSearch' },
      { t: 'Manual pages and exclusions',
        b: 'Add pages the sitemap does not list. The Skip checkbox removes a page from the audit and from findings.',
        s: '#pagesTable' },
      { t: 'English-only sections',
        b: 'Directories listed here are excluded from translation checks and from the sitemap 404 crawl.',
        s: '#excludeDirs' }
    ],

    /* ---------- Power BI instructions ---------- */
    pbi: [
      { t: 'Option A: live URLs',
        b: 'Four URLs, one per table, connected through Power BI\u2019s web connector. Supports scheduled refresh.',
        s: '#pbiOptA' },
      { t: 'Option B: CSV files',
        b: 'Downloads the same four tables as files for manual import.',
        s: '#pbiOptB' },
      { t: 'Configure tables',
        b: 'Common to both options: column types, table relationships, and refresh setup.',
        s: '#pbiConfig' }
    ]
  };

  var idx = 0, list = [], root = document;

  function el(tag, cls, css) {
    var e = root.createElement(tag);
    if (cls) e.className = cls;
    if (css) e.style.cssText = css;
    return e;
  }

  function teardown() {
    ['__tourOv', '__tourSpot', '__tourBox'].forEach(function (id) {
      var n = root.getElementById(id);
      if (n) n.parentNode.removeChild(n);
    });
    root.removeEventListener('keydown', onKey, true);
  }

  function onKey(e) {
    if (e.key === 'Escape') { teardown(); }
    else if (e.key === 'ArrowRight') { go(1); }
    else if (e.key === 'ArrowLeft') { go(-1); }
  }

  function ensureChrome() {
    if (root.getElementById('__tourOv')) return;
    var ov = el('div', null,
      'position:fixed;inset:0;background:rgba(10,10,10,.72);z-index:2147483600;');
    ov.id = '__tourOv';
    ov.addEventListener('click', teardown);

    var spot = el('div', null,
      'position:absolute;border-radius:10px;box-shadow:0 0 0 3px #FFBE5F,0 0 0 9999px rgba(10,10,10,.72);' +
      'z-index:2147483601;pointer-events:none;transition:all .28s cubic-bezier(.4,0,.2,1);');
    spot.id = '__tourSpot';

    var box = el('div', null,
      'position:absolute;z-index:2147483602;max-width:330px;background:#242424;color:#f0f0f0;' +
      'border:1px solid #3a3a3a;border-radius:10px;padding:16px 18px;box-shadow:0 10px 34px rgba(0,0,0,.5);' +
      'font:400 13.5px/1.6 Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;' +
      'transition:all .28s cubic-bezier(.4,0,.2,1);');
    box.id = '__tourBox';

    root.body.appendChild(ov);
    root.body.appendChild(spot);
    root.body.appendChild(box);
    root.addEventListener('keydown', onKey, true);
  }

  function place(target) {
    var spot = root.getElementById('__tourSpot');
    var box = root.getElementById('__tourBox');
    var r = target.getBoundingClientRect();
    var pad = 8;
    var top = r.top + window.scrollY - pad, left = r.left + window.scrollX - pad;

    spot.style.top = top + 'px';
    spot.style.left = left + 'px';
    spot.style.width = (r.width + pad * 2) + 'px';
    spot.style.height = (r.height + pad * 2) + 'px';

    // prefer below, flip above when there isn't room
    var below = r.bottom + 14 + window.scrollY;
    var roomBelow = window.innerHeight - r.bottom;
    box.style.top = (roomBelow > 190 ? below : (r.top + window.scrollY - box.offsetHeight - 14)) + 'px';
    var l = r.left + window.scrollX;
    var maxL = window.scrollX + window.innerWidth - box.offsetWidth - 16;
    box.style.left = Math.max(window.scrollX + 16, Math.min(l, maxL)) + 'px';
  }

  function render() {
    var step = list[idx];
    var target = root.querySelector(step.s);
    if (!target) { go(1); return; }          // skip steps whose target isn't on screen

    ensureChrome();
    try { target.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {}

    var box = root.getElementById('__tourBox');
    box.innerHTML =
      '<div style="font-size:10px;letter-spacing:.11em;text-transform:uppercase;color:#FFBE5F;margin-bottom:6px">'
        + (idx + 1) + ' of ' + list.length + '</div>'
      + '<div style="font-size:15px;font-weight:600;margin-bottom:6px">' + step.t + '</div>'
      + '<div style="color:#b5b5b5">' + step.b + '</div>'
      + '<div style="display:flex;gap:8px;margin-top:14px;align-items:center">'
      +   '<button data-tour="prev" style="border:1px solid #3a3a3a;background:none;color:#999;border-radius:7px;padding:6px 11px;font:inherit;font-size:12px;cursor:pointer'
      +     (idx === 0 ? ';visibility:hidden' : '') + '">Back</button>'
      +   '<button data-tour="next" style="border:none;background:#FFBE5F;color:#1a1a1a;border-radius:7px;padding:6px 14px;font:inherit;font-size:12px;font-weight:600;cursor:pointer">'
      +     (idx === list.length - 1 ? 'Done' : 'Next') + '</button>'
      +   '<button data-tour="end" style="margin-left:auto;border:none;background:none;color:#777;font:inherit;font-size:12px;cursor:pointer">Skip</button>'
      + '</div>';

    box.querySelector('[data-tour="next"]').onclick = function () { go(1); };
    box.querySelector('[data-tour="prev"]').onclick = function () { go(-1); };
    box.querySelector('[data-tour="end"]').onclick = teardown;

    setTimeout(function () { place(target); }, 60);
  }

  function go(n) {
    idx += n;
    if (idx < 0) { idx = 0; return; }
    if (idx >= list.length) { teardown(); return; }
    render();
  }

  function start(key, doc) {
    root = doc || document;
    list = (STEPS[key] || []).filter(function (s) { return !!root.querySelector(s.s); });
    if (!list.length) return false;
    idx = 0;
    render();
    return true;
  }

  window.SiteAuditTour = { start: start, stop: teardown, steps: STEPS };

  // The dashboard lives in an iframe; the parent asks it to run its own tour.
  window.addEventListener('message', function (e) {
    if (e && e.data === 'tour:dash') start('dash', document);
  });
})();
