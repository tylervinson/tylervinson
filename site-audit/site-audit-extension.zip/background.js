/* Toolbar click is context-aware: on azblue.com it opens the review panel,
   anywhere else it opens the dashboard. onClicked counts as the user gesture
   sidePanel.open() requires, so no dashboard round-trip is needed. */
const DASH = 'dashboard.html';
const SITE_HOSTS = ['www.azblue.com', 'azblue.com'];

function isSite(url) {
  try { return SITE_HOSTS.includes(new URL(url).hostname); } catch (e) { return false; }
}

chrome.action.onClicked.addListener((tab) => {
  // On the site already → just dock the panel. Called first, synchronously,
  // so the user gesture is still valid.
  if (tab && isSite(tab.url)) {
    try { chrome.sidePanel.open({ windowId: tab.windowId }); return; }
    catch (e) { /* fall through to the dashboard */ }
  }
  openDashboard();
});

async function openDashboard() {
  const url = chrome.runtime.getURL(DASH);
  const open = await chrome.tabs.query({ url });
  if (open.length) {
    await chrome.tabs.update(open[0].id, { active: true });
    await chrome.windows.update(open[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
}

/* Panel is available on azblue.com and on our own pages; disabled elsewhere. */
async function syncPanel(tabId, url) {
  if (!url) return;
  const on = isSite(url) || url.startsWith(chrome.runtime.getURL(''));
  try { await chrome.sidePanel.setOptions({ tabId, path: 'sidepanel.html', enabled: on }); }
  catch (e) { /* tab may be gone */ }
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'loading' || info.url) syncPanel(tabId, tab.url);
});
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try { const t = await chrome.tabs.get(tabId); syncPanel(tabId, t.url); } catch (e) {}
});

/* The dashboard asks us to open azblue.com; the panel asks us to open the dashboard. */
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg && msg.type === 'openSite') {
    chrome.tabs.create({ url: msg.url || 'https://www.azblue.com/' });
    respond({ ok: true });
  }
  if (msg && msg.type === 'openDashboard') {
    openDashboard();
    respond({ ok: true });
  }
  return true;
});
