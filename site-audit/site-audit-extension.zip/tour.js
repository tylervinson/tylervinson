/* Guided tours. Self-contained — no library, no CSP concerns.
   Runs in the parent page and, for the dashboard, inside its iframe. */
(function () {
  var STEPS = {
    /* ---------- Admin dashboard (runs inside the iframe) ---------- */
    dash: [
      { t: 'Run totals',
        b: 'Counts for the current run: pages audited, critical findings, warnings, broken links, and findings not yet marked done or ignored.',
        s: '.kpis' },
      { t: '404 errors',
        b: 'Two groups. Missing translations are language versions that returned an error. The sitemap monitor lists URLs from the saved sitemap that now fail, re-checked twice a day.',
        s: '.card-404' },
      { t: 'Findings',
        b: 'Findings grouped by issue, language, or section. Each group expands to a sortable table of the affected pages.',
        s: '#findings-drill' },
      { t: 'Finding detail',
        b: 'Expanding a row shows the text or URL that triggered the finding, a suggested action, and buttons to mark it done or ignored.',
        s: '#findings-drill .drill' },
      { t: 'Top problem pages',
        b: 'Pages ranked by number of open findings.',
        s: '.dash-col' },
      { t: 'Publish',
        b: 'Generate new audit runs an audit. Publish run to team writes it to shared state. Until a run is published it is not visible to the side panel, other users, or the Power BI export.',
        s: '.pub-actions' }
    ],

    /* ---------- AEP Launch: choose a path, then walk it ---------- */
    aep: [
      { t: 'Build and compare',
        b: 'Walk through a release check step by step. Pre-launch validates new content before it ships. Post-launch confirms every page that should have updated did.',
        center: true,
        choices: [
          { label: 'Pre-launch validation',  flow: 'aep_pre',  track: 'pre'  },
          { label: 'Post-launch verification', flow: 'aep_post', track: 'post' },
          { label: 'Not now', dismiss: true }
        ] },
    ],

    aep_pre: [
      { t: 'Set the section scope', s: '#aepScope',
        b: 'Type a section name, for example medicare. It covers all three languages, so no language prefix is needed.' },
      { t: 'Step 1 — capture production', s: '#aepPreStep1',
        b: 'Runs a scoped audit against the live site and saves it as a snapshot. This is what the new content gets compared against.' },
      { t: 'Step 2 — capture the candidate', s: '#aepPreStep2',
        b: 'Same checks against cm.prod or staging, wherever the new content is. cm.prod needs you signed in to Sitecore.' },
      { t: 'Name your snapshots', s: '#aepSnapList',
        b: 'Both captures appear here with their environment and time. Click a label to rename it. Snapshots are shared with the team.' },
      { t: 'Step 3 — compare', s: '#aepPreStep3',
        b: 'Select the production snapshot on the left and the candidate on the right, then Compare.' },
      { t: 'Read the counts', s: '#aepPreBar',
        b: 'Would launch broken and Translation not updated are the two to act on before deploying.' },
      { t: 'Open a changed page', s: '#aepPreOut',
        b: 'Expand a group, then a page, to see the text that changed and any document that was swapped.' }
    ],

    aep_post: [
      { t: 'Set the section scope', s: '#aepScope',
        b: 'Use the same scope for both captures. If they differ, the comparison warns you and the counts will not line up.' },
      { t: 'Step 1 — capture before the deploy', s: '#aepPostStep1',
        b: 'Run this before the release goes out. Without it there is nothing to compare against afterwards.' },
      { t: 'Step 2 — deploy', s: '#aepPostStep2',
        b: 'Your normal release process. Nothing happens in the extension. Come back once it is live and caches have cleared.' },
      { t: 'Step 3 — capture after the deploy', s: '#aepPostStep3',
        b: 'Same scope, same environment. This is the second half of the comparison.' },
      { t: 'Your captures', s: '#aepSnapList',
        b: 'Both snapshots appear here. Rename them so the before and after are obvious.' },
      { t: 'Step 4 — compare', s: '#aepPostStep4',
        b: 'Before on the left, after on the right, then Compare.' },
      { t: 'Start with Unchanged', s: '#aepPostBar',
        b: 'Unchanged lists pages identical before and after. Cross-check it against what the release was meant to update — anything on both lists did not deploy.' },
      { t: 'Work the rest', s: '#aepPostOut',
        b: 'Now failing and Lost translations are highest priority. Translation lag is the retranslation queue.' }
    ],

    /* ---------- Audit Settings ---------- */
    generate: [
      { t: 'Page discovery',
        b: 'Reads the sitemap and builds the list of pages to audit. Re-run after the site structure changes.',
        s: '#discoveredPanel' },
      { t: 'Path lookup',
        b: 'Checks whether a given path is included in the current page list.',
        s: '#discSearch' },
      { t: 'Manual pages and exclusions',
        b: 'Add pages the sitemap does not list. The Skip checkbox removes a page from the audit and from findings.',
        s: '#pagesTable' },
      { t: 'English-only sections',
        b: 'Directories listed here are excluded from translation checks and from the sitemap 404 crawl.',
        s: '#excludeDirs' }
    ],

    /* ---------- Power BI instructions ---------- */
    pbi: [
      { t: 'Option A: live URLs',
        b: 'Four URLs, one per table, connected through Power BI\u2019s web connector. Supports scheduled refresh.',
        s: '#pbiOptA' },
      { t: 'Option B: CSV files',
        b: 'Downloads the same four tables as files for manual import.',
        s: '#pbiOptB' },
      { t: 'Configure tables',
        b: 'Common to both options: column types, table relationships, and refresh setup.',
        s: '#pbiConfig' }
    ]
  };

  var idx = 0, list = [], root = document, pinned = false, curKey = '';

  function el(tag, cls, css) {
    var e = root.createElement(tag);
    if (cls) e.className = cls;
    if (css) e.style.cssText = css;
    return e;
  }

  /* On close the card simply fades where it is. A gold light then runs once around
     the button border so it is obvious where the prompt went. */
  function flashButton() {
    var btn = document.getElementById('tourBtn');
    if (!btn) return;
    var wasHidden = getComputedStyle(btn).display === 'none';
    if (wasHidden) btn.style.display = 'inline-flex';

    var r = btn.getBoundingClientRect();
    if (!r.width) { return; }

    if (!document.getElementById('__tourFlashCss')) {
      var st = document.createElement('style');
      st.id = '__tourFlashCss';
      st.textContent = '@keyframes tourTrace{from{stroke-dashoffset:var(--len)}to{stroke-dashoffset:0}}'
        + '@keyframes tourTraceFade{0%,70%{opacity:1}100%{opacity:0}}';
      document.head.appendChild(st);
    }

    var pad = 3, w = r.width + pad * 2, h = r.height + pad * 2, rad = 10;
    var perim = 2 * (w - 2 * rad) + 2 * (h - 2 * rad) + 2 * Math.PI * rad;
    var dash = Math.max(26, perim * 0.22);

    var wrap = document.createElement('div');
    wrap.id = '__tourFlash';
    wrap.style.cssText = 'position:fixed;left:' + (r.left - pad) + 'px;top:' + (r.top - pad) + 'px;'
      + 'width:' + w + 'px;height:' + h + 'px;pointer-events:none;z-index:2147483640;';
    wrap.innerHTML =
      '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" fill="none" style="overflow:visible">'
      + '<rect x="1" y="1" width="' + (w - 2) + '" height="' + (h - 2) + '" rx="' + rad + '" '
      +   'stroke="#FFBE5F" stroke-width="2" stroke-linecap="round" '
      +   'style="--len:' + perim.toFixed(1) + ';stroke-dasharray:' + dash.toFixed(1) + ' ' + (perim - dash).toFixed(1) + ';'
      +   'filter:drop-shadow(0 0 5px rgba(255,190,95,.85));'
      +   'animation:tourTrace .62s cubic-bezier(.45,0,.2,1) forwards, tourTraceFade .72s ease forwards;"/>'
      + '</svg>';
    document.body.appendChild(wrap);
    setTimeout(function () { var el = document.getElementById('__tourFlash'); if (el) el.remove(); }, 800);
  }

  function collapseToButton(done) {
    var box = root.getElementById('__tourBox');
    var ov = root.getElementById('__tourOv');
    var spot = root.getElementById('__tourSpot');
    if (spot) spot.style.boxShadow = 'none';
    if (ov) { ov.style.transition = 'opacity .2s ease'; ov.style.opacity = '0'; }
    if (box) {
      box.style.transition = 'opacity .18s ease';
      box.style.opacity = '0';                      // fades in place, no travel
    }
    setTimeout(function () {
      if (done) done();
      flashButton();
    }, 190);
  }

  function teardown() {
    ['__tourOv', '__tourSpot', '__tourBox'].forEach(function (id) {
      var n = root.getElementById(id);
      if (n) n.parentNode.removeChild(n);
    });
    root.removeEventListener('keydown', onKey, true);
    pinned = false;
    list = [];
    if (watcher) { clearInterval(watcher); watcher = null; }
  }

  function onKey(e) {
    if (e.key === 'Escape') { teardown(); }
    else if (e.key === 'ArrowRight') { go(1); }
    else if (e.key === 'ArrowLeft') { go(-1); }
  }

  function reveal() {
    var box = root.getElementById('__tourBox');
    if (!box) return;
    if (box.dataset.shown === '1') return;
    box.dataset.shown = '1';
    box.style.transform = (box.style.transform || '') + ' scale(.97)';
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        box.style.opacity = '1';
        box.style.transform = box.style.transform.replace(' scale(.97)', ' scale(1)');
      });
    });
  }

  function placeCentre() {
    var box = root.getElementById('__tourBox');
    var spot = root.getElementById('__tourSpot');
    var ov = root.getElementById('__tourOv');
    if (!box) return;
    box.style.position = 'fixed';
    box.style.left = '50%';
    box.style.top = '50%';
    box.style.right = 'auto';
    box.style.bottom = 'auto';
    box.style.transform = 'translate(-50%, -50%)';
    box.style.maxWidth = '380px';
    reveal();
    if (spot) { spot.style.width = '0px'; spot.style.height = '0px'; spot.style.boxShadow = '0 0 0 9999px rgba(10,10,10,.74)'; }
    if (ov) ov.style.display = 'block';
  }

  function applyMode() {
    var ov = root.getElementById('__tourOv');
    var spot = root.getElementById('__tourSpot');
    var box = root.getElementById('__tourBox');
    if (!ov || !spot || !box) return;
    // A centred prompt is never docked: skip straight to centring so the card is
    // not briefly positioned in the corner first.
    var cur = list[idx];
    if (cur && cur.center) { placeCentre(); return; }
    box.style.transform = '';
    if (pinned) {
      // ring only, no dimming, nothing blocking the page
      ov.style.display = 'none';
      spot.style.boxShadow = '0 0 0 2px #fff';
      box.style.position = 'fixed';
      box.style.right = '18px';
      box.style.bottom = '18px';
      box.style.left = 'auto';
      box.style.top = 'auto';
      box.style.maxWidth = '300px';
    } else {
      ov.style.display = 'block';
      spot.style.boxShadow = '0 0 0 2px #fff,0 0 0 9999px rgba(10,10,10,.74)';
      box.style.position = 'absolute';
      box.style.right = 'auto';
      box.style.bottom = 'auto';
      box.style.maxWidth = '330px';
    }
  }

  function ensureChrome() {
    if (root.getElementById('__tourOv')) return;
    var ov = el('div', null,
      'position:fixed;inset:0;background:transparent;z-index:2147483600;pointer-events:none;');
    ov.id = '__tourOv';

    var spot = el('div', null,
      /* the outward shadow dims everything except this rect — the cutout is the highlight */
      'position:absolute;border-radius:8px;box-shadow:none;width:0;height:0;' +
      'z-index:2147483601;pointer-events:none;transition:box-shadow .18s ease, top .24s cubic-bezier(.2,.8,.2,1), left .24s cubic-bezier(.2,.8,.2,1), width .24s cubic-bezier(.2,.8,.2,1), height .24s cubic-bezier(.2,.8,.2,1);');
    spot.id = '__tourSpot';

    var box = el('div', null,
      'position:absolute;z-index:2147483602;max-width:330px;background:#242424;color:#f0f0f0;' +
      'border:1px solid #3a3a3a;border-radius:10px;padding:16px 18px;box-shadow:0 10px 34px rgba(0,0,0,.5);' +
      'font:400 13.5px/1.6 Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;' +
      // only opacity and scale animate; position changes are instant so the card
      // never slides across the screen
      'opacity:0;transform-origin:center;' +
      'transition:opacity .18s ease, transform .24s cubic-bezier(.2,.8,.2,1);');
    box.id = '__tourBox';

    root.body.appendChild(ov);
    root.body.appendChild(spot);
    root.body.appendChild(box);
    root.addEventListener('keydown', onKey, true);
  }

  function place(target) {
    if (pinned) { placeRing(target); return; }   // docked: never reposition the card
    reveal();
    var spot = root.getElementById('__tourSpot');
    var box = root.getElementById('__tourBox');
    var r = target.getBoundingClientRect();
    var pad = 8;
    var top = r.top + window.scrollY - pad, left = r.left + window.scrollX - pad;

    spot.style.top = top + 'px';
    spot.style.left = left + 'px';
    spot.style.width = (r.width + pad * 2) + 'px';
    spot.style.height = (r.height + pad * 2) + 'px';

    // prefer below, flip above when there isn't room
    var below = r.bottom + 14 + window.scrollY;
    var roomBelow = window.innerHeight - r.bottom;
    box.style.top = (roomBelow > 190 ? below : (r.top + window.scrollY - box.offsetHeight - 14)) + 'px';
    var l = r.left + window.scrollX;
    var maxL = window.scrollX + window.innerWidth - box.offsetWidth - 16;
    box.style.left = Math.max(window.scrollX + 16, Math.min(l, maxL)) + 'px';
  }

  function placeRing(target) {
    reveal();
    var spot = root.getElementById('__tourSpot');
    var r = target.getBoundingClientRect(), pad = 6;
    spot.style.top = (r.top + window.scrollY - pad) + 'px';
    spot.style.left = (r.left + window.scrollX - pad) + 'px';
    spot.style.width = (r.width + pad * 2) + 'px';
    spot.style.height = (r.height + pad * 2) + 'px';
  }

  function reattachIfLost() {
    // some views re-render large parts of the page; re-append if our nodes were removed
    if (!list.length) return;
    if (!root.getElementById('__tourBox')) { ensureChrome(); applyMode(); }
  }

  function render() {
    reattachIfLost();
    var step = list[idx];
    var target = step.s ? root.querySelector(step.s) : null;
    if (step.s && !target && !step.center) { go(1); return; }

    ensureChrome();
    applyMode();
    if (target) { try { target.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {} }

    var box = root.getElementById('__tourBox');
    var head = '<div style="font-size:10px;letter-spacing:.11em;text-transform:uppercase;color:#FFBE5F;margin-bottom:6px">'
             + (step.choices ? 'Choose a path' : (idx + 1) + ' of ' + list.length) + '</div>'
             + '<div style="font-size:15px;font-weight:600;margin-bottom:6px">' + step.t + '</div>'
             + '<div style="color:#b5b5b5">' + step.b + '</div>';

    if (step.choices) {
      box.innerHTML = head
        + '<div style="display:flex;flex-direction:column;gap:7px;margin-top:14px">'
        + step.choices.map(function (c, i) {
            return '<button data-choice="' + i + '" style="border:1px solid #3a3a3a;background:#2c2c2c;color:#f0f0f0;'
                 + 'border-radius:7px;padding:9px 12px;font:inherit;font-size:12.5px;font-weight:500;cursor:pointer;text-align:left">'
                 + c.label + '</button>';
          }).join('')
        + '</div>'
        + '';
      box.querySelectorAll('[data-choice]').forEach(function (b) {
        b.onclick = function () {
          var c = step.choices[+b.getAttribute('data-choice')];
          if (c.dismiss) {
            collapseToButton(function () {
              teardown();
              if (typeof window.onTourDismissed === 'function') window.onTourDismissed();
            });
            return;
          }
          if (c.track && typeof window.aepPickTrack === 'function') {
            try { window.aepPickTrack(c.track); } catch (e) {}
          }
          // the step-by-step flows open pinned so the page stays usable
          setTimeout(function () { start(c.flow, root, true); }, 260);
        };
      });
      var endBtn = box.querySelector('[data-tour="end"]');
      if (endBtn) endBtn.onclick = function () {
        collapseToButton(function () {
          teardown();
          if (typeof window.onTourDismissed === 'function') window.onTourDismissed();
        });
      };
      setTimeout(function () {
        if (step.center) placeCentre();
        else if (pinned) { if (target) placeRing(target); }
        else place(target);
      }, 60);
      return;
    }

    box.innerHTML = head
      + '<div style="display:flex;gap:8px;margin-top:14px;align-items:center">'
      +   '<button data-tour="prev" style="border:1px solid #3a3a3a;background:none;color:#999;border-radius:7px;padding:6px 11px;font:inherit;font-size:12px;cursor:pointer'
      +     (idx === 0 ? ';visibility:hidden' : '') + '">Back</button>'
      +   '<button data-tour="next" style="border:none;background:#FFBE5F;color:#1a1a1a;border-radius:7px;padding:6px 14px;font:inherit;font-size:12px;font-weight:600;cursor:pointer">'
      +     (idx === list.length - 1 ? 'Done' : 'Next') + '</button>'
      +   '<button data-tour="pin" title="' + (pinned ? 'Return to guided view' : 'Keep these steps open while you work')
      +     '" style="border:1px solid ' + (pinned ? '#FFBE5F' : '#3a3a3a') + ';background:none;color:'
      +     (pinned ? '#FFBE5F' : '#999') + ';border-radius:7px;padding:6px 10px;font:inherit;font-size:12px;cursor:pointer">'
      +     (pinned ? 'Unpin' : 'Pin') + '</button>'
      +   '<button data-tour="end" style="margin-left:auto;border:none;background:none;color:#777;font:inherit;font-size:12px;cursor:pointer">'
      +     (pinned ? 'Close' : 'Skip') + '</button>'
      + '</div>';

    box.querySelector('[data-tour="next"]').onclick = function () { go(1); };
    box.querySelector('[data-tour="prev"]').onclick = function () { go(-1); };
    box.querySelector('[data-tour="end"]').onclick = function () {
      collapseToButton(function () {
        teardown();
        if (typeof window.onTourDismissed === 'function') window.onTourDismissed();
      });
    };
    box.querySelector('[data-tour="pin"]').onclick = function () {
      pinned = !pinned;
      applyMode();
      render();
    };

    setTimeout(function () { if (!pinned && target) place(target); else if (target) placeRing(target); }, 60);
  }

  function go(n) {
    idx += n;
    if (idx < 0) { idx = 0; return; }
    if (idx >= list.length) { teardown(); return; }
    render();
  }

  function start(key, doc, keepPinned) {
    root = doc || document;
    curKey = key;
    // pinned unless a caller explicitly asks otherwise: the page stays usable
    pinned = (keepPinned === undefined) ? true : !!keepPinned;
    list = (STEPS[key] || []).filter(function (st) { return !st.s || !!root.querySelector(st.s); });
    if (!list.length) return false;
    idx = 0;
    render();
    watch();
    return true;
  }

  var watcher = null;
  function watch() {
    if (watcher) return;
    watcher = setInterval(function () {
      if (!list.length) { clearInterval(watcher); watcher = null; return; }
      if (!root.getElementById('__tourBox')) { ensureChrome(); applyMode(); render(); }
      else if (list[idx] && list[idx].s) {
        var t = root.querySelector(list[idx].s);
        if (t) { pinned ? placeRing(t) : place(t); }   // keep the ring on target as the page shifts
        if (pinned) applyMode();                       // and keep the card docked
      }
    }, 600);
  }

  window.SiteAuditTour = { start: start, stop: teardown, steps: STEPS };

  // The dashboard lives in an iframe; the parent asks it to run its own tour.
  window.addEventListener('message', function (e) {
    if (e && e.data === 'tour:dash') start('dash', document);
  });
})();
