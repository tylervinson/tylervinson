let generatedTemplate = '';
let generatedJSON = '';

// Message display functions
function showMessage(elementId, message, type) {
  const messageEl = document.getElementById(elementId);
  messageEl.textContent = message;
  messageEl.className = `message ${type} visible`;
  
  if (type === 'success') {
    setTimeout(() => {
      messageEl.classList.remove('visible');
    }, 3000);
  }
}

function hideMessage(elementId) {
  const messageEl = document.getElementById(elementId);
  messageEl.classList.remove('visible');
}

function setButtonLoading(buttonId, isLoading, originalText) {
  const button = document.getElementById(buttonId);
  if (isLoading) {
    button.disabled = true;
    button.innerHTML = '<span class="loading-spinner"></span>' + originalText;
  } else {
    button.disabled = false;
    button.innerHTML = originalText;
  }
}

// Auto-detect snippets from the current page
async function autoDetectSnippets() {
  const scanButton = document.getElementById('scanButton');
  const originalText = 'Scan Current Page';
  
  try {
    setButtonLoading('scanButton', true, 'Scanning...');
    hideMessage('scanMessage');
    
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    chrome.tabs.sendMessage(tab.id, { action: 'findSnippets' }, (response) => {
      setButtonLoading('scanButton', false, originalText);
      
      if (chrome.runtime.lastError) {
        showMessage('scanMessage', '❌ Unable to scan page. Make sure you\'re on a valid webpage and refresh the extension.', 'error');
        return;
      }
      
      const snippetsContainer = document.getElementById('detectedSnippets');
      
      if (response.snippets && response.snippets.length > 0) {
        snippetsContainer.innerHTML = '';
        
        response.snippets.forEach((snippet, index) => {
          const snippetDiv = document.createElement('div');
          snippetDiv.className = 'snippet-item';
          snippetDiv.innerHTML = `
            <div class="snippet-info">
              <strong>Snippet ${index + 1}</strong>
              <span class="snippet-stats">${snippet.cellCount} fields, ${snippet.sectionCount} sections</span>
            </div>
            <div class="snippet-preview">${snippet.preview}</div>
          `;
          
          snippetDiv.onclick = () => loadSnippet(index);
          snippetsContainer.appendChild(snippetDiv);
        });
        
        snippetsContainer.classList.add('visible');
        showMessage('scanMessage', `✓ Found ${response.snippets.length} snippet(s)! Click one to generate templates.`, 'success');
      } else {
        snippetsContainer.innerHTML = '<div class="no-snippets">No form snippets detected on this page</div>';
        snippetsContainer.classList.add('visible');
        showMessage('scanMessage', 'ℹ️ No form snippets detected. Try pasting HTML manually below.', 'info');
      }
    });
  } catch (error) {
    setButtonLoading('scanButton', false, originalText);
    showMessage('scanMessage', '❌ Error scanning page: ' + error.message, 'error');
  }
}

// Load a specific snippet and generate template
async function loadSnippet(index) {
  try {
    showMessage('generateMessage', 'Loading snippet...', 'info');
    
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    chrome.tabs.sendMessage(tab.id, { action: 'getSnippet', index: index }, (response) => {
      if (response.snippet) {
        document.getElementById('htmlInput').value = response.snippet.html;
        generateTemplate();
        
        // Scroll to results
        setTimeout(() => {
          document.getElementById('stats').scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        showMessage('generateMessage', '❌ Failed to load snippet', 'error');
      }
    });
  } catch (error) {
    showMessage('generateMessage', '❌ Error loading snippet: ' + error.message, 'error');
  }
}

function generateTemplate() {
  const htmlInput = document.getElementById('htmlInput').value.trim();
  
  if (!htmlInput) {
    showMessage('generateMessage', '❌ Please paste HTML content first', 'error');
    return;
  }
  
  try {
    setButtonLoading('generateButton', true, 'Generating...');
    hideMessage('generateMessage');
    
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlInput, 'text/html');
    
    const fields = [];
    const sections = [];
    
    // Find all section headers
    const sectionHeaders = doc.querySelectorAll('.slate-webFormSection h1, [data-slate-node="element"].slate-webFormSection h1');
    sectionHeaders.forEach(header => {
      const sectionText = header.textContent.trim();
      if (sectionText && sectionText !== 'Form Submission') {
        sections.push(sectionText);
      }
    });
    
    // Find all form cells (fields)
    const cells = doc.querySelectorAll('.slate-webFormCell, [data-slate-node="element"].slate-webFormCell');
    
    cells.forEach(cell => {
      const paragraphs = cell.querySelectorAll('p');
      if (paragraphs.length < 2) return;
      
      const labelElement = paragraphs[0].querySelector('strong');
      if (!labelElement) return;
      
      const label = labelElement.textContent.trim();
      
      // Try to find variable in two ways:
      // 1. Look for merge field span with data-merge-field attribute
      let variable = null;
      const variableElement = cell.querySelector('[data-merge-field="true"]');
      if (variableElement) {
        variable = variableElement.getAttribute('title') || variableElement.textContent.trim();
      } else {
        // 2. Look for plain text variable in format {$Variable_Name}
        const secondParagraph = paragraphs[1].textContent.trim();
        const match = secondParagraph.match(/\{\$([^}|]+)(?:\|[^}]*)?\}/);
        if (match) {
          variable = match[1];
        }
      }
      
      if (label && variable) {
        // Determine which section this field belongs to
        let currentSection = null;
        let prev = cell.previousElementSibling;
        while (prev) {
          if (prev.classList.contains('slate-webFormSection')) {
            const sectionHeader = prev.querySelector('h1');
            if (sectionHeader) {
              currentSection = sectionHeader.textContent.trim();
              break;
            }
          }
          prev = prev.previousElementSibling;
        }
        
        fields.push({
          label: label,
          variable: variable,
          section: currentSection
        });
      }
    });
    
    if (fields.length === 0) {
      setButtonLoading('generateButton', false, 'Generate Template');
      showMessage('generateMessage', '❌ No form fields found in the HTML. Make sure it contains merge fields.', 'error');
      return;
    }
    
    // Generate the template and JSON
    generatedTemplate = generateHTMLTemplate(fields, sections);
    generatedJSON = generateTestJSON(fields);
    
    // Update UI
    document.getElementById('fieldCount').textContent = fields.length;
    document.getElementById('sectionCount').textContent = sections.length;
    document.getElementById('stats').classList.add('visible');
    document.getElementById('templateOutput').textContent = generatedTemplate;
    document.getElementById('outputSection').classList.add('visible');
    document.getElementById('jsonOutput').textContent = generatedJSON;
    document.getElementById('jsonOutputSection').classList.add('visible');
    
    setButtonLoading('generateButton', false, 'Generate Template');
    showMessage('generateMessage', `✓ Successfully generated templates with ${fields.length} fields!`, 'success');
    
  } catch (error) {
    setButtonLoading('generateButton', false, 'Generate Template');
    showMessage('generateMessage', '❌ Error parsing HTML: ' + error.message, 'error');
    console.error(error);
  }
}

function generateTestJSON(fields) {
  const testData = {};
  
  fields.forEach(field => {
    const variable = field.variable;
    const label = field.label;
    
    // Generate appropriate test data based on field label
    testData[variable] = generateTestValue(label, variable);
  });
  
  return JSON.stringify(testData, null, 2);
}

function generateTestValue(label, variable) {
  const lowerLabel = label.toLowerCase();
  const lowerVar = variable.toLowerCase();
  
  // NPI numbers
  if (lowerLabel.includes('npi') || lowerVar.includes('npi')) {
    return '1234567890';
  }
  
  // Tax ID
  if (lowerLabel.includes('tax id') || lowerVar.includes('tax')) {
    return '12-3456789';
  }
  
  // Phone numbers
  if (lowerLabel.includes('phone') || lowerVar.includes('phone')) {
    return '(602) 555-0100';
  }
  
  // Fax numbers
  if (lowerLabel.includes('fax') || lowerVar.includes('fax')) {
    return '(602) 555-0101';
  }
  
  // Email addresses
  if (lowerLabel.includes('email') || lowerVar.includes('email')) {
    return 'contact@example.com';
  }
  
  // Addresses
  if (lowerLabel.includes('address') || lowerVar.includes('address')) {
    return '123 Main Street, Suite 100, Phoenix, AZ 85001';
  }
  
  // Specialty
  if (lowerLabel.includes('specialty') || lowerVar.includes('specialty')) {
    return 'Internal Medicine';
  }
  
  // Provider/Group Name
  if (lowerLabel.includes('provider name') || lowerLabel.includes('group name') || 
      lowerVar.includes('provider') || lowerVar.includes('group')) {
    return 'ABC Medical Group';
  }
  
  // Dates
  if (lowerLabel.includes('date') || lowerVar.includes('date')) {
    return '01/15/2024';
  }
  
  // Yes/No fields
  if (lowerLabel.includes('are you') || lowerLabel.includes('do you')) {
    return 'Yes';
  }
  
  // Office hours
  if (lowerLabel.includes('office hours') || lowerLabel.includes('hours')) {
    return 'Monday-Friday: 8:00 AM - 5:00 PM';
  }
  
  // Time fields
  if (lowerLabel.includes('start time') || lowerVar.includes('start')) {
    return '8:00 AM';
  }
  if (lowerLabel.includes('end time') || lowerVar.includes('end')) {
    return '5:00 PM';
  }
  
  // Website URL
  if (lowerLabel.includes('website') || lowerLabel.includes('url') || lowerVar.includes('url')) {
    return 'www.example.com';
  }
  
  // Signature
  if (lowerLabel.includes('signature') || lowerVar.includes('signature')) {
    return 'Dr. John Smith';
  }
  
  // Title/Degree
  if (lowerLabel.includes('title') || lowerLabel.includes('degree')) {
    return 'MD';
  }
  
  // Privilege
  if (lowerLabel.includes('privilege') || lowerVar.includes('privilege')) {
    return 'Active';
  }
  
  // Default: use the label as a template
  return `Test value for ${label}`;
}

function generateHTMLTemplate(fields, sections) {
  let html = `<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: Arial, sans-serif;
  font-size: 10pt;
  margin: 0;
  padding: 20px;
}
table {
  width: 7.5in;
  border-collapse: collapse;
  margin-bottom: 20px;
}
.section-header {
  background-color: #f2f1f1;
  font-weight: bold;
  padding: 8px;
  text-align: left;
}
.field-row td {
  padding: 6px 8px;
  border-bottom: 1px solid #e0e0e0;
  vertical-align: top;
}
.field-number {
  width: 10%;
  font-weight: bold;
}
.field-label {
  width: 45%;
  font-weight: bold;
}
.field-value {
  width: 45%;
}
.document-uploaded {
  font-style: italic;
  color: #666;
}
</style>
</head>
<body>
<table>
`;

  let rowNumber = 1;
  let currentSection = null;
  
  fields.forEach(field => {
    // Add section header if section changes
    if (field.section && field.section !== currentSection) {
      currentSection = field.section;
      html += `  <tr>
    <td colspan="3" class="section-header">${field.section}</td>
  </tr>
`;
    }
    
    // Add field row
    html += `  {if $${field.variable} != ''}
  <tr class="field-row">
    <td class="field-number">${rowNumber}</td>
    <td class="field-label">${field.label}</td>
    <td class="field-value">{$${field.variable}}</td>
  </tr>
  {/if}
`;
    rowNumber++;
  });
  
  html += `</table>
</body>
</html>`;
  
  return html;
}

function copyTemplate(event) {
  navigator.clipboard.writeText(generatedTemplate).then(() => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✓ Copied!';
    btn.style.background = '#4CAF50';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  }).catch(err => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✗ Failed';
    btn.style.background = '#f44336';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  });
}

function copyJSON(event) {
  navigator.clipboard.writeText(generatedJSON).then(() => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✓ Copied!';
    btn.style.background = '#4CAF50';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  }).catch(err => {
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✗ Failed';
    btn.style.background = '#f44336';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
    }, 2000);
  });
}

function clearAll() {
  document.getElementById('htmlInput').value = '';
  document.getElementById('templateOutput').textContent = '';
  document.getElementById('jsonOutput').textContent = '';
  document.getElementById('stats').classList.remove('visible');
  document.getElementById('outputSection').classList.remove('visible');
  document.getElementById('jsonOutputSection').classList.remove('visible');
  document.getElementById('detectedSnippets').classList.remove('visible');
  document.getElementById('detectedSnippets').innerHTML = '';
  hideMessage('scanMessage');
  hideMessage('generateMessage');
  generatedTemplate = '';
  generatedJSON = '';
}

// Initialize event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('scanButton').addEventListener('click', autoDetectSnippets);
  document.getElementById('generateButton').addEventListener('click', generateTemplate);
  document.querySelectorAll('.btn-secondary').forEach(btn => {
    if (btn.textContent === 'Clear') {
      btn.addEventListener('click', clearAll);
    }
  });
  
  // Add event listeners for copy buttons
  const copyButtons = document.querySelectorAll('.btn-success');
  copyButtons.forEach(btn => {
    if (btn.textContent.includes('Copy Template')) {
      btn.addEventListener('click', copyTemplate);
    } else if (btn.textContent.includes('Copy JSON')) {
      btn.addEventListener('click', copyJSON);
    }
  });
});
