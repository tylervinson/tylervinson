// Content script that runs on web pages to find and extract HTML snippets

// Function to get element by XPath
function getElementByXPath(xpath) {
  return document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

// Function to find elements that likely contain form snippets
function findFormSnippets() {
  const snippets = [];
  
  // Primary XPath for the document builder element
  const primaryXPath = '/html/body/div[1]/div[2]/div[2]/form/div/div/div[1]/div/div/div[1]/div[2]/div[2]/div[1]/div[1]';
  const primaryElement = getElementByXPath(primaryXPath);
  
  if (primaryElement) {
    // Check if it contains form cells or sections
    const hasCells = primaryElement.querySelectorAll('.slate-webFormCell, [data-slate-node="element"].slate-webFormCell').length > 0;
    const hasSections = primaryElement.querySelectorAll('.slate-webFormSection').length > 0;
    
    if (hasCells || hasSections) {
      snippets.push({
        index: 0,
        html: primaryElement.outerHTML,
        cellCount: primaryElement.querySelectorAll('.slate-webFormCell').length,
        sectionCount: primaryElement.querySelectorAll('.slate-webFormSection').length,
        preview: primaryElement.textContent.substring(0, 100).trim(),
        source: 'xpath'
      });
    }
  }
  
  // Fallback: Look for elements with slate-webForm classes if XPath fails
  if (snippets.length === 0) {
    const formContainers = document.querySelectorAll('[class*="slate-webForm"], [class*="webForm"]');
    
    formContainers.forEach((container, index) => {
      // Check if it contains form cells or sections
      const hasCells = container.querySelectorAll('.slate-webFormCell, [data-slate-node="element"].slate-webFormCell').length > 0;
      const hasSections = container.querySelectorAll('.slate-webFormSection').length > 0;
      
      if (hasCells || hasSections) {
        snippets.push({
          index: index,
          html: container.outerHTML,
          cellCount: container.querySelectorAll('.slate-webFormCell').length,
          sectionCount: container.querySelectorAll('.slate-webFormSection').length,
          preview: container.textContent.substring(0, 100).trim(),
          source: 'class'
        });
      }
    });
  }
  
  return snippets;
}

// Listen for messages from the sidebar
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'findSnippets') {
    const snippets = findFormSnippets();
    sendResponse({ snippets: snippets });
  } else if (request.action === 'getSnippet') {
    const snippets = findFormSnippets();
    const snippet = snippets[request.index];
    sendResponse({ snippet: snippet });
  }
  return true;
});
