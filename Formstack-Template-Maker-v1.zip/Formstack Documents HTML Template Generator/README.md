# HTML Snippet to Template Converter - Chrome Extension

Convert HTML snippets to PDF-optimized email templates with test JSON data.

## Installation Instructions

### Step 1: Download the Extension
You should have a folder called `html-converter-extension` with these files:
```
html-converter-extension/
├── manifest.json
├── sidepanel.html
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
```

### Step 2: Install in Chrome

1. Open Google Chrome
2. Go to `chrome://extensions/` (type this in the address bar)
3. Enable "Developer mode" (toggle in the top-right corner)
4. Click "Load unpacked"
5. Select the `html-converter-extension` folder
6. The extension will be installed!

**Important:** If you already installed a previous version, click the refresh icon (🔄) on the extension card in `chrome://extensions/` to reload it with the latest changes.

### Step 3: Open the Sidebar

1. Click the extension icon in your Chrome toolbar
2. The converter will open in Chrome's sidebar on the right side
3. The sidebar stays open while you browse, making it easy to convert snippets anytime!

### Step 4: Use the Extension

**Option 1: Auto-Detect (Recommended)**
1. Navigate to a page containing HTML form snippets
2. Open the sidebar (click extension icon)
3. Click "Scan Current Page"
4. Click on any detected snippet to automatically generate templates

**Option 2: Manual Paste**
1. Copy your HTML snippet manually
2. Paste it in the text area
3. Click "Generate Template"

Both methods will:
- Generate the HTML template
- Generate test JSON data
- Display field and section counts

## Features

- ✅ **Auto-detect snippets** from current page (NEW!)
- ✅ Opens in Chrome's sidebar (stays visible while browsing)
- ✅ Converts HTML snippets to email templates
- ✅ Generates test JSON data for merge fields
- ✅ Clean, flat design interface
- ✅ One-click copy functionality
- ✅ Dark mode interface
- ✅ Works completely offline

## Updating the Extension

If you make changes to the files:
1. Go to `chrome://extensions/`
2. Click the refresh icon on your extension card

## Uninstalling

1. Go to `chrome://extensions/`
2. Click "Remove" on the extension card

---

**Version:** 1.0.0
**Color Scheme:** #262c2e background, #FFBE5F accent
**Layout:** Chrome Sidebar Panel
