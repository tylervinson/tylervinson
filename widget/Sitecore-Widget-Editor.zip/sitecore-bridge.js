// =============================================================================
// Sitecore Bridge — Notifies Sitecore + TinyMCE that DOM content has changed
// =============================================================================
// 
// Problem: When we update the DOM directly, Sitecore's Experience Editor
// doesn't detect any change because TinyMCE (the rich text editor) maintains
// its own internal content model. The save button stays grayed out.
//
// Solution: After every DOM mutation we:
//   1. Find the TinyMCE editor instance that owns the modified element
//   2. Sync TinyMCE's internal content from the live DOM
//   3. Mark the editor as dirty (unsaved changes)
//   4. Fire the events Sitecore listens for to enable the save button
//
// Supports: Sitecore 9.x / 10.x Experience Editor with TinyMCE 4.x
// =============================================================================

const SitecoreBridge = {

  /**
   * Call this AFTER you've updated the DOM.
   * Pass the widget element that was modified.
   * Returns true if Sitecore was successfully notified.
   */
  notifyChange(widgetElement) {
    if (!widgetElement) return false;

    const results = {
      tinyMCE: false,
      scFieldChange: false,
      scChrome: false
    };

    // Strategy 1: TinyMCE notification (primary — this is the one that matters)
    results.tinyMCE = this._notifyTinyMCE(widgetElement);

    // Strategy 2: Sitecore field-level change event
    results.scFieldChange = this._notifySitecoreField(widgetElement);

    // Strategy 3: Sitecore chrome/frame notification
    results.scChrome = this._notifySitecoreChrome(widgetElement);

    // Strategy 4: Fallback — dispatch generic input/change events
    this._dispatchDOMEvents(widgetElement);

    console.log('[Sitecore Bridge] Notification results:', results);

    return results.tinyMCE || results.scFieldChange || results.scChrome;
  },


  // ---------------------------------------------------------------------------
  // Strategy 1: Find and notify TinyMCE
  // ---------------------------------------------------------------------------
  _notifyTinyMCE(widgetElement) {
    try {
      // TinyMCE can live in the main window or inside an iframe
      const contexts = this._getEditorContexts();

      for (const ctx of contexts) {
        const tinymce = ctx.tinymce || ctx.tinyMCE;
        if (!tinymce || !tinymce.editors) continue;

        for (const editor of tinymce.editors) {
          if (!editor || !editor.getBody) continue;

          const editorBody = editor.getBody();
          if (!editorBody) continue;

          // Check if our widget lives inside this editor's body
          if (editorBody.contains(widgetElement) || editorBody === widgetElement.closest('[contenteditable="true"]')) {
            console.log('[Sitecore Bridge] Found TinyMCE editor:', editor.id);

            // Force TinyMCE to re-read the DOM into its internal model
            const currentContent = editorBody.innerHTML;
            editor.setContent(currentContent, { no_events: false });

            // Mark as dirty (has unsaved changes)
            editor.setDirty(true);

            // Fire all relevant TinyMCE events
            editor.fire('change');
            editor.fire('input');
            editor.fire('NodeChange');
            editor.fire('SetContent');

            // If there's an undo manager, add an undo level
            if (editor.undoManager) {
              editor.undoManager.add();
            }

            return true;
          }
        }
      }

      // Fallback: if we can't find the widget inside an editor body,
      // just mark ALL editors dirty (less precise but effective)
      for (const ctx of contexts) {
        const tinymce = ctx.tinymce || ctx.tinyMCE;
        if (!tinymce || !tinymce.editors) continue;

        for (const editor of tinymce.editors) {
          if (!editor || !editor.getBody) continue;

          // Resync content from DOM
          const editorBody = editor.getBody();
          if (editorBody) {
            editor.setContent(editorBody.innerHTML, { no_events: false });
            editor.setDirty(true);
            editor.fire('change');
            editor.fire('NodeChange');
            if (editor.undoManager) editor.undoManager.add();
          }
        }
        return true;
      }
    } catch (e) {
      console.warn('[Sitecore Bridge] TinyMCE notification error:', e);
    }

    return false;
  },


  // ---------------------------------------------------------------------------
  // Strategy 2: Sitecore Experience Editor field change tracking
  // ---------------------------------------------------------------------------
  _notifySitecoreField(widgetElement) {
    try {
      const contexts = this._getEditorContexts();

      for (const ctx of contexts) {
        // Sitecore Experience Editor uses Sitecore.PageModes
        const sc = ctx.Sitecore;
        if (!sc) continue;

        // Method A: PageModes.ChromeManager
        if (sc.PageModes && sc.PageModes.ChromeManager) {
          const chromeManager = sc.PageModes.ChromeManager;
          if (chromeManager.resetChromes) {
            chromeManager.resetChromes();
            console.log('[Sitecore Bridge] Reset Sitecore chromes');
          }
        }

        // Method B: Mark page as modified via ContentEditor
        if (sc.ContentEditor && sc.ContentEditor.setModified) {
          sc.ContentEditor.setModified(true);
          console.log('[Sitecore Bridge] Set ContentEditor modified');
          return true;
        }

        // Method C: WebEditRibbon — the save button controller
        if (sc.WebEditRibbon && sc.WebEditRibbon.prototype) {
          // Try to enable save
          const ribbon = sc.WebEditRibbon.prototype;
          if (ribbon.setModified) {
            ribbon.setModified(true);
            return true;
          }
        }

        // Method D: Trigger Sitecore's field modified postback
        if (ctx.__scFieldModified) {
          ctx.__scFieldModified = true;
          return true;
        }

        // Method E: Set the global modified flag (common in SC 9.x/10.x)
        if (typeof ctx.scForm !== 'undefined' && ctx.scForm) {
          ctx.scForm.setModified(true);
          console.log('[Sitecore Bridge] Set scForm modified');
          return true;
        }
      }
    } catch (e) {
      console.warn('[Sitecore Bridge] Sitecore field notification error:', e);
    }

    return false;
  },


  // ---------------------------------------------------------------------------
  // Strategy 3: Sitecore chrome/frame-level notification
  // ---------------------------------------------------------------------------
  _notifySitecoreChrome(widgetElement) {
    try {
      // In Experience Editor, editable fields are wrapped in Sitecore "chromes"
      // which are tracked via data attributes and special wrapper elements.

      // Walk up from the widget to find the Sitecore chrome wrapper
      let chromeEl = widgetElement.closest('[scfieldtype]') 
                  || widgetElement.closest('[sc-part-of]')
                  || widgetElement.closest('.scWebEditInput')
                  || widgetElement.closest('[contenteditable="true"]');

      if (chromeEl) {
        // Dispatch events that Sitecore's chrome system listens for
        const events = ['input', 'change', 'keyup', 'blur'];
        events.forEach(eventName => {
          chromeEl.dispatchEvent(new Event(eventName, { bubbles: true }));
        });

        // Also dispatch a MutationEvent-style notification
        chromeEl.dispatchEvent(new CustomEvent('sc:fieldchanged', {
          bubbles: true,
          detail: { source: 'widget-editor-extension' }
        }));

        console.log('[Sitecore Bridge] Notified Sitecore chrome element');
        return true;
      }

      // If widget is inside an iframe (common in Experience Editor),
      // try to notify the parent frame
      if (window.parent && window.parent !== window) {
        try {
          window.parent.postMessage({
            type: 'sc:fieldmodified',
            source: 'widget-editor-extension'
          }, '*');
        } catch (e) {
          // Cross-origin, can't post to parent
        }
      }
    } catch (e) {
      console.warn('[Sitecore Bridge] Chrome notification error:', e);
    }

    return false;
  },


  // ---------------------------------------------------------------------------
  // Strategy 4: Fallback — dispatch standard DOM events
  // ---------------------------------------------------------------------------
  _dispatchDOMEvents(widgetElement) {
    try {
      // Walk up to find any contenteditable ancestor
      let editableAncestor = widgetElement.closest('[contenteditable="true"]');
      const target = editableAncestor || widgetElement;

      // Dispatch standard events that editors commonly listen for
      const eventTypes = ['input', 'change', 'keyup', 'keydown', 'blur', 'focus'];
      eventTypes.forEach(type => {
        target.dispatchEvent(new Event(type, { bubbles: true, cancelable: true }));
      });

      // Also fire a mutation-like input event
      target.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        cancelable: true,
        inputType: 'insertText'
      }));

      console.log('[Sitecore Bridge] Dispatched fallback DOM events');
    } catch (e) {
      console.warn('[Sitecore Bridge] DOM event dispatch error:', e);
    }
  },


  // ---------------------------------------------------------------------------
  // Helper: Collect all window contexts where editors might live
  // ---------------------------------------------------------------------------
  _getEditorContexts() {
    const contexts = [window];

    try {
      // Check parent frame (Experience Editor toolbar lives in parent)
      if (window.parent && window.parent !== window) {
        contexts.push(window.parent);
      }
      if (window.top && window.top !== window && window.top !== window.parent) {
        contexts.push(window.top);
      }
    } catch (e) {
      // Security restriction, just use current window
    }

    return contexts;
  }
};

// Make available globally for content-script.js
if (typeof window !== 'undefined') {
  window.SitecoreBridge = SitecoreBridge;
}
