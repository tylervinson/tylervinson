// background.js - Sitecore Widget Editor v1.3.0
const REGISTRY_URL    = 'https://www.tylervinson.com/widget/widget-registry.json';
const CURRENT_VERSION = '1.3.0';
const DOWNLOAD_URL    = 'https://www.tylervinson.com/widget/';

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);

async function checkForUpdates() {
  try {
    const res  = await fetch(REGISTRY_URL + '?cb=' + Date.now());
    if (!res.ok) return;
    const data = await res.json();
    await chrome.storage.local.set({ widgetRegistry: data });
    const remoteVersion = data.version || null;
    if (remoteVersion && remoteVersion !== CURRENT_VERSION) {
      chrome.runtime.sendMessage({
        type: 'UPDATE_AVAILABLE',
        currentVersion: CURRENT_VERSION,
        remoteVersion: remoteVersion,
        downloadUrl: DOWNLOAD_URL
      }).catch(() => {});
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#FFBE5F' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch(e) {}
}

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const url  = chrome.runtime.getURL('widget-registry.json');
    const res  = await fetch(url);
    const data = await res.json();
    await chrome.storage.local.set({ widgetRegistry: data });
  } catch(e) {}
  checkForUpdates();
});

chrome.runtime.onStartup.addListener(checkForUpdates);
setInterval(checkForUpdates, 4 * 60 * 60 * 1000);