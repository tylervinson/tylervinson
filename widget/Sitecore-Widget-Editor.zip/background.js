// Background service worker - handles extension icon clicks

chrome.action.onClicked.addListener((tab) => {
  // Open the side panel when extension icon is clicked
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Optional: Keep side panel open across navigation
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
