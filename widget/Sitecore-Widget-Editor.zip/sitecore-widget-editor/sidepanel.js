// sidepanel.js — Animated Cards Widget Editor

var currentData = null;
var currentTabId = null;

document.addEventListener('DOMContentLoaded', function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0]) return;
    currentTabId = tabs[0].id;
    pingAndLoad();
  });

  document.getElementById('apply-btn').addEventListener('click', applyChanges);
});

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === 'WIDGET_STATUS' && msg.found) pingAndLoad();
});

function pingAndLoad() {
  if (!currentTabId) return;
  chrome.tabs.sendMessage(currentTabId, { type: 'GET_WIDGET_DATA' }, function(response) {
    if (chrome.runtime.lastError || !response || !response.found) {
      setStatus('No animated cards widget found.', 'not-found');
      showNotFound();
      return;
    }
    currentData = JSON.parse(JSON.stringify(response.data));
    setStatus('Animated Cards — ready to edit', 'found');
    buildEditor(response.data);
    showEditor();
  });
}

function setStatus(msg, cls) {
  var el = document.getElementById('status-bar');
  el.textContent = msg;
  el.className = cls || '';
}

function showNotFound() {
  document.getElementById('not-found').style.display = '';
  document.getElementById('editor').style.display = 'none';
  document.getElementById('footer').style.display = 'none';
}

function showEditor() {
  document.getElementById('not-found').style.display = 'none';
  document.getElementById('editor').style.display = '';
  document.getElementById('footer').style.display = '';
}

function buildEditor(data) {
  var editorEl = document.getElementById('editor');
  editorEl.innerHTML = '';

  data.cards.forEach(function(card, idx) {
    var section = makeSection('Card ' + (idx + 1), true);
    var body = section.querySelector('.section-body');

    // Number field
    var numGroup = document.createElement('div');
    numGroup.className = 'field-group';
    var numLabel = document.createElement('label');
    numLabel.textContent = 'Number';
    var numInput = document.createElement('input');
    numInput.type = 'text';
    numInput.dataset.cardId = card.id;
    numInput.dataset.field = 'number';
    numInput.value = card.number;
    numGroup.appendChild(numLabel);
    numGroup.appendChild(numInput);
    body.appendChild(numGroup);

    // Label field
    var lblGroup = document.createElement('div');
    lblGroup.className = 'field-group';
    var lblLabel = document.createElement('label');
    lblLabel.textContent = 'Label';
    var lblInput = document.createElement('input');
    lblInput.type = 'text';
    lblInput.dataset.cardId = card.id;
    lblInput.dataset.field = 'label';
    lblInput.value = card.label;
    lblGroup.appendChild(lblLabel);
    lblGroup.appendChild(lblInput);
    body.appendChild(lblGroup);

    editorEl.appendChild(section);
  });
}

function makeSection(title, open) {
  var section = document.createElement('div');
  section.className = 'section';

  var header = document.createElement('div');
  header.className = 'section-header' + (open ? ' open' : '');

  var titleSpan = document.createElement('span');
  titleSpan.textContent = title;
  var chevron = document.createElement('span');
  chevron.className = 'chevron';
  chevron.textContent = '▼';

  header.appendChild(titleSpan);
  header.appendChild(chevron);

  var body = document.createElement('div');
  body.className = 'section-body' + (open ? ' open' : '');

  header.addEventListener('click', function() {
    var isOpen = body.classList.contains('open');
    body.classList.toggle('open', !isOpen);
    header.classList.toggle('open', !isOpen);
  });

  section.appendChild(header);
  section.appendChild(body);
  return section;
}

function collectFormData() {
  var cardMap = {};

  document.querySelectorAll('input[data-card-id]').forEach(function(inp) {
    var id = inp.dataset.cardId;
    if (!cardMap[id]) cardMap[id] = { id: id };
    cardMap[id][inp.dataset.field] = inp.value;
  });

  // Maintain original card order
  var cards = currentData.cards.map(function(c) {
    return cardMap[c.id] || c;
  });

  return { cards: cards };
}

function applyChanges() {
  var btn = document.getElementById('apply-btn');
  var statusEl = document.getElementById('apply-status');

  btn.disabled = true;
  btn.textContent = 'Applying...';
  statusEl.className = '';
  statusEl.textContent = '';

  var data = collectFormData();

  chrome.tabs.sendMessage(currentTabId, { type: 'APPLY_WIDGET_DATA', data: data }, function(response) {
    btn.disabled = false;
    btn.textContent = 'Apply Changes';

    if (chrome.runtime.lastError || !response || !response.success) {
      statusEl.className = 'error';
      statusEl.textContent = 'Failed to apply — reload the page and try again.';
      return;
    }

    statusEl.className = 'success';
    statusEl.textContent = '✓ Changes applied';
    currentData = JSON.parse(JSON.stringify(data));

    setTimeout(function() {
      statusEl.textContent = '';
      statusEl.className = '';
    }, 3000);
  });
}
