// sidepanel.js — Sitecore Widget Editor v1.0.0
// Empty starter — no widgets registered.

let currentTab = null;

document.addEventListener('DOMContentLoaded', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0]) return;
    currentTab = tabs[0];
    try {
      const url = new URL(tabs[0].url);
      document.getElementById('pageUrl').textContent = url.hostname + url.pathname.slice(0, 40);
    } catch(e) {}
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'UPDATE_AVAILABLE') {
    const banner = document.getElementById('updateBanner');
    if (banner) {
      banner.style.display = 'block';
      banner.innerHTML = '&#9888; New version available (v' + message.remoteVersion + '). '
        + '<a href="' + message.downloadUrl + '" target="_blank">Download update &rarr;</a>';
    }
  }
});
