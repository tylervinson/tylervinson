// sidepanel.js — Sitecore Widget Editor
// Auto-generated. Do not edit manually.

let currentTab = null;
let selectedWidget = null;
let widgetList = [];

document.addEventListener('DOMContentLoaded', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0]) return;
    currentTab = tabs[0];
    try {
      const url = new URL(tabs[0].url);
      document.getElementById('pageUrl').textContent = url.hostname + url.pathname.slice(0, 40);
    } catch(e) {}
    scanPage();
  });
});

function scanPage() {
  setStatus('Scanning...');
  chrome.tabs.sendMessage(currentTab.id, { type: 'GET_WIDGETS' }, response => {
    if (chrome.runtime.lastError || !response) {
      setStatus('Could not connect — reload the page and try again');
      showList([]);
      return;
    }
    widgetList = response.widgets || [];
    setStatus(widgetList.length + ' widget(s) found');
    showList(widgetList);
  });
}

function showList(widgets) {
  const content = document.getElementById('content');
  if (widgets.length === 0) {
    content.innerHTML = '<div class="empty">No registered widgets found on this page.<br><br>Make sure the page contains elements with the registered CSS classes.</div>';
    return;
  }
  let html = '<div class="section-label">Widgets on this page</div>';
  widgets.forEach((w, i) => {
    html += '<button class="widget-btn" onclick="selectWidget(' + i + ')">'
         + '<div class="name">' + w.widgetName + '</div>'
         + '<div class="meta">.' + w.widgetClass + ' &middot; ' + (w.hasItems ? w.itemCount + ' item(s)' : 'single element') + '</div>'
         + '</button>';
  });
  html += '<div style="margin-top:12px"><button class="btn btn-clear" style="width:100%;flex:none" onclick="scanPage()">Refresh Scan</button></div>';
  content.innerHTML = html;
}

function selectWidget(idx) {
  selectedWidget = widgetList[idx];
  setStatus('Loading...');
  chrome.tabs.sendMessage(currentTab.id, {
    type: 'GET_WIDGET_DATA',
    widgetClass: selectedWidget.widgetClass,
    index: selectedWidget.index
  }, response => {
    if (chrome.runtime.lastError || !response || !response.data) {
      showError('Could not load widget data.');
      return;
    }
    renderEditor(selectedWidget, response.data);
  });
}

function renderEditor(widget, data) {
  if (widget.widgetClass === 'insurance-comparison-tool') return renderInsuranceComparisonToolEditor(widget, data);
  if (widget.widgetClass === 'animated-cards') return renderAnimatedCardsEditor(widget, data);
  renderGenericEditor(widget, data);
}

function renderInsuranceComparisonToolEditor(widget, data) {
  const items=(data&&data.items)||[], plans=(data&&data.plans)||[];
  let html=getBackBtn()+'<div class="section-label">'+widget.widgetName+'</div>';
  if(items.length) {
    html+='<div class="item-card-header" style="font-size:11px;color:#FFBE5F;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">Plan Cards</div>';
    items.forEach((item,i)=>{
      const lbl=item.name||item.type||('Item '+(i+1));
      html+='<div class="item-card"><div class="item-card-header">'+lbl+'</div>';
      html += '<div class="form-group"><label>Type</label><input type="text" data-item-id="' + item.id + '" data-field="type" value="' + escHtml(item.type || '') + '"></div>';
      html += '<div class="form-group"><label>Name</label><input type="text" data-item-id="' + item.id + '" data-field="name" value="' + escHtml(item.name || '') + '"></div>';
      html += '<div class="form-group"><label>Coverage</label><select data-item-id="' + item.id + '" data-field="coverage">' + ('<option value="Individual Coverage"' + (item.coverage === 'Individual Coverage' ? ' selected' : '') + '>Individual Coverage</option>') + '' + ('<option value="Family Coverage"' + (item.coverage === 'Family Coverage' ? ' selected' : '') + '>Family Coverage</option>') + '</select></div>';
      html += '<div class="form-group"><label>Price</label><input type="text" data-item-id="' + item.id + '" data-field="price" value="' + escHtml(item.price || '') + '"></div>';
      html+='</div>';
    });
  }
  if(plans.length) {
    html+='<hr><div class="item-card-header" style="font-size:11px;color:#FFBE5F;text-transform:uppercase;letter-spacing:.05em;margin:12px 0 8px">Plan Details</div>';
    plans.forEach(plan=>{
      html+='<div class="item-card"><div class="item-card-header">'+plan.charAt(0).toUpperCase()+plan.slice(1)+' Plan</div>';
      html += '<div class="form-group"><label>Price</label><input type="text" data-grid-plan="' + plan + '" data-field="price" value="' + escHtml((data.grid && data.grid[plan] && data.grid[plan]['price']) || '') + '"></div>';
      html += '<div class="form-group"><label>Deductible</label><input type="text" data-grid-plan="' + plan + '" data-field="deductible" value="' + escHtml((data.grid && data.grid[plan] && data.grid[plan]['deductible']) || '') + '"></div>';
      html += '<div class="form-group"><label>Max Oop</label><input type="text" data-grid-plan="' + plan + '" data-field="max_oop" value="' + escHtml((data.grid && data.grid[plan] && data.grid[plan]['max-oop']) || '') + '"></div>';
      html += '<div class="form-group"><label>Coverage</label><input type="text" data-grid-plan="' + plan + '" data-field="coverage" value="' + escHtml((data.grid && data.grid[plan] && data.grid[plan]['coverage']) || '') + '"></div>';
      html += '<div class="form-group"><label>Doctor Copay</label><input type="text" data-grid-plan="' + plan + '" data-field="doctor_copay" value="' + escHtml((data.grid && data.grid[plan] && data.grid[plan]['doctor-copay']) || '') + '"></div>';
      html += '<div class="form-group"><label>Rx</label><select data-grid-plan="' + plan + '" data-field="rx">' + ('<option value="Generic only"' + ((data.grid && data.grid[plan] && data.grid[plan]['rx']) || '' === 'Generic only' ? ' selected' : '') + '>Generic only</option>') + '' + ('<option value="Generic & Brand"' + ((data.grid && data.grid[plan] && data.grid[plan]['rx']) || '' === 'Generic & Brand' ? ' selected' : '') + '>Generic & Brand</option>') + '' + ('<option value="Full coverage"' + ((data.grid && data.grid[plan] && data.grid[plan]['rx']) || '' === 'Full coverage' ? ' selected' : '') + '>Full coverage</option>') + '</select></div>';
      html += '<div class="form-group"><label>Er Copay</label><input type="text" data-grid-plan="' + plan + '" data-field="er_copay" value="' + escHtml((data.grid && data.grid[plan] && data.grid[plan]['er-copay']) || '') + '"></div>';
      html += '<div class="form-group"><label>Mental Health</label><select data-grid-plan="' + plan + '" data-field="mental_health">' + ('<option value="Limited"' + ((data.grid && data.grid[plan] && data.grid[plan]['mental-health']) || '' === 'Limited' ? ' selected' : '') + '>Limited</option>') + '' + ('<option value="Included"' + ((data.grid && data.grid[plan] && data.grid[plan]['mental-health']) || '' === 'Included' ? ' selected' : '') + '>Included</option>') + '' + ('<option value="Full coverage"' + ((data.grid && data.grid[plan] && data.grid[plan]['mental-health']) || '' === 'Full coverage' ? ' selected' : '') + '>Full coverage</option>') + '</select></div>';
      html += '<div class="form-group"><label>Dental Vision</label><select data-grid-plan="' + plan + '" data-field="dental_vision">' + ('<option value="Not included"' + ((data.grid && data.grid[plan] && data.grid[plan]['dental-vision']) || '' === 'Not included' ? ' selected' : '') + '>Not included</option>') + '' + ('<option value="Vision only"' + ((data.grid && data.grid[plan] && data.grid[plan]['dental-vision']) || '' === 'Vision only' ? ' selected' : '') + '>Vision only</option>') + '' + ('<option value="Both included"' + ((data.grid && data.grid[plan] && data.grid[plan]['dental-vision']) || '' === 'Both included' ? ' selected' : '') + '>Both included</option>') + '</select></div>';
      html+='</div>';
    });
  }
  html+=getBtnRow();
  const content=document.getElementById('content');
  content.innerHTML=html;
  attachSave(()=>{const map={}; content.querySelectorAll('[data-item-id][data-field]').forEach(inp=>{const id=inp.dataset.itemId; if(!map[id]) map[id]={id}; map[id][inp.dataset.field]=inp.value;}); const grid={}; content.querySelectorAll('[data-grid-plan][data-field]').forEach(inp=>{const p=inp.dataset.gridPlan; if(!grid[p]) grid[p]={}; grid[p][inp.dataset.field]=inp.value;}); return{items:Object.values(map),grid};}, widget);
  setStatus('Editing '+widget.widgetName);
}

function renderAnimatedCardsEditor(widget, data) {
  const items=(data&&data.items)||[];
  let html = getBackBtn()+'<div class="section-label">'+widget.widgetName+'</div>';
  items.forEach((item,i)=>{
    const lbl=item.name||item.type||('Item '+(i+1));
    html+='<div class="item-card"><div class="item-card-header">'+lbl+'</div>';
    html += '<div class="form-group"><label>Number</label><input type="text" data-item-id="' + item.id + '" data-field="number" value="' + escHtml(item.number || '') + '"></div>';
    html += '<div class="form-group"><label>Text</label><input type="text" data-item-id="' + item.id + '" data-field="text" value="' + escHtml(item.text || '') + '"></div>';
    html+='</div>';
  });
  html+=getBtnRow();
  const content=document.getElementById('content');
  content.innerHTML=html;
  attachSave(()=>{const map={}; content.querySelectorAll('[data-item-id][data-field]').forEach(inp=>{const id=inp.dataset.itemId; if(!map[id]) map[id]={id}; map[id][inp.dataset.field]=inp.value;}); return{items:Object.values(map)};}, widget);
  setStatus('Editing '+widget.widgetName);
}

function renderGenericEditor(widget, data) {
  let html = getBackBtn() + '<div class="section-label">' + widget.widgetName + '</div>';
  Object.entries(data).forEach(([key, val]) => {
    if (typeof val !== 'object') {
      html += '<div class="form-group"><label>' + key + '</label>'
           + '<input type="text" data-field="' + key + '" value="' + escHtml(String(val)) + '"></div>';
    }
  });
  html += getBtnRow();
  const content = document.getElementById('content');
  content.innerHTML = html;
  attachSave(() => collectFields(content), widget);
}

function getBackBtn() {
  return '<button class="back-btn" onclick="showList(widgetList)">&#8592; Back</button>';
}
function getBtnRow() {
  return '<div class="btn-row">'
    + '<button class="btn btn-apply" id="applyBtn">Apply Changes</button>'
    + '<button class="btn btn-clear" onclick="showList(widgetList)">Cancel</button>'
    + '</div>';
}

function attachSave(collectFn, widget) {
  const btn = document.getElementById('applyBtn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    applyChanges(widget, collectFn());
  });
}

function applyChanges(widget, data) {
  chrome.tabs.sendMessage(currentTab.id, {
    type: 'UPDATE_WIDGET_DATA',
    widgetClass: widget.widgetClass,
    index: widget.index,
    data: data
  }, response => {
    if (chrome.runtime.lastError || !response || !response.success) {
      showError('Failed to apply changes.');
    } else {
      showSuccess('Changes applied!');
    }
  });
}

function collectFields(container) {
  const data = {};
  container.querySelectorAll('[data-field]').forEach(input => {
    data[input.dataset.field] = input.value;
  });
  return data;
}

function showSuccess(msg) {
  const prev = document.querySelector('.success-msg, .error-msg');
  if (prev) prev.remove();
  const el = document.createElement('div');
  el.className = 'success-msg'; el.textContent = msg;
  document.getElementById('content').prepend(el);
  setTimeout(() => el.remove(), 3000);
  setStatus('Saved');
}
function showError(msg) {
  const prev = document.querySelector('.success-msg, .error-msg');
  if (prev) prev.remove();
  const el = document.createElement('div');
  el.className = 'error-msg'; el.textContent = msg;
  document.getElementById('content').prepend(el);
  setStatus('Error');
}
function setStatus(msg) {
  document.getElementById('status').textContent = msg;
}
function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'WIDGETS_UPDATED') {
    widgetList = message.widgets || [];
    if (!selectedWidget) showList(widgetList);
  }
  if (message.type === 'UPDATE_AVAILABLE') {
    const banner = document.getElementById('updateBanner');
    if (banner) {
      banner.style.display = 'block';
      banner.innerHTML = '&#9888; New version available (v' + message.remoteVersion + '). '
        + '<a href="' + message.downloadUrl + '" target="_blank" style="color:#FFBE5F;font-weight:500">Download update &rarr;</a>';
    }
  }
});