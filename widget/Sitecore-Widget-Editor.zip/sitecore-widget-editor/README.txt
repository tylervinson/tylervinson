Sitecore Widget Editor — v1.2.6
Generated: 3/2/2026, 12:28:04 PM
Widgets: 2

  - Insurance Plan Comparison Tool (.insurance-comparison-tool) — type, name, coverage, price
  - Animated Cards (.animated-cards) — number, text

INSTALLATION
------------
1. Unzip this file
2. Open Chrome → chrome://extensions
3. Enable Developer mode (top right toggle)
4. Click Load unpacked
5. Select the sitecore-widget-editor folder

USAGE
-----
1. Navigate to a Sitecore page with your widgets
2. Click the extension icon in the toolbar
3. The sidebar scans and lists detected widgets
4. Select a widget → edit fields → Apply Changes

ADDING MORE WIDGETS
-------------------
Run the Code Generator again for each new widget.
Each generation includes ALL registry widgets in the ZIP.
