Sitecore Widget Editor — Starter Extension v1.0.0
==================================================

This is a clean starter with no widgets registered.

To add widget support:
1. Visit https://www.tylervinson.com/widget/
2. Use the Code Generator to generate a widget
3. Install the downloaded extension ZIP (it will include your widgets)

INSTALLATION
------------
1. Unzip this file
2. Open Chrome → chrome://extensions
3. Enable Developer mode (top-right toggle)
4. Click "Load unpacked"
5. Select the sitecore-widget-editor folder

The extension will automatically notify you when an updated
version is available at tylervinson.com/widget/.
