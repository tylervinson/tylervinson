// background.js — Sitecore Widget Editor v1.2.6
// Checks tylervinson.com/widget/widget-registry.json for updates

const REGISTRY_URL = 'https://www.tylervinson.com/widget/widget-registry.json';
const CURRENT_VERSION = '1.2.6';
const DOWNLOAD_URL = 'https://www.tylervinson.com/widget/';

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);

// ── Version check ──────────────────────────────────────
async function checkForUpdates() {
  try {
    const res = await fetch(REGISTRY_URL + '?cb=' + Date.now());
    if (!res.ok) return;
    const data = await res.json();
    const remoteVersion = data.version || null;
    if (remoteVersion && remoteVersion !== CURRENT_VERSION) {
      chrome.runtime.sendMessage({
        type: 'UPDATE_AVAILABLE',
        currentVersion: CURRENT_VERSION,
        remoteVersion: remoteVersion,
        downloadUrl: DOWNLOAD_URL
      }).catch(() => {});
      // Badge the icon
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#FFBE5F' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch(e) {}
}

// Check on install/startup and every 4 hours
chrome.runtime.onInstalled.addListener(checkForUpdates);
chrome.runtime.onStartup.addListener(checkForUpdates);
setInterval(checkForUpdates, 4 * 60 * 60 * 1000);