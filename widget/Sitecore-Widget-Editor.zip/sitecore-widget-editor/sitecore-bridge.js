// sitecore-bridge.js — Notifies Sitecore of DOM changes
window.SitecoreBridge = {
  notifyChange: function(element) {
    if (!element) return;
    ['input', 'change', 'blur'].forEach(evtType => {
      element.dispatchEvent(new Event(evtType, { bubbles: true, cancelable: true }));
    });
    try {
      if (window.tinymce) {
        const editors = window.tinymce.get();
        if (editors && editors.length) {
          editors.forEach(ed => {
            try { ed.setDirty(true); ed.fire('change'); } catch(e) {}
          });
        }
      }
    } catch(e) {}
    try {
      if (window.Sitecore && window.Sitecore.PageModes) {
        if (window.Sitecore.PageModes.ChromeManager) {
          window.Sitecore.PageModes.ChromeManager.resetChromes();
        }
        document.dispatchEvent(new CustomEvent('scEditableChanged', {
          bubbles: true, detail: { element: element }
        }));
      }
    } catch(e) {}
    try {
      const m = element.getAttribute('data-sc-modified') === 'true' ? 'false' : 'true';
      element.setAttribute('data-sc-modified', m);
    } catch(e) {}
  }
};