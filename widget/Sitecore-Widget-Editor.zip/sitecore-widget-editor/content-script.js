// content-script.js — Sitecore Widget Editor v1.0.0
// No widgets registered yet. Install an updated extension from
// https://www.tylervinson.com/widget/ to add widget support.

const WIDGET_REGISTRY = [];

function detectWidgets() { return []; }
function findWidget(widgetClass, index) {
  return document.querySelectorAll('.' + widgetClass)[index] || null;
}
function getWidgetData(widgetClass, index) { return null; }
function updateWidgetData(widgetClass, index, data) { return false; }

let _observerTimer = null;
new MutationObserver(() => {
  clearTimeout(_observerTimer);
  _observerTimer = setTimeout(() => {
    chrome.runtime.sendMessage({ type: 'WIDGETS_UPDATED', widgets: detectWidgets() }).catch(() => {});
  }, 500);
}).observe(document.body, { childList: true, subtree: true });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_WIDGETS') {
    sendResponse({ widgets: detectWidgets() });
    return true;
  }
  if (msg.type === 'GET_WIDGET_DATA') {
    sendResponse({ data: getWidgetData(msg.widgetClass, msg.index || 0) });
    return true;
  }
  if (msg.type === 'UPDATE_WIDGET_DATA') {
    sendResponse({ success: updateWidgetData(msg.widgetClass, msg.index || 0, msg.data) });
    return true;
  }
});

chrome.runtime.sendMessage({ type: 'WIDGETS_UPDATED', widgets: detectWidgets() }).catch(() => {});
