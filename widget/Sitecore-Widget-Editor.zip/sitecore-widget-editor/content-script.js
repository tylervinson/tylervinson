// content-script.js — Sitecore Widget Editor v1.2.6
// Auto-generated. Do not edit manually.

// ============================================================
// WIDGET REGISTRY
// ============================================================
const WIDGET_REGISTRY = [
  {
    class: 'insurance-comparison-tool',
    name: 'Insurance Plan Comparison Tool',
    mode: 'composite',
    hasItems: true,
    hasGrid: true,
    fields: ['type', 'name', 'coverage', 'price'],
    gridPlans: ['basic', 'standard', 'premium', 'family'],
    gridFields: ['price', 'deductible', 'max-oop', 'coverage', 'doctor-copay', 'rx', 'er-copay', 'mental-health', 'dental-vision']
  },
  {
    class: 'animated-cards',
    name: 'Animated Cards',
    mode: 'items',
    hasItems: true,
    hasGrid: false,
    fields: ['number', 'text'],
    gridPlans: [],
    gridFields: []
  }
];

// ============================================================
// DETECT WIDGETS ON PAGE
// ============================================================
function detectWidgets() {
  const found = [];
  WIDGET_REGISTRY.forEach(config => {
    document.querySelectorAll('.' + config.class).forEach((el, idx) => {
      found.push({
        widgetClass: config.class,
        widgetName: config.name,
        mode: config.mode || (config.hasItems ? 'items' : (config.hasGrid ? 'grid' : 'single')),
        hasItems: config.hasItems || false,
        hasGrid: config.hasGrid || false,
        fields: config.fields,
        index: idx,
        itemCount: config.hasItems ? el.querySelectorAll('[data-item-id]').length : (config.gridPlans ? config.gridPlans.length : 1),
      });
    });
  });
  return found;
}

// ============================================================
// FIND WIDGET ELEMENT
// ============================================================
function findWidget(widgetClass, index) {
  return document.querySelectorAll('.' + widgetClass)[index] || null;
}

// ============================================================
// GET WIDGET DATA (router)
// ============================================================
function getWidgetData(widgetClass, index) {
  const element = findWidget(widgetClass, index);
  if (!element) return null;
  if (widgetClass === 'insurance-comparison-tool') return getInsuranceComparisonToolData(element);
  if (widgetClass === 'animated-cards') return getAnimatedCardsData(element);
  return null;
}

// ============================================================
// UPDATE WIDGET DATA (router)
// ============================================================
function updateWidgetData(widgetClass, index, data) {
  const element = findWidget(widgetClass, index);
  if (!element) return false;
  if (widgetClass === 'insurance-comparison-tool') return updateInsuranceComparisonToolData(element, data);
  if (widgetClass === 'animated-cards') return updateAnimatedCardsData(element, data);
  return false;
}

// ============================================================
// WIDGET IMPLEMENTATIONS
// ============================================================
// --- Insurance Plan Comparison Tool ---
function getInsuranceComparisonToolData(el) {
  const items = Array.from(el.querySelectorAll('[data-item-id]')).map(item => ({
    id: item.getAttribute('data-item-id'),
      type: item.getAttribute('data-type') || '',
      name: item.getAttribute('data-name') || '',
      coverage: item.getAttribute('data-coverage') || '',
      price: item.getAttribute('data-price') || ''
  }));
  const gd = getInsuranceComparisonToolGridData(el);
  return { items, plans: gd.plans, grid: gd.grid };
}

function updateInsuranceComparisonToolData(el, data) {
  if (data.items) { data.items.forEach(d => {
    const item = el.querySelector('[data-item-id="' + d.id + '"]'); if (!item) return;
    if (d.type !== undefined) {
      item.setAttribute('data-type', d.type);
      item.querySelectorAll('[data-type]').forEach(n => n.setAttribute('data-type', d.type));
      const v = item.querySelector('.item-type');
      if (v) v.textContent = d.type;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(item);
    }
    if (d.name !== undefined) {
      item.setAttribute('data-name', d.name);
      item.querySelectorAll('[data-name]').forEach(n => n.setAttribute('data-name', d.name));
      const v = item.querySelector('.item-name');
      if (v) v.textContent = d.name;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(item);
    }
    if (d.coverage !== undefined) {
      item.setAttribute('data-coverage', d.coverage);
      item.querySelectorAll('[data-coverage]').forEach(n => n.setAttribute('data-coverage', d.coverage));
      const v = item.querySelector('.item-coverage');
      if (v) v.textContent = d.coverage;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(item);
    }
    if (d.price !== undefined) {
      item.setAttribute('data-price', d.price);
      item.querySelectorAll('[data-price]').forEach(n => n.setAttribute('data-price', d.price));
      const v = item.querySelector('.item-price');
      if (v) v.textContent = d.price;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(item);
    }
  }); }
  if (data.grid) updateInsuranceComparisonToolGridData(el, data);
  return true;
}

function getInsuranceComparisonToolGridData(el) {
  const plans = [...new Set(Array.from(el.querySelectorAll('[data-plan]')).map(c => c.getAttribute('data-plan')))];
  const result = {};
  plans.forEach(plan => { result[plan] = {};
    el.querySelectorAll('[data-plan="' + plan + '"][data-field]').forEach(cell => {
      result[plan][cell.getAttribute('data-field')] = cell.getAttribute('data-value') || cell.textContent.trim();
    });
  });
  return { plans, grid: result };
}

function updateInsuranceComparisonToolGridData(el, data) {
  if (!data.grid) return false;
  Object.entries(data.grid).forEach(([plan, flds]) => {
    Object.entries(flds).forEach(([field, value]) => {
      const cell = el.querySelector('[data-plan="' + plan + '"][data-field="' + field + '"]');
      if (!cell) return;
      cell.setAttribute('data-value', value); cell.textContent = value;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(cell);
    });
  });
  return true;
}

// --- Animated Cards ---
function getAnimatedCardsData(el) {
  return { items: Array.from(el.querySelectorAll('[data-item-id]')).map(item => ({
    id: item.getAttribute('data-item-id'),
      number: item.getAttribute('data-number') || '',
      text: item.getAttribute('data-text') || ''
  })) };
}

function updateAnimatedCardsData(el, data) {
  if (!data.items) return false;
  data.items.forEach(d => {
    const item = el.querySelector('[data-item-id="' + d.id + '"]');
    if (!item) return;
    if (d.number !== undefined) {
      item.setAttribute('data-number', d.number);
      item.querySelectorAll('[data-number]').forEach(n => n.setAttribute('data-number', d.number));
      const v = item.querySelector('.item-number');
      if (v) v.textContent = d.number;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(item);
    }
    if (d.text !== undefined) {
      item.setAttribute('data-text', d.text);
      item.querySelectorAll('[data-text]').forEach(n => n.setAttribute('data-text', d.text));
      const v = item.querySelector('.item-text');
      if (v) v.textContent = d.text;
      if (window.SitecoreBridge) window.SitecoreBridge.notifyChange(item);
    }
  });
  return true;
}

// ============================================================
// MUTATION OBSERVER
// ============================================================
let _observerTimer = null;
new MutationObserver(() => {
  clearTimeout(_observerTimer);
  _observerTimer = setTimeout(() => {
    chrome.runtime.sendMessage({ type: 'WIDGETS_UPDATED', widgets: detectWidgets() }).catch(() => {});
  }, 500);
}).observe(document.body, { childList: true, subtree: true });

// ============================================================
// MESSAGE HANDLER
// ============================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_WIDGETS') {
    sendResponse({ widgets: detectWidgets() });
    return true;
  }
  if (msg.type === 'GET_WIDGET_DATA') {
    sendResponse({ data: getWidgetData(msg.widgetClass, msg.index || 0) });
    return true;
  }
  if (msg.type === 'UPDATE_WIDGET_DATA') {
    sendResponse({ success: updateWidgetData(msg.widgetClass, msg.index || 0, msg.data) });
    return true;
  }
});

// Initial scan
chrome.runtime.sendMessage({ type: 'WIDGETS_UPDATED', widgets: detectWidgets() }).catch(() => {});