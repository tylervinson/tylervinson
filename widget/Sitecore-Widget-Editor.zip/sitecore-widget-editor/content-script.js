// content-script.js — Animated Cards Widget Editor

function getWidget() {
  return document.querySelector('.card-row.editable-widget');
}

function getWidgetData() {
  var widget = getWidget();
  if (!widget) return null;

  var cards = [];
  var counters = widget.querySelectorAll('.number[id^="counter"]');

  for (var i = 0; i < counters.length; i++) {
    var counter = counters[i];
    var card = counter.closest('.profile-card');

    // Get number — text content minus the % symbol span
    var clone = counter.cloneNode(true);
    var symbol = clone.querySelector('.percent-symbol');
    if (symbol) symbol.remove();
    var number = clone.textContent.trim();

    var copyText = card ? card.querySelector('.copy-text') : null;

    cards.push({
      id: counter.id,
      number: number,
      label: copyText ? copyText.textContent.trim() : ''
    });
  }

  return { cards: cards };
}

function applyWidgetData(data) {
  var widget = getWidget();
  if (!widget) return false;

  if (data.cards) {
    for (var i = 0; i < data.cards.length; i++) {
      var cardData = data.cards[i];
      var counter = document.getElementById(cardData.id);
      if (!counter) continue;

      // Update number — preserve the % symbol span
      if (cardData.number !== undefined) {
        var symbol = counter.querySelector('.percent-symbol');
        counter.textContent = cardData.number;
        // Re-append % symbol
        if (symbol) {
          counter.appendChild(symbol);
        } else {
          var s = document.createElement('span');
          s.className = 'percent-symbol';
          s.textContent = '%';
          counter.appendChild(s);
        }
        // Keep data-target in sync so counter animation uses the new value
        counter.setAttribute('data-target', cardData.number.replace(/[^0-9.]/g, ''));
      }

      // Update label
      if (cardData.label !== undefined) {
        var card = counter.closest('.profile-card');
        if (card) {
          var copyText = card.querySelector('.copy-text');
          if (copyText) copyText.textContent = cardData.label;
        }
      }
    }
  }

  notifySitecore(widget);
  return true;
}

function notifySitecore(element) {
  ['input', 'change', 'blur'].forEach(function(evtType) {
    element.dispatchEvent(new Event(evtType, { bubbles: true, cancelable: true }));
  });
  try {
    if (window.Sitecore && window.Sitecore.PageModes && window.Sitecore.PageModes.ChromeManager) {
      window.Sitecore.PageModes.ChromeManager.resetChromes();
    }
  } catch(e) {}
  try {
    if (window.tinymce) {
      window.tinymce.get().forEach(function(ed) {
        try { ed.setDirty(true); ed.fire('change'); } catch(e) {}
      });
    }
  } catch(e) {}
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'GET_WIDGET_DATA') {
    var widget = getWidget();
    if (!widget) {
      sendResponse({ found: false });
    } else {
      sendResponse({ found: true, data: getWidgetData() });
    }
    return true;
  }
  if (msg.type === 'APPLY_WIDGET_DATA') {
    var success = applyWidgetData(msg.data);
    sendResponse({ success: success });
    return true;
  }
  if (msg.type === 'PING') {
    sendResponse({ found: !!getWidget() });
    return true;
  }
});

chrome.runtime.sendMessage({ type: 'WIDGET_STATUS', found: !!getWidget() }).catch(function() {});
