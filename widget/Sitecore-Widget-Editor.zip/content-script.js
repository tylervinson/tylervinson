// content-script.js - Sitecore Widget Editor v1.3.0
// No local registry. Field definitions passed in each message from the sidepanel.

function detectWidgets(registry) {
  if (!registry || !registry.widgets) return [];
  var found = [];
  registry.widgets.forEach(function(def) {
    document.querySelectorAll('.' + def.class).forEach(function(el, idx) {
      found.push({ widgetClass: def.class, name: def.name, index: idx });
    });
  });
  return found;
}

function getWidgetData(def, index) {
  if (!def) return null;
  var root = document.querySelectorAll('.' + def.class)[index];
  if (!root) return null;
  var data = {};
  (def.standaloneFields || []).forEach(function(f) {
    var el = root.querySelector(f.selector);
    data[f.key] = el ? (f.attr ? el.getAttribute(f.attr) : el.textContent.trim()) : '';
  });
  if (def.repeat) {
    var items = root.querySelectorAll(def.repeat.selector);
    data.items = [];
    items.forEach(function(item, i) {
      var row = { _index: i };
      def.fields.forEach(function(f) {
        if (f.selector) {
          var el = item.querySelector(f.selector);
          row[f.key] = el ? (f.attr ? el.getAttribute(f.attr) : el.textContent.trim()) : '';
        } else if (f.gridSelector) {
          var pn  = i + 1;
          var cs  = f.gridCellSelector.replace('{planNum}', pn);
          var gr  = root.querySelector(f.gridSelector);
          var cel = gr ? gr.querySelector(cs) : null;
          row[f.key] = cel ? cel.textContent.trim() : '';
        }
      });
      data.items.push(row);
    });
  }
  return data;
}

function updateWidgetData(def, index, data) {
  if (!def) return false;
  var root = document.querySelectorAll('.' + def.class)[index];
  if (!root || !data) return false;
  (def.standaloneFields || []).forEach(function(f) {
    if (data[f.key] === undefined) return;
    var el = root.querySelector(f.selector);
    if (!el) return;
    if (f.attr) { el.setAttribute(f.attr, data[f.key]); } else { el.textContent = data[f.key]; }
    window.SitecoreBridge.notifyChange(el);
  });
  if (def.repeat && data.items) {
    var items = root.querySelectorAll(def.repeat.selector);
    data.items.forEach(function(row, i) {
      var item = items[i];
      if (!item) return;
      var pn = i + 1;
      def.fields.forEach(function(f) {
        if (row[f.key] === undefined) return;
        var val = row[f.key];
        if (f.selector) {
          var el = item.querySelector(f.selector);
          if (el) { if (f.attr) { el.setAttribute(f.attr, val); } else { el.textContent = val; } window.SitecoreBridge.notifyChange(el); }
        }
        if (f.syncDataAttr) {
          var sv = f.syncNumeric ? String(val).replace(/[^0-9.]/g, '') : val;
          if (sv) item.setAttribute(f.syncDataAttr, sv);
        }
        if (f.gridSelector) {
          var cs  = f.gridCellSelector.replace('{planNum}', pn);
          var gr  = root.querySelector(f.gridSelector);
          var cel = gr ? gr.querySelector(cs) : null;
          if (cel) { cel.textContent = val; window.SitecoreBridge.notifyChange(cel); }
        }
      });
    });
  }
  return true;
}

function cloneItem(def, widgetIndex) {
  if (!def || !def.repeat) return false;
  var root  = document.querySelectorAll('.' + def.class)[widgetIndex];
  if (!root) return false;
  var items = root.querySelectorAll(def.repeat.selector);
  if (!items.length) return false;
  var last  = items[items.length - 1];
  var clone = last.cloneNode(true);
  // Clear all text fields on the clone
  def.fields.forEach(function(f) {
    if (f.selector) {
      var el = clone.querySelector(f.selector);
      if (el) { if (f.attr) { el.setAttribute(f.attr, ''); } else { el.textContent = ''; } }
    }
  });
  last.parentNode.insertBefore(clone, last.nextSibling);
  window.SitecoreBridge.notifyChange(root);
  return true;
}

function deleteItem(def, widgetIndex, itemIndex) {
  if (!def || !def.repeat) return false;
  var root  = document.querySelectorAll('.' + def.class)[widgetIndex];
  if (!root) return false;
  var items = root.querySelectorAll(def.repeat.selector);
  if (items.length <= 1) return false; // never delete the last one
  var item  = items[itemIndex];
  if (!item) return false;
  item.parentNode.removeChild(item);
  window.SitecoreBridge.notifyChange(root);
  return true;
}

var _ot = null;
new MutationObserver(function() {
  clearTimeout(_ot);
  _ot = setTimeout(function() {
    chrome.runtime.sendMessage({ type: 'DOM_CHANGED' }).catch(function() {});
  }, 500);
}).observe(document.body, { childList: true, subtree: true });

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'GET_WIDGETS') {
    sendResponse({ widgets: detectWidgets(msg.registry) });
    return true;
  }
  if (msg.type === 'GET_WIDGET_DATA') {
    sendResponse({ data: getWidgetData(msg.def, msg.index || 0) });
    return true;
  }
  if (msg.type === 'UPDATE_WIDGET_DATA') {
    sendResponse({ success: updateWidgetData(msg.def, msg.index || 0, msg.data) });
    return true;
  }
  if (msg.type === 'CLONE_ITEM') {
    sendResponse({ success: cloneItem(msg.def, msg.index || 0) });
    return true;
  }
  if (msg.type === 'DELETE_ITEM') {
    sendResponse({ success: deleteItem(msg.def, msg.widgetIndex || 0, msg.itemIndex) });
    return true;
  }
});
