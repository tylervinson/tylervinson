// =============================================================================
// Content Script — Widget Editor Extension
// Automatically detects widgets with .editable-widget class
// =============================================================================

console.log('[Widget Editor] Content script loaded');

// ---------------------------------------------------------------------------
// Mutation observer for dynamically loaded widgets
// ---------------------------------------------------------------------------
let observer = null;

function setupMutationObserver() {
  if (observer) return;

  observer = new MutationObserver(() => {
    clearTimeout(observer._timeout);
    observer._timeout = setTimeout(() => {
      const widgets = document.querySelectorAll('.editable-widget');
      widgets.forEach(widget => {
        if (!widget.dataset.widgetDetected) {
          widget.dataset.widgetDetected = 'true';
          const widgetClass = getWidgetClass(widget);
          console.log(`[Widget Editor] Auto-detected widget: ${widgetClass}`);
        }
      });
    }, 500);
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupMutationObserver);
} else {
  setupMutationObserver();
}

// ---------------------------------------------------------------------------
// Message handler
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === 'detectWidgets') {
    const foundWidgets = detectWidgets();
    if (foundWidgets.length > 0) {
      sendResponse({ widgets: foundWidgets });
    }
    return foundWidgets.length > 0;
  }

  if (request.action === 'getWidgetData') {
    const el = findWidgetElement(request.widgetClass);
    if (!el) return false;
    const data = getWidgetData(request.widgetClass);
    sendResponse({ data });
    return true;
  }

  if (request.action === 'updateWidgetData') {
    const el = findWidgetElement(request.widgetClass);
    if (!el) return false;
    const success = updateWidgetData(request.widgetClass, request.data);
    sendResponse({ success });
    return true;
  }

  return false;
});

// ---------------------------------------------------------------------------
// Helper: Get widget class from element
// ---------------------------------------------------------------------------
function getWidgetClass(element) {
  const classes = Array.from(element.classList);
  return classes.find(c => c !== 'editable-widget') || classes[1] || 'unknown';
}

// ---------------------------------------------------------------------------
// Helper: Find widget element
// ---------------------------------------------------------------------------
function findWidgetElement(className) {
  return document.querySelector(`.editable-widget.${className}`);
}

// ---------------------------------------------------------------------------
// Detect all widgets on page
// ---------------------------------------------------------------------------
function detectWidgets() {
  const widgets = document.querySelectorAll('.editable-widget');
  const found = [];

  widgets.forEach(widget => {
    const widgetClass = getWidgetClass(widget);
    found.push({
      className: widgetClass,
      name: widget.dataset.widgetName || widgetClass.replace(/-/g, ' '),
      description: widget.dataset.widgetDescription || ''
    });
  });

  return found;
}

// ---------------------------------------------------------------------------
// Get widget data - extract editable fields
// ---------------------------------------------------------------------------
function getWidgetData(widgetClass) {
  const widget = findWidgetElement(widgetClass);
  if (!widget) return null;

  // Check if widget has multi-object pattern
  const objects = widget.querySelectorAll('[data-object-id]');
  
  if (objects.length > 0) {
    return extractMultiObjectData(widget, objects);
  } else {
    return extractSingleObjectData(widget);
  }
}

function extractMultiObjectData(widget, objects) {
  const data = { objects: [] };

  objects.forEach(obj => {
    const item = { id: obj.dataset.objectId };
    
    // Find all editable elements within this object
    const editables = findEditableElements(obj);
    
    editables.forEach(el => {
      const field = extractFieldData(el);
      if (field) {
        Object.assign(item, field);
      }
    });

    data.objects.push(item);
  });

  return data;
}

function extractSingleObjectData(widget) {
  const data = {};
  
  // Find all editable elements in widget
  const editables = findEditableElements(widget);
  
  editables.forEach(el => {
    const field = extractFieldData(el);
    if (field) {
      Object.assign(data, field);
    }
  });

  return data;
}

function findEditableElements(container) {
  const editables = [];
  
  // Text elements with dynamic-content or data-content
  container.querySelectorAll('.dynamic-content, .data-content').forEach(el => {
    if (el.tagName.toLowerCase() !== 'a' && el.tagName.toLowerCase() !== 'img') {
      editables.push({ element: el, type: 'text' });
    }
  });
  
  // Links with dynamic-link or data-link
  container.querySelectorAll('.dynamic-link, .data-link').forEach(el => {
    editables.push({ element: el, type: 'link' });
  });
  
  // Images with dynamic-img or data-img
  container.querySelectorAll('.dynamic-img, .data-img').forEach(el => {
    editables.push({ element: el, type: 'image' });
  });
  
  return editables;
}

function extractFieldData(editable) {
  const { element, type } = editable;
  const field = {};
  
  if (type === 'text') {
    // Look for data-p-1, data-h1-1, data-li-1, etc.
    const attr = Array.from(element.attributes).find(a => 
      a.name.startsWith('data-') && a.name.match(/-\d+$/)
    );
    
    if (attr) {
      // Has data attribute - extract value from attribute
      const fieldName = attr.name.replace('data-', '').replace(/-/g, '_');
      field[fieldName] = attr.value;
    } else {
      // No data attribute - extract from visible text
      // Generate a field name based on position
      const fieldName = `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      field[fieldName] = element.textContent || '';
      element.dataset._tempFieldName = fieldName; // Store for update
    }
    
  } else if (type === 'link') {
    // Look for data-a-1, data-a-2, etc.
    const attr = Array.from(element.attributes).find(a => 
      a.name.startsWith('data-a-') && a.name.match(/-\d+$/)
    );
    
    if (attr) {
      const fieldName = attr.name.replace('data-', '').replace(/-/g, '_');
      field[fieldName + '_url'] = attr.value;
      field[fieldName + '_text'] = element.textContent || '';
    } else {
      const fieldName = `link_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      field[fieldName + '_url'] = element.getAttribute('href') || '';
      field[fieldName + '_text'] = element.textContent || '';
      element.dataset._tempFieldName = fieldName;
    }
    
  } else if (type === 'image') {
    // Look for data-img-1, data-img-2, etc.
    const attr = Array.from(element.attributes).find(a => 
      a.name.startsWith('data-img-') && a.name.match(/-\d+$/)
    );
    
    if (attr) {
      const fieldName = attr.name.replace('data-', '').replace(/-/g, '_');
      field[fieldName + '_url'] = attr.value;
      field[fieldName + '_alt'] = element.getAttribute('alt') || '';
    } else {
      const fieldName = `img_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      field[fieldName + '_url'] = element.getAttribute('src') || '';
      field[fieldName + '_alt'] = element.getAttribute('alt') || '';
      element.dataset._tempFieldName = fieldName;
    }
  }
  
  return field;
}

// ---------------------------------------------------------------------------
// Update widget data
// ---------------------------------------------------------------------------
function updateWidgetData(widgetClass, data) {
  const widget = findWidgetElement(widgetClass);
  if (!widget) return false;

  console.log(`[Widget Editor] Updating widget: ${widgetClass}`, data);

  if (data.objects) {
    return updateMultiObjectWidget(widget, data);
  } else {
    return updateSingleObjectWidget(widget, data);
  }
}

function updateMultiObjectWidget(widget, data) {
  const objects = widget.querySelectorAll('[data-object-id]');
  
  data.objects.forEach((obj, index) => {
    if (!objects[index]) return;
    
    updateElementsInContainer(objects[index], obj);
  });

  notifySitecore(widget);
  return true;
}

function updateSingleObjectWidget(widget, data) {
  updateElementsInContainer(widget, data);
  notifySitecore(widget);
  return true;
}

function updateElementsInContainer(container, data) {
  Object.keys(data).forEach(key => {
    if (key === 'id') return;
    
    const value = data[key];
    
    // Check if this is a URL or text field for links/images
    if (key.endsWith('_url')) {
      const baseKey = key.replace('_url', '');
      const textKey = baseKey + '_text';
      updateLinkOrImage(container, baseKey, value, data[textKey]);
    } else if (key.endsWith('_text') || key.endsWith('_alt')) {
      // Skip - handled with _url fields
      return;
    } else {
      // Regular text field
      updateTextField(container, key, value);
    }
  });
}

function updateTextField(container, fieldName, value) {
  const attrName = 'data-' + fieldName.replace(/_/g, '-');
  
  // Try to find element by data attribute
  let element = container.querySelector(`[${attrName}]`);
  
  // If not found, try by temp field name
  if (!element) {
    element = container.querySelector(`[data-_temp-field-name="${fieldName}"]`);
  }
  
  if (!element) return;
  
  // Update data attribute if it exists
  if (element.hasAttribute(attrName)) {
    element.setAttribute(attrName, value);
  }
  
  // Always update visible text
  element.textContent = value;
}

function updateLinkOrImage(container, fieldName, url, textOrAlt) {
  const attrName = 'data-' + fieldName.replace(/_/g, '-');
  
  // Try to find element by data attribute
  let element = container.querySelector(`[${attrName}]`);
  
  // If not found, try by temp field name
  if (!element) {
    element = container.querySelector(`[data-_temp-field-name="${fieldName}"]`);
  }
  
  if (!element) return;
  
  const tagName = element.tagName.toLowerCase();
  
  if (tagName === 'a') {
    // Update link
    if (element.hasAttribute(attrName)) {
      element.setAttribute(attrName, url);
    }
    element.setAttribute('href', url);
    if (textOrAlt !== undefined) {
      element.textContent = textOrAlt;
    }
  } else if (tagName === 'img') {
    // Update image
    if (element.hasAttribute(attrName)) {
      element.setAttribute(attrName, url);
    }
    element.setAttribute('src', url);
    if (textOrAlt !== undefined) {
      element.setAttribute('alt', textOrAlt);
    }
  }
}

// ---------------------------------------------------------------------------
// Helper: Notify Sitecore of changes
// ---------------------------------------------------------------------------
function notifySitecore(widget) {
  if (widget && window.SitecoreBridge) {
    const notified = window.SitecoreBridge.notifyChange(widget);
    console.log(`[Widget Editor] Sitecore notified: ${notified}`);
  } else {
    console.warn('[Widget Editor] SitecoreBridge not available');
  }
}
