// ─── DASHBOARD ───────────────────────────────────────────────────────────────

/* Sanity check: bundled Quill should be loaded before sidepanel.js runs.
   If it isn't, richtext fields silently broken — warn loudly. */
if (typeof Quill === 'undefined') {
  console.error('[ZMW] CRITICAL: Quill is not defined. The quill.js script failed to load. Richtext fields will not work.');
} else {
  console.log('[ZMW] Quill loaded, version:', Quill.version || '(unknown)');
}

/* Self-diagnosing startup. If anything throws during init, show the error
   directly in the panel instead of leaving it blank. */
window.addEventListener('error', function(e) {
  try {
    var body = document.body;
    if (!body) return;
    var existing = document.getElementById('zmw-startup-error');
    if (existing) return; // only show the first one
    var box = document.createElement('div');
    box.id = 'zmw-startup-error';
    box.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:#1a1a1a;color:#e57373;padding:16px;font-family:Menlo,Consolas,monospace;font-size:11px;z-index:99999;overflow:auto;line-height:1.4;';
    box.innerHTML =
      '<div style="color:#FFBE5F;font-weight:600;margin-bottom:8px;font-size:12px;">Startup error</div>' +
      '<div style="color:#e0e0e0;margin-bottom:8px;white-space:pre-wrap;">' + (e.message || 'Unknown error') + '</div>' +
      '<div style="color:#888;font-size:10px;">' + (e.filename || '') + ':' + (e.lineno || 0) + ':' + (e.colno || 0) + '</div>' +
      (e.error && e.error.stack ? '<pre style="color:#888;font-size:10px;margin-top:8px;white-space:pre-wrap;">' + e.error.stack + '</pre>' : '');
    body.appendChild(box);
  } catch (ee) {}
});

var _currentView = 'dashboard'; // 'dashboard' | 'widget'
var _scHost = null;
var _scUsername = null;
var _searchTimer = null;

// ── View switching ──────────────────────────────────────────────────────────

function showDashboard() {
  _currentView = 'dashboard';
  document.getElementById('view-dashboard').style.display = 'block';
  document.getElementById('view-widget').style.display = 'none';
  document.getElementById('picker').style.display = 'none';
  document.getElementById('apply-bar').style.display = 'none';
  document.getElementById('homeBtn').classList.add('hidden');
  document.getElementById('header-text').querySelector('h1').textContent = 'Widget Editor';
  loadCheckedOut();
}

function showWidgetView() {
  _currentView = 'widget';
  document.getElementById('view-dashboard').style.display = 'none';
  document.getElementById('view-widget').style.display = 'flex';
  document.getElementById('homeBtn').classList.remove('hidden');
}

// ── Recents ─────────────────────────────────────────────────────────────────

var MAX_RECENTS = 10;

function addRecent(itemId, itemName, itemPath) {
  if (!itemId || !itemName) return;
  chrome.storage.local.get('recentItems', function(data) {
    var recents = data.recentItems || [];
    // Remove if already exists
    recents = recents.filter(function(r) { return r.id !== itemId; });
    // Add to front
    recents.unshift({ id: itemId, name: itemName, path: itemPath || '', ts: Date.now() });
    // Cap at max
    recents = recents.slice(0, MAX_RECENTS);
    chrome.storage.local.set({ recentItems: recents });
    if (_currentView === 'dashboard') renderRecents(recents);
  });
}

function renderRecents(recents) {
  var el = document.getElementById('recentsList');
  if (!recents || recents.length === 0) {
    el.innerHTML = '<div class="dash-empty">No recent items yet</div>';
    return;
  }
  el.innerHTML = '';
  recents.forEach(function(item) {
    el.appendChild(makeDashItem(item.name, item.path, item.id, null));
  });
}

function loadRecents() {
  chrome.storage.local.get('recentItems', function(data) {
    renderRecents(data.recentItems || []);
  });
}

// ── Checked Out ─────────────────────────────────────────────────────────────

function loadCheckedOut() {
  var el = document.getElementById('lockedList');
  var countEl = document.getElementById('lockedCount');
  el.innerHTML = '<div class="dash-empty">Loading...</div>';
  fetchLockedItems(null, el, countEl);
}

function fetchLockedItems(username, el, countEl) {
  // Delegate entirely to content script — API key lives there only
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0]) {
      el.innerHTML = '<div class="dash-empty">No active tab found</div>';
      return;
    }
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_LOCKED_ITEMS' }, { frameId: 0 }, function(res) {
      if (chrome.runtime.lastError || !res) {
        el.innerHTML = '<div class="dash-empty">Could not reach Content Editor</div>';
        return;
      }
      if (res.error) {
        el.innerHTML = '<div class="dash-empty">Could not load checked out items: ' + res.error + '</div>';
        return;
      }
      var locked = res.items || [];
      countEl.textContent = locked.length ? String(locked.length) : '';
      if (locked.length === 0) {
        el.innerHTML = '<div class="dash-empty">No items checked out</div>';
        return;
      }
      el.innerHTML = '';
      locked.forEach(function(item) {
        var name = item.ItemName || item.DisplayName || '';
        var path = item.ItemPath || '';
        var id = item.ItemID || '';
        el.appendChild(makeDashItem(name, path, id, 'locked'));
      });
    });
  });
}

// ── Search ───────────────────────────────────────────────────────────────────

function initSearch() {
  var input = document.getElementById('dashSearch');
  var resultsEl = document.getElementById('searchResults');
  var spinner = document.getElementById('searchSpinner');
  var sectionsEl = document.getElementById('section-recents');
  var lockedEl = document.getElementById('section-locked');

  input.addEventListener('input', function() {
    clearTimeout(_searchTimer);
    var q = input.value.trim();
    if (!q) {
      resultsEl.style.display = 'none';
      resultsEl.innerHTML = '';
      sectionsEl.style.display = 'block';
      lockedEl.style.display = 'block';
      spinner.style.display = 'none';
      return;
    }
    sectionsEl.style.display = 'none';
    lockedEl.style.display = 'none';
    spinner.style.display = 'inline';
    _searchTimer = setTimeout(function() { runSearch(q); }, 350);
  });
}

function runSearch(q) {
  var resultsEl = document.getElementById('searchResults');
  var spinner = document.getElementById('searchSpinner');
  var url = 'https://' + _scHost + '/sitecore/api/ssc/item/search' +
    '?term=' + encodeURIComponent(q) +
    '&includeStandardTemplateFields=false' +
    '&pageSize=15' +
    '&database=master';

  fetch(url, { credentials: 'include' })
    .then(function(r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(function(d) {
      spinner.style.display = 'none';
      resultsEl.style.display = 'block';
      resultsEl.innerHTML = '';
      var results = (d && d.Results) ? d.Results : (Array.isArray(d) ? d : []);
      if (results.length === 0) {
        resultsEl.innerHTML = '<div class="dash-empty" style="padding:8px 0">No results for "' + q + '"</div>';
        return;
      }
      results.forEach(function(item) {
        var name = item.ItemName || item.Name || item.DisplayName || '';
        var path = item.ItemPath || item.Path || '';
        var template = item.TemplateName || item.ItemTemplateName || '';
        var id = item.ItemID || item.Id || item.ID || '';
        var row = document.createElement('div');
        row.className = 'search-result';
        row.innerHTML =
          '<div style="flex:1;min-width:0;">' +
            '<div class="search-result-name">' + escHtml(name) + '</div>' +
            '<div class="search-result-path">' + escHtml(path) + '</div>' +
          '</div>' +
          '<div class="search-result-template">' + escHtml(template) + '</div>';
        row.onclick = function() {
          addRecent(id, name, path);
          navigateToItem(id, path);
        };
        resultsEl.appendChild(row);
      });
    })
    .catch(function() {
      spinner.style.display = 'none';
      resultsEl.style.display = 'block';
      resultsEl.innerHTML = '<div class="dash-empty" style="padding:8px 0">Search failed</div>';
    });
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function makeDashItem(name, path, itemId, badge) {
  var row = document.createElement('div');
  row.className = 'dash-item';
  var badgeHtml = badge ? '<span class="dash-item-badge ' + badge + '">' + badge + '</span>' : '';
  row.innerHTML =
    '<div class="dash-item-icon"><svg width="10" height="12" viewBox="0 0 10 12" fill="none"><rect x="0.5" y="0.5" width="9" height="11" rx="1" stroke="#888"/><line x1="2" y1="3.5" x2="8" y2="3.5" stroke="#888"/><line x1="2" y1="5.5" x2="8" y2="5.5" stroke="#888"/><line x1="2" y1="7.5" x2="6" y2="7.5" stroke="#888"/></svg></div>' +
    '<div class="dash-item-body">' +
      '<div class="dash-item-name">' + escHtml(name || '') + '</div>' +
      '<div class="dash-item-path">' + escHtml(path || '') + '</div>' +
    '</div>' +
    badgeHtml;
  if (itemId) row.onclick = function() { navigateToItem(itemId, path); };
  return row;
}

function navigateToItem(itemId, path) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0]) return;
    // Send to frame 0 — scForm lives in the top CE frame
    chrome.tabs.sendMessage(tabs[0].id, { type: 'NAVIGATE_TO_ITEM', itemId: itemId }, { frameId: 0 }, function(res) {
      if (chrome.runtime.lastError || !res || !res.success) {
        // Fallback: try without frameId constraint
        chrome.tabs.sendMessage(tabs[0].id, { type: 'NAVIGATE_TO_ITEM', itemId: itemId });
      }
    });
  });
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function detectScHost(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0]) { if (cb) cb(); return; }
    try {
      var u = new URL(tabs[0].url);
      _scHost = u.host;
      var sub = document.getElementById('pageUrl');
      if (sub) sub.textContent = u.hostname;
    } catch(e) {}
    if (cb) cb();
  });
}

function detectScUsername() {
  // Ask content script to read the username from the CE page DOM
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_SC_USERNAME' }, function(res) {
      if (!chrome.runtime.lastError && res && res.username) {
        _scUsername = res.username;
        if (_currentView === 'dashboard') loadCheckedOut();
      }
    });
  });
}

// sidepanel.js - Sitecore Widget Editor v4.1.0
var REGISTRY_URL='https://www.tylervinson.com/widget/widget-registry.json';
var _registry=null,currentTab=null,foundWidgets=[],activeWidget=null;

function fetchRegistry(cb){
  function applyRegistry(remote) {
    // Always load bundled registry first, then merge remote widgets on top
    fetch(chrome.runtime.getURL('widget-registry.json'))
      .then(function(r) { return r.json(); })
      .then(function(bundled) {
        // Build merged widget list: start with bundled, override/add from remote
        var merged = bundled.widgets.slice();
        if (remote && remote.widgets) {
          remote.widgets.forEach(function(rw) {
            var idx = merged.findIndex(function(bw) { return bw.class === rw.class; });
            if (idx >= 0) { merged[idx] = rw; } else { merged.push(rw); }
          });
        }
        _registry = Object.assign({}, remote || bundled, { widgets: merged });
        var version = (_registry && _registry.version) || bundled.version;
        if (version) {
          chrome.storage.local.set({ lastSeenRegistryVersion: version });
          chrome.action.setBadgeText({ text: '' });
        }
        cb(null);
      })
      .catch(function() { cb(new Error('Could not load bundled registry')); });
  }
  fetch(REGISTRY_URL+'?cb='+Date.now())
    .then(function(r) { return r.json(); })
    .then(function(d) { applyRegistry(d); })
    .catch(function() { applyRegistry(null); });
}

function getWidgetDef(cls){if(!_registry||!_registry.widgets)return null;for(var i=0;i<_registry.widgets.length;i++){if(_registry.widgets[i].class===cls)return _registry.widgets[i];}return null;}

document.addEventListener('DOMContentLoaded',function(){
  // Dashboard init — chain async calls so _scHost is set before loading data
  loadRecents();
  initSearch();
  showDashboard();
  // Detect host for search URL, but don't gate anything behind it
  detectScHost(function() {});
  loadCheckedOut();
  detectScUsername();
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_SC_ITEM_NAME' }, { frameId: 0 }, function(res) {
      if (!chrome.runtime.lastError && res && res.itemId) {
        addRecent(res.itemId, res.itemName || res.itemId, tabs[0].url || '');
        loadRecents();
      }
    });
  });

  document.getElementById('homeBtn').addEventListener('click', function() {
    showDashboard();
    loadRecents();
    loadCheckedOut();
  });

  document.getElementById('widgetSelect').addEventListener('change', function() {
    // Remove the placeholder prompt once user picks something
    var prompt = this.querySelector('option[disabled]');
    if (prompt) prompt.remove();
    loadWidget(foundWidgets[parseInt(this.value, 10)]);
  });chrome.tabs.query({active:true,currentWindow:true},function(tabs){if(!tabs[0])return;currentTab=tabs[0];try{var u=new URL(tabs[0].url);document.getElementById('pageUrl').textContent=u.hostname+u.pathname.slice(0,50);}catch(e){}setStateMsg('Loading registry...');fetchRegistry(function(err){if(err||!_registry){setStateMsg('Could not load widget registry.');return;}scanPage();});

  document.getElementById('refreshBtn').addEventListener('click', function() {
    var btn = document.getElementById('refreshBtn');
    var prevWidget = activeWidget;
    btn.classList.add('spinning');
    setStatus('Refreshing registry...');
    activeWidget = null;
    fetchRegistry(function(err) {
      btn.classList.remove('spinning');
      if (err || !_registry) {
        activeWidget = prevWidget;
        setStatus('Registry fetch failed', 'err');
        return;
      }
      activeWidget = prevWidget;
      scanPage(!!prevWidget);
      setStatus(prevWidget ? 'Registry refreshed ✓' : 'Registry refreshed ✓', 'ok');
      setTimeout(function() {
        setStatus(prevWidget ? 'Editing: ' + prevWidget.name : 'Ready');
      }, 2000);
    });
  });});});
var _bgRescanInterval = null;
var _scanInProgress   = false;

function startBackgroundRescan() {
  if (_bgRescanInterval) return;
  _bgRescanInterval = setInterval(function() {
    /* Only re-poll while no widgets are active */
    if (foundWidgets && foundWidgets.length > 0) { stopBackgroundRescan(); return; }
    chrome.runtime.sendMessage({ type: 'GET_WIDGETS_ALL_FRAMES', registry: _registry }, function(res) {
      if (chrome.runtime.lastError) return;
      var widgets = res ? res.widgets : [];
      if (widgets.length > 0) {
        stopBackgroundRescan();
        handleWidgets(widgets, false, res ? res.mode : null);
      }
    });
  }, 3000);
}

function stopBackgroundRescan() {
  if (_bgRescanInterval) { clearInterval(_bgRescanInterval); _bgRescanInterval = null; }
}

function scanPage(restoreActive, _attempt) {
  var attempt = _attempt || 1;
  /* Concurrency guard: ignore new scan requests while one is already running.
     Retries from inside the same scan pass _attempt > 1 so they bypass this. */
  if (_scanInProgress && attempt === 1) return;
  _scanInProgress = true;
  chrome.runtime.sendMessage({ type: 'GET_WIDGETS_ALL_FRAMES', registry: _registry }, function(res) {
    if (chrome.runtime.lastError) { _scanInProgress = false; setStateMsg('No editable widgets found on this page.'); return; }
    var widgets = res ? res.widgets : [];
    if (widgets.length === 0 && attempt < 10) {
      // Fast retry burst — iframe may not be ready yet
      setTimeout(function() { scanPage(restoreActive, attempt + 1); }, 600);
      if (attempt === 1) setStateMsg('Scanning' + '...');
      return;
    }
    _scanInProgress = false;
    handleWidgets(widgets, restoreActive, res ? res.mode : null);
    /* If still no widgets after the fast burst, keep polling slowly so that
       unlocking the item in Sitecore is picked up without the user having to
       navigate away and back. */
    if (widgets.length === 0) { startBackgroundRescan(); } else { stopBackgroundRescan(); }
  });
}

function handleWidgets(widgets, restoreActive, mode) {

  foundWidgets = widgets || [];
  if (widgets && widgets.length > 0) {
    showWidgetView();
  } else {
    showDashboard();
    loadRecents();
    loadCheckedOut();
  }
  var select = document.getElementById('widgetSelect');
  select.innerHTML = '';

  if (foundWidgets.length === 0) {
    document.getElementById('picker').style.display = 'none';
    setStateMsg('No registered widgets found on this page.');
    setStatus('No widgets detected');
    return;
  }

  // Auto-load — CE only, single widget per scan
  document.getElementById('picker').style.display = 'none';
  loadWidget(foundWidgets[0]);
}

function loadWidget(widgetDef){activeWidget=widgetDef;var def=getWidgetDef(widgetDef.widgetClass);if(!def){setStateMsg('Widget definition not found in registry.');return;}setStateMsg('Loading...');var defWithIds=Object.assign({},def,{itemId:widgetDef.itemId,fieldId:widgetDef.fieldId});chrome.runtime.sendMessage({type:'FRAME_MSG',msg:{type:'GET_WIDGET_DATA',def:defWithIds,index:widgetDef.index,registry:_registry}},function(res){if(chrome.runtime.lastError||!res||!res.data){setStateMsg('Could not read widget data.');return;}renderForm(defWithIds,res.data);setStatus('Editing: '+widgetDef.name);});}



// Convert "10:00 AM" / "2:30 PM" → "10:00" / "14:30"
function parseTo24h(str) {
  str = (str || '').trim();
  var m = str.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
  if (!m) return '00:00';
  var h = parseInt(m[1], 10), min = m[2], period = (m[3] || '').toUpperCase();
  if (period === 'PM' && h !== 12) h += 12;
  if (period === 'AM' && h === 12) h = 0;
  return (h < 10 ? '0' + h : h) + ':' + min;
}

// Convert 24h "14:30" → "2:30 PM"
function formatDisplayTime(hhmm) {
  var parts = (hhmm || '00:00').split(':');
  var h = parseInt(parts[0], 10), min = parts[1] || '00';
  var period = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return h + ':' + min + ' ' + period;
}

// Short month names
var MONTH_SHORT_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function renderForm(def, data) {
  var c = document.getElementById('content');
  c.innerHTML = '';

  if (def.standaloneFields && def.standaloneFields.length > 0) {
    var h = document.createElement('div'); h.className = 'section-header'; h.textContent = 'General'; c.appendChild(h);
    def.standaloneFields.forEach(function(field) { c.appendChild(makeField(field.label, 'sa_' + field.key, data[field.key] || '', field.type)); });
  }

  if (def.repeat && data.items) {
    var sh = document.createElement('div'); sh.className = 'section-header'; sh.textContent = def.repeat.groupLabel + 's'; c.appendChild(sh);

    var today = new Date();
    today.setHours(0, 0, 0, 0);

    // Date field key for filtering — now 'datetime'
    var dateFieldKey = def.repeat.dateField || null;

    /* Count meetings older than 60 days — these are candidates for manual purge.
       The Apply path automatically drops anything older than 90 days as a backstop. */
    if (dateFieldKey) {
      var sixtyDaysAgo = new Date(today);
      sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
      var purgeCount = 0;
      data.items.forEach(function(item) {
        if (!item[dateFieldKey]) return;
        var d = new Date(String(item[dateFieldKey]).split('T')[0]);
        if (!isNaN(d) && d < sixtyDaysAgo) purgeCount++;
      });
      if (purgeCount > 0) {
        var tidy = document.createElement('button');
        tidy.className = 'tidy-btn';
        tidy.textContent = 'Remove ' + purgeCount + ' meeting' + (purgeCount === 1 ? '' : 's') + ' older than 60 days';
        tidy.title = 'Permanently removes past meetings dated more than 60 days ago. Sitecore version history retains them.';
        tidy.addEventListener('click', function() {
          if (!confirm('Remove ' + purgeCount + ' past meeting' + (purgeCount === 1 ? '' : 's') + ' older than 60 days from this widget?\n\nThis is permanent in the live field, but Sitecore version history will retain prior versions.')) return;
          purgePastMeetings(def, 60);
        });
        c.appendChild(tidy);
      }
    }

    var visibleCount = 0;
    data.items.forEach(function(item, i) {
      // Filter out past meetings
      if (dateFieldKey && item[dateFieldKey]) {
        var meetingDate = new Date(item[dateFieldKey]);
        meetingDate.setHours(0, 0, 0, 0);
        if (meetingDate < today) { return; }
      }

      // For existing meetings, build a datetime-local value from data-end + time text
      // item.datetime holds the raw data-end attribute (YYYY-MM-DD)
      // item.time holds the .zmw-time text (e.g. "10:00 AM") — derive HH:MM from it
      var dtValue = item.datetime || '';
      if (dtValue && dtValue.length === 10) {
        // Parse time text into 24h HH:MM
        var timeStr = item.time || '00:00';
        var t24 = parseTo24h(timeStr);
        dtValue = dtValue + 'T' + t24;
      }
      // Override item.datetime with the combined value for the field input
      item.datetime = dtValue;

      visibleCount++;
      var glf = def.repeat.groupLabelField;
      var title = (glf && item[glf]) ? (def.repeat.groupLabel + ' ' + (i+1) + ' — ' + item[glf]) : (def.repeat.groupLabel + ' ' + (i+1));
      var grp = document.createElement('div'); grp.className = 'card-group'; grp.setAttribute('data-item-index', i);
      var gh = document.createElement('div'); gh.className = 'card-group-header'; gh.textContent = title; gh.id = 'ghdr_' + i; grp.appendChild(gh);
      var body = document.createElement('div'); body.className = 'card-group-body';

      var btnF  = def.fields.filter(function(f) { return f.selector || (f.attr && !f.gridSelector); });
      var gridF = def.fields.filter(function(f) { return !f.selector && !f.attr && f.gridSelector; });

      btnF.forEach(function(f) {
        var fe = makeField(
          f.label + (f.hint ? ' <span style="color:#444;font-weight:400">— ' + f.hint + '</span>' : ''),
          'it_' + i + '_' + f.key,
          item[f.key] || '',
          f.type || 'text',
          true // allowHtmlLabel
        );
        if (glf && f.key === glf) {
          fe.querySelector('input,textarea').addEventListener('input', (function(idx) { return function(e) {
            var el = document.getElementById('ghdr_' + idx);
            if (el) el.textContent = e.target.value ? (def.repeat.groupLabel + ' ' + (idx+1) + ' — ' + e.target.value) : (def.repeat.groupLabel + ' ' + (idx+1));
          }; })(i));
        }
        body.appendChild(fe);
      });

      if (gridF.length > 0) {
        var sub = document.createElement('div'); sub.className = 'sub-header'; sub.textContent = 'Comparison Table'; body.appendChild(sub);
        gridF.forEach(function(f) { body.appendChild(makeField(f.label, 'it_' + i + '_' + f.key, item[f.key] || '', f.type || 'text')); });
      }

      // Remove button
      var delBtn = document.createElement('button');
      delBtn.className = 'item-delete-btn';
      delBtn.textContent = 'Remove Meeting';
      delBtn.addEventListener('click', (function(grpEl) { return function() {
        if (confirm('Remove this meeting?')) { grpEl.remove(); }
      }; })(grp));
      body.appendChild(delBtn);

      grp.appendChild(body); c.appendChild(grp);
    });

    if (visibleCount === 0) {
      var empty = document.createElement('div'); empty.className = 'state-msg'; empty.style.padding = '12px 0';
      empty.textContent = 'No upcoming meetings. Use the button below to add one.';
      c.appendChild(empty);
    }

    // Add Meeting button
    var addBtn = document.createElement('button');
    addBtn.className = 'add-item-btn';
    addBtn.textContent = '+ Add Meeting';
    addBtn.addEventListener('click', function() { addNewMeetingForm(def, c, addBtn); });
    c.appendChild(addBtn);
  }

  document.getElementById('apply-bar').style.display = 'block';
  document.getElementById('applyBtn').onclick = applyChanges;
}

function addNewMeetingForm(def, container, addBtn) {
  var newIndex = Date.now();
  var grp = document.createElement('div'); grp.className = 'card-group'; grp.setAttribute('data-new-item', '1');
  var gh = document.createElement('div'); gh.className = 'card-group-header'; gh.textContent = 'New Meeting'; grp.appendChild(gh);
  var body = document.createElement('div'); body.className = 'card-group-body';

  def.fields.forEach(function(f) {
    if (!f.selector && !f.attr) return; // skip grid fields
    body.appendChild(makeField(
      f.label + (f.hint ? ' <span style="color:#444;font-weight:400">— ' + f.hint + '</span>' : ''),
      'new_' + newIndex + '_' + f.key,
      '',
      f.type || 'text',
      true
    ));
  });

  var delBtn = document.createElement('button');
  delBtn.className = 'item-delete-btn'; delBtn.textContent = 'Cancel';
  delBtn.addEventListener('click', function() { grp.remove(); });
  body.appendChild(delBtn);

  grp.appendChild(body);
  container.insertBefore(grp, addBtn);
}


function applyChanges() {
  if (!activeWidget) return;
  var def = getWidgetDef(activeWidget.widgetClass);
  if (!def) return;
  setStatus('Applying… waiting for editor dialog');
  var data = collectFormData(def);
  chrome.runtime.sendMessage({ type: 'FRAME_MSG', msg: { type: 'UPDATE_WIDGET_DATA', def: def, index: activeWidget.index, data: data, registry: _registry } }, function(res) {
    if (chrome.runtime.lastError || !res || !res.success) {
      var errMsg = (res && res.error === 'timeout')
        ? 'Editor dialog did not open — try again'
        : (res && res.error === 'Edit HTML button not found')
          ? 'Edit HTML button not found — ensure a Rich Text field is selected'
          : 'Error applying changes';
      setStatus(errMsg, 'err'); return;
    }
    var isCE = activeWidget && activeWidget.mode === 'content-editor';
    setStatus(isCE ? 'Saved to Sitecore ✓' : 'Changes applied ✓', 'ok');
    setTimeout(function() { setStatus('Editing: ' + activeWidget.name); }, 2500);
  });
}

/* Manual cleanup — sends current form data with a tighter past-cutoff so
   buildUpdatedHtml drops meetings older than the cutoff in addition to writing
   the form's normal edits. */
function purgePastMeetings(def, cutoffDays) {
  if (!activeWidget) return;
  setStatus('Removing past meetings…');
  var data = collectFormData(def);
  data.__pastCutoffDays = cutoffDays;
  chrome.runtime.sendMessage({ type: 'FRAME_MSG', msg: { type: 'UPDATE_WIDGET_DATA', def: def, index: activeWidget.index, data: data, registry: _registry } }, function(res) {
    if (chrome.runtime.lastError || !res || !res.success) {
      setStatus('Error removing past meetings', 'err'); return;
    }
    setStatus('Past meetings removed ✓ — reload to refresh', 'ok');
    /* Reload the widget to refresh the form (purged items shouldn't appear anymore) */
    setTimeout(function() {
      if (activeWidget) { loadWidget(activeWidget); }
    }, 1500);
  });
}

function collectFormData(def) {
  var data = {};
  (def.standaloneFields || []).forEach(function(f) { data[f.key] = val('sa_' + f.key); });

  // Helper: get value from a field row, accounting for Quill richtext fields
  function getFieldValue(elementId) {
    var el = document.getElementById(elementId);
    if (!el) return null;
    var parent = el.parentElement;
    if (parent && parent._quill) {
      var html = parent._quill.root.innerHTML;
      if (html === '<p><br></p>') return '';
      return html;
    }
    /* el.value works for inputs/textareas, but is undefined on divs (richtext).
       If Quill failed to mount on a richtext field, fall back to reading the
       div's innerHTML so we don't silently send empty data. */
    if (el.value !== undefined) return el.value;
    if (el.tagName === 'DIV') {
      console.warn('[ZMW] Richtext field', elementId, 'has no Quill instance — falling back to div innerHTML. Quill probably failed to load.');
      return el.innerHTML || '';
    }
    return null;
  }

  if (def.repeat) {
    data.items = [];
    var c = document.getElementById('content');

    // Surviving existing items
    var existingGroups = c.querySelectorAll('.card-group[data-item-index]');
    existingGroups.forEach(function(grp) {
      var i = grp.getAttribute('data-item-index');
      var row = { __originalIndex: parseInt(i, 10) };
      def.fields.forEach(function(f) {
        var v = getFieldValue('it_' + i + '_' + f.key);
        if (v !== null) { row[f.key] = v; }
      });
      data.items.push(row);
    });

    // New items
    var newGroups = c.querySelectorAll('.card-group[data-new-item]');
    newGroups.forEach(function(grp) {
      var row = { __originalIndex: -1 };
      // Walk every field row in this group — handles inputs, textareas,
      // AND Quill editors (which don't have a regular .value)
      var fieldRows = grp.querySelectorAll('.field-row');
      fieldRows.forEach(function(fr) {
        var idEl = fr.querySelector('[id^="new_"]');
        if (!idEl) return;
        var m = idEl.id.match(/^new_\d+_(.+)$/);
        if (!m) return;
        if (fr._quill) {
          var html = fr._quill.root.innerHTML;
          row[m[1]] = (html === '<p><br></p>') ? '' : html;
        } else {
          row[m[1]] = idEl.value;
        }
      });
      if (row.title || row.datetime) { data.items.push(row); }
    });
  }

  return data;
}




function makeField(label, id, value, type, allowHtmlLabel) {
  var row = document.createElement('div'); row.className = 'field-row';
  var lbl = document.createElement('label'); lbl.setAttribute('for', id);
  if (allowHtmlLabel) { lbl.innerHTML = label; } else { lbl.textContent = label; }
  row.appendChild(lbl);

  if (type === 'richtext') {
    // Quill needs the host element to be attached to the document before init —
    // otherwise it can't measure layout and the toolbar fails to render. The
    // caller appends `row` AFTER makeField returns, so defer the Quill init
    // to a microtask. By the time setTimeout(0) fires, `editorEl` is in the DOM.
    var editorEl = document.createElement('div');
    editorEl.id = id;
    row.appendChild(editorEl);
    setTimeout(function() {
      if (!editorEl.isConnected) {
        console.warn('[ZMW] Quill init: host element not attached, skipping');
        return;
      }
      try {
        var quill = new Quill(editorEl, {
          theme: 'snow',
          placeholder: 'Detail body — supports bold, italic, links, lists, and images.',
          modules: {
            toolbar: [
              ['bold', 'italic'],
              [{ list: 'ordered' }, { list: 'bullet' }],
              ['link', 'image'],
              ['clean']
            ]
          }
        });
        if (value) { quill.clipboard.dangerouslyPasteHTML(value); }
        row._quill = quill;
      } catch (e) {
        console.error('[ZMW] Quill init failed:', e);
      }
    }, 0);
    return row;
  }

  var inp;
  if (type === 'textarea') {
    inp = document.createElement('textarea');
  } else {
    inp = document.createElement('input');
    if (type === 'date' || type === 'datetime-local' || type === 'url' || type === 'email' || type === 'number' || type === 'tel') {
      inp.type = type;
    } else {
      inp.type = 'text';
    }
  }
  inp.id = id; inp.value = value || ''; row.appendChild(inp);
  return row;
}

function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function setStateMsg(msg) { document.getElementById('content').innerHTML = '<div class="state-msg">' + msg + '</div>'; document.getElementById('apply-bar').style.display = 'none'; }
function setStatus(msg, cls) { var el = document.getElementById('status'); el.textContent = msg; el.className = cls || ''; }

chrome.runtime.onMessage.addListener(function(message) {
  if (message.type === 'CONTENT_ITEM_CHANGED') {
    // Track in recents
    if (message.itemId) {
      addRecent(message.itemId, message.itemName || message.itemId, message.itemPath || '');
    }
    // Scan for widgets first — only fall back to dashboard if none found
    activeWidget = null;
    setTimeout(function() { scanPage(false); }, 800);
  }
  if (message.type === 'UPDATE_AVAILABLE') {
    var b = document.getElementById('updateBanner');
    b.style.display = 'block';
    b.innerHTML = '&#9888; New version available (v' + message.remoteVersion + '). <a href="' + message.downloadUrl + '" target="_blank">Download update &rarr;</a>';
  }
  if (message.type === 'DOM_CHANGED' && currentTab && activeWidget) { scanPage(true); }
  if (message.type === 'WYSIWYG_STATUS') {
    if (message.status === 'waiting') setStatus('Waiting for editor dialog…');
  }
});
