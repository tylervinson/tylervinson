// content-script.js — Sitecore Widget Editor

/* ─── DEDUPE ──────────────────────────────────────────────────────────────────
   When the extension is reloaded while a Sitecore page is open, Chrome injects
   a new content-script instance but the old one stays registered. Every
   chrome.runtime message then fires N message handlers, causing duplicate
   API calls and duplicate UPDATE flows. This claim-the-window flag ensures
   only the most-recent injection handles messages; older instances exit
   their handlers early. */
if (window.__zmwContentScriptLoaded__) {
  console.warn('[ZMW] An older content-script instance is still loaded. Reload the Sitecore page to clear it.');
}
window.__zmwContentScriptLoaded__ = (window.__zmwContentScriptLoaded__ || 0) + 1;
var ZMW_INSTANCE_ID = window.__zmwContentScriptLoaded__;
function isCurrentInstance() { return window.__zmwContentScriptLoaded__ === ZMW_INSTANCE_ID; }

// ─── CONSTANTS ───────────────────────────────────────────────────────────────

var SSC_API_KEY        = '{90524103-7799-489C-9E53-C0D995207FB4}';
var WYSIWYG_MAX_ATTEMPTS  = 30;   // 30 × 200 ms = 6 s
var WYSIWYG_POLL_INTERVAL = 200;  // ms

/* Concurrency guard so duplicate UPDATE_WIDGET_DATA messages don't race */
var ZMW_UPDATE_IN_PROGRESS = false;

// ─── ENVIRONMENT ─────────────────────────────────────────────────────────────

function isContentEditorTop() {
  return /Content%20Editor|ContentEditor/i.test(window.location.href) &&
         window === window.top;
}

// ─── LOCKED ITEMS (dashboard only) ───────────────────────────────────────────

function fetchLockedItemsForUser(cb) {
  var scUsername = null;
  var logoutArea = document.querySelector('#ctl00_SmartPanel') ||
                   document.querySelector('.scLoginPanel') ||
                   document.body;
  var links = logoutArea ? logoutArea.querySelectorAll('a') : [];
  for (var i = 0; i < links.length; i++) {
    if (/log.?out/i.test(links[i].textContent || links[i].title || '')) {
      var prev = links[i].previousElementSibling;
      if (prev && prev.tagName === 'A') { scUsername = prev.textContent.trim(); break; }
    }
  }
  if (!scUsername) {
    var m = (document.body ? document.body.innerHTML : '').match(/sitecore\\([a-zA-Z0-9._@-]+)/i);
    if (m) scUsername = m[1];
  }
  var searchTerm = scUsername ? scUsername.replace(/^.*[\\/]/, '') : null;
  if (!searchTerm) { cb(null, []); return; }

  var url = 'https://' + window.location.host +
    '/sitecore/api/ssc/item/search' +
    '?term=' + encodeURIComponent('__lock:*' + searchTerm + '*') +
    '&sc_apikey=' + encodeURIComponent(SSC_API_KEY) +
    '&includeStandardTemplateFields=true' +
    '&fields=ItemID,ItemName,ItemPath,__lock' +
    '&pageSize=50&database=master';

  fetch(url, { credentials: 'include' })
    .then(function(r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    .then(function(d) {
      cb(null, (d && d.Results ? d.Results : []).filter(function(item) {
        return item.__lock && item.__lock.indexOf('owner') !== -1;
      }));
    })
    .catch(function(e) { cb(e, []); });
}

// ─── ITEM DETECTION (dashboard recent items) ──────────────────────────────────

function detectCurrentItemId() {
  var el = document.querySelector('input.scEditorHeaderQuickInfoInput');
  if (el && el.value) {
    var m = el.value.match(/[{(]([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})[})]/);
    if (m) return m[1].toLowerCase();
  }
  return null;
}

function detectCurrentItemName() {
  var el = document.querySelector('.scEditorHeaderTitlePanel') ||
           document.querySelector('#scEditorHeaderTitle');
  if (el && el.textContent.trim()) return el.textContent.trim();
  var node = document.querySelector('.scContentTreeNode .selected, .scContentTreeNodeActive');
  return node ? node.textContent.trim() : null;
}

function detectCurrentItemPath() {
  var inputs = document.querySelectorAll('input.scEditorHeaderQuickInfoInput');
  return inputs[2] ? inputs[2].value : '';
}

// ─── WYSIWYG AUTOMATION ───────────────────────────────────────────────────────

function findEditHtmlButton() {
  var all = document.querySelectorAll('a, span, div, input, button');
  for (var i = 0; i < all.length; i++) {
    if (/^edit\s+html$/i.test((all[i].textContent || all[i].value || '').trim())) return all[i];
  }
  return document.querySelector('[id*="EditHtml"], [data-sc-id*="EditHtml"], [id*="edithtml" i]') || null;
}

function findAcceptButton(doc) {
  var btns = doc.querySelectorAll('input[type=button], button, a');
  for (var i = 0; i < btns.length; i++) {
    if (/accept/i.test(btns[i].value || btns[i].textContent || btns[i].title || '')) return btns[i];
  }
  return doc.querySelector('input[type=submit], button[type=submit]') || null;
}

function findCancelButton(doc) {
  var btns = doc.querySelectorAll('input[type=button], button, a, span');
  for (var i = 0; i < btns.length; i++) {
    var text = (btns[i].value || btns[i].textContent || btns[i].title || '').trim();
    if (/^cancel$/i.test(text)) return btns[i];
  }
  return null;
}

function findTextareaInFrames() {
  var frames = document.querySelectorAll('iframe');
  for (var i = 0; i < frames.length; i++) {
    try {
      var ta = frames[i].contentDocument &&
               frames[i].contentDocument.getElementById('ctl00_ctl00_ctl05_Html');
      if (ta) return ta;
      var inner = frames[i].contentDocument.querySelectorAll('iframe');
      for (var j = 0; j < inner.length; j++) {
        try {
          var ta2 = inner[j].contentDocument &&
                    inner[j].contentDocument.getElementById('ctl00_ctl00_ctl05_Html');
          if (ta2) return ta2;
        } catch(e) {}
      }
    } catch(e) {}
  }
  return null;
}

// Open the Edit HTML dialog if needed, write updatedHtml, click Accept.
function openHtmlEditorAndUpdate(updatedHtml, cb) {
  var btn = findEditHtmlButton();
  if (!btn) { cb(false, 'Edit HTML button not found'); return; }
  btn.click();
  try { chrome.runtime.sendMessage({ type: 'WYSIWYG_STATUS', status: 'waiting' }); } catch(e) {}
  var attempts = 0;
  var interval = setInterval(function() {
    attempts++;
    var ta = findTextareaInFrames();
    if (ta) {
      clearInterval(interval);
      ta.value = updatedHtml;
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      ta.dispatchEvent(new Event('input',  { bubbles: true }));
      var acceptBtn = findAcceptButton(ta.ownerDocument);
      if (acceptBtn) {
        setTimeout(function() { acceptBtn.click(); cb(true); }, 150);
      } else {
        cb(false, 'Accept button not found');
      }
    } else if (attempts >= WYSIWYG_MAX_ATTEMPTS) {
      clearInterval(interval);
      cb(false, 'timeout');
    }
  }, WYSIWYG_POLL_INTERVAL);
}

// ─── HTML HELPERS ─────────────────────────────────────────────────────────────

function formatTime12h(hhmm) {
  var parts = (hhmm || '00:00').split(':');
  var h = parseInt(parts[0], 10), min = parts[1] || '00';
  var period = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return h + ':' + min + ' ' + period;
}

function parseTo24h(str) {
  str = (str || '').trim();
  var m = str.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
  if (!m) return '00:00';
  var h = parseInt(m[1], 10), min = m[2], period = (m[3] || '').toUpperCase();
  if (period === 'PM' && h !== 12) h += 12;
  if (period === 'AM' && h === 12) h = 0;
  return (h < 10 ? '0' + h : h) + ':' + min;
}

// ─── HTML PARSING ─────────────────────────────────────────────────────────────

function parseWidgetsFromHtml(registry, html) {
  var doc = new DOMParser().parseFromString('<div id="_root">' + html + '</div>', 'text/html');
  var found = [];
  if (!registry || !registry.widgets) return found;
  registry.widgets.forEach(function(def) {
    doc.querySelectorAll('.' + def.class).forEach(function(el, idx) {
      found.push({ widgetClass: def.class, name: def.name, index: idx });
    });
  });
  return found;
}

function getWidgetDataFromHtml(def, html, index) {
  var doc  = new DOMParser().parseFromString('<div id="_root">' + html + '</div>', 'text/html');
  var root = doc.querySelectorAll('.' + def.class)[index];
  if (!root) return null;
  var data = {};

  (def.standaloneFields || []).forEach(function(f) {
    var el = root.querySelector(f.selector);
    data[f.key] = el ? (f.attr ? el.getAttribute(f.attr) : el.textContent.trim()) : '';
  });

  if (def.repeat) {
    data.items = [];
    root.querySelectorAll(def.repeat.selector).forEach(function(item, i) {
      var row = {};
      def.fields.forEach(function(f) {
        if (f.type === 'datetime-local') {
          // Synthesise from data-end attr + time display text
          var dateVal = item.getAttribute(def.repeat.dateAttr || 'data-end') || '';
          var timeEl  = item.querySelector('.zmw-time');
          var t24     = parseTo24h(timeEl ? timeEl.textContent.trim() : '');
          row[f.key]  = dateVal ? (dateVal + 'T' + t24) : '';
        } else if (f.attr && !f.selector) {
          row[f.key] = item.getAttribute(f.attr) || '';
        } else if (f.selector) {
          var el = item.querySelector(f.selector);
          row[f.key] = el ? (f.attr ? el.getAttribute(f.attr) : el.textContent.trim()) : '';
        }
      });
      data.items.push(row);
    });
  }
  return data;
}

function buildUpdatedHtml(def, index, data, html) {
  console.log('[ZMW-DBG] buildUpdatedHtml START', { def_class: def.class, index: index, dataItems: data.items ? data.items.length : 0, htmlLength: html.length });
  console.log('[ZMW-DBG] data:', JSON.stringify(data, null, 2));
  var doc  = new DOMParser().parseFromString('<div id="_root">' + html + '</div>', 'text/html');
  var root = doc.querySelectorAll('.' + def.class)[index];
  console.log('[ZMW-DBG] root found?', !!root, 'matches found:', doc.querySelectorAll('.' + def.class).length);
  if (!root) return null;

  (def.standaloneFields || []).forEach(function(f) {
    if (data[f.key] === undefined) return;
    var el = root.querySelector(f.selector);
    if (!el) return;
    f.attr ? el.setAttribute(f.attr, data[f.key]) : (el.textContent = data[f.key]);
  });

  if (def.repeat && data.items) {
    var existingItems   = Array.from(root.querySelectorAll(def.repeat.selector));
    var newItemTemplate = def.repeat.newItemTemplate || null;
    var dateAttr        = def.repeat.dateAttr || null;
    var repeatContainer = root.querySelector('.zmw-meeting-list') || root;

    // Separate past items (keep) from too-old items (drop) from future items
    var today = new Date(); today.setHours(0, 0, 0, 0);
    var pastItems   = [];
    var futureItems = {}; // keyed by original index

    /* Cutoff for dropping old past items. Default = 90 (automatic backstop).
       Caller can pass a tighter cutoff (e.g. 60) for the manual purge button. */
    var pastCutoffDays = (typeof data.__pastCutoffDays === 'number') ? data.__pastCutoffDays : 90;
    var cutoffDate = new Date(today);
    cutoffDate.setDate(cutoffDate.getDate() - pastCutoffDays);
    console.log('[ZMW-DBG] past-item cutoff:', pastCutoffDays, 'days; will drop items dated before', cutoffDate.toISOString().split('T')[0]);

    var droppedCount = 0;
    existingItems.forEach(function(el, i) {
      if (!dateAttr) { futureItems[i] = el; return; }
      var d = new Date((el.getAttribute(dateAttr) || '').split('T')[0]);
      if (isNaN(d)) { futureItems[i] = el; return; }
      if (d < cutoffDate) { droppedCount++; return; }   // drop — too old
      if (d < today)      { pastItems.push(el); return; } // past but within cutoff — keep
      futureItems[i] = el;                                // future — managed by form
    });
    console.log('[ZMW-DBG] existingItems:', existingItems.length, 'past kept:', pastItems.length, 'past dropped:', droppedCount, 'future:', Object.keys(futureItems).length);

    // Detach all — we re-insert in controlled order
    existingItems.forEach(function(el) { el.parentNode && el.parentNode.removeChild(el); });

    // Fields rendered with innerHTML (preserves markup in detail bodies)
    var htmlFields = {};
    (def.fields || []).forEach(function(f) {
      if (f.type === 'textarea' || f.type === 'richtext') htmlFields[f.key] = true;
    });

    // 1. Past items first, untouched
    pastItems.forEach(function(el) { repeatContainer.appendChild(el); });

    // 2. Future items from form data — sort chronologically before inserting
    var dtKey = '';
    (def.fields || []).forEach(function(f) { if (f.type === 'datetime-local') dtKey = f.key; });

    var sortedItems = data.items.slice().sort(function(a, b) {
      var da = a.__originalIndex >= 0 && futureItems[a.__originalIndex]
        ? (futureItems[a.__originalIndex].getAttribute(dateAttr) || '')
        : (dtKey && a[dtKey] ? a[dtKey].split('T')[0] : '9999-12-31');
      var db = b.__originalIndex >= 0 && futureItems[b.__originalIndex]
        ? (futureItems[b.__originalIndex].getAttribute(dateAttr) || '')
        : (dtKey && b[dtKey] ? b[dtKey].split('T')[0] : '9999-12-31');
      return da < db ? -1 : da > db ? 1 : 0;
    });

    sortedItems.forEach(function(row) {
      var origIdx = row.__originalIndex !== undefined ? row.__originalIndex : -1;
      var item;
      console.log('[ZMW-DBG] processing row origIdx=', origIdx, 'datetime=', row.datetime, 'title=', row.title);

      if (origIdx >= 0 && futureItems[origIdx]) {
        item = futureItems[origIdx];
        console.log('[ZMW-DBG]   matched existing item at index', origIdx);
      } else {
        // New item — stamp from template
        if (!newItemTemplate) { console.log('[ZMW-DBG]   no template, skipping'); return; }
        console.log('[ZMW-DBG]   stamping NEW item from template');
        var tpl = newItemTemplate;
        Object.keys(row).forEach(function(k) {
          if (k !== '__originalIndex') tpl = tpl.split('{' + k + '}').join(row[k] || '');
        });
        tpl = tpl.replace(/\{[^}]+\}/g, '');
        var tmp = doc.createElement('div');
        tmp.innerHTML = tpl;
        item = tmp.firstElementChild;
      }

      if (!item) return;

      // datetime-local field drives data-end + date slab display fields
      var dtField = (def.fields || []).find(function(f) { return f.type === 'datetime-local'; });
      if (dtField && row[dtField.key]) {
        var parts    = row[dtField.key].split('T');
        var datePart = parts[0];
        var timePart = parts[1] || '00:00';
        var dObj     = new Date(datePart + 'T00:00:00');
        var MONTHS   = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        item.setAttribute('data-end', datePart);
        var mEl = item.querySelector('.zmw-month'); if (mEl) mEl.textContent = MONTHS[dObj.getMonth()];
        var dEl = item.querySelector('.zmw-day');   if (dEl) dEl.textContent = String(dObj.getDate()).padStart(2, '0');
        var tEl = item.querySelector('.zmw-time');  if (tEl) tEl.textContent = formatTime12h(timePart);
      }

      def.fields.forEach(function(f) {
        if (f.type === 'datetime-local') return; // handled above
        if (row[f.key] === undefined || row[f.key] === null) return;
        var v = row[f.key];
        if (f.attr && !f.selector) {
          item.setAttribute(f.attr, v);
        } else if (f.selector) {
          var el = item.querySelector(f.selector);
          if (el) htmlFields[f.key] ? (el.innerHTML = v) : (el.textContent = v);
        }
      });

      repeatContainer.appendChild(item);
    });
  }

  var finalHtml = doc.getElementById('_root').innerHTML;
  console.log('[ZMW-DBG] buildUpdatedHtml DONE, output length:', finalHtml.length, 'diff vs input:', finalHtml.length - html.length);
  console.log('[ZMW-DBG] input HTML first 300 chars:', html.substring(0, 300));
  console.log('[ZMW-DBG] output HTML first 300 chars:', finalHtml.substring(0, 300));
  return finalHtml;
}

// ─── CONTENT ITEM TRACKING (dashboard recents) ────────────────────────────────

var _lastItemId = null;

function broadcastItemChanged(id) {
  try {
    chrome.runtime.sendMessage({
      type: 'CONTENT_ITEM_CHANGED',
      itemId: id,
      itemName: detectCurrentItemName() || id,
      itemPath: detectCurrentItemPath()
    });
  } catch(e) {}
}

if (isContentEditorTop()) {
  var _ciEl = document.querySelector('input.scEditorHeaderQuickInfoInput');
  if (_ciEl) {
    new MutationObserver(function() {
      var id = detectCurrentItemId();
      if (id && id !== _lastItemId) { _lastItemId = id; broadcastItemChanged(id); }
    }).observe(_ciEl, { attributes: true, attributeFilter: ['value'] });
  }
  setInterval(function() {
    var id = detectCurrentItemId();
    if (id && id !== _lastItemId) { _lastItemId = id; broadcastItemChanged(id); }
  }, 1500);
}

// ─── MESSAGE HANDLER ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {

  // ── GET_SC_USERNAME ──────────────────────────────────────────────────────────
  if (msg.type === 'GET_SC_USERNAME') {
    var links = document.querySelectorAll('a');
    var name  = null;
    for (var i = 0; i < links.length; i++) {
      if (/log.?out/i.test(links[i].textContent || '')) {
        var prev = links[i].previousElementSibling;
        if (prev && prev.tagName === 'A') { name = prev.textContent.trim(); break; }
      }
    }
    sendResponse({ username: name });
    return true;
  }

  // ── GET_LOCKED_ITEMS (dashboard) ─────────────────────────────────────────────
  if (msg.type === 'GET_LOCKED_ITEMS') {
    fetchLockedItemsForUser(function(err, items) {
      sendResponse({ items: items, error: err ? err.message : null });
    });
    return true;
  }

  // ── GET_SC_ITEM_NAME (dashboard recents) ─────────────────────────────────────
  if (msg.type === 'GET_SC_ITEM_NAME') {
    var itemId = detectCurrentItemId();
    sendResponse({
      itemId:   itemId,
      itemName: detectCurrentItemName() || itemId,
      itemPath: detectCurrentItemPath()
    });
    return true;
  }

  // ── Content Editor top-frame only beyond here ─────────────────────────────────
  if (!isContentEditorTop()) return;

  // ── GET_WIDGETS — scan all Rich Text fields via SSC API for registered widgets ─
  if (msg.type === 'GET_WIDGETS') {
    var currentItemId = detectCurrentItemId();
    if (!currentItemId) { sendResponse({ widgets: [], mode: 'content-editor' }); return true; }
    fetch('https://' + window.location.host +
          '/sitecore/api/ssc/aggregate/content/Items(' +
          encodeURIComponent("'" + currentItemId + "'") +
          ')/Fields?sc_apikey=' + encodeURIComponent(SSC_API_KEY),
          { credentials: 'include' })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        var found = [];
        (d.value || []).forEach(function(field) {
          if (!field.Value || field.Type !== 'Rich Text') return;
          parseWidgetsFromHtml(msg.registry, field.Value).forEach(function(w) {
            found.push(w);
          });
        });
        sendResponse({ widgets: found, mode: 'content-editor' });
      })
      .catch(function() { sendResponse({ widgets: [], mode: 'content-editor' }); });
    return true;
  }

  // ── GET_WIDGET_DATA — read from SSC API, no dialog opens ─────────────────────
  if (msg.type === 'GET_WIDGET_DATA') {
    if (!isCurrentInstance()) return;
    /* If the textarea is open because the user manually clicked Edit HTML,
       prefer reading from there so we get any in-flight edits. */
    var ta = findTextareaInFrames();
    if (ta && ta.value) {
      console.log('[ZMW-DBG] GET: textarea already open (user-initiated), reading from it');
      sendResponse({ data: getWidgetDataFromHtml(msg.def, ta.value, msg.index || 0) });
      return true;
    }
    console.log('[ZMW-DBG] GET: using SSC API (no dialog)');
    var currentItemId = detectCurrentItemId();
    if (!currentItemId) { sendResponse({ data: null }); return true; }
    fetch('https://' + window.location.host +
          '/sitecore/api/ssc/aggregate/content/Items(' +
          encodeURIComponent("'" + currentItemId + "'") +
          ')/Fields?sc_apikey=' + encodeURIComponent(SSC_API_KEY),
          { credentials: 'include' })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        var cls = msg.def.class;
        var fieldHtml = null;
        (d.value || []).forEach(function(field) {
          if (!field.Value || field.Type !== 'Rich Text') return;
          if (field.Value.indexOf(cls) !== -1) { fieldHtml = field.Value; }
        });
        if (!fieldHtml) { sendResponse({ data: null }); return; }
        sendResponse({ data: getWidgetDataFromHtml(msg.def, fieldHtml, msg.index || 0) });
      })
      .catch(function(e) { console.log('[ZMW-DBG] GET: API error', e); sendResponse({ data: null }); });
    return true;
  }

  // ── UPDATE_WIDGET_DATA — clean fresh-open write, same as working widgets ─────
  if (msg.type === 'UPDATE_WIDGET_DATA') {
    if (!isCurrentInstance()) { console.log('[ZMW-DBG] UPDATE: ignoring (stale instance)'); return; }
    if (ZMW_UPDATE_IN_PROGRESS) {
      console.log('[ZMW-DBG] UPDATE: ignoring duplicate — one already in progress');
      sendResponse({ success: false, error: 'duplicate' });
      return true;
    }
    ZMW_UPDATE_IN_PROGRESS = true;
    function clearUpdateLock() { ZMW_UPDATE_IN_PROGRESS = false; }

    var btn = findEditHtmlButton();
    if (!btn) { clearUpdateLock(); sendResponse({ success: false, error: 'Edit HTML button not found' }); return true; }
    console.log('[ZMW-DBG] UPDATE: clicking Edit HTML');
    btn.click();
    var readAttempts = 0;
    var readInterval = setInterval(function() {
      readAttempts++;
      var ta2 = findTextareaInFrames();
      if (ta2 && ta2.value) {
        clearInterval(readInterval);
        console.log('[ZMW-DBG] UPDATE: textarea ready, length:', ta2.value.length);
        var updated2 = buildUpdatedHtml(msg.def, msg.index || 0, msg.data, ta2.value);
        if (!updated2) { clearUpdateLock(); sendResponse({ success: false, error: 'HTML rebuild failed' }); return; }
        ta2.value = updated2;
        ta2.dispatchEvent(new Event('change', { bubbles: true }));
        ta2.dispatchEvent(new Event('input',  { bubbles: true }));
        console.log('[ZMW-DBG] UPDATE: wrote', updated2.length, 'chars, matches?', ta2.value === updated2);
        var acceptBtn2 = findAcceptButton(ta2.ownerDocument);
        if (acceptBtn2) {
          setTimeout(function() {
            console.log('[ZMW-DBG] UPDATE: clicking Accept, ta.value still matches?', ta2.value === updated2);
            acceptBtn2.click();
            console.log('[ZMW-DBG] UPDATE: success');
            clearUpdateLock();
            sendResponse({ success: true });
          }, 150);
        } else {
          clearUpdateLock();
          sendResponse({ success: false, error: 'Accept button not found' });
        }
      } else if (readAttempts >= WYSIWYG_MAX_ATTEMPTS) {
        clearInterval(readInterval);
        clearUpdateLock();
        sendResponse({ success: false, error: 'timeout' });
      }
    }, WYSIWYG_POLL_INTERVAL);
    return true;
  }

});
