// sitecore-bridge.js — runs in page world, listens for events from content-script
window.SitecoreBridge = {
  notifyChange: function(element) {
    if (!element) return;
    ['input', 'change', 'blur'].forEach(function(evtType) {
      try { element.dispatchEvent(new Event(evtType, { bubbles: true, cancelable: true })); } catch(e) {}
    });
    try {
      var el = element;
      while (el && el !== document.body) {
        if (el.contentEditable === 'true') {
          el.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
          break;
        }
        el = el.parentElement;
      }
    } catch(e) {}
    try {
      if (window.Sitecore && window.Sitecore.PageModes && window.Sitecore.PageModes.PageEditor) {
        window.Sitecore.PageModes.PageEditor.setModified(true);
      }
    } catch(e) {}
    try {
      if (window.Sitecore && window.Sitecore.PageModes && window.Sitecore.PageModes.ChromeManager) {
        window.Sitecore.PageModes.ChromeManager.resetChromes();
      }
    } catch(e) {}
  }
};

// Listen for navigate events — invoke scForm.item:load in page context
document.addEventListener('__sitecoreBridgeNavigate', function(e) {
  try {
    var itemId = e.detail && e.detail.itemId;
    if (!itemId) return;
    if (window.scForm) {
      window.scForm.invoke('item:load(id=' + itemId + ')');
    }
  } catch(err) {}
});

