// background.js - Sitecore Widget Editor v4.2.0
const REGISTRY_URL = 'https://www.tylervinson.com/widget/widget-registry.json';
const DOWNLOAD_URL = 'https://www.tylervinson.com/widget/';

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);

async function checkForUpdates() {
  try {
    const res  = await fetch(REGISTRY_URL + '?cb=' + Date.now());
    if (!res.ok) return;
    const data = await res.json();
    await chrome.storage.local.set({ widgetRegistry: data });
    const remoteVersion = data.version || null;
    // Compare against the last seen registry version, not the extension build version
    chrome.storage.local.get('lastSeenRegistryVersion', function(stored) {
      const lastSeen = stored.lastSeenRegistryVersion || null;
      if (remoteVersion && lastSeen && remoteVersion !== lastSeen) {
        chrome.runtime.sendMessage({
          type: 'UPDATE_AVAILABLE',
          remoteVersion: remoteVersion,
          downloadUrl: DOWNLOAD_URL
        }).catch(() => {});
        chrome.action.setBadgeText({ text: '!' });
        chrome.action.setBadgeBackgroundColor({ color: '#FFBE5F' });
      } else {
        chrome.action.setBadgeText({ text: '' });
      }
    });
  } catch(e) {}
}

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const url  = chrome.runtime.getURL('widget-registry.json');
    const res  = await fetch(url);
    const data = await res.json();
    await chrome.storage.local.set({ widgetRegistry: data });
  } catch(e) {}
  checkForUpdates();
});

chrome.runtime.onStartup.addListener(checkForUpdates);
setInterval(checkForUpdates, 4 * 60 * 60 * 1000);

function getActiveTab(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    cb(tabs && tabs[0] ? tabs[0] : null);
  });
}

// GET_WIDGETS — relays to content script which reads from WYSIWYG textarea
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type !== 'GET_WIDGETS_ALL_FRAMES') return;
  getActiveTab(function(tab) {
    if (!tab) { sendResponse({ widgets: [], mode: 'unknown' }); return; }
    chrome.tabs.sendMessage(tab.id, { type: 'GET_WIDGETS', registry: msg.registry }, { frameId: 0 }, function(res) {
      if (!chrome.runtime.lastError && res) {
        sendResponse(res);
      } else {
        sendResponse({ widgets: [], mode: 'content-editor' });
      }
    });
  });
  return true;
});

// FRAME_MSG — all content editor messages go directly to top frame (frame 0)
// Top frame handles everything via SSC API — no frame scanning needed
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type !== 'FRAME_MSG') return;
  getActiveTab(function(tab) {
    if (!tab) { sendResponse(null); return; }
    chrome.tabs.sendMessage(tab.id, msg.msg, { frameId: 0 }, function(res) {
      if (!chrome.runtime.lastError && res !== undefined && res !== null) {
        sendResponse(res);
      } else {
        // Frame 0 failed — try sending to active tab without frameId (EE fallback)
        chrome.tabs.sendMessage(tab.id, msg.msg, function(r) {
          if (!chrome.runtime.lastError && r !== undefined) {
            sendResponse(r);
          } else {
            sendResponse(null);
          }
        });
      }
    });
  });
  return true;
});

// Forward CONTENT_ITEM_CHANGED from content script to sidepanel
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'CONTENT_ITEM_CHANGED') {
    chrome.runtime.sendMessage(msg).catch(function() {});
  }
});
