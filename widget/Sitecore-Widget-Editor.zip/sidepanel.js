// sidepanel.js - Sitecore Widget Editor v1.3.0
var REGISTRY_URL='https://www.tylervinson.com/widget/widget-registry.json';
var _registry=null,currentTab=null,foundWidgets=[],activeWidget=null;

function fetchRegistry(cb){fetch(REGISTRY_URL+'?cb='+Date.now()).then(function(r){return r.json();}).then(function(d){_registry=d;cb(null);}).catch(function(e){cb(e);});}

function getWidgetDef(cls){if(!_registry||!_registry.widgets)return null;for(var i=0;i<_registry.widgets.length;i++){if(_registry.widgets[i].class===cls)return _registry.widgets[i];}return null;}

document.addEventListener('DOMContentLoaded',function(){document.getElementById('widgetSelect').addEventListener('change',function(){loadWidget(foundWidgets[parseInt(this.value,10)]);});chrome.tabs.query({active:true,currentWindow:true},function(tabs){if(!tabs[0])return;currentTab=tabs[0];try{var u=new URL(tabs[0].url);document.getElementById('pageUrl').textContent=u.hostname+u.pathname.slice(0,50);}catch(e){}setStateMsg('Loading registry...');fetchRegistry(function(err){if(err||!_registry){setStateMsg('Could not load widget registry.');return;}scanPage();});});});
function scanPage(){chrome.tabs.sendMessage(currentTab.id,{type:'GET_WIDGETS',registry:_registry},function(res){if(chrome.runtime.lastError){setStateMsg('No editable widgets found on this page.');return;}handleWidgets(res?res.widgets:[]);});}

function handleWidgets(widgets){foundWidgets=widgets||[];if(foundWidgets.length===0){document.getElementById('picker').style.display='none';setStateMsg('No registered widgets found on this page.');setStatus('No widgets detected');return;}if(foundWidgets.length===1){document.getElementById('picker').style.display='none';}else{var select=document.getElementById('widgetSelect');select.innerHTML='';foundWidgets.forEach(function(w,i){var dupes=foundWidgets.filter(function(x){return x.widgetClass===w.widgetClass;}).length>1;var opt=document.createElement('option');opt.value=i;opt.textContent=dupes?(w.name+' #'+(w.index+1)):w.name;select.appendChild(opt);});document.getElementById('picker').style.display='block';}loadWidget(foundWidgets[0]);}

function loadWidget(widgetDef){activeWidget=widgetDef;var def=getWidgetDef(widgetDef.widgetClass);if(!def){setStateMsg('Widget definition not found in registry.');return;}setStateMsg('Loading...');chrome.tabs.sendMessage(currentTab.id,{type:'GET_WIDGET_DATA',def:def,index:widgetDef.index},function(res){if(chrome.runtime.lastError||!res||!res.data){setStateMsg('Could not read widget data.');return;}renderForm(def,res.data);setStatus('Editing: '+widgetDef.name);});}

function renderForm(def, data) {
  var c = document.getElementById('content');
  c.innerHTML = '';
  if (def.standaloneFields && def.standaloneFields.length > 0) {
    var h = document.createElement('div'); h.className = 'section-header'; h.textContent = 'General'; c.appendChild(h);
    def.standaloneFields.forEach(function(field) { c.appendChild(makeField(field.label, 'sa_' + field.key, data[field.key] || '', field.type)); });
  }
  if (def.repeat && data.items) {
    var sh = document.createElement('div'); sh.className = 'section-header'; sh.textContent = def.repeat.groupLabel + 's'; c.appendChild(sh);
    data.items.forEach(function(item, i) {
      var glf = def.repeat.groupLabelField;
      var title = (glf && item[glf]) ? (def.repeat.groupLabel + ' ' + (i+1) + ' — ' + item[glf]) : (def.repeat.groupLabel + ' ' + (i+1));
      var grp = document.createElement('div'); grp.className = 'card-group';
      var gh = document.createElement('div'); gh.className = 'card-group-header'; gh.textContent = title; gh.id = 'ghdr_' + i; grp.appendChild(gh);
      var body = document.createElement('div'); body.className = 'card-group-body';
      var btnF  = def.fields.filter(function(f) { return  f.selector; });
      var gridF = def.fields.filter(function(f) { return !f.selector && f.gridSelector; });
      btnF.forEach(function(f) {
        var fe = makeField(f.label, 'it_' + i + '_' + f.key, item[f.key] || '', f.type || 'text');
        if (glf && f.key === glf) {
          fe.querySelector('input,textarea').addEventListener('input', (function(idx) { return function(e) {
            var el = document.getElementById('ghdr_' + idx);
            if (el) el.textContent = e.target.value ? (def.repeat.groupLabel + ' ' + (idx+1) + ' — ' + e.target.value) : (def.repeat.groupLabel + ' ' + (idx+1));
          }; })(i));
        }
        body.appendChild(fe);
      });
      if (gridF.length > 0) {
        var sub = document.createElement('div'); sub.className = 'sub-header'; sub.textContent = 'Comparison Table'; body.appendChild(sub);
        gridF.forEach(function(f) { body.appendChild(makeField(f.label, 'it_' + i + '_' + f.key, item[f.key] || '', f.type || 'text')); });
      }
      grp.appendChild(body); c.appendChild(grp);
    });
  }
  var btn = document.createElement('button'); btn.id = 'applyBtn'; btn.textContent = 'Apply Changes'; btn.addEventListener('click', applyChanges); c.appendChild(btn);
}

function applyChanges() {
  if (!activeWidget) return;
  var def = getWidgetDef(activeWidget.widgetClass);
  if (!def) return;
  setStatus('Applying...');
  var data = collectFormData(def);
  chrome.tabs.sendMessage(currentTab.id, { type: 'UPDATE_WIDGET_DATA', def: def, index: activeWidget.index, data: data }, function(res) {
    if (chrome.runtime.lastError || !res || !res.success) { setStatus('Error applying changes', 'err'); return; }
    setStatus('Changes applied \u2713', 'ok');
    setTimeout(function() { setStatus('Editing: ' + activeWidget.name); }, 2500);
  });
}

function collectFormData(def) {
  var data = {};
  (def.standaloneFields || []).forEach(function(f) { data[f.key] = val('sa_' + f.key); });
  if (def.repeat) {
    data.items = [];
    var i = 0;
    while (document.getElementById('ghdr_' + i) !== null) {
      var row = {};
      def.fields.forEach(function(f) { row[f.key] = val('it_' + i + '_' + f.key); });
      data.items.push(row);
      i++;
    }
  }
  return data;
}

function makeField(label, id, value, type) {
  var row = document.createElement('div'); row.className = 'field-row';
  var lbl = document.createElement('label'); lbl.setAttribute('for', id); lbl.textContent = label; row.appendChild(lbl);
  var inp = (type === 'textarea') ? document.createElement('textarea') : document.createElement('input');
  if (inp.tagName === 'INPUT') inp.type = 'text';
  inp.id = id; inp.value = value || ''; row.appendChild(inp);
  return row;
}

function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function setStateMsg(msg) { document.getElementById('content').innerHTML = '<div class="state-msg">' + msg + '</div>'; }
function setStatus(msg, cls) { var el = document.getElementById('status'); el.textContent = msg; el.className = cls || ''; }

chrome.runtime.onMessage.addListener(function(message) {
  if (message.type === 'UPDATE_AVAILABLE') {
    var b = document.getElementById('updateBanner');
    b.style.display = 'block';
    b.innerHTML = '&#9888; New version available (v' + message.remoteVersion + '). <a href="' + message.downloadUrl + '" target="_blank">Download update &rarr;</a>';
  }
  if (message.type === 'DOM_CHANGED' && currentTab) { scanPage(); }
});
