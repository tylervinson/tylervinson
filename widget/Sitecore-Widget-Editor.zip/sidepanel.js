// =============================================================================
// Sidepanel — Widget Editor Extension
// Dynamically generates editor UI for discovered widgets
// =============================================================================

console.log('[Widget Editor] Sidepanel loaded');

document.addEventListener('DOMContentLoaded', () => {
  loadAvailableWidgets();
});

// ---------------------------------------------------------------------------
// Load and display available widgets
// ---------------------------------------------------------------------------
async function loadAvailableWidgets() {
  document.getElementById('loading').style.display = 'block';
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  chrome.tabs.sendMessage(tab.id, { action: 'detectWidgets' }, (response) => {
    document.getElementById('loading').style.display = 'none';
    
    if (chrome.runtime.lastError || !response || !response.widgets) {
      showError('No editable widgets found on this page. Add class="editable-widget" to your widgets.');
      return;
    }
    
    displayWidgetList(response.widgets);
  });
}

function displayWidgetList(widgets) {
  const container = document.getElementById('widgetList');
  container.innerHTML = '';
  
  widgets.forEach(widget => {
    const card = document.createElement('div');
    card.className = 'widget-card';
    card.innerHTML = `
      <div class="widget-card-header">
        <div class="widget-card-title">${widget.name}</div>
        <div class="widget-card-class">${widget.className}</div>
      </div>
      ${widget.description ? `<div class="widget-card-description">${widget.description}</div>` : ''}
    `;
    card.addEventListener('click', () => loadWidgetEditor(widget.className));
    container.appendChild(card);
  });
  
  document.getElementById('widgetListSection').style.display = 'block';
  console.log(`[Widget Editor] Displaying ${widgets.length} widgets`);
}

// ---------------------------------------------------------------------------
// Load widget data and generate editor
// ---------------------------------------------------------------------------
async function loadWidgetEditor(widgetClass) {
  document.getElementById('loading').style.display = 'block';
  document.getElementById('widgetListSection').style.display = 'none';
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  chrome.tabs.sendMessage(tab.id, {
    action: 'getWidgetData',
    widgetClass: widgetClass
  }, (response) => {
    document.getElementById('loading').style.display = 'none';
    
    if (chrome.runtime.lastError || !response || !response.data) {
      showError('Could not read widget data from the page.');
      return;
    }
    
    renderEditor(widgetClass, response.data);
  });
}

// ---------------------------------------------------------------------------
// Render editor form
// ---------------------------------------------------------------------------
function renderEditor(widgetClass, data) {
  const container = document.getElementById('editorContainer');
  
  console.log(`[Widget Editor] Rendering editor for: ${widgetClass}`, data);
  
  let html = `
    <div class="editor-header">
      <button class="back-btn" id="backToList">← Back</button>
      <div class="editor-title">${widgetClass.replace(/-/g, ' ')}</div>
    </div>
  `;
  
  if (data.objects) {
    // Multi-object widget
    html += renderMultiObjectForm(data.objects);
  } else {
    // Single object widget
    html += renderSingleObjectForm(data);
  }
  
  html += `
    <div class="button-group">
      <button class="btn-secondary" id="resetBtn">Reset</button>
      <button class="btn-primary" id="saveBtn">Apply Changes</button>
    </div>
  `;
  
  container.innerHTML = html;
  container.style.display = 'block';
  
  // Store original data
  window.currentWidgetClass = widgetClass;
  window.currentWidgetData = data;
  
  // Attach event listeners
  document.getElementById('backToList').addEventListener('click', showWidgetList);
  document.getElementById('resetBtn').addEventListener('click', () => loadWidgetEditor(widgetClass));
  document.getElementById('saveBtn').addEventListener('click', () => saveWidgetData(widgetClass));
}

function renderMultiObjectForm(objects) {
  let html = '';
  
  objects.forEach((obj, index) => {
    html += `
      <div class="section-card">
        <div class="section-title">Item ${index + 1}</div>
        ${renderFieldsForObject(obj, index)}
      </div>
    `;
  });
  
  return html;
}

function renderSingleObjectForm(data) {
  return `
    <div class="section-card">
      ${renderFieldsForObject(data, 0)}
    </div>
  `;
}

function renderFieldsForObject(obj, objIndex) {
  let html = '';
  let lineCounter = 0;
  let linkCounter = 0;
  let imgCounter = 0;
  
  // Group fields by type
  const fields = Object.keys(obj).filter(k => k !== 'id');
  
  fields.forEach(key => {
    // Skip text/alt fields - they're handled with url fields
    if (key.endsWith('_text') || key.endsWith('_alt')) return;
    
    if (key.endsWith('_url')) {
      // Link or Image field
      const baseKey = key.replace('_url', '');
      const textKey = baseKey + '_text';
      const altKey = baseKey + '_alt';
      
      if (fields.includes(textKey)) {
        // Link field
        linkCounter++;
        html += `
          <div class="form-group">
            <label>Link ${linkCounter} URL</label>
            <input type="text" id="${objIndex}_${key}" value="${obj[key] || ''}" placeholder="URL">
          </div>
          <div class="form-group">
            <label>Link ${linkCounter} Text</label>
            <input type="text" id="${objIndex}_${textKey}" value="${obj[textKey] || ''}" placeholder="Type here">
          </div>
        `;
      } else if (fields.includes(altKey)) {
        // Image field
        imgCounter++;
        html += `
          <div class="form-group">
            <label>Image ${imgCounter} URL</label>
            <input type="text" id="${objIndex}_${key}" value="${obj[key] || ''}" placeholder="Image URL">
          </div>
          <div class="form-group">
            <label>Image ${imgCounter} Alt Text</label>
            <input type="text" id="${objIndex}_${altKey}" value="${obj[altKey] || ''}" placeholder="Type here">
          </div>
        `;
      }
    } else {
      // Regular text field
      lineCounter++;
      const value = obj[key] || '';
      const isLong = value.length > 100;
      
      html += `
        <div class="form-group">
          <label>Line ${lineCounter}</label>
          ${isLong ? 
            `<textarea id="${objIndex}_${key}" rows="3">${value}</textarea>` :
            `<input type="text" id="${objIndex}_${key}" value="${value}" placeholder="Type here">`
          }
        </div>
      `;
    }
  });
  
  return html;
}

// ---------------------------------------------------------------------------
// Save widget data
// ---------------------------------------------------------------------------
async function saveWidgetData(widgetClass) {
  const data = reconstructDataFromForm();
  
  console.log(`[Widget Editor] Saving data:`, data);
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  chrome.tabs.sendMessage(tab.id, {
    action: 'updateWidgetData',
    widgetClass: widgetClass,
    data: data
  }, (response) => {
    if (response && response.success) {
      showSuccess('Changes applied successfully!');
    } else {
      showError('Failed to apply changes. Please try again.');
    }
  });
}

function reconstructDataFromForm() {
  const originalData = window.currentWidgetData;
  
  if (originalData.objects) {
    // Multi-object widget
    const objects = originalData.objects.map((obj, index) => {
      const newObj = { id: obj.id };
      
      Object.keys(obj).forEach(key => {
        if (key === 'id') return;
        
        const inputId = `${index}_${key}`;
        const input = document.getElementById(inputId);
        
        if (input) {
          newObj[key] = input.value;
        }
      });
      
      return newObj;
    });
    
    return { objects };
  } else {
    // Single object widget
    const newData = {};
    
    Object.keys(originalData).forEach(key => {
      const inputId = `0_${key}`;
      const input = document.getElementById(inputId);
      
      if (input) {
        newData[key] = input.value;
      }
    });
    
    return newData;
  }
}

// ---------------------------------------------------------------------------
// UI Helpers
// ---------------------------------------------------------------------------
function showWidgetList() {
  document.getElementById('editorContainer').style.display = 'none';
  document.getElementById('messageArea').innerHTML = '';
  loadAvailableWidgets();
}

function showSuccess(message) {
  const messageArea = document.getElementById('messageArea');
  messageArea.innerHTML = `<div class="success-message">${message}</div>`;
  setTimeout(() => { messageArea.innerHTML = ''; }, 5000);
}

function showError(message) {
  const messageArea = document.getElementById('messageArea');
  messageArea.innerHTML = `<div class="error-message">${message}</div>`;
  document.getElementById('loading').style.display = 'none';
}
